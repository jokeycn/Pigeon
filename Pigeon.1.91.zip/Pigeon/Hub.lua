--[[
    Pigeon - Whisper hub
    The full view: every conversation (including ones closed from the dock),
    searchable, with pinning, group invite and "pop out" back to the docked
    window. Opened from the dock's stack button, the window's "all" button,
    /pigeon or its key binding. Drag the header to move it.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local W, H_ = 760, 460
local MIN_H = 340 -- the shortest the hub can be dragged
local LIST_W = 280 -- current list column width (drag the divider to change)
local LIST_MIN, LIST_MAX = 280, 480
local ROW_H, HEADER_H, NEW_H = 64, 26, 36

local Hub = CreateFrame("Frame", "PigeonHub", UIParent)
ns.Hub = Hub
Hub:SetSize(W, H_)
Hub:SetFrameStrata("DIALOG")
Hub:SetToplevel(true) -- clicking it (or opening it) brings it above the other windows
Hub:SetMovable(true)
Hub:SetClampedToScreen(true)
Hub:EnableMouse(true)
Hub:Hide()
Hub.rows = {}
Hub.scrollY, Hub.scrollTarget, Hub.contentH = 0, 0, 0
Hub.selected = {} -- select mode: [convo] = true
local BAR_H = 40 -- select mode's bottom action bar

---------------------------------------------------------------------------
-- List entries
---------------------------------------------------------------------------

local function SortBySeq(a, b) return (a.seq or 0) > (b.seq or 0) end

-- Friends view: everyone on the character and Battle.net friends lists who has
-- no conversation yet (conversations with friends are listed as usual).
local function Clean(v)
    if v == nil or not ns.Readable(v) then return nil end
    return v
end

local function FriendSub(online, level, area)
    if not online then return L["Offline"] end
    local bits = {}
    if type(level) == "number" and level > 0 then bits[#bits + 1] = L["Level %d"]:format(level) end
    if type(area) == "string" and area ~= "" then bits[#bits + 1] = area end
    if #bits == 0 then return L["Online"] end
    return table.concat(bits, "  ·  ")
end

local function HasConvo(key, current)
    local c = ns.convos[key]
    return c and (#c.messages > 0 or c == current)
end

-- The WoW character a Battle.net friend is playing right now, if we can
-- whisper it as a character from this client: returns the whisper name
-- ("Name" on our realm, "Name-Realm" otherwise) and the game account info.
local function UsableGame(g, realm, faction)
    if type(g) ~= "table" or not Clean(g.isOnline) or not g.isOnline then return nil end
    local prog = Clean(g.clientProgram)
    if prog ~= (BNET_CLIENT_WOW or "WoW") then return nil end
    local char = Clean(g.characterName)
    if type(char) ~= "string" or char == "" then return nil end
    local proj, mine = Clean(g.wowProjectID), WOW_PROJECT_ID
    if type(proj) == "number" and mine and proj ~= mine then return nil end
    if mine ~= WOW_PROJECT_MAINLINE then
        local f = Clean(g.factionName)
        if type(f) == "string" and f ~= "" and faction and f ~= faction then return nil end
    end
    local target = char
    local r = Clean(g.realmName)
    if type(r) == "string" then
        r = r:gsub("%s", "")
        if r ~= "" and r ~= realm then
            -- Forever's server rules don't accept "Name-Realm" whispers: a friend on
            -- another realm can only be reached through Battle.net.
            if ns.IsForever and ns.IsForever() then return nil end
            target = char .. "-" .. r
        end
    end
    return target
end

local function FriendCharacter(index, info)
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    local g = info.gameAccountInfo
    local target = UsableGame(g, realm, faction)
    if target then return target, g end
    if C_BattleNet.GetFriendNumGameAccounts and C_BattleNet.GetFriendGameAccountInfo then
        for j = 1, (C_BattleNet.GetFriendNumGameAccounts(index) or 0) do
            local ok, ga = pcall(C_BattleNet.GetFriendGameAccountInfo, index, j)
            target = ok and UsableGame(ga, realm, faction)
            if target then return target, ga end
        end
    end
end

local function CollectFriends(q, current)
    local out = {}
    local function Add(display, extra, e)
        display = display or "?"
        if q ~= "" and not (display:lower():find(q, 1, true) or (extra and extra:lower():find(q, 1, true))) then return end
        e.kind, e.display = "friend", display
        e.proxy = { kind = e.bnID and "bn" or "wow", class = e.class, display = display, name = e.name }
        out[#out + 1] = e
    end
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    if C_FriendList and C_FriendList.GetNumFriends and C_FriendList.GetFriendInfoByIndex then
        for i = 1, (C_FriendList.GetNumFriends() or 0) do
            local ok, f = pcall(C_FriendList.GetFriendInfoByIndex, i)
            local name = ok and f and Clean(f.name)
            if type(name) == "string" and name ~= "" then
                local full = name
                if realm and realm ~= "" and not full:find("-", 1, true) then full = full .. "-" .. realm end
                if not HasConvo("w:" .. full, current) then
                    local online = Clean(f.connected) and true or false
                    local class = Clean(f.className)
                    class = type(class) == "string" and ns.ClassFileFromLocalized(class) or nil
                    local level = Clean(f.level)
                    local area = Clean(f.area)
                    local note = Clean(f.notes)
                    Add((Ambiguate and Ambiguate(full, "none")) or full, nil, {
                        name = name, online = online, class = class, level = level, area = area,
                        note = type(note) == "string" and note ~= "" and note or nil,
                        sub = FriendSub(online, level, area),
                    })
                end
            end
        end
    end
    if BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo then
        for i = 1, (BNGetNumFriends() or 0) do
            local ok, info = pcall(C_BattleNet.GetFriendAccountInfo, i)
            local id = ok and info and Clean(info.bnetAccountID)
            if type(id) == "number" and id ~= 0 and not HasConvo("b:" .. id, current) then
                local tag = Clean(info.battleTag)
                local acct = Clean(info.accountName)
                local display = type(tag) == "string" and (tag:match("^[^#]+") or tag)
                    or (type(acct) == "string" and acct) or "Battle.net"
                local game = info.gameAccountInfo or {}
                local online = Clean(game.isOnline) and true or false
                local charTarget, cg, skip
                if online then
                    charTarget, cg = FriendCharacter(i, info)
                    if cg then game = cg end
                    -- Keep an existing Battle.net conversation; don't split it.
                    local bc = ns.convos["b:" .. id]
                    if bc and #bc.messages > 0 then charTarget = nil end
                    -- Already talking to that character? Then the convo row covers him.
                    if charTarget then
                        local full = charTarget
                        if not full:find("-", 1, true) and realm and realm ~= "" then full = full .. "-" .. realm end
                        if HasConvo("w:" .. full, current) then skip = true end
                    end
                end
                local char = Clean(game.characterName)
                local class = Clean(game.className)
                class = type(class) == "string" and ns.ClassFileFromLocalized(class) or nil
                local level = Clean(game.characterLevel)
                local area = Clean(game.areaName) or Clean(game.richPresence)
                local note = Clean(info.note)
                local sub = FriendSub(online, level, area)
                if online and type(char) == "string" and char ~= "" then sub = char .. "  ·  " .. sub end
                if not skip then Add(display, type(char) == "string" and char or nil, {
                    bnID = id, charTarget = charTarget, online = online, class = class, level = level, area = area,
                    note = type(note) == "string" and note ~= "" and note or nil, sub = sub,
                }) end
            end
        end
    end
    table.sort(out, function(a, b) return a.display:lower() < b.display:lower() end)
    local on, off = {}, {}
    for _, e in ipairs(out) do
        local bucket = e.online and on or off
        bucket[#bucket + 1] = e
    end
    return on, off
end

function Hub:BuildEntries()
    local raw = strtrim(self.search.edit:GetText() or "")
    local q = raw:lower()
    local pinned, recent = {}, {}
    local exact = false
    local found = {}
    local filter = self.filter or "all"
    for _, c in pairs(ns.convos) do
        local passes = filter == "all" or (filter == "unread" and (c.unread or 0) > 0) or (filter == "starred" and c.starred)
            or (filter == "friends" and ns.IsFriend(c)) or filter == "hidden"
        -- Chats hidden with the x only show under the Hidden filter (or when searching, so they can be found).
        if filter == "hidden" then
            passes = passes and c.hubHidden
        elseif c.hubHidden and q == "" then
            passes = false
        end
        if (#c.messages > 0 or c == self.convo) and passes then
            local name = (c.display or ""):lower()
            if q == "" or name:find(q, 1, true) then
                if name == q or (c.name and c.name:lower() == q) then exact = true end
                local bucket = c.pinned and pinned or recent
                bucket[#bucket + 1] = c
            elseif q ~= "" then
                -- Not the name: look through what was said.
                local idx, text = ns.Social.FindInHistory(c, q)
                if idx then found[#found + 1] = { convo = c, index = idx, snippet = text } end
            end
        end
    end
    table.sort(pinned, SortBySeq)
    table.sort(recent, SortBySeq)
    table.sort(found, function(a, b) return (a.convo.seq or 0) > (b.convo.seq or 0) end)

    local entries = {}
    if raw ~= "" and not exact and not raw:find("%s") then
        entries[#entries + 1] = { kind = "new", name = raw }
    end
    if #pinned > 0 then
        entries[#entries + 1] = { kind = "header", label = L["Pinned"], count = #pinned }
        for _, c in ipairs(pinned) do entries[#entries + 1] = { kind = "convo", convo = c } end
    end
    if #recent > 0 then
        entries[#entries + 1] = { kind = "header", label = L["Recent"], count = #recent }
        for _, c in ipairs(recent) do entries[#entries + 1] = { kind = "convo", convo = c } end
    end
    if filter == "friends" then
        local on, off = CollectFriends(q, self.convo)
        if #on > 0 then
            entries[#entries + 1] = { kind = "header", label = L["Online"], count = #on }
            for _, e in ipairs(on) do entries[#entries + 1] = e end
        end
        if #off > 0 then
            entries[#entries + 1] = { kind = "header", label = L["Offline"], count = #off }
            for _, e in ipairs(off) do entries[#entries + 1] = e end
        end
    end
    if #found > 0 then
        entries[#entries + 1] = { kind = "header", label = L["In messages"], count = #found }
        for _, f in ipairs(found) do
            entries[#entries + 1] = { kind = "convo", convo = f.convo, index = f.index, snippet = f.snippet }
        end
    end
    return entries
end

local function RowClick(row, button)
    local e = row.entry
    if not e then return end
    if Hub.selectMode then
        -- Select mode: a click ticks / unticks a conversation; other rows do nothing.
        if e.kind == "convo" then
            if button == "RightButton" then
                ns.Social.Menu(row, e.convo)
            else
                Hub.selected[e.convo] = (not Hub.selected[e.convo]) or nil
                Hub:RenderList(true)
                Hub:PaintSelect()
            end
        end
        return
    end
    if e.kind == "convo" then
        if button == "RightButton" then
            ns.Social.Menu(row, e.convo)
        else
            Hub:Select(e.convo)
            if e.index then
                -- A message search hit: scroll the log so that message is at the bottom.
                Hub.log.scroll = math.max(0, #e.convo.messages - e.index)
                Hub.log:Render(e.convo)
            end
        end
    elseif e.kind == "new" or e.kind == "friend" then
        local c
        local bc = e.bnID and ns.convos["b:" .. e.bnID]
        if e.bnID and e.charTarget and not (bc and #bc.messages > 0) then
            c = ns.StartConvo(e.charTarget) or ns.BNetConvo(e.bnID)
        elseif e.bnID then
            c = ns.BNetConvo(e.bnID)
        else
            c = ns.StartConvo(e.name)
        end
        if c then
            Hub.search.edit:SetText("")
            Hub.search.edit:ClearFocus()
            Hub:Select(c)
            Hub.input.edit:SetFocus()
        end
    end
end

local function Row(i)
    local row = Hub.rows[i]
    if row then return row end
    row = CreateFrame("Button", nil, Hub.list)
    row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    row:SetScript("OnClick", RowClick)
    row:SetScript("OnEnter", function(self)
        local e = self.entry
        if e and e.kind == "convo" then
            if not Hub.selectMode and not e.snippet then self.del:Show() self.right:Hide() end
            ns.ShowPlayerTooltip(self, e.convo, "ANCHOR_LEFT",
                Hub.selectMode and L["Click: select  ·  Right-click: pin, star, note…"]
                or L["Click: open  ·  Right-click: pin, star, note…"])
        end
    end)
    row:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        if not self.del:IsMouseOver() then
            self.del:Hide()
            if self.entry and self.entry.kind == "convo" then self.right:Show() end
        end
    end)

    -- Hover-revealed delete cross (top-right, over the timestamp). Reads the
    -- convo from row.entry at click time so row reuse is safe.
    -- On a normal row the cross hides the chat (history kept, it returns when they
    -- reply); under the Hidden filter it deletes for good.
    local delTip = function()
        local e = row.entry
        return (e and e.convo and e.convo.hubHidden) and L["Delete conversation"] or L["Hide conversation"]
    end
    local del = T.WashHover(T.IconButton(row, 16, T.Icons.Close, delTip), delTip)
    del:SetPoint("TOPRIGHT", row, "TOPRIGHT", -10, -6)
    del:SetFrameLevel(row:GetFrameLevel() + 5)
    del:SetAlpha(0.6)
    del:Hide()
    del:HookScript("OnEnter", function(s) s:SetAlpha(1) end)
    del:HookScript("OnLeave", function(s)
        s:SetAlpha(0.6)
        if not row:IsMouseOver() then
            s:Hide()
            if row.entry and row.entry.kind == "convo" then row.right:Show() end
        end
    end)
    del:SetScript("OnClick", function()
        local e = row.entry
        if not (e and e.kind == "convo" and e.convo) then return end
        local c = e.convo
        if c.hubHidden then
            ns.AskDeleteConvo(c)
        else
            c.hubHidden = true -- listed under Hidden until they reply or you open it
            c.hidden = true
            c.unread = 0
            if Hub.convo == c then Hub.convo = nil end
            if ns.Window and ns.Window.convo == c and T.IsOpen(ns.Window) then ns.Window:Close() end
            ns.Refresh()
        end
    end)
    row.del = del

    row.sel = row:CreateTexture(nil, "BACKGROUND")
    row.sel:SetPoint("TOPLEFT", 6, -2)
    row.sel:SetPoint("BOTTOMRIGHT", -6, 2)
    T.Shape(row.sel, 8)
    row.selBar = T.AccentTexture(row:CreateTexture(nil, "ARTWORK"))
    row.selBar:SetPoint("TOPLEFT", 6, -10)
    row.selBar:SetPoint("BOTTOMLEFT", 6, 10)
    row.selBar:SetWidth(2)

    local hl = row:CreateTexture(nil, "HIGHLIGHT")
    hl:SetPoint("TOPLEFT", 6, -2)
    hl:SetPoint("BOTTOMRIGHT", -6, 2)
    T.Shape(hl, 8)
    T.Color(hl, 1, 1, 1, 0.05)

    -- Select mode checkbox: a rounded square, accent-filled when ticked.
    local check = CreateFrame("Frame", nil, row)
    check:SetSize(16, 16)
    check:SetPoint("LEFT", 14, 0)
    check:EnableMouse(false)
    check.bg = T.ShapeFill(check, T.INPUT_BG, 4)
    check.border = T.Border(check, T.INPUT_BORDER, 1, 4)
    check.dot = check:CreateTexture(nil, "ARTWORK")
    check.dot:SetSize(6, 6)
    check.dot:SetPoint("CENTER")
    T.Shape(check.dot, 2)
    check:Hide()
    row.check = check

    row.tile = ns.MakeTile(row, 42)
    row.tile:SetPoint("LEFT", 16, 0)
    row.tile:EnableMouse(false)
    row.pill = ns.MakeBadge(row, 20)
    row.pill:SetPoint("BOTTOMRIGHT", -14, 10)
    function row.pill:Refresh()
        for _,tex in ipairs(self.parts)do T.Color(tex,T.ACCENT)end
        local a=T.ACCENT
        local col=a[1]*.299+a[2]*.587+a[3]*.114>.55 and T.DARK_TEXT or T.TEXT
        self.text:SetTextColor(col[1],col[2],col[3],1) self.outline:Hide()
    end

    row.name = T.Text(row, 13)
    row.name.wsSettingsWeight = "bold"
    T.StyleText(row.name, 13, "")
    row.name:SetPoint("TOPLEFT", row.tile, "TOPRIGHT", 10, 0)
    row.name:SetPoint("RIGHT", row, "RIGHT", -42, 0)
    row.name:SetJustifyH("LEFT") row.name:SetWordWrap(false)
    row.right = T.Text(row, 10, T.SECTION)
    row.right.wsChatText = true
    T.StyleText(row.right, 10, "")
    row.right:SetPoint("TOPRIGHT", -12, -9)
    row.sub = T.Text(row, 12, T.LABEL)
    row.sub.wsChatText = true
    T.StyleText(row.sub, 12, "")
    row.sub:SetPoint("BOTTOMLEFT", row.tile, "BOTTOMRIGHT", 10, 0)
    row.sub:SetPoint("RIGHT", -32, 0)
    row.sub:SetJustifyH("LEFT")
    row.sub:SetWordWrap(false)

    row.star = row:CreateTexture(nil, "OVERLAY")
    row.star:SetSize(12, 12)
    row.star:SetPoint("BOTTOMRIGHT", -14, 10)
    if row.star.SetAtlas then row.star:SetAtlas("PetJournal-FavoritesIcon") end
    if not row.star:GetTexture() and not (row.star.GetAtlas and row.star:GetAtlas()) then
        row.star:SetColorTexture(ns.Social.STAR[1], ns.Social.STAR[2], ns.Social.STAR[3], 1)
        row.star:SetSize(6, 6)
    end
    row.star:Hide()

    row.label = T.Text(row, 10, T.SECTION) -- section headers / "new" rows
    row.label:SetPoint("LEFT", 14, 0)

    Hub.rows[i] = row
    return row
end

local function EntryH(e)
    return (e.kind == "header" and HEADER_H) or (e.kind == "new" and NEW_H) or ROW_H
end

-- Pixel scrolling: scrollY is what is drawn, scrollTarget where the wheel /
-- scroll-into-view wants it; the list's OnUpdate eases one toward the other.
function Hub:ClampScroll()
    local maxY = math.max(0, (self.contentH or 0) - (self.list:GetHeight() or 0))
    self.scrollTarget = math.max(0, math.min(self.scrollTarget or 0, maxY))
    self.scrollY = math.max(0, math.min(self.scrollY or 0, maxY))
end

function Hub:SetScrollTarget(y, instant)
    self.scrollTarget = y
    if instant then self.scrollY = y end
    self:ClampScroll()
    if instant then self.scrollY = self.scrollTarget end
    self:RenderList(true)
    self.list:SetScript("OnUpdate", (self.scrollY ~= self.scrollTarget) and self.ScrollStep or nil)
end

function Hub.ScrollStep(list, dt)
    local self = Hub
    local d = self.scrollTarget - self.scrollY
    if math.abs(d) < 0.5 then
        self.scrollY = self.scrollTarget
        list:SetScript("OnUpdate", nil)
    else
        self.scrollY = self.scrollY + d * math.min(1, dt * 18)
    end
    self:RenderList(true)
end

-- Minimal pixel scroll that shows the whole row of a conversation.
function Hub:RevealConvo(c)
    if not (c and self.entries) then return end
    for i, e in ipairs(self.entries) do
        if e.kind == "convo" and e.convo == c then
            local top, h = self.offsets[i], EntryH(e)
            local view = self.list:GetHeight()
            local t = self.scrollTarget or 0
            if top < t then t = top elseif top + h > t + view then t = top + h - view end
            if t ~= self.scrollTarget then self:SetScrollTarget(t) end
            return
        end
    end
end

function Hub:RenderList(keepEntries)
    local entries
    if keepEntries and self.entries then
        entries = self.entries
    else
        entries = self:BuildEntries()
        self.entries = entries
        local offsets, acc = {}, 0
        for i, e in ipairs(entries) do offsets[i] = acc acc = acc + EntryH(e) end
        self.offsets, self.contentH = offsets, acc
        -- selection only survives for conversations that still exist
        for c in pairs(self.selected) do
            if ns.convos[c.key] ~= c then self.selected[c] = nil end
        end
    end
    self.entryCount = #entries
    local prevT = self.scrollTarget
    self:ClampScroll()
    if not keepEntries and prevT ~= self.scrollTarget then
        self.list:SetScript("OnUpdate", (self.scrollY ~= self.scrollTarget) and self.ScrollStep or nil)
    end
    local limit = self.list:GetHeight()
    local scrollY = self.scrollY
    local used = 0

    for i = 1, #entries do
        local e = entries[i]
        local h = EntryH(e)
        local y = self.offsets[i] - scrollY
        if y >= limit then break end
        if y + h > 0 then -- (Lua 5.1: no goto) rows above the viewport are skipped
        used = used + 1
        local row = Row(used)
        row.entry = e
        row:SetHeight(h)
        row:SetHitRectInsets(0, 0, y < 0 and -y or 0, (y + h > limit) and (y + h - limit) or 0) -- clicks only on the visible part
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", self.list, "TOPLEFT", 0, -y)
        row:SetPoint("RIGHT", self.list, "RIGHT", 0, 0)
        T.Color(row.sel, 0, 0, 0, 0)
        row.selBar:Hide()
        row.pill:Hide()
        if row.del then row.del:Hide() end
        -- select mode: checkbox on conversation rows, content shifted to make room
        local picking = self.selectMode and e.kind == "convo"
        row.tile:ClearAllPoints()
        row.tile:SetPoint("LEFT", picking and 40 or 16, 0)
        if picking then
            local on = self.selected[e.convo]
            local a = T.ACCENT
            row.check:Show()
            if on then
                T.Color(row.check.bg, a[1], a[2], a[3], 0.95)
                T.SetBorderColor(row.check.border, a)
                local dark = (0.299 * a[1] + 0.587 * a[2] + 0.114 * a[3]) > 0.6
                row.check.dot:SetVertexColor(dark and 0.06 or 1, dark and 0.06 or 1, dark and 0.08 or 1, 1)
                row.check.dot:Show()
            else
                T.Color(row.check.bg, T.INPUT_BG)
                T.SetBorderColor(row.check.border, T.INPUT_BORDER)
                row.check.dot:Hide()
            end
        else
            row.check:Hide()
        end

        if e.kind == "friend" then
            local c = e.proxy
            row.label:Hide()
            row.tile:Show()
            row.name:Show()
            row.sub:Show()
            row.right:Hide()
            row.tile.hideOffline = true
            ns.PaintTile(row.tile, c, false, false)
            row.name:SetText(e.display)
            row.name:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
            row.sub:SetText(e.sub or "")
            row.sub:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
            row.sub:SetPoint("RIGHT", row, "RIGHT", -14, 0)
            row.star:Hide()
            row:SetAlpha(e.online and 1 or 0.6)
        elseif e.kind == "convo" then
            local c = e.convo
            row.label:Hide()
            row.tile:Show()
            row.name:Show()
            row.sub:Show()
            row.right:Show()
            row.tile.hideOffline = true
            ns.PaintTile(row.tile, c, false, false)
            local r, g, b = ns.ConvoColor(c)
            row.name:SetText(c.display or "?")
            row.name:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
            local last = c.messages[#c.messages]
            if (c.unread or 0) > 0 then
                row.right:SetText(last and date("%H:%M",last.t) or "")
                row.right:SetTextColor(T.SECTION[1],T.SECTION[2],T.SECTION[3])
                row.pill:SetCount(c.unread)
                row.pill:Show()
                row.sub:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
            else
                row.right:SetText(last and date("%H:%M", last.t) or "")
                row.right:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
                row.sub:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
            end
            if e.snippet then
                row.sub:SetText('"' .. e.snippet .. '"')
                row.sub:SetTextColor(T.LABEL[1], T.LABEL[2], T.LABEL[3])
            else
                row.sub:SetText(last and (last.out and L["You: %s"]:format(last.text) or last.text) or L["New conversation"])
            end
            row.star:SetShown(c.starred and true or false)
            row.star:ClearAllPoints()
            row.star:SetPoint("BOTTOMRIGHT",(c.unread or 0)>0 and -40 or -14,10)
            row.sub:SetPoint("RIGHT", row, "RIGHT", c.starred and (c.unread or 0)>0 and -64 or -44, 0)
            if c == self.convo then
                local a=T.ACCENT
                T.Color(row.sel,.12*.92+a[1]*.08,.125*.92+a[2]*.08,.15*.92+a[3]*.08,1)
                row.sub:SetTextColor(T.LABEL[1]*.6+a[1]*.4,T.LABEL[2]*.6+a[2]*.4,T.LABEL[3]*.6+a[3]*.4)
                row.selBar:Hide()
            end
            if picking and self.selected[c] then
                local a = T.ACCENT
                T.Color(row.sel, .12*.84+a[1]*.16, .125*.84+a[2]*.16, .15*.84+a[3]*.16, 1)
            end
            row:SetAlpha(c.hidden and 0.7 or 1)
            -- A re-render (e.g. after clicking the row) hides the cross; bring it back
            -- while the mouse is still on the row instead of waiting for a new hover.
            if row.del and not self.selectMode and not e.snippet and row:IsMouseOver() then
                row.del:Show()
                row.right:Hide()
            end
        else
            row.tile:Hide()
            row.name:Hide()
            row.sub:Hide()
            row.star:Hide()
            row:SetAlpha(1)
            row.label:Show()
            if e.kind == "header" then
                row.label:SetText(e.label:upper())
                row.label:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
                row.right:Show()
                row.right:SetText(e.count)
                row.right:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
                row:EnableMouse(false)
            else
                row.label:SetText(L["+  Whisper %s"]:format(e.name))
                row.label:SetTextColor(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3])
                row.right:Hide()
            end
        end
        if e.kind ~= "header" then row:EnableMouse(true) end
        row:Show()
        end
    end
    for i = used + 1, #self.rows do
        self.rows[i]:Hide()
        self.rows[i].entry = nil
    end
    if used == 0 then
        self.listEmpty:SetText(self.filter == "friends" and L["No friends to show."]
            or self.filter == "hidden" and L["No hidden conversations."]
            or L["No whispers yet.\nType a name above to start one."])
    end
    self.listEmpty:SetShown(used == 0)
    if self.selectMode and not keepEntries then self:PaintSelect() end
end

---------------------------------------------------------------------------
-- Select mode: tick conversations and delete them in bulk
---------------------------------------------------------------------------

-- Every conversation currently listed (current filter + search), once each.
function Hub:ListedConvos()
    local out, seen = {}, {}
    for _, e in ipairs(self.entries or {}) do
        if e.kind == "convo" and not seen[e.convo] then
            seen[e.convo] = true
            out[#out + 1] = e.convo
        end
    end
    return out
end

-- The ticked conversations that are in the current view (what Delete acts on).
function Hub:SelectedListed()
    local out = {}
    for _, c in ipairs(self:ListedConvos()) do
        if self.selected[c] then out[#out + 1] = c end
    end
    return out
end

function Hub:PaintSelect()
    local btn, bar = self.selectBtn, self.selectBar
    if not (btn and bar) then return end
    local on = self.selectMode
    btn.label:SetText(on and L["Done"] or L["Select"])
    T.FitText(btn, 62, 120, 20)
    local lc = on and T.ACCENT or T.LABEL
    btn.label:SetTextColor(lc[1], lc[2], lc[3])
    T.SetBorderColor(btn.border, on and T.ACCENT or T.INPUT_BORDER, on and 0.8 or nil)
    if not on then return end

    local listed = self:ListedConvos()
    local n = #self:SelectedListed()
    local all = #listed > 0 and n == #listed
    bar.count:SetText(L["%d selected"]:format(n))
    bar.count:SetTextColor(T.LABEL[1], T.LABEL[2], T.LABEL[3])
    -- select-all checkbox: same accent check style as the row checks
    local cb, ac = bar.all, T.ACCENT
    cb.allOn = all
    if all then
        T.Color(cb.bg, ac[1], ac[2], ac[3], 0.95)
        T.SetBorderColor(cb.border, ac)
        local dark = (0.299 * ac[1] + 0.587 * ac[2] + 0.114 * ac[3]) > 0.6
        cb.dot:SetVertexColor(dark and 0.06 or 1, dark and 0.06 or 1, dark and 0.08 or 1, 1)
        cb.dot:Show()
    else
        T.Color(cb.bg, T.INPUT_BG)
        T.SetBorderColor(cb.border, T.INPUT_BORDER)
        cb.dot:Hide()
    end
    cb:SetAlpha(#listed > 0 and 1 or 0.4)
    if #listed > 0 then cb:Enable() else cb:Disable() end
    -- Delete is danger-styled (same red as "Clear history" in the menu)
    local del = bar.del
    del.label:SetText(L["Delete"])
    T.FitText(del, 56, 110, 24)
    del.label:SetTextColor(1, 0.38, 0.38, n > 0 and 1 or 0.4)
    T.Color(del.bg, 1, 0.38, 0.38, n > 0 and 0.14 or 0.04)
    T.SetBorderColor(del.border, { 1, 0.38, 0.38 }, n > 0 and 0.8 or 0.25)
    if n > 0 then del:Enable() else del:Disable() end
end

function Hub:SetSelectMode(on, quiet)
    on = on and true or nil
    if on == self.selectMode then return end
    self.selectMode = on
    if not on then wipe(self.selected) end
    local bar = self.selectBar
    if bar then bar:SetShown(on or false) end
    if self.list then
        self.list:ClearAllPoints()
        self.list:SetPoint("TOPLEFT", 0, -122)
        self.list:SetPoint("BOTTOMLEFT", 0, on and (8 + BAR_H) or 8)
        self.list:SetWidth(LIST_W)
    end
    self:PaintSelect()
    if not quiet then
        self:ClampScroll()
        self:RenderList()
    end
end

StaticPopupDialogs.PIGEON_DELETE_CONVOS = {
    text = "",
    button1 = L["Delete"],
    button2 = CANCEL or L["Cancel"],
    OnAccept = function(_, list) Hub:DeleteConvos(list) end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

function Hub:AskDelete()
    local list = self:SelectedListed()
    if #list == 0 then return end
    StaticPopupDialogs.PIGEON_DELETE_CONVOS.text = #list == 1
        and L["Delete 1 conversation? This clears its message history and can't be undone."]
        or L["Delete %d conversations? This clears their message history and can't be undone."]
    StaticPopup_Show("PIGEON_DELETE_CONVOS", #list, nil, list)
end

-- Wipe the history and drop the conversations from the saved table
-- (ns.convos is PigeonHistory.convos), so they don't come back after /reload.
function Hub:DeleteConvos(list)
    if type(list) ~= "table" or #list == 0 then return end
    local gone = {}
    for _, c in ipairs(list) do
        gone[c] = true
        wipe(c.messages)
        c.unread = 0
        c.hidden = true
        if self.convo == c then self.convo = nil end
        if ns.Window and ns.Window.convo == c then
            if T.IsOpen(ns.Window) then ns.Window:Close() end
            ns.Window.convo = nil -- never leave the window pointing at a deleted conversation
        end
    end
    for key, c in pairs(ns.convos) do
        if gone[c] then ns.convos[key] = nil end
    end
    self:SetSelectMode(false, true)
    ns.Refresh() -- redraws list + pane (pane shows its empty state without a convo)
end

-- Permanently delete one conversation. Accepts a convo key (ns.convos key) or the convo record.
function ns.DeleteConvo(keyOrConvo)
    local c = type(keyOrConvo) == "table" and keyOrConvo or ns.convos[keyOrConvo]
    if not c then return end
    Hub:DeleteConvos({ c })
end

-- Same, but asks for confirmation first when the conversation has message history.
function ns.AskDeleteConvo(keyOrConvo)
    local c = type(keyOrConvo) == "table" and keyOrConvo or ns.convos[keyOrConvo]
    if not c then return end
    if c.messages and #c.messages > 0 then
        StaticPopupDialogs.PIGEON_DELETE_CONVOS.text =
            L["Delete 1 conversation? This clears its message history and can't be undone."]
        StaticPopup_Show("PIGEON_DELETE_CONVOS", 1, nil, { c })
    else
        ns.DeleteConvo(c)
    end
end

-- Ask the game for fresh friends data, and redraw (throttled) when it arrives.
function Hub:RequestFriends()
    if C_FriendList and C_FriendList.ShowFriends then C_FriendList.ShowFriends() end
end

local FRIEND_EVENTS = { "FRIENDLIST_UPDATE", "BN_FRIEND_LIST_SIZE_CHANGED", "BN_FRIEND_INFO_CHANGED",
                        "BN_FRIEND_ACCOUNT_ONLINE", "BN_FRIEND_ACCOUNT_OFFLINE" }

local function OnFriendEvent()
    ns.InvalidateFriends()
    if Hub.friendPending or Hub.filter ~= "friends" or not Hub:IsShown() then return end
    Hub.friendPending = true
    C_Timer.After(0.5, function()
        Hub.friendPending = nil
        if Hub:IsShown() and Hub.filter == "friends" and Hub.list then Hub:RenderList() end
    end)
end

---------------------------------------------------------------------------
-- Conversation pane
---------------------------------------------------------------------------

function Hub:RenderPane()
    local c = self.convo
    local has = c ~= nil
    for _, f in ipairs(self.paneParts) do f:SetShown(has) end
    self.paneEmpty:SetShown(not has)
    if not has then return end

    local r, g, b = ns.ConvoColor(c)
    self.name:SetText(c.display or "?")
    self.name:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
    self.meta:SetText(ns.MetaLine(c))
    self.note:SetText(c.note and (L["Note: %s"]:format(c.note)) or "")
    ns.PaintTile(self.bigTile, c, false, false)
    if type(CreateColor) == "function" then
        self.wash:SetColorTexture(1, 1, 1, 1)
        self.wash:SetGradient("HORIZONTAL", CreateColor(r, g, b, 0), CreateColor(r, g, b, 0))
    end
    for _, tb in ipairs({ { self.pin, c.pinned }, { self.star, c.starred } }) do
        tb[1].active = tb[2] and true or false
        tb[1].iconColor = tb[2] and T.ACCENT or T.LABEL
        tb[1]:SetIconColor(tb[1].iconColor)
        if tb[2] then
            T.Color(tb[1].bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.12)
        else
            T.Color(tb[1].bg, T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], T.INPUT_BG[4] or 1)
        end
        T.SetBorderColor(tb[1].border, tb[2] and T.ACCENT or T.INPUT_BORDER, tb[2] and 0.7 or nil)
    end
    if self.star.starTex then
        self.star.starTex:SetDesaturated(not c.starred)
        self.star.starTex:SetAlpha(c.starred and 1 or 0.5)
    end
    self:LayoutQuickBar()
    self.invite:SetShown(c.kind == "wow")
    self.input:SetPlaceholder(L["Message…"])
    self.log:Render(c)
end

-- The quick replies row sits between the log and the input when it's on.
function Hub:LayoutQuickBar()
    local on = ns.Social.QuickBarOn()
    if on then self.quick:Refresh() end
    self.quick:SetShown(on)
    if self.quickOn == on then return end
    self.quickOn = on
    self.log:ClearAllPoints()
    self.log:SetPoint("TOPLEFT", 16, -72)
    self.log:SetPoint("BOTTOMRIGHT", -16, on and 92 or 60)
    self.log.fallbackH = (self:GetHeight() or H_) - 132 - (on and 32 or 0)
end

function Hub:Render()
    if not self.list then return end
    self:RenderList()
    self:RenderPane()
end

function Hub:Select(c)
    if not c then return end
    local changed = c ~= self.convo
    self.convo = c
    c.unread = 0
    self.log:Reset(c)
    ns.Refresh()
    if self.list and self.list:IsVisible() then self:RevealConvo(c) end
    if changed then
        T.Tween(self.pane, "swap", 0.18, 0, 1, function(v) self.pane:SetAlpha(v) end)
    end
end

---------------------------------------------------------------------------
-- Open / close
---------------------------------------------------------------------------

function Hub:Open(c)
    if self.PaintChips then self:PaintChips() end
    if self.filter == "friends" then self:RequestFriends() end
    if ns.Window and T.IsOpen(ns.Window) then ns.Window:Close() end
    if ns.Dock.preview:IsShown() then ns.Dock.preview:Hide() end
    local target = c or self.convo
    if not target then target = ns.List()[1] end
    if not T.IsOpen(self) then
        local p = ns.db.hubPoint
        if self.ApplySavedSize then self:ApplySavedSize() end
        T.Place(self, p[1], UIParent, p[2], p[3], p[4])
        self.scrollY, self.scrollTarget = 0, 0
        self:Show()
        self:Raise()
        self.wsP = 0
        T.Reveal(self, { dy = -10, dur = 0.24 })
    end
    if target then
        self:Select(target)
    else
        self.convo = nil
        self:Render()
    end
end

function Hub:Close(done)
    if not T.IsOpen(self) then
        if done then done() end
        return
    end
    self.input.edit:ClearFocus()
    self.search.edit:ClearFocus()
    T.Conceal(self, { dy = -10, dur = 0.2 }, done)
end

function Hub:Toggle()
    if T.IsOpen(self) then self:Close() else self:Open() end
end

---------------------------------------------------------------------------
-- Build
---------------------------------------------------------------------------

local function Divider(parent)
    local d = parent:CreateTexture(nil, "ARTWORK")
    d:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])
    return d
end

function Hub:Init()
    T.Panel(self) T.Reshape(self, 22) -- follows the Look page (colour, opacity, glass)
    tinsert(UISpecialFrames, "PigeonHub") -- Escape closes it

    local inset = (T.Rounded() and self.wsRadius) and (self.wsRadius + 1) or 0
    local bar = T.AccentTexture(self:CreateTexture(nil, "ARTWORK"))
    bar:SetPoint("TOPLEFT", inset, 0)
    bar:SetPoint("TOPRIGHT", -inset, 0)
    bar:SetHeight(2)
    bar:SetAlpha(0)
    self.strip = bar

    -- Header: title + drag handle + close
    local header = CreateFrame("Frame", nil, self)
    header:SetPoint("TOPLEFT", 0, -3)
    header:SetPoint("TOPRIGHT", self, "TOPLEFT", LIST_W, -3)
    header:SetHeight(38)
    self.listHeader = header
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() Hub:StartMoving() end)
    header:SetScript("OnDragStop", function()
        Hub:StopMovingOrSizing()
        local p, _, rp, x, y = Hub:GetPoint()
        ns.db.hubPoint = { p, rp, x, y }
        T.Place(Hub, p, UIParent, rp, x, y)
    end)
    local mark = header:CreateTexture(nil, "ARTWORK")
    mark:SetTexture(T.MEDIA .. "Symbols\\BIRD.tga") mark:SetSize(18, 18) mark:SetPoint("LEFT", 16, 0)
    mark.wsShaped = true -- tint the artwork without replacing its texture
    T.AccentTexture(mark)
    self.brandIcon = mark
    local title = T.Text(header, 17, T.TEXT)
    title:SetPoint("LEFT", 46, 0)
    title:SetText("Pigeon")
    local close = T.WashHover(T.GlyphButton(header, "x", 24, true), L["Close"])
    close:SetPoint("RIGHT", -6, 0)
    close:SetScript("OnClick", function() Hub:Close() end)
    self.closeBtn, self.titleText, self.dragHeader = close, title, header

    -- "Select" toggles bulk-select mode (tick conversations, delete them together)
    local selBtn = T.Button(header, L["Select"], 62, 22)
    selBtn:SetPoint("RIGHT", close, "LEFT", -4, 0)
    selBtn:SetScript("OnClick", function() Hub:SetSelectMode(not Hub.selectMode) end)
    self.selectBtn = selBtn
    T.FitText(selBtn, 62, 100, 20) -- capped, so the settings button next to it always fits beside the title

    -- Settings, one click from the hub (the slash command is /pigeon).
    local gear = T.WashHover(T.IconButton(header, 24, T.Icons.Sliders, L["Settings"], true), L["Settings"])
    gear:SetPoint("RIGHT", selBtn, "LEFT", -6, 0)
    gear:SetScript("OnClick", function() ns.Settings:Toggle() end)
    self.settingsBtn = gear

    local hdiv = Divider(self)
    hdiv:SetHeight(1)
    hdiv:SetPoint("TOPLEFT", 0, -41)
    hdiv:SetPoint("TOPRIGHT", self, "TOPLEFT", LIST_W, -41)
    hdiv:SetAlpha(0)
    self.listHdiv = hdiv

    -- Left: search + list
    local search = T.Reshape(T.EditBox(self, L["Search people or messages"]), 12)
    search:SetPoint("TOPLEFT", 10, -50)
    search:SetWidth(LIST_W - 20)
    search.edit:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
    search.edit:HookScript("OnTextChanged", function()
        Hub.scrollY, Hub.scrollTarget = 0, 0
        Hub:RenderList()
    end)
    search.edit:SetScript("OnEnterPressed", function(e)
        -- Enter picks the first match, or starts a new whisper.
        if Hub.selectMode then e:ClearFocus() return end
        local first = Hub.rows[1] and Hub.rows[1]:IsShown() and Hub.rows[1]
        for _, row in ipairs(Hub.rows) do
            if row:IsShown() and row.entry and row.entry.kind ~= "header" then first = row break end
        end
        if first and first.entry and first.entry.kind ~= "header" then RowClick(first, "LeftButton") end
        e:ClearFocus()
    end)
    search.wsQuietFocus = true
    self.search = search
    -- Placeholder too wide for the box (long translations): short form + full text in a tooltip.
    local function FitSearch()
        local full = L["Search people or messages"]
        local ph = search.placeholder
        ph:SetText(full)
        search.fullHint = nil
        local avail = (search:GetWidth() or (LIST_W - 20)) - 24
        if (ph:GetStringWidth() or 0) <= avail then return end
        local short = (full:match("^(%S+)%s") or full)
        local function trim(str) return (str:gsub("[%z\1-\127\194-\244][\128-\191]*$", "")) end
        while #short > 1 do
            ph:SetText(short .. "...")
            if (ph:GetStringWidth() or 0) <= avail then break end
            short = trim(short)
        end
        search.fullHint = full
    end
    local function HintOn(f)
        f:HookScript("OnEnter", function()
            if not search.fullHint then return end
            GameTooltip:SetOwner(search, "ANCHOR_TOP")
            GameTooltip:AddLine(search.fullHint)
            GameTooltip:Show()
        end)
        f:HookScript("OnLeave", function() if search.fullHint then GameTooltip:Hide() end end)
    end
    HintOn(search)
    HintOn(search.edit)
    self.FitSearch = FitSearch
    FitSearch()

    -- Filter: All · Unread · Starred · Friends as one segmented control, the
    -- chosen segment a solid pill (text dark or light to suit the accent).
    self.filter = "all"
    self.chips = {}
    local SEG_H = 28
    local track = CreateFrame("Frame", nil, self)
    track:SetPoint("TOPLEFT", self, "TOPLEFT", 10, -86)
    track:SetSize(LIST_W - 20, SEG_H)
    track.bg = T.ShapeFill(track, T.INPUT_BG, SEG_H / 2)
    track.border = T.Border(track, T.INPUT_BORDER, 1, SEG_H / 2)
    self.filterTrack = track
    -- All / Unread / Starred sized to their text, then a "..." chip whose menu
    -- holds Friends and Hidden (the "..." chip lights up while one of them is active).
    local filters = { { "all", L["All"] }, { "unread", L["Unread"] }, { "starred", L["Starred"] },
        { "friends", L["Friends"] }, { "hidden", L["Hidden"] }, { "more", "..." } }
    local PILL_H = SEG_H
    local R = 8 -- the chat tabs' corner radius, so every chip and the highlight share one shape
    local GAP = 4
    -- ONE shared highlight pill slides between the segments. It sits below every
    -- chip (and so below their labels) in frame level.
    local trackLevel = track:GetFrameLevel()
    local hl = CreateFrame("Frame", nil, track)
    hl:SetFrameLevel(trackLevel + 1)
    hl.bg = T.ShapeFill(hl, { 1, 1, 1, 0 }, R)
    hl:SetSize(20, PILL_H)
    self.filterHL = hl

    local function MoreTip(b)
        local name = Hub.filter == "friends" and L["Friends"] or Hub.filter == "hidden" and L["Hidden"] or L["More"]
        GameTooltip:SetOwner(b, "ANCHOR_TOP")
        GameTooltip:AddLine(name)
        GameTooltip:Show()
    end
    function self:OpenFilterMenu(owner)
        local function pick(key)
            return function()
                Hub.scrollY, Hub.scrollTarget = 0, 0
                Hub:SetFilter(key)
                if key == "friends" then Hub:RequestFriends() end
                Hub:RenderList()
            end
        end
        -- only the filters that did not fit as chips are in the menu
        local items = {}
        if not self.promoted or not self.promoted.friends then
            items[#items + 1] = { label = L["Friends"], selected = self.filter == "friends", fn = pick("friends") }
        end
        if not self.promoted or not self.promoted.hidden then
            items[#items + 1] = { label = L["Hidden"], selected = self.filter == "hidden", fn = pick("hidden") }
        end
        ns.Social.OpenMenu(owner, L["More"], items)
    end

    for _, f in ipairs(filters) do
        local chip = CreateFrame("Button", nil, track)
        chip:SetFrameLevel(trackLevel + 2)
        chip:SetHeight(SEG_H)
        -- Each chip is its own rounded pill (dark fill + hairline); the shared highlight
        -- slides over them, below the labels.
        local back = CreateFrame("Frame", nil, track)
        back:SetFrameLevel(trackLevel)
        back:SetPoint("TOPLEFT", chip, "TOPLEFT", 0, 0)
        back:SetPoint("BOTTOMRIGHT", chip, "BOTTOMRIGHT", 0, 0)
        back.fill = T.ShapeFill(back, T.INPUT_BG, R)
        back.edge = T.Border(back, T.INPUT_BORDER, 1, R)
        chip.back = back
        chip.key = f[1]
        chip.lit = 0
        local pill = CreateFrame("Frame", nil, chip)
        -- a little shorter than its slot and inset from its neighbours
        pill:SetPoint("LEFT", 0, 0)
        pill:SetPoint("RIGHT", 0, 0)
        pill:SetHeight(PILL_H)
        chip.bg = T.ShapeFill(pill, { 1, 1, 1, 0 }, R) -- hover fill for inactive chips
        chip.text = T.Text(pill, 11, T.SECTION, "") -- on the pill frame, above the highlight
        chip.text:SetDrawLayer("OVERLAY", 7)
        chip.text:SetPoint("CENTER", chip, "CENTER")
        chip.text:SetText(f[2])
        chip:SetWidth(40)
        chip:SetScript("OnClick", function(b)
            if b.key == "more" then Hub:OpenFilterMenu(b) return end
            Hub.scrollY, Hub.scrollTarget = 0, 0
            Hub:SetFilter(b.key)
            if b.key == "friends" then Hub:RequestFriends() end
            Hub:RenderList()
        end)
        chip:SetScript("OnEnter", function(b)
            b.hover = true
            Hub:PaintChips()
            if b.key == "more" then MoreTip(b) end
        end)
        chip:SetScript("OnLeave", function(b)
            b.hover = nil
            Hub:PaintChips()
            if b.key == "more" then GameTooltip:Hide() end
        end)
        self.chips[#self.chips + 1] = chip
    end

    -- Friends / Hidden become chips when the column is wide enough; otherwise
    -- they live under the "..." chip.
    local function ChipFor(key)
        if (key == "friends" or key == "hidden") and not (self.promoted and self.promoted[key]) then key = "more" end
        for _, chip in ipairs(self.chips) do if chip.key == key then return chip end end
    end
    local function PlaceHL(x, w)
        hl.x, hl.w = x, w
        hl:ClearAllPoints()
        hl:SetPoint("LEFT", track, "LEFT", x, 0)
        hl:SetSize(w, PILL_H)
    end
    local function PlaceChip(chip, x, w)
        chip:ClearAllPoints()
        chip:SetPoint("LEFT", track, "LEFT", x, 0)
        chip:SetWidth(w)
        chip.hx, chip.hw = x, w -- where the highlight sits when this chip is chosen
    end
    -- Chips take their text width plus padding (shrinking the padding if a long
    -- translation would not fit); "..." is pinned to the right end.
    local function Layout()
        local more = ChipFor("more")
        local TRACK_W = LIST_W - 20
        local mw = 34
        local MINPAD = 16
        local base, extra = {}, {}
        for _, chip in ipairs(self.chips) do
            if chip.key == "friends" or chip.key == "hidden" then
                extra[#extra + 1] = chip
            elseif chip ~= more then
                base[#base + 1] = chip
            end
        end
        local function need(n)
            local count, w = #base + n, 0
            for i = 1, #base do w = w + (base[i].text:GetStringWidth() or 0) + MINPAD end
            for i = 1, n do w = w + (extra[i].text:GetStringWidth() or 0) + MINPAD end
            w = w + GAP * (count - 1)
            if n < #extra then w = w + GAP + mw end -- the "..." chip stays for what is left
            return w
        end
        local k = 0
        for n = #extra, 1, -1 do
            if need(n) <= TRACK_W then k = n break end
        end
        self.promoted = { friends = k >= 1, hidden = k >= 2 }
        local shown, tw = {}, 0
        for _, chip in ipairs(base) do shown[#shown + 1] = chip end
        for i = 1, #extra do
            local on = i <= k
            extra[i]:SetShown(on)
            extra[i].back:SetShown(on)
            if on then shown[#shown + 1] = extra[i] end
        end
        local hasMore = k < #extra
        more:SetShown(hasMore)
        more.back:SetShown(hasMore)
        for _, chip in ipairs(shown) do tw = tw + (chip.text:GetStringWidth() or 0) end
        local avail = TRACK_W - (hasMore and (mw + GAP) or 0) - GAP * (#shown - 1)
        -- Share the whole track: equal padding around every label (never under 8),
        -- so short English labels spread out instead of bunching up to the left.
        local pad = math.max(8, math.floor((avail - tw) / #shown))
        local x = 0
        for _, chip in ipairs(shown) do
            local cw = math.floor((chip.text:GetStringWidth() or 0) + pad + 0.5)
            PlaceChip(chip, x, cw)
            x = x + cw + GAP
        end
        PlaceChip(more, TRACK_W - mw, mw)
    end
    -- Label colours: inactive (or hovered) <-> the colour that reads on the pill.
    local function ActiveText()
        local look = ns.db and ns.db.look
        local soft = look and (look.preset == "softsignal" or look.preset == "island")
        if soft then return T.TEXT[1], T.TEXT[2], T.TEXT[3] end
        local a = T.ACCENT
        if (0.299 * a[1] + 0.587 * a[2] + 0.114 * a[3]) > 0.6 then return 0.06, 0.06, 0.08 end
        return 1, 1, 1
    end
    local function PaintLabels()
        local ar, ag, ab = ActiveText()
        local current = ChipFor(self.filter)
        for _, chip in ipairs(self.chips) do
            local c = chip.hover and T.TEXT or T.SECTION
            local k = chip.lit or 0
            chip.text:SetTextColor(c[1] + (ar - c[1]) * k, c[2] + (ag - c[2]) * k, c[3] + (ab - c[3]) * k)
            -- hover fill only on chips that are not (becoming) the chosen one
            T.Color(chip.bg, 1, 1, 1, (chip.hover and chip ~= current) and 0.06 or 0)
        end
    end
    local function StopSlide()
        track.sliding = nil
        track:SetScript("OnUpdate", nil)
    end
    local SLIDE = 0.18
    local function SlideStep(_, dt)
        local s = track.sliding
        if not s then StopSlide() return end
        s.t = s.t + dt
        local p = math.min(1, s.t / SLIDE)
        local e = 1 - (1 - p) * (1 - p) * (1 - p) -- ease out (cubic)
        PlaceHL(s.x0 + (s.x1 - s.x0) * e, s.w0 + (s.w1 - s.w0) * e)
        local current = ChipFor(self.filter)
        for _, chip in ipairs(self.chips) do
            local from = s.lit0[chip.key] or 0
            chip.lit = from + ((chip == current and 1 or 0) - from) * e
        end
        PaintLabels()
        if p >= 1 then StopSlide() end
    end

    function self:PaintChips()
        local a = T.ACCENT
        T.Color(track.bg, 0, 0, 0, 0) -- the track is only a positioning frame now
        T.SetBorderColor(track.border, T.INPUT_BORDER, 0)
        for _, chip in ipairs(self.chips) do
            T.Color(chip.back.fill, T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], T.INPUT_BG[4] or 1)
            T.SetBorderColor(chip.back.edge, T.INPUT_BORDER)
        end
        -- mirrors the chat tabs: soft presets get a tinted pill, the rest a solid one
        local look = ns.db and ns.db.look
        local soft = look and (look.preset == "softsignal" or look.preset == "island")
        T.Color(hl.bg, a[1], a[2], a[3], soft and 0.42 or 0.9)
        if not track.sliding then
            Layout()
            local on = ChipFor(self.filter)
            if on then PlaceHL(on.hx, on.hw) end
            for _, chip in ipairs(self.chips) do chip.lit = (chip == on) and 1 or 0 end
        end
        PaintLabels()
        if self.FitSearch then self.FitSearch() end
        if self.PaintSelect then self:PaintSelect() end
    end

    -- Choose a filter; the highlight slides there when the hub is on screen,
    -- otherwise (first paint, hidden hub) it just snaps. The "..." chip never slides.
    function self:SetFilter(key)
        if key == self.filter then return end
        self.filter = key
        local target = ChipFor(key)
        if not (target and hl.x and self:IsVisible()) or target.key == "more" then
            StopSlide()
            self:PaintChips()
            return
        end
        local lit0 = {}
        for _, chip in ipairs(self.chips) do lit0[chip.key] = chip.lit or 0 end
        track.sliding = { t = 0, x0 = hl.x, w0 = hl.w, x1 = target.hx, w1 = target.hw, lit0 = lit0 }
        track:SetScript("OnUpdate", SlideStep)
        PaintLabels()
    end
    function self:SnapFilter()
        StopSlide()
        self:PaintChips()
    end
    self:PaintChips()

    local list = CreateFrame("Frame", nil, self)
    list:SetPoint("TOPLEFT", 0, -122)
    list:SetPoint("BOTTOMLEFT", 0, 8)
    list:SetWidth(LIST_W)
    list:SetClipsChildren(true)
    list:EnableMouseWheel(true)
    list:SetScript("OnMouseWheel", function(_, delta)
        Hub:SetScrollTarget((Hub.scrollTarget or 0) - delta * ROW_H * 0.75)
    end)
    list:SetScript("OnSizeChanged", function()
        if Hub.entries then Hub:RenderList(true) end
    end)
    self.list = list

    -- Select mode's action bar: [checkbox] N selected ........ [Delete] [x]
    local bar = CreateFrame("Frame", nil, self)
    bar:SetPoint("BOTTOMLEFT", 0, 8)
    bar:SetSize(LIST_W, BAR_H)
    bar:EnableMouse(true)
    bar:Hide()
    local bdiv = Divider(bar)
    bdiv:SetHeight(1)
    bdiv:SetPoint("TOPLEFT", 10, 0)
    bdiv:SetPoint("TOPRIGHT", -10, 0)

    bar.cancel = T.WashHover(T.IconButton(bar, 26, T.Icons.Close, L["Cancel"], true), L["Cancel"])
    bar.cancel:SetPoint("RIGHT", bar, "RIGHT", -10, -2)
    bar.cancel:SetScript("OnClick", function() Hub:SetSelectMode(false) end)

    bar.del = T.Button(bar, L["Delete"], 60, 26)
    bar.del:SetPoint("RIGHT", bar.cancel, "LEFT", -6, 0)
    bar.del:SetScript("OnClick", function() Hub:AskDelete() end)

    -- select all / none: a rounded square like the row checks
    local cb = CreateFrame("Button", nil, bar)
    cb:SetSize(16, 16)
    cb:SetPoint("LEFT", bar, "LEFT", 14, -2)
    cb:SetHitRectInsets(-4, -4, -4, -4)
    cb.bg = T.ShapeFill(cb, T.INPUT_BG, 4)
    cb.border = T.Border(cb, T.INPUT_BORDER, 1, 4)
    cb.dot = cb:CreateTexture(nil, "ARTWORK")
    cb.dot:SetSize(6, 6)
    cb.dot:SetPoint("CENTER")
    T.Shape(cb.dot, 2)
    cb:SetScript("OnClick", function()
        local listed = Hub:ListedConvos()
        local sel = Hub:SelectedListed()
        if #listed > 0 and #sel == #listed then
            wipe(Hub.selected)
        else
            for _, c in ipairs(listed) do Hub.selected[c] = true end
        end
        Hub:RenderList(true)
        Hub:PaintSelect()
    end)
    cb:SetScript("OnEnter", function(b)
        GameTooltip:SetOwner(b, "ANCHOR_TOP")
        GameTooltip:AddLine(b.allOn and L["Select none"] or L["Select all"])
        GameTooltip:Show()
    end)
    cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    bar.all = cb

    bar.count = T.Text(bar, 12, T.LABEL)
    bar.count:SetPoint("LEFT", cb, "RIGHT", 10, 0)
    bar.count:SetPoint("RIGHT", bar.del, "LEFT", -8, 0)
    bar.count:SetJustifyH("LEFT")
    bar.count:SetWordWrap(false)
    self.selectBar = bar
    self:PaintSelect()

    self.listEmpty = T.Text(list, 12, T.SECTION)
    self.listEmpty:SetPoint("TOP", 0, -20)
    self.listEmpty:SetWidth(LIST_W - 30)
    self.listEmpty:SetText(L["No whispers yet.\nType a name above to start one."])

    local vdiv = Divider(self)
    vdiv:SetWidth(1)
    vdiv:SetPoint("TOPLEFT", LIST_W, -16)
    vdiv:SetPoint("BOTTOMLEFT", LIST_W, 16)
    self.vdiv = vdiv

    -- Splitter: drag the divider to make the list column wider (more filter chips,
    -- longer names) or narrower. The width is remembered.
    local split = CreateFrame("Button", nil, self) -- a Button, for OnDoubleClick
    split:SetWidth(10)
    split:SetPoint("TOP", vdiv, "TOP", 0, 0)
    split:SetPoint("BOTTOM", vdiv, "BOTTOM", 0, 0)
    split:SetFrameLevel(self:GetFrameLevel() + 20)
    split:EnableMouse(true)
    split:SetScript("OnEnter", function() SetCursor("UI_RESIZE_CURSOR") end)
    split:SetScript("OnLeave", function() if not split.drag then SetCursor(nil) end end)
    split:SetScript("OnMouseDown", function(f, btn)
        if btn ~= "LeftButton" then return end
        f.drag = true
        f.startX = GetCursorPosition() / (self:GetEffectiveScale() or 1)
        f.startW = LIST_W
        f:SetScript("OnUpdate", function()
            local dx = GetCursorPosition() / (self:GetEffectiveScale() or 1) - f.startX
            Hub:SetListWidth(f.startW + dx, true)
        end)
    end)
    split:SetScript("OnMouseUp", function(f)
        f.drag = nil
        f:SetScript("OnUpdate", nil)
        if not f:IsMouseOver() then SetCursor(nil) end
        if ns.db then ns.db.hubListW = math.floor(LIST_W + 0.5) end
        Hub:SetListWidth(LIST_W)
    end)
    split:SetScript("OnDoubleClick", function()
        Hub:SetListWidth(280)
        if ns.db then ns.db.hubListW = nil end
    end)
    split:SetScript("OnHide", function(f)
        f.drag = nil
        f:SetScript("OnUpdate", nil)
    end)
    self.splitter = split

    -- Right: conversation pane
    local pane = CreateFrame("Frame", nil, self)
    pane:SetPoint("TOPLEFT", LIST_W + 1, 0)
    pane:SetPoint("BOTTOMRIGHT", 0, 0)
    self.pane = pane
    local drag = CreateFrame("Frame", nil, pane)
    drag:SetPoint("TOPLEFT") drag:SetPoint("TOPRIGHT",pane,"TOPRIGHT",-174,0) drag:SetHeight(64)
    drag:EnableMouse(true) drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart", header:GetScript("OnDragStart"))
    drag:SetScript("OnDragStop", header:GetScript("OnDragStop"))
    self.conversationDragHeader = drag

    self.paneParts = {}
    local function part(f) self.paneParts[#self.paneParts + 1] = f return f end

    -- Header card: big tile, name, level · zone, note, and an icon toolbar.
    self.wash = part(pane:CreateTexture(nil, "BACKGROUND"))
    self.wash:SetPoint("TOPLEFT", 0, 0)
    self.wash:SetPoint("BOTTOMRIGHT", pane, "TOPRIGHT", 0, -64)
    self.wash:SetColorTexture(0, 0, 0, 0)

    self.bigTile = part(ns.MakeTile(pane, 40))
    self.bigTile:SetPoint("TOPLEFT", 14, -12)
    self.bigTile:EnableMouse(false)

    -- Keep the toolbar outside the drag/tooltip hit areas and above them.
    -- Mouse-enabled header frames must never compete with action buttons.
    local toolbar=CreateFrame("Frame",nil,pane)
    toolbar:SetPoint("TOPRIGHT") toolbar:SetSize(174,64)
    toolbar:SetFrameLevel(pane:GetFrameLevel()+5)
    toolbar:EnableMouse(false)
    self.toolbar=toolbar

    local function Tool(icon, tip, onClick)
        local b = part(T.WashHover(T.IconButton(toolbar, 26, icon, tip, true), tip))
        b:SetScript("OnClick", onClick)
        return b
    end
    local more = Tool(T.Icons.Dots, L["More: note, close, clear history…"], function(b) ns.Social.Menu(b, Hub.convo) end)
    more:SetPoint("TOPRIGHT", -12, -18)
    self.moreBtn=more
    local pop = Tool(T.Icons.PopOut, L["Pop out to the docked window"], function()
        local c = Hub.convo
        Hub:Close(function() ns.Window:Open(c) end)
    end)
    pop:SetPoint("RIGHT", more, "LEFT", -5, 0)
    self.popBtn = pop
    local star = part(T.WashHover(T.IconButton(toolbar, 26, T.Icons.Star, L["Star (important)"], true), L["Star (important)"]))
    star:SetScript("OnClick", function()
        local c = Hub.convo
        if c then c.starred = not c.starred or nil ns.Refresh() end
    end)
    star:SetPoint("RIGHT", pop, "LEFT", -5, 0)
    self.star = star
    local pin = Tool(T.Icons.Pin, L["Pin to the top"], function()
        local c = Hub.convo
        if c then c.pinned = not c.pinned or nil ns.Refresh() end
    end)
    pin:SetPoint("RIGHT", star, "LEFT", -5, 0)
    self.pin = pin
    local invite = Tool(T.Icons.Invite, L["Invite to group"], function()
        local c = Hub.convo
        if not c or c.kind ~= "wow" then return end
        ns.Invite(ns.WhisperTarget(c), c.guid)
    end)
    invite:SetPoint("RIGHT", pin, "LEFT", -5, 0)
    self.invite = invite

    self.name = part(T.Text(pane, 15))
    self.name:SetPoint("TOPLEFT", self.bigTile, "TOPRIGHT", 12, 0)
    self.name:SetPoint("RIGHT", invite, "LEFT", -8, 0)
    self.name:SetJustifyH("LEFT")
    self.name:SetWordWrap(false)
    self.meta = part(T.Text(pane, 10, T.SECTION))
    self.meta:SetPoint("TOPLEFT", self.name, "BOTTOMLEFT", 0, -3)
    self.meta:SetPoint("RIGHT", invite, "LEFT", -8, 0)
    self.meta:SetJustifyH("LEFT")
    self.meta:SetWordWrap(false)
    self.note = part(T.Text(pane, 10, ns.Social.STAR))
    self.note:SetPoint("TOPLEFT", self.meta, "BOTTOMLEFT", 0, -2)
    self.note:SetPoint("RIGHT", invite, "LEFT", -8, 0)
    self.note:SetJustifyH("LEFT")
    self.note:SetWordWrap(false)

    -- Hovering the tile / name shows the player tooltip.
    local nameHit = part(CreateFrame("Frame", nil, pane))
    nameHit:SetPoint("TOPLEFT", self.bigTile, "TOPLEFT", -2, 2)
    nameHit:SetPoint("BOTTOMRIGHT",pane,"TOPRIGHT",-174,-58)
    self.nameHit=nameHit
    nameHit:EnableMouse(true)
    nameHit:RegisterForDrag("LeftButton")
    nameHit:SetScript("OnDragStart", header:GetScript("OnDragStart"))
    nameHit:SetScript("OnDragStop", header:GetScript("OnDragStop"))

    nameHit:SetScript("OnEnter", function(f) ns.ShowPlayerTooltip(f, Hub.convo, "ANCHOR_BOTTOMRIGHT") end)
    nameHit:SetScript("OnLeave", function() GameTooltip:Hide() end)
    nameHit:SetScript("OnMouseUp", function(f, button)
        if button == "RightButton" then ns.Social.Menu(f, Hub.convo) end
    end)

    local pdiv = part(Divider(pane))
    pdiv:SetHeight(1)
    pdiv:SetPoint("TOPLEFT", 0, -64)
    pdiv:SetPoint("TOPRIGHT", 0, -64)

    local log = part(ns.NewBubbleLog(pane, { widthFrac = 0.72, fontSize = 14, stamps = true }))
    log:SetPoint("TOPLEFT", 16, -72)
    log:SetPoint("BOTTOMRIGHT", -16, 92)
    log.fallbackW, log.fallbackH = (self:GetWidth() or W) - LIST_W - 33, (self:GetHeight() or H_) - 164
    self.log = log

    -- Twitch Emotes (when installed) gets a button between the box and send.
    local emote = ns.Emotes.Button(pane, 32, function() return Hub.input and Hub.input.edit end)
    local input = part(T.EditBox(pane, L["Whisper…"]))
    input.wsQuietFocus = true
    input:SetPoint("BOTTOMLEFT", 16, 14)
    input:SetPoint("BOTTOMRIGHT", -64, 14)
    input:SetHeight(36)
    T.Reshape(input, 13)
    input.edit:SetScript("OnEnterPressed", function(e)
        ns.Send(Hub.convo, e:GetText())
        e:SetText("")
        Hub.log.scroll = 0
    end)
    input.wsComposerWell=T.ComposerWell(input)
    input.wsComposerWell:SetPoint("TOPLEFT",input,"TOPLEFT",1,-1)
    input.wsComposerWell:SetPoint("BOTTOMRIGHT",input,"BOTTOMRIGHT",emote and -42 or -1,1)
    input.placeholder.wsChatText=true T.StyleText(input.placeholder,14,"")
    input.edit.wsChatText=true T.ApplyFont(input.edit,14,"") input.edit:SetShadowColor(0,0,0,0)
    input:SetPlaceholder(L["Message…"])
    T.PaintComposer(input.bg,input.border,input.wsComposerWell)
    self.input = input

    local send = part(T.SendButton(pane, 36))
    self.sendBtn = send
    send:SetPoint("BOTTOMRIGHT", -16, 14)
    send:SetScript("OnClick", function()
        ns.Send(Hub.convo, input.edit:GetText())
        input.edit:SetText("")
    end)
    self.emoteBtn = emote
    if emote then
        part(emote)
        ns.Emotes.Embed(emote,input,input.edit,input.placeholder)
        if emote.controlIcon then emote.controlIcon:SetSize(22,22)end
    end

    local quick = part(ns.Social.QuickBar(pane, function() return Hub.convo end,
        function() return Hub.input and Hub.input.edit end))
    quick:SetPoint("BOTTOMLEFT", 16, 60)
    quick:SetPoint("BOTTOMRIGHT", -16, 60)
    self.quick = quick

    -- One line, clipped to the pane: wider fonts used to push it past the edge.
    local hint = part(T.Text(pane, 10, T.DIM))
    hint:SetPoint("BOTTOMLEFT", 14, 9)
    hint:SetPoint("BOTTOMRIGHT", -14, 9)
    hint:SetJustifyH("LEFT")
    hint:SetWordWrap(false)
    hint:SetText("")

    self.paneEmpty = T.Text(pane, 13, T.SECTION)
    self.paneEmpty:SetPoint("CENTER")
    self.paneEmpty:SetText(L["Pick a conversation, or type a name in the search box."])

    -- List column width: clamped so the conversation pane keeps room (>= 420px).
    function self:SetListWidth(w, live)
        local maxW = math.min(LIST_MAX, math.max(LIST_MIN, (self:GetWidth() or W) - 420))
        w = math.floor(math.max(LIST_MIN, math.min(maxW, tonumber(w) or 280)) + 0.5)
        if w == LIST_W and not self.listWDirty then return end
        self.listWDirty = nil
        LIST_W = w
        self.listHeader:ClearAllPoints()
        self.listHeader:SetPoint("TOPLEFT", 0, -3)
        self.listHeader:SetPoint("TOPRIGHT", self, "TOPLEFT", w, -3)
        self.listHdiv:ClearAllPoints()
        self.listHdiv:SetPoint("TOPLEFT", 0, -41)
        self.listHdiv:SetPoint("TOPRIGHT", self, "TOPLEFT", w, -41)
        self.search:SetWidth(w - 20)
        self.filterTrack:SetWidth(w - 20)
        self.list:SetWidth(w)
        self.selectBar:SetWidth(w)
        self.listEmpty:SetWidth(w - 30)
        self.vdiv:ClearAllPoints()
        self.vdiv:SetPoint("TOPLEFT", w, -16)
        self.vdiv:SetPoint("BOTTOMLEFT", w, 16)
        self.pane:ClearAllPoints()
        self.pane:SetPoint("TOPLEFT", w + 1, 0)
        self.pane:SetPoint("BOTTOMRIGHT", 0, 0)
        self.log.fallbackW = (self:GetWidth() or W) - w - 33
        if self.FitSearch then self:FitSearch() end
        if self.PaintChips then self:PaintChips() end
        if self.entries then self:RenderList(true) end
        if self.convo and not live then self.log:Render() end
    end

    -- Resizing: min is the original size, max is capped to the screen. The
    -- list column width is adjustable (splitter); the conversation pane takes the rest.
    local function Bounds()
        local uw, uh = UIParent:GetWidth() or 1400, UIParent:GetHeight() or 900
        return W, MIN_H, math.max(W, math.min(1400, uw - 40)), math.max(H_, math.min(900, uh - 40))
    end
    local function Clamp(w, h)
        local minW, minH, maxW, maxH = Bounds()
        w, h = tonumber(w), tonumber(h)
        if not w or not h then return nil end
        return math.max(minW, math.min(maxW, w)), math.max(minH, math.min(maxH, h))
    end
    local resizeOpts = {
        minW = W, minH = MIN_H, maxW = select(3, Bounds()), maxH = select(4, Bounds()),
        onDone = function(w, h)
            local cw, ch = Clamp(w, h)
            if cw and ns.db then ns.db.hubSize = { math.floor(cw + 0.5), math.floor(ch + 0.5) } end
            -- StartSizing re-anchors the frame; remember the new resting anchor like a drag does.
            local p, _, rp, x, y = Hub:GetPoint()
            if p then
                ns.db.hubPoint = { p, rp, x, y }
                T.Place(Hub, p, UIParent, rp, x, y)
            end
        end,
    }
    local grip = T.ResizeGrip(self, resizeOpts)
    self.resizeEdges = T.ResizeEdges(self, resizeOpts)
    -- the pane's send button ends at 16px from the corner; keep the grip clear of it
    grip:SetSize(16, 16)
    grip:ClearAllPoints()
    grip:SetPoint("BOTTOMRIGHT", 0, 0)
    self.grip = grip

    function self:ApplySavedSize()
        local minW, minH, maxW, maxH = Bounds()
        if self.SetResizeBounds then
            self:SetResizeBounds(minW, minH, maxW, maxH)
        else
            if self.SetMinResize then self:SetMinResize(minW, minH) end
            if self.SetMaxResize then self:SetMaxResize(maxW, maxH) end
        end
        local s = ns.db and ns.db.hubSize
        local w, h
        if type(s) == "table" then w, h = Clamp(s[1], s[2]) end
        if not w then w, h = Clamp(self:GetWidth(), self:GetHeight()) end
        if w and (w ~= self:GetWidth() or h ~= self:GetHeight()) then self:SetSize(w, h) end
    end

    -- Re-flow once per burst of size changes: fallbacks, list, and message wrap.
    local function Reflow()
        self.resizeQueued = nil
        local w, h = self:GetWidth() or W, self:GetHeight() or H_
        local want = ns.db and tonumber(ns.db.hubListW) or LIST_W
        self:SetListWidth(want) -- re-clamp to the new hub width
        self.log.fallbackW = w - LIST_W - 33
        self.log.fallbackH = h - 132 - (self.quickOn and 32 or 0)
        if not self:IsShown() then return end
        if self.entries then self:RenderList(true) end
        if self.convo then self.log:Render() end
    end
    self:SetScript("OnSizeChanged", function()
        if self.resizeQueued then return end
        self.resizeQueued = true
        C_Timer.After(0.05, Reflow)
    end)
    self:ApplySavedSize()
    do
        local lw = ns.db and tonumber(ns.db.hubListW)
        if lw and lw ~= LIST_W then self:SetListWidth(lw) end
    end

    self:SetScript("OnShow", function()
        for _, ev in ipairs(FRIEND_EVENTS) do pcall(self.RegisterEvent, self, ev) end
        if self.filter == "friends" then self:RequestFriends() end
        if self.PaintChips then self:PaintChips() end -- re-measure chips once fonts are ready
    end)
    self:SetScript("OnEvent", OnFriendEvent)
    self:SetScript("OnHide", function()
        for _, ev in ipairs(FRIEND_EVENTS) do pcall(self.UnregisterEvent, self, ev) end
        self:SetSelectMode(false, true) -- leave select mode when the hub closes
        self:SnapFilter() -- no half-finished slide next time it opens
        self.input.edit:ClearFocus()
        self.search.edit:ClearFocus()
    end)
end
