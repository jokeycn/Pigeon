--[[

    Pigeon - Settings

    Island-style categories and tabs over the existing Chat, Tabs, Whispers,

    Replies, Alerts, Behavior, Look and Profiles builders, built from

    small toggle / slider / choice widgets. Open with /pigeon config, the chat

    box's "=" button, or right-click a chat tab (jumps to that tab's filters).

]]

local _, ns = ...
local T = ns.Theme
local LT = ns.L
local K = ns.SettingsKit
local builders = K.builders
local FitPage, MIN_H, MIN_W, NAV_W, PAGE_KEYS, PaintSection, S, SECTION_GAP, SECTION_HEAD, SettingsButton, SettingsEditBox, SettingsText, Toggle, UpdateContentW = K.FitPage, K.MIN_H, K.MIN_W, K.NAV_W, K.PAGE_KEYS, K.PaintSection, K.S, K.SECTION_GAP, K.SECTION_HEAD, K.SettingsButton, K.SettingsEditBox, K.SettingsText, K.Toggle, K.UpdateContentW




---------------------------------------------------------------------------

-- Frame

---------------------------------------------------------------------------



local CATEGORIES = {

    { key = "general", name = LT["General"], icon = "Shield", sub = LT["Behavior and saved setups."], tabs = {

        { "behavior", LT["Behavior"] }, { "profiles", LT["Profiles"] },

    } },

    { key = "appearance", name = LT["Appearance"], icon = "Sliders", head = LT["Appearance"], sub = LT["How Pigeon looks, from panels to messages."], tabs = {

        { "look", LT["Look"], { LT["Theme"], LT["Colours"], LT["Chat window"], LT["Transparency"], LT["Settings window"] } },

        { "look", LT["Messages"], { LT["Preview"], LT["Text"], LT["Text colours"], LT["Message details"] } },
        { "look", LT["Layout"], { LT["Panels"], LT["Tiles"], LT["Size"] } },

    } },

    { key = "chat", name = LT["Chat"], icon = "List", head = LT["Features"], sub = LT["Your chat box and everyday reading."], tabs = {

        { "chat", LT["Layout"], { LT["Chat box"], "ElvUI", LT["EllesmereUI"], LT["Placement"] } },

        { "chat", LT["Tab bar"], { LT["Tab bar"], LT["Tab counters"] } },

        { "chat", LT["Text"], { LT["Text"], LT["Channel chips"], LT["History"], LT["Chat text colours"] } },

    } },

    { key = "tabs", name = LT["Tabs"], icon = "Tabs", sub = LT["Choose what each tab shows and join channels."], tabs = {
        { "tabs", LT["Tabs"] },
    } },

    { key = "whispers", name = LT["Whispers"], icon = "Person", sub = LT["Notifications, conversation tiles and quick replies."], tabs = {

        { "whispers", LT["Notifications"], { LT["Notifications"], LT["Whispers in chat"] } }, { "whispers", LT["Dock"], { LT["Dock"] } },

        { "replies", LT["Replies"], { LT["Quick replies"], LT["Away message"] } },

    } },

    { key = "alerts", name = LT["Alerts"], icon = "Bell", sub = LT["Keep useful messages in view."], tabs = {

        { "alerts", LT["Keywords"], { LT["Keyword alerts"] } }, { "alerts", LT["Filters"], { LT["Spam filter"], LT["Group finding"] } },

    } },

}

local function Category(key, tabName)

    for _, c in ipairs(CATEGORIES) do

        for _, tab in ipairs(c.tabs) do

            if tab[1] == key and (not tabName or tab[2] == tabName) then return c, tab end

        end

    end

end

local function Has(list, value)

    if not list then return true end

    for _, v in ipairs(list) do if v == value then return true end end

    return false

end



-- A bounded, scrollable list; it never modifies Blizzard's menu state.

local menu, catcher

K.CloseMenu = function()

    if menu then menu:Hide() end

    if catcher then catcher:Hide() end

end

K.OpenMenu = function(owner, options, current, pick)

    if #options == 0 then return end

    if not menu then

        catcher = CreateFrame("Button", nil, S)

        catcher:SetAllPoints(UIParent)

        catcher:SetFrameLevel(S:GetFrameLevel() + 90)

        catcher:RegisterForClicks("AnyUp")

        catcher:SetScript("OnClick", K.CloseMenu)

        menu = CreateFrame("Frame", nil, S)

        menu:SetFrameLevel(S:GetFrameLevel() + 91)

        menu:SetClampedToScreen(true)

        menu:EnableMouse(true)

        menu:EnableMouseWheel(true)

        T.Panel(menu, nil, nil, 13)

        menu.rows = {}

        for i = 1, 10 do

            local row = CreateFrame("Button", nil, menu)

            row:SetSize(248, 28)

            row:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 28)

            row.text = SettingsText(row, 12.5, T.TEXT, "", "bold")

            row.text:SetPoint("LEFT", 10, 0)

            row.text:SetPoint("RIGHT", -25, 0)

            row.text:SetJustifyH("LEFT")

            row.text:SetWordWrap(false)

            row.check = SettingsText(row, 12, T.ACCENT)

            row.check:SetPoint("RIGHT", -8, 0)

            row.check:SetText("•")

            local hl = row:CreateTexture(nil, "HIGHLIGHT")

            hl:SetAllPoints() T.Shape(hl, 8) T.Color(hl, 1, 1, 1, 0.07)

            row:SetScript("OnClick", function()

                local value, fn = row.value, menu.pick

                K.CloseMenu()

                fn(value)

            end)

            menu.rows[i] = row

        end

        function menu:Paint()

            for i, row in ipairs(self.rows) do

                local option = self.options[i + self.offset]

                row:SetShown(option ~= nil)

                if option then

                    row.value = option[1]

                    row.text:SetText(option[2])

                    row.check:SetShown(option[1] == self.current)

                end

            end

        end

        menu:SetScript("OnMouseWheel", function(_, delta)

            menu.offset = math.max(0, math.min(math.max(0, #menu.options - 10), menu.offset - delta))

            menu:Paint()

        end)

        menu:SetScript("OnHide", function() catcher:Hide() menu.owner = nil end)

        menu:Hide() catcher:Hide()

    end

    if menu:IsShown() and menu.owner == owner then K.CloseMenu() return end

    menu.owner, menu.options, menu.current, menu.pick = owner, options, current, pick

    -- Solid, so the controls behind a dropdown never show through its rows.
    local solid = T.INPUT_BG
    T.Color(menu.bg, solid[1], solid[2], solid[3], 1)

    local selected = 1

    for i, option in ipairs(options) do if option[1] == current then selected = i end end

    menu.offset = math.max(0, math.min(math.max(0, #options - 10), selected - 5))

    menu:SetSize(260, math.min(10, #options) * 28 + 12)

    menu:ClearAllPoints()

    if (owner:GetBottom() or 0) < menu:GetHeight() + 12 then

        menu:SetPoint("BOTTOMRIGHT", owner, "TOPRIGHT", 0, 4)

    else menu:SetPoint("TOPRIGHT", owner, "BOTTOMRIGHT", 0, -4) end

    menu:Paint() catcher:Show() menu:Show()

    S.choiceMenu = menu

end



K.Reflow = function(page)

    if not page.sections then return end

    FitPage(page)

    local top = 0

    local preview = page.previewDock

    local showPreview = preview and page.activeTab and page.activeTab[2] == LT["Messages"]

    if preview then preview:SetShown(showPreview and true or false) end

    local inset = showPreview and 240 or 0

    page.scrollInset = inset

    page.scroll:ClearAllPoints()

    page.scroll:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -inset)

    page.scroll:SetPoint("BOTTOMRIGHT", page, "BOTTOMRIGHT", -12, 0)

    local first = true

    for _, section in ipairs(page.sections) do

        local visible = Has(page.activeTab and page.activeTab[3], section.name)

        if visible and section.open == nil then section.open = first end

        if visible then first = false end

        section.header:SetShown(visible)

        section.card:SetShown(visible and section.open and true or false)

        if visible then

            section.y = top

            section.header:ClearAllPoints()

            section.header:SetPoint("TOPLEFT", page.content, "TOPLEFT", 0, -top)

            PaintSection(section)

            top = top + SECTION_HEAD

            section.card:ClearAllPoints()

            section.card:SetPoint("TOPLEFT", page.content, "TOPLEFT", 0, -top)

            if section.open then top = top + section.height end

            top = top + SECTION_GAP

        end

    end

    page.content:SetHeight(math.max(10, top + 12))

    page.updateScroll()

end

-- Accent / class-tint / palette changes: repaint every section bar.
hooksecurefunc(T, "Refresh", function()
    for _, page in pairs(S.pages or {}) do
        for _, section in ipairs(page.sections or {}) do
            if section.open ~= nil then PaintSection(section) end
        end
    end
end)



local STATIC_LABELS = {

    tabs = { LT["Tabs"], LT["New tab"], LT["Auto-filter"], LT["Show everything"], LT["Move"], LT["Delete tab"], LT["Tab appearance"], LT["Text size"], LT["Background"], LT["Join channel"], LT["Joined channels"], LT["Crafting"], LT["Hide keywords"] },

    profiles = { LT["Profiles"], LT["Save this setup"], LT["Load"], LT["Use here"], LT["Export setup"], LT["Import setup"], LT["Share"] },

}

function S:EnsurePage(key)

    if self.pages[key] then return self.pages[key] end

    UpdateContentW() -- builders size their widgets from the current window width

    local page = CreateFrame("Frame", nil, self)

    page.settingsKey = key

    page:SetPoint("TOPLEFT", NAV_W + 26, -112)

    page:SetPoint("BOTTOMRIGHT", -26, 20)

    page:Hide()

    builders[key](page)

    page.labels = page.labels or STATIC_LABELS[key] or {}

    self.pages[key] = page

    return page

end



-- Use the same solid selection and contrast rule as the tab cards.
local function NavigationColor(selected)
    if not selected then return T.SECTION end
    local a=T.ACCENT
    return a[1]*.299+a[2]*.587+a[3]*.114>.55 and T.DARK_TEXT or T.TEXT
end

function S:ShowPage(key, arg, tabName)

    if not builders[key] then return end

    K.CloseMenu()

    local category, tab = Category(key, tabName)

    self.remembered = self.remembered or {}

    if not tabName and self.current == key and self.activeTab and self.activeTab[1] == key then tab = self.activeTab end

    self.activeCategory, self.activeTab = category, tab

    self.remembered[category.key] = tab

    self.searchActive = nil
    if self.searchPanel then self.searchPanel:Hide() end

    for _, p in pairs(self.pages) do p:Hide() end

    local page = self:EnsurePage(key)

    page:ClearAllPoints()
    page:SetPoint("TOPLEFT", NAV_W+26, #category.tabs==1 and -80 or -112)
    page:SetPoint("BOTTOMRIGHT", -26, 20)
    page.activeTab = tab

    UpdateContentW()

    FitPage(page) -- no-op unless the window was resized while this page was hidden

    if key == "tabs" and arg then page.selected = arg end

    for _, w in ipairs(page.widgets or {}) do w:Refresh() end

    if page.Render then page:Render() end

    K.Reflow(page)

    if page.updateScroll then page.scroll:SetVerticalScroll(0) page.updateScroll() end

    page:Show()

    self.current = key

    for _, b in ipairs(self.navButtons) do

        local on = b.key == category.key

        T.Color(b.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], on and 1 or 0)

        local c = NavigationColor(on)

        b.text:SetTextColor(c[1], c[2], c[3])

        b.icon:SetIconColor(NavigationColor(on))

    end

    self.pageTitle:SetText(category.name)

    self.subtitle:SetText(category.sub)

    for _, b in ipairs(self.tabButtons) do b:Hide() b.slots = nil end

    for i, item in ipairs(category.tabs) do

        local b = self.tabButtons[i]

        if not b then

            b = CreateFrame("Button", nil, self)

            b:SetHeight(30)

            b.text = SettingsText(b, 12, T.SECTION)

            b.text:SetPoint("CENTER", 0, 3)

            b.line = T.AccentTexture(b:CreateTexture(nil, "ARTWORK"))

            b.line:SetPoint("BOTTOMLEFT") b.line:SetPoint("BOTTOMRIGHT") b.line:SetHeight(2)

            b:SetScript("OnClick", function() S:ShowPage(b.tab[1], nil, b.tab[2]) end)

            self.tabButtons[i] = b

        end

        b.tab = item

        b.slot, b.slots = i, #category.tabs

        b.text:SetText(item[2])

        local col = item == tab and T.ACCENT or T.SECTION

        b.text:SetTextColor(col[1], col[2], col[3])

        b.line:SetShown(item == tab) b:SetShown(#category.tabs>1)

    end

    self:LayoutTabButtons()

    if self.resultBox then self.resultBox:Hide() end

end

-- Category tab buttons split the page width evenly.
function S:LayoutTabButtons()
    for _, b in ipairs(self.tabButtons or {}) do
        if b.slots then
            local w = K.CONTENT_W / b.slots
            b:SetWidth(w)
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", self, "TOPLEFT", NAV_W + 26 + (b.slot - 1) * w, -76)
        end
    end
end

-- Window resized: refit the visible page and the tab strip. Hidden pages refit
-- lazily in ShowPage (FitPage compares page.fitW with CONTENT_W).
function S:Relayout()
    self.lastRelayout = GetTime()
    UpdateContentW()
    self:LayoutTabButtons()
    local page = self.current and self.pages[self.current]
    if page then
        if page.sections then
            K.Reflow(page)
        else
            FitPage(page)
            if page.updateScroll then page.updateScroll() end
        end
    end
end

-- Throttled entry for OnSizeChanged while dragging: at most one relayout per
-- 0.03s, with a trailing call so the final size is always applied.
function S:RequestRelayout()
    if not self.built then return end
    local now = GetTime()
    if now - (self.lastRelayout or 0) >= 0.03 then
        self:Relayout()
    elseif not self.relayoutQueued and C_Timer and C_Timer.After then
        self.relayoutQueued = true
        C_Timer.After(0.04, function()
            S.relayoutQueued = nil
            if S:IsShown() then S:Relayout() end
        end)
    end
end

function S:NeedReload() if self.reloadBtn then self.reloadBtn:Show() end end

function S:RefreshChrome()

    for _, b in ipairs(self.navButtons or {}) do

        local on = self.activeCategory and b.key == self.activeCategory.key

        T.Color(b.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], on and 1 or 0)

        b.icon:SetIconColor(NavigationColor(on))
        local file = T.FONT
        if not (ns.db.look and ns.db.look.font) and type(IslandXP_FontPath) == "function" then file = IslandXP_FontPath("medium") or file end
        local family = T.FontFamily(file,13,"")
        if family and b.text.SetFontObject then b.text:SetFontObject(family) else b.text:SetFont(file,13,"") end
        b.text:SetShadowColor(0,0,0,0)
        local color = NavigationColor(on)
        b.text:SetTextColor(color[1],color[2],color[3])

    end

end



-- Search results take over the settings panel (like Island's settings search): one
-- row per match with where it lives, instead of a small dropdown under the box.
function S:BuildSearchPanel()
    if self.searchPanel then return self.searchPanel end
    local p = CreateFrame("Frame", nil, self)
    p:SetPoint("TOPLEFT", NAV_W + 26, -80)
    p:SetPoint("BOTTOMRIGHT", -26, 20)
    p:Hide()
    local scroll = CreateFrame("ScrollFrame", nil, p)
    scroll:SetAllPoints()
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(1, 1)
    scroll:SetScrollChild(child)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(s, delta)
        local max = math.max(0, child:GetHeight() - s:GetHeight())
        s:SetVerticalScroll(math.max(0, math.min(max, s:GetVerticalScroll() - delta * 54)))
    end)
    p:SetScript("OnSizeChanged", function(_, w) child:SetWidth(math.max(1, w)) end)
    p.scroll, p.child, p.rows = scroll, child, {}
    self.searchPanel = p
    return p
end

local function OpenResult(r)
    S.search.edit:SetText("") S.search.edit:ClearFocus()
    S:ShowPage(r[1], nil, r.tab and r.tab[2])
    if r.entry then
        local page = S.pages[r[1]]
        r.entry.section.open = true K.Reflow(page)
        local maxScroll = math.max(0, page.content:GetHeight() - page.scroll:GetHeight())
        page.scroll:SetVerticalScroll(math.min(maxScroll, r.entry.section.y + SECTION_HEAD + (r.entry.widget.settingsOffset or 0)))
        page.updateScroll()
        local label = r.entry.widget.text
        label:SetTextColor(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3])
        if C_Timer and C_Timer.After then C_Timer.After(2, function() label:SetTextColor(T.LABEL[1], T.LABEL[2], T.LABEL[3]) end) end
    end
end

function S:HideResults()
    if not self.searchActive then return end
    self.searchActive = nil
    if self.searchPanel then self.searchPanel:Hide() end
    local prev = self.searchPrev
    if prev and prev[1] then self:ShowPage(prev[1], nil, prev[2]) end
end

function S:ShowResults(q, results)
    if #q < 2 then self:HideResults() return end
    local p = self:BuildSearchPanel()
    if not self.searchActive then
        self.searchActive = true
        self.searchPrev = { self.current, self.activeTab and self.activeTab[2] }
    end
    for _, page in pairs(self.pages) do page:Hide() end
    for _, tb in ipairs(self.tabButtons) do tb:Hide() end
    self.pageTitle:SetText(LT["Search settings"])
    self.subtitle:SetText(#results == 0 and LT["Nothing matches."] or LT["Select a result to open its setting."])
    p.child:SetWidth(math.max(1, p:GetWidth()))
    local ROW, GAP = 50, 4
    for i, r in ipairs(results) do
        local row = p.rows[i]
        if not row then
            row = CreateFrame("Button", nil, p.child)
            row:SetHeight(ROW)
            row.bg = T.ShapeFill(row, { 1, 1, 1, 0.045 }, 10)
            row.label = SettingsText(row, 13, T.TEXT)
            row.label:SetPoint("TOPLEFT", 14, -9) row.label:SetPoint("RIGHT", -14, 0)
            row.label:SetJustifyH("LEFT") row.label:SetWordWrap(false)
            row.context = SettingsText(row, 10.5, T.SECTION)
            row.context:SetPoint("TOPLEFT", 14, -29) row.context:SetPoint("RIGHT", -14, 0)
            row.context:SetJustifyH("LEFT") row.context:SetWordWrap(false)
            row:SetScript("OnEnter", function(self) T.Color(self.bg, 1, 1, 1, 0.10) end)
            row:SetScript("OnLeave", function(self) T.Color(self.bg, 1, 1, 1, 0.045) end)
            row:SetScript("OnClick", function(self) OpenResult(self.result) end)
            p.rows[i] = row
        end
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -(i - 1) * (ROW + GAP))
        row:SetPoint("TOPRIGHT", p.child, "TOPRIGHT", 0, -(i - 1) * (ROW + GAP))
        row.result, row.key = r, r[1]
        row.label:SetText(r[3])
        local where = r[2]
        if r.tab then where = where .. "  >  " .. r.tab[2] end
        if r.entry and r.entry.section and r.entry.section.name then where = where .. "  >  " .. r.entry.section.name end
        row.context:SetText(where)
        row:Show()
    end
    for i = #results + 1, #p.rows do p.rows[i]:Hide() end
    p.child:SetHeight(math.max(1, #results * (ROW + GAP)))
    p.scroll:SetVerticalScroll(0)
    p:Show()
end

-- Search records real controls and their section, including folded and inactive tabs.

function S:Search(text)

    K.CloseMenu()

    local q = strtrim(text or ""):lower()

    local results = {}

    if #q >= 2 then

        for _, key in ipairs(PAGE_KEYS) do

            local page = self:EnsurePage(key)

            local category = Category(key)

            local seen = {}

            for _, entry in ipairs(page.entries or {}) do

                local tab

                for _, candidate in ipairs(category.tabs) do

                    if candidate[1] == key and Has(candidate[3], entry.section.name) then tab = candidate break end

                end

                local options = entry.widget.settingsOptions

                if type(options) == "function" then options = options() end

                local choices = {}

                for _, option in ipairs(type(options) == "table" and options or {}) do choices[#choices + 1] = option[2] end

                local words = (category.name .. " " .. (tab and tab[2] or "") .. " " .. entry.section.name .. " " .. entry.label .. " " .. table.concat(choices, " ")):lower()

                local match = true

                for word in q:gmatch("%S+") do if not words:find(word, 1, true) then match = false break end end

                if match and not seen[entry.label] then

                    seen[entry.label] = true

                    results[#results + 1] = { key, category.name, entry.label, tab = tab, entry = entry }

                end

            end

            for _, label in ipairs(page.labels or {}) do

                if not seen[label] and label:lower():find(q, 1, true) then

                    seen[label] = true

                    results[#results + 1] = { key, category.name, label }

                end

            end

        end

    end

    self.results = results
    self:ShowResults(q, results)
    return results

end



-- Resizing: the minimum is the original 780x580 so nothing is ever tighter than
-- before; the maximum is capped to the screen.
local function SizeBounds()
    local uw, uh = UIParent:GetWidth() or 1400, UIParent:GetHeight() or 900
    return MIN_W, MIN_H, math.max(MIN_W, math.min(1200, uw - 40)), math.max(MIN_H, math.min(900, uh - 40))
end

local function ClampSize(w, h)
    w, h = tonumber(w), tonumber(h)
    if not w or not h then return nil end
    local minW, minH, maxW, maxH = SizeBounds()
    return math.max(minW, math.min(maxW, w)), math.max(minH, math.min(maxH, h))
end

-- Applies the resize bounds and the saved (account-wide) size, if any.
function S:ApplySavedSize()
    local minW, minH, maxW, maxH = SizeBounds()
    if self.SetResizeBounds then
        self:SetResizeBounds(minW, minH, maxW, maxH)
    else
        if self.SetMinResize then self:SetMinResize(minW, minH) end
        if self.SetMaxResize then self:SetMaxResize(maxW, maxH) end
    end
    local saved = ns.db and ns.db.settingsSize
    local w, h
    if type(saved) == "table" then w, h = ClampSize(saved[1], saved[2]) end
    if not w then w, h = ClampSize(self:GetWidth(), self:GetHeight()) end
    if w and (w ~= self:GetWidth() or h ~= self:GetHeight()) then
        self:SetSize(w, h)
        UpdateContentW()
    end
end

function S:Build()

    if self.built then return end

    self.built = true

    T.Panel(self) T.Reshape(self, 26)

    self.wsMinAlpha = 0.97

    T.Refresh()

    tinsert(UISpecialFrames, "PigeonSettings")

    local header = CreateFrame("Frame", nil, self)

    header:SetPoint("TOPLEFT") header:SetPoint("TOPRIGHT") header:SetHeight(72)

    header:EnableMouse(true) header:RegisterForDrag("LeftButton")

    header:SetScript("OnDragStart", function() S:StartMoving() end)

    header:SetScript("OnDragStop", function()

        S:StopMovingOrSizing()

        local p, _, rp, x, y = S:GetPoint() T.Place(S, p, UIParent, rp, x, y)

    end)

    local logo = header:CreateTexture(nil, "ARTWORK")

    logo:SetTexture(T.MEDIA .. "Symbols\\BIRD.tga") logo:SetSize(30, 30) logo:SetPoint("TOPLEFT", 20, -24)

    logo.wsShaped = true -- preserve the bird artwork when theme colours refresh
    T.AccentTexture(logo)

    self.title = SettingsText(header, 18, T.TEXT) self.title:SetPoint("LEFT", logo, "RIGHT", 10, 5) self.title:SetText("Pigeon")

    local version = SettingsText(header, 10.5, T.SECTION, "", "medium") version:SetPoint("TOPLEFT", self.title, "BOTTOMLEFT", 0, -2)

    local metadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata

    local ok, value = pcall(metadata or function() end, "Pigeon", "Version")

    version:SetText(LT["Version %s"]:format(ok and value or "?"))

    self.pageTitle = SettingsText(header, 21, T.TEXT) self.pageTitle:SetPoint("TOPLEFT", NAV_W + 26, -23)

    self.subtitle = SettingsText(header, 12, T.SECTION) self.subtitle:SetPoint("TOPLEFT", self.pageTitle, "BOTTOMLEFT", 0, -5)

    local close = T.GlyphButton(header, "x", 24) close:SetPoint("TOPRIGHT", -14, -16)

    close:SetScript("OnClick", function() S:Close() end)

    self.closeBtn, self.titleText, self.dragHeader = close, self.title, header

    local search = T.Reshape(SettingsEditBox(self, LT["Search settings"]), 10)

    search:SetSize(NAV_W - 36, 30) search:SetPoint("TOPLEFT", 18, -78)

    search.edit:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])

    search.wsQuietFocus = true
    self.search = search

    -- An x to clear the search, shown while there is text.
    local clear = T.IconButton(search, 20, T.Icons.Close, LT["Clear search"])
    clear:SetPoint("RIGHT", search, "RIGHT", -6, 0)
    clear:SetFrameLevel(search:GetFrameLevel() + 6)
    clear:SetScript("OnClick", function() search.edit:SetText("") search.edit:ClearFocus() end)
    clear:Hide()
    do
        local l, r, t, bt = search.edit:GetTextInsets()
        search.edit:SetTextInsets(l or 0, (r or 0) + 24, t or 0, bt or 0)
    end
    search.edit:HookScript("OnTextChanged", function(e) clear:SetShown((e:GetText() or "") ~= "") end)

    local box = self:BuildSearchPanel() -- results take over the content area
    self.resultBox = box

    search.edit:HookScript("OnTextChanged", function(e) S:Search(e:GetText()) end)

    search.edit:SetScript("OnEnterPressed", function(e)

        local first = box.rows[1]

        if first and first:IsShown() then first:GetScript("OnClick")(first) end e:ClearFocus()

    end)

    search.edit:HookScript("OnEscapePressed", function(e) e:SetText("") box:Hide() K.CloseMenu() end)

    local reload = SettingsButton(self, LT["Reload to apply"], NAV_W - 40, 26, true)

    reload:SetPoint("BOTTOMLEFT", 20, 70) reload:SetScript("OnClick", function() ReloadUI() end) reload:Hide() self.reloadBtn = reload

    local rule = self:CreateTexture(nil, "ARTWORK") rule:SetColorTexture(1, 1, 1, 0.06) rule:SetWidth(1)

    rule:SetPoint("TOPLEFT", NAV_W, -18) rule:SetPoint("BOTTOMLEFT", NAV_W, 18)

    self.navButtons, self.tabButtons = {}, {}

    local navIcons = { appearance="Drop", chat="Chat", whispers="Mail", alerts="Bell", general="Gear" }
    local y = -120

    for _, c in ipairs(CATEGORIES) do

        if c.head then

            local h = SettingsText(self, 9.5, T.SECTION, "") h:SetPoint("TOPLEFT", 24, y - 8) h:SetText(c.head:upper()) y = y - 28

        end

        local b = CreateFrame("Button", nil, self)

        b:SetSize(NAV_W - 28, 30) b:SetPoint("TOPLEFT", 14, y) b.key = c.key

        b.bg = T.ShapeFill(b, { 0, 0, 0, 0 }, 12)

        b.icon = T.DrawIcon(CreateFrame("Frame", nil, b), function(f, Bar)
            local tex = Bar(16,16,0,0)
            tex:SetTexture(c.key=="tabs" and (T.MEDIA .. "Controls\\Tabs.tga") or (T.MEDIA .. "Navigation\\" .. navIcons[c.key] .. ".tga"))
            tex.wsShaped = true
        end)

        b.icon:SetSize(15, 15) b.icon:SetPoint("LEFT", 12, 0) b.icon:SetIconColor(T.SECTION)

        b.text = SettingsText(b, 13, T.LABEL, "") b.text:SetPoint("LEFT", 37, 0) b.text:SetText(c.name)

        local hl = b:CreateTexture(nil, "HIGHLIGHT") hl:SetAllPoints() T.Shape(hl, 10) T.Color(hl, 1, 1, 1, 0.04)

        b:SetScript("OnClick", function()

            search.edit:SetText("")

            local tab = S.remembered and S.remembered[c.key] or c.tabs[1]

            S:ShowPage(tab[1], nil, tab[2])

        end)

        local file = T.FONT
        if not (ns.db.look and ns.db.look.font) and type(IslandXP_FontPath) == "function" then
            file = IslandXP_FontPath("medium") or file
        end
        local family = T.FontFamily(file, 13, "")
        if family and b.text.SetFontObject then b.text:SetFontObject(family) else b.text:SetFont(file,13,"") end
        b.text:SetShadowColor(0,0,0,0)
        self.navButtons[#self.navButtons + 1] = b y = y - 34

    end

    local hint = SettingsText(self, 10.5, T.SECTION) hint:SetPoint("BOTTOMLEFT", 24, 24) hint:SetText(LT["Type /pigeon config\nto open settings."])

    -- Resize grip (bottom-right corner). OnSizeChanged re-flows the page,
    -- throttled; releasing the grip saves the size and does a final full relayout.
    local _, _, maxW, maxH = SizeBounds()
    self.grip = T.ResizeGrip(self, {
        minW = MIN_W, minH = MIN_H, maxW = maxW, maxH = maxH,
        onDone = function(w, h)
            local cw, ch = ClampSize(w, h)
            if cw and ns.db then ns.db.settingsSize = { math.floor(cw + 0.5), math.floor(ch + 0.5) } end
            -- StartSizing re-anchors the frame; remember the new resting anchor like a drag does.
            local p, _, rp, x, y = S:GetPoint()
            if p then T.Place(S, p, UIParent, rp, x, y) end
            S:Relayout()
        end,
    })
    self:HookScript("OnSizeChanged", function() S:RequestRelayout() end)

    self:HookScript("OnHide", function()

        K.CloseMenu() box:Hide() search.edit:ClearFocus()

        for _, p in pairs(self.pages) do if p.name then p.name.edit:ClearFocus() end end

    end)

end

function S:Open(page, arg)

    self:Build()

    self:ApplySavedSize()

    if not T.IsOpen(self) then

        if not self.wsAnchor then T.Place(self, "CENTER", UIParent, "CENTER", 0, 40) end

        self:Show() self:Raise() self.wsP = 0 T.Reveal(self, { dy = -10, dur = 0.22 })

    end

    self:ShowPage(page or self.current or "look", arg)

end

function S:Close() K.CloseMenu() T.Conceal(self, { dy = -10, dur = 0.18 }) end

function S:Toggle(page)

    if T.IsOpen(self) and (not page or page == self.current) then self:Close() else self:Open(page) end

end

