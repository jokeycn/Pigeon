--[[

    Pigeon - Theme

    Pigeon's own look: flat dark panels, thin borders, an accent colour and

    the game font, all adjustable on the Look page. Optional compatibility:

    when Horizon Suite, ElvUI or EllesmereUI is loaded, their font and colours

    can be followed instead of the defaults below.

]]



local ADDON_FOLDER, ns = ...
local L = ns.L

local T = {}

ns.Theme = T



-- Default palette.

T.BACKDROP     = { 0.08, 0.08, 0.12, 0.90 }

T.BORDER       = { 0.35, 0.38, 0.45, 0.45 }

T.CARD         = { 0.09, 0.09, 0.11, 0.96 }

T.CARD_BORDER  = { 0.18, 0.20, 0.24, 0.60 }

T.INPUT_BG     = { 0.07, 0.07, 0.10, 0.96 }

T.INPUT_BORDER = { 0.20, 0.22, 0.28, 0.60 }

T.DIVIDER      = { 0.35, 0.40, 0.50, 0.25 }

T.ACCENT       = { 0.48, 0.58, 0.82, 1 }

T.TEXT         = { 1, 1, 1, 1 }

T.LABEL        = { 0.84, 0.84, 0.88, 1 }

T.SECTION      = { 0.58, 0.64, 0.74, 1 }

T.DIM          = { 0.44, 0.47, 0.56, 1 }

T.WHISPER      = { 1, 0.5, 1, 1 }

T.WHISPER_SELF = { 1, 0.84, 1, 1 }

T.BNET         = { 0.51, 0.77, 1, 1 }

T.YOURS        = { 1, 1, 1, 1 }

T.DARK_TEXT    = { 0.06, 0.06, 0.08, 1 }



T.FONT = STANDARD_TEXT_FONT



-- Colours the Look page can override; restored before each refresh so

-- switching an override back to "auto" really goes back.

local BASE = {}

for _, k in ipairs({ "BACKDROP", "BORDER", "CARD", "CARD_BORDER", "INPUT_BG", "INPUT_BORDER", "DIVIDER", "TEXT", "LABEL", "SECTION", "DIM", "WHISPER", "YOURS", "BNET" }) do

    local c = T[k]

    BASE[k] = { c[1], c[2], c[3], c[4] }

end



local fontStrings = {}   -- every FontString we style, so a font change can be re-applied

local accentTextures = {} -- textures painted with the accent colour

local panels = {}         -- panels using the default backdrop/border, repainted on theme changes

local inputs = {}         -- composers and search fields following the input palette

local accentBorders = {}  -- borders painted with the accent colour



local function copy(c)

    return { c[1], c[2], c[3], c[4] }

end



function T.ClassColor(classFile)

    if classFile then

        -- Respect class colour overrides from ElvUI / !ClassColors style addons.

        local c = CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[classFile]

        if not c and C_ClassColor and C_ClassColor.GetClassColor then

            c = C_ClassColor.GetClassColor(classFile)

        end

        if not c and RAID_CLASS_COLORS then

            c = RAID_CLASS_COLORS[classFile]

        end

        if c then return c.r, c.g, c.b end

    end

    return T.SECTION[1], T.SECTION[2], T.SECTION[3]

end



-- Pull live values from Horizon Suite when it is loaded.

local function ReadHorizon()

    local hs = _G.HorizonSuite

    local font = GameFontNormal and GameFontNormal:GetFont()

    if type(hs) == "table" then

        if type(hs.FONT_PATH) == "string" and hs.FONT_PATH ~= "" then

            font = hs.FONT_PATH

        end

        if type(hs.GetActiveGlobalFont) == "function" then

            local ok, f = pcall(hs.GetActiveGlobalFont)

            if ok and type(f) == "string" and f ~= "" then font = f end

        end

        if type(hs.Design) == "table" then

            if hs.Design.BACKDROP_COLOR then T.BACKDROP = copy(hs.Design.BACKDROP_COLOR) end

            if hs.Design.BORDER_COLOR then T.BORDER = copy(hs.Design.BORDER_COLOR) end

        end

        if type(hs.GetDB) == "function" then

            local ok, r, g, b = pcall(function()

                return hs.GetDB("backdropColorR", nil), hs.GetDB("backdropColorG", nil), hs.GetDB("backdropColorB", nil)

            end)

            if ok and tonumber(r) and tonumber(g) and tonumber(b) then

                T.BACKDROP = { tonumber(r), tonumber(g), tonumber(b), T.BACKDROP[4] or 0.9 }

            end

        end

    end

    T.FONT = font or STANDARD_TEXT_FONT

end



-- Fonts from UI addons often only carry Latin letters, so Chinese,

-- Korean or Cyrillic text would show as empty boxes. The game's own chat

-- avoids that with a font family: one font per alphabet. Build the same

-- thing around the theme font (cached per font/size/outline).

local FALLBACKS = {

    { "korean", "Fonts\\2002.TTF" },

    { "simplifiedchinese", "Fonts\\ARKai_T.ttf" },

    { "traditionalchinese", "Fonts\\blei00d.TTF" },

    { "russian", "Fonts\\FRIZQT___CYR.TTF" },

}

local families, familyCount = {}, 0

function T.FontFamily(file, size, flags)

    if type(CreateFontFamily) ~= "function" then return nil end

    size = math.floor((size or 13) * 2 + 0.5) / 2

    flags = flags or ""

    local key = file .. "|" .. size .. "|" .. flags

    if families[key] ~= nil then return families[key] or nil end

    local members = { { alphabet = "roman", file = file, height = size, flags = flags } }

    for _, fb in ipairs(FALLBACKS) do

        members[#members + 1] = { alphabet = fb[1], file = fb[2], height = size, flags = flags }

    end

    familyCount = familyCount + 1

    local ok, font = pcall(CreateFontFamily, "PigeonFont" .. familyCount, members)

    families[key] = (ok and font) or false

    return families[key] or nil

end



-- Point a FontString / EditBox / ScrollingMessageFrame at the theme font,

-- with the other alphabets filled in whenever the client supports it.

function T.TextScale()
    local s = ns.db and ns.db.look and ns.db.look.uiTextScale
    if type(s) == "number" and s >= 0.8 and s <= 1.6 then return s end
    return 1
end

function T.ApplyFont(obj, size, flags)

    flags = flags or ""

    local file = T.FONT
    -- The chat concept uses readable medium-weight text; keep manual font choices.
    if obj.wsChatText and not (ns.db and ns.db.look and ns.db.look.font) and ns.Island and ns.Island.Loaded() then
        file = type(IslandXP_FontPath) == "function" and IslandXP_FontPath("medium") or "Interface\\AddOns\\Island\\Media\\Fonts\\OpenSans-Medium.ttf"
    end
    if obj.wsSettingsWeight and not (ns.db and ns.db.look and ns.db.look.font) and ns.Island and ns.Island.Loaded() then
        size = obj.wsSettingsSize or size
        local weight = obj.wsSettingsWeight
        file = type(IslandXP_FontPath) == "function" and IslandXP_FontPath(weight) or
            ("Interface\\AddOns\\Island\\Media\\Fonts\\OpenSans-" .. ({medium="Medium",bold="Bold",extra="ExtraBold"})[weight] .. ".ttf")
    end
    -- Look > Size > Interface text: one multiplier for every label Pigeon styles. Chat
    -- message text keeps its own size setting.
    if not obj.wsNoScale then size = math.floor(size * T.TextScale() + 0.5) end
    local fam = T.FontFamily(file, size, flags)

    if fam and obj.SetFontObject then

        obj:SetFontObject(fam)

        if obj:GetFont() then return end

    end

    obj:SetFont(file, size, flags)

    if not obj:GetFont() then obj:SetFont(STANDARD_TEXT_FONT, size, flags) end

end



function T.StyleText(fs, size, flags)

    flags = flags or "OUTLINE"

    T.ApplyFont(fs, size, flags)

    fs:SetShadowColor(0, 0, 0, flags == "" and 0 or 1)

    fs:SetShadowOffset(1, -1)

    fs.wsSize, fs.wsFlags = size, flags

end



function T.Text(parent, size, color, flags)

    local fs = parent:CreateFontString(nil, "OVERLAY")

    T.StyleText(fs, size, flags)

    if color then fs:SetTextColor(color[1], color[2], color[3], color[4] or 1) end

    -- Remember palette roles so labels follow a theme change while already open.

    for key in pairs(BASE) do

        if color == T[key] then fs.wsColorKey = key break end

    end

    fontStrings[#fontStrings + 1] = fs

    return fs

end



---------------------------------------------------------------------------

-- Shapes: rounded corners from small 9-slice textures shipped in Media/.

-- A shaped texture keeps its image and is tinted with vertex colours, so

-- everything that colours one goes through T.Color (a plain

-- SetColorTexture would replace the shape with a square).

-- Look page > Corner radius: 0 (square) to 8 (the original look), applied live by T.ApplyCorners.
-- ns.db.look.cornerRadius; nil falls back to the old look.corners key
-- ("square" = 0), otherwise 8 (the original rounded look).
---------------------------------------------------------------------------

T.MEDIA = "Interface\\AddOns\\" .. ADDON_FOLDER .. "\\Media\\"

local RADII = { 4, 6, 8, 10, 12, 16 }

-- With the Island XP look on, every corner is a step rounder.
local ISLAND_RADIUS = { [4] = 6, [6] = 8, [8] = 12, [10] = 16, [12] = 16 }

-- Everything T.Shape / T.ShapeMask / T.Border touched, so T.ApplyCorners can
-- re-shape it when the slider moves. Weak keys: dead frames drop out.
local shaped = setmetatable({}, { __mode = "k" })  -- shaped textures (design radius in tex.wsDesign)
local masks = setmetatable({}, { __mode = "k" })   -- shaped mask textures
local borders = setmetatable({}, { __mode = "k" }) -- 1px borders that swap ring <-> four lines
local cornerHooks = {}
local appliedCorner

local function CornerValue()
    local L = ns.db and ns.db.look
    if not L then return 8 end
    local v = tonumber(L.cornerRadius)
    if v == nil then v = (L.corners == "square") and 0 or 8 end
    return math.max(0, math.min(8, v)) -- 8 is the original look and the maximum
end

function T.CornerRadius() return CornerValue() end

function T.Rounded()
    return CornerValue() > 0 and T.canRound ~= false
end

-- Slider 8 = today's look: each design radius is scaled by value / 8, then
-- snapped to the nearest shipped texture.
local function NearestRadius(r)
    r = r * math.max(CornerValue(), 1) / 8
    local best = RADII[1]
    for _, x in ipairs(RADII) do if math.abs(x - r) < math.abs(best - r) then best = x end end
    if ns.Island and ns.Island.Active() then best = ISLAND_RADIUS[best] or best end
    return best
end

local function SkinShape(tex, radius, line)
    local r = NearestRadius(radius)
    tex:SetTexture(T.MEDIA .. "Round" .. r .. (line and "Line" or ""))
    local m = r + 1
    tex:SetTextureSliceMargins(m, m, m, m)
    if tex.SetTextureSliceMode then
        tex:SetTextureSliceMode((Enum and Enum.UITextureSliceMode and Enum.UITextureSliceMode.Stretched) or 0)
    end
    tex.wsShaped = true
    return true
end

-- Give tex a rounded shape (radius in UI units). Returns true if shaped.
-- The texture is remembered either way, so it can be shaped later.
function T.Shape(tex, radius, line)
    if not radius then return false end
    if tex.SetTextureSliceMargins then
        tex.wsDesign, tex.wsLine, tex.wsKeep = radius, line and true or nil, true
        shaped[tex] = true
    end
    if tex.wsFlat then return false end -- squared on purpose (classic chat)
    if not T.Rounded() then return false end
    if not tex.SetTextureSliceMargins then T.canRound = false return false end
    return SkinShape(tex, radius, line)
end

-- Shape a mask texture like a rounded fill of the same radius (same image,
-- same 9-slice corners), so what it clips lines up with shaped textures.
-- Returns true when the corners are sliced (exact), false when the image
-- is only stretched (close).
function T.ShapeMask(mask, radius)
    masks[mask] = true
    mask.wsDesign = radius
    local r = NearestRadius(radius)
    mask:SetTexture(T.MEDIA .. "Round" .. r, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    if type(mask.SetTextureSliceMargins) ~= "function" then return false end
    local m = r + 1
    local ok = pcall(mask.SetTextureSliceMargins, mask, m, m, m, m)
    if ok and mask.SetTextureSliceMode then
        pcall(mask.SetTextureSliceMode, mask, (Enum and Enum.UITextureSliceMode and Enum.UITextureSliceMode.Stretched) or 0)
    end
    return ok
end

function T.Circle(tex)
    tex:SetTexture(T.MEDIA .. "Circle")
    tex.wsShaped = true
end

-- Colour any of our textures, shaped or plain.
function T.Color(tex, r, g, b, a)
    if type(r) == "table" then r, g, b, a = r[1], r[2], r[3], a or r[4] end
    if tex.wsKeep then tex.wsR, tex.wsG, tex.wsB, tex.wsA = r, g, b, a or 1 end -- so a corner change can restore it
    if tex.wsShaped then
        tex:SetVertexColor(r, g, b, a or 1)
    else
        tex:SetColorTexture(r, g, b, a or 1)
    end
end

-- Change the corner radius of something built with T.Panel / T.EditBox.
function T.Reshape(frame, radius)
    if frame.bg and (frame.bg.wsShaped or frame.bg.wsDesign) then T.Shape(frame.bg, radius) end
    local border = frame.border
    if border and border.cradius then
        border.cradius = radius
        if border.ring then T.Shape(border.ring, radius, true) end
    elseif border and #border == 1 and border[1].wsShaped then
        T.Shape(border[1], radius, true)
    end
    if frame.sheen and (frame.sheen.wsShaped or frame.sheen.wsDesign) then T.Shape(frame.sheen, radius) end
    frame.wsRadius = radius
    return frame
end

-- A filled shape covering frame (or a square fill when rounding is off).
function T.ShapeFill(frame, color, radius, layer, sublevel)
    local tex = frame:CreateTexture(nil, layer or "BACKGROUND", nil, sublevel)
    tex:SetAllPoints()
    T.Shape(tex, radius)
    T.Color(tex, color)
    return tex
end

function T.Fill(frame, color, layer)
    local tex = frame:CreateTexture(nil, layer or "BACKGROUND")
    tex:SetAllPoints()
    tex:SetColorTexture(color[1], color[2], color[3], color[4] or 1)
    return tex
end

-- Four edge textures of thickness t.
local function MakeEdges(frame, color, t)
    local function edge()
        local tex = frame:CreateTexture(nil, "BORDER")
        tex.wsKeep = true
        T.Color(tex, color)
        return tex
    end
    local top, bottom, left, right = edge(), edge(), edge(), edge()
    top:SetPoint("TOPLEFT"); top:SetPoint("TOPRIGHT"); top:SetHeight(t)
    bottom:SetPoint("BOTTOMLEFT"); bottom:SetPoint("BOTTOMRIGHT"); bottom:SetHeight(t)
    left:SetPoint("TOPLEFT"); left:SetPoint("BOTTOMLEFT"); left:SetWidth(t)
    right:SetPoint("TOPRIGHT"); right:SetPoint("BOTTOMRIGHT"); right:SetWidth(t)
    return { top, bottom, left, right }
end

-- Crisp 1px (or n px) border. With a radius and 1px it is one rounded ring,
-- or four lines when corners are off; the returned table switches between the
-- two live (fixed = true opts out, for borders the caller swaps itself).
function T.Border(frame, color, thickness, radius, fixed)
    local t = thickness or 1
    if radius and t == 1 then
        local border = {}
        if not fixed then
            border.cframe, border.cradius = frame, radius
            borders[border] = true
        end
        if T.Rounded() then
            local line = frame:CreateTexture(nil, "BORDER")
            line:SetAllPoints()
            if T.Shape(line, radius, true) then
                T.Color(line, color)
                border.ring = line
                border[1] = line
                return border
            end
            line:Hide()
        end
        local e = MakeEdges(frame, color, 1)
        border.edges = e
        for i = 1, 4 do border[i] = e[i] end
        return border
    end
    return MakeEdges(frame, color, t)
end

-- Swap one border between its ring and its four lines.
local function SwitchBorder(b, rounded)
    local frame = b.cframe
    if not frame then return end
    if rounded then
        if b.ring and b[1] == b.ring then return end
        local e = b.edges
        local shown = not e or e[1]:IsShown()
        local ring = b.ring
        if not ring then
            ring = frame:CreateTexture(nil, "BORDER")
            ring:SetAllPoints()
            if not T.Shape(ring, b.cradius, true) then ring:Hide() return end
            b.ring = ring
        end
        if e then
            T.Color(ring, e[1].wsR or 1, e[1].wsG or 1, e[1].wsB or 1, e[1].wsA or 1)
            for i = 1, 4 do e[i]:Hide() b[i] = nil end
        end
        b[1] = ring
        ring:SetShown(shown)
    else
        local e = b.edges
        if e and b[1] == e[1] then return end
        local ring = b.ring
        local shown = not ring or ring:IsShown()
        if not e then
            e = MakeEdges(frame, ring and { ring.wsR or 1, ring.wsG or 1, ring.wsB or 1, ring.wsA or 1 } or T.BORDER, 1)
            b.edges = e
        elseif ring then
            for i = 1, 4 do T.Color(e[i], ring.wsR or 1, ring.wsG or 1, ring.wsB or 1, ring.wsA or 1) end
        end
        if ring then ring:Hide() end
        for i = 1, 4 do b[i] = e[i] e[i]:SetShown(shown) end
    end
end

-- Put one registered texture in the shape for the current radius.
local function Reskin(tex, rounded)
    if rounded then
        local wasFlat = not tex.wsShaped
        if SkinShape(tex, tex.wsDesign, tex.wsLine) then
            if wasFlat then tex:SetVertexColor(tex.wsR or 1, tex.wsG or 1, tex.wsB or 1, tex.wsA or 1) end
            if tex.wsCornerHid then tex.wsCornerHid = nil tex:Show() end
        end
    elseif tex.wsLine then
        if tex:IsShown() then tex.wsCornerHid = true tex:Hide() end
    elseif tex.wsShaped then
        tex.wsShaped = nil
        pcall(tex.SetTextureSliceMargins, tex, 0, 0, 0, 0)
        tex:SetVertexColor(1, 1, 1, 1)
        tex:SetColorTexture(tex.wsR or 1, tex.wsG or 1, tex.wsB or 1, tex.wsA or 1)
    end
end

-- Square a registered shape / border whatever the corner setting says (and
-- put it back). Used by the classic chat look; leaves unregistered things alone.
function T.Flatten(tex, flat)
    flat = flat and true or nil
    if (tex.wsFlat or nil) == flat then return end
    tex.wsFlat = flat
    if shaped[tex] then Reskin(tex, (not flat) and T.Rounded()) end
end

function T.FlattenBorder(border, flat)
    flat = flat and true or nil
    if (border.wsFlat or nil) == flat then return end
    border.wsFlat = flat
    if border.cframe then SwitchBorder(border, (not flat) and T.Rounded()) end
end

-- Other files register a function(rounded) to re-dress things that cannot be
-- expressed as a shaped texture (masks, outlines...). Runs after each change.
function T.OnCorners(fn) cornerHooks[#cornerHooks + 1] = fn end



function T.SetBorderColor(border, color, alpha)

    for _, tex in ipairs(border) do

        T.Color(tex, color[1], color[2], color[3], alpha or color[4] or 1)

    end

end



-- radius: rounded corners (panels 8, inputs and buttons 6); nil = square.

function T.Panel(frame, bg, border, radius)

    if radius == nil and not bg and not border then radius = 8 end

    frame.wsRadius = radius

    frame.bg = T.ShapeFill(frame, bg or T.BACKDROP, radius)

    frame.border = T.Border(frame, border or T.BORDER, 1, radius)

    if not bg and not border then

        panels[#panels + 1] = frame

        T.Glass(frame)

    end

    return frame

end



-- "Glass" panel style: a background that brightens toward the top, a soft

-- sheen over the upper half and a thin highlight along the top edge.

-- T.Glass adds the extra layers once; T.PaintSurface paints a frame's

-- background in the current style (Look page: Panel style / Glass shine).

local GRAD = type(CreateColor) == "function"

function T.Glass(frame)

    if frame.sheen then return frame end

    local r = frame.wsRadius

    frame.sheen = frame:CreateTexture(nil, "BACKGROUND", nil, 1)

    if T.Shape(frame.sheen, r) then

        frame.sheen:SetAllPoints() -- full-height rounded sheen, fading downward

        frame.sheenFull = true

    else

        frame.sheen:SetPoint("TOPLEFT", 1, -1)

        frame.sheen:SetPoint("BOTTOMRIGHT", frame, "RIGHT", -1, 0)

    end

    frame.sheen:Hide()

    frame.shine = frame:CreateTexture(nil, "BORDER", nil, 1)

    local inset = (r and T.Rounded()) and (r + 1) or 1

    frame.shine:SetPoint("TOPLEFT", inset, -1)

    frame.shine:SetPoint("TOPRIGHT", -inset, -1)

    frame.shine:SetHeight(1)

    frame.shine:Hide()

    return frame

end



local function Vertical(tex, br, bg, bb, ba, tr, tg, tb, ta)

    if tex.wsShaped then

        if GRAD then

            tex:SetGradient("VERTICAL", CreateColor(br, bg, bb, ba), CreateColor(tr, tg, tb, ta))

        else

            tex:SetVertexColor((br + tr) / 2, (bg + tg) / 2, (bb + tb) / 2, (ba + ta) / 2)

        end

        return

    end

    tex:SetColorTexture(1, 1, 1, 1)

    if GRAD then

        tex:SetGradient("VERTICAL", CreateColor(br, bg, bb, ba), CreateColor(tr, tg, tb, ta))

    else

        tex:SetColorTexture((br + tr) / 2, (bg + tg) / 2, (bb + tb) / 2, (ba + ta) / 2)

    end

end



function T.PaintSurface(frame, r, g, b, a)

    local L = ns.db and ns.db.look

    local glass = L and L.panelStyle == "glass" and a > 0

    if not glass then

        Vertical(frame.bg, r, g, b, a, r, g, b, a)

        if frame.sheen then frame.sheen:Hide() frame.shine:Hide() end

        return

    end

    local k = L.glass or 0.5

    local lift = 0.10 * k

    Vertical(frame.bg,

        r * 0.75, g * 0.75, b * 0.75, math.min(1, a * 1.05),

        math.min(1, r + lift), math.min(1, g + lift), math.min(1, b + lift), a * (1 - 0.3 * k))

    if frame.sheen then

        if frame.sheenFull then

            Vertical(frame.sheen, 1, 1, 1, 0, 1, 1, 1, 0.14 * k) -- fades out toward the bottom

        else

            Vertical(frame.sheen, 1, 1, 1, 0, 1, 1, 1, 0.12 * k)

        end

        frame.shine:SetColorTexture(1, 1, 1, 0.35 * k)

        frame.sheen:Show()

        frame.shine:Show()

    end

end



function T.AccentTexture(tex)

    accentTextures[#accentTextures + 1] = tex

    T.Color(tex, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1)

    return tex

end



function T.AccentBorder(border)

    accentBorders[#accentBorders + 1] = border

    T.SetBorderColor(border, T.ACCENT)

    return border

end



-- Small flat text button (Open, X, send arrow…).

-- Buttons and cards are listed so the "game frames" look can dress them.

T.buttons, T.cards = {}, {}

function T.RegisterCard(card)

    T.cards[#T.cards + 1] = card

    if ns.GameFrames and ns.GameFrames.On() then ns.GameFrames.DressCard(card) end

    return card

end



function T.Button(parent, label, w, h, filled)

    local b = CreateFrame("Button", nil, parent)

    b:SetSize(w, h)

    T.buttons[#T.buttons + 1] = b

    if filled then

        local bg = b:CreateTexture(nil, "BACKGROUND")

        bg:SetAllPoints()

        T.Shape(bg, 6)

        b.bg = T.AccentTexture(bg)

        b.label = T.Text(b, 13, T.DARK_TEXT, "")

    else

        T.Panel(b, T.INPUT_BG, T.INPUT_BORDER, 6)

        b.label = T.Text(b, 12, T.LABEL)

    end

    b.label:SetPoint("CENTER")

    b.label:SetText(label)

    local hl = b:CreateTexture(nil, "HIGHLIGHT")

    hl:SetAllPoints()

    T.Shape(hl, 6)

    T.Color(hl, 1, 1, 1, 0.08)

    b.hl = hl

    if ns.GameFrames and ns.GameFrames.On() then ns.GameFrames.DressButton(b) end

    return b

end



-- Size a button to its label: width = text width + padding, clamped to [minW, maxW].
-- Call again whenever the label, locale or font changes.
function T.FitText(b, minW, maxW, padding)
    local label = b and b.label
    if not label then return end
    minW, maxW, padding = minW or 0, maxW or 9999, padding or 16
    label:SetWidth(0)
    local w = math.floor((label:GetStringWidth() or 0) + padding + 0.5)
    if w > maxW then
        label:SetWordWrap(false)
        label:SetWidth(math.max(1, maxW - padding))
    end
    b:SetWidth(math.max(minW, math.min(maxW, w)))
end

-- Icon-less close/collapse button drawn as plain outlined text.

function T.GlyphButton(parent, glyph, size, filled)
    if glyph == "x" then return T.IconButton(parent, size or 24, T.Icons.Close, L["Close"], filled) end

    local b = CreateFrame("Button", nil, parent)

    b:SetSize(size or 24, size or 24)

    b.label = T.Text(b, 13, T.SECTION)

    b.label:SetPoint("CENTER")

    b.label:SetText(glyph)

    b:SetScript("OnEnter", function(self) self.label:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3]) end)

    b:SetScript("OnLeave", function(self) self.label:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3]) end)

    return b

end



-- Square icon button drawn from flat bars (no image files), in the

-- panel style: faint card fill and 1px border, accent border on hover.

-- draw(b, Bar) builds the icon; Bar(w, h, x, y) adds one bar at an offset

-- from the centre. b:SetIconColor(c) repaints every bar.

-- Draw one of T.Icons onto any frame (centred); returns the frame with

-- .bars and :SetIconColor.

function T.DrawIcon(f, draw)

    f.bars = f.bars or {}

    local function Bar(w, h, x, y)

        local tex = f:CreateTexture(nil, "ARTWORK")

        tex:SetSize(w, h)

        tex:SetPoint("CENTER", x or 0, y or 0)

        if tex.SetSnapToPixelGrid then tex:SetSnapToPixelGrid(true) end

        f.bars[#f.bars + 1] = tex

        return tex

    end

    function f:SetIconColor(c)

        for _, tex in ipairs(self.bars) do T.Color(tex, c) end

    end

    draw(f, Bar)

    return f

end



-- filled: the hub's look (dark filled pill like its chips); otherwise the faint chat-box style.
function T.IconButton(parent, size, draw, tip, filled)

    local b = CreateFrame("Button", nil, parent)

    b:SetSize(size, size)

    b.filled = filled
    if filled then
        b.bg = T.ShapeFill(b, T.INPUT_BG, 8)
    else
        b.bg = T.ShapeFill(b, { 1, 1, 1, 0.04 }, 8)
    end

    b.border = T.Border(b, T.INPUT_BORDER, 1, 8)

    T.DrawIcon(b, draw)

    b.iconColor = T.LABEL

    b:SetIconColor(b.iconColor)

    b:SetScript("OnEnter", function(self)

        T.Color(self.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.16)

        T.SetBorderColor(self.border, T.ACCENT, 0.55)

        self:SetIconColor(T.TEXT)

        local text = type(tip) == "function" and tip() or tip

        if text then

            GameTooltip:SetOwner(self, "ANCHOR_TOP")

            GameTooltip:AddLine(text)

            GameTooltip:Show()

        end

    end)

    b:SetScript("OnLeave", function(self)

        if self.active then T.Color(self.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.12) elseif self.filled then T.Color(self.bg, T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], T.INPUT_BG[4] or 1) else T.Color(self.bg, 1, 1, 1, 0.04) end

        T.SetBorderColor(self.border, self.active and T.ACCENT or T.INPUT_BORDER, self.active and 0.7 or nil)

        self:SetIconColor(self.iconColor)

        GameTooltip:Hide()

    end)

    local pressedPoints
    local function ReleaseIcon()
        if not pressedPoints then return end
        for tex, point in pairs(pressedPoints) do
            tex:ClearAllPoints()
            tex:SetPoint(unpack(point))
        end
        pressedPoints = nil
    end
    b:SetScript("OnMouseDown", function(self)
        if pressedPoints then return end
        pressedPoints = {}
        for _, tex in ipairs(self.bars) do
            local p, r, rp, x, y = tex:GetPoint()
            pressedPoints[tex] = {p, r, rp, x, y}
            tex:SetPoint(p, r, rp, x, y - 1)
        end
    end)
    b:SetScript("OnMouseUp", ReleaseIcon)
    -- Sending on mouse-down can hide the composer before mouse-up arrives.
    b:HookScript("OnHide", ReleaseIcon)
    b:HookScript("OnDisable", ReleaseIcon)

    return b

end



-- Hover like a text button (a soft white wash) instead of the accent tint an icon button
-- normally uses. tip: the tooltip text, or a function returning it.
function T.WashHover(b, tip)
    local wash = b:CreateTexture(nil, "HIGHLIGHT")
    wash:SetAllPoints()
    T.Shape(wash, 8)
    T.Color(wash, 1, 1, 1, 0.08)
    b:SetScript("OnEnter", function(self)
        self:SetIconColor(T.TEXT)
        local text = type(tip) == "function" and tip() or tip
        if text then
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine(text)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function(self)
        self:SetIconColor(self.iconColor)
        GameTooltip:Hide()
    end)
    return b
end

-- Icons for IconButton.

T.Icons = {}

function T.Icons.Plus(_, Bar)

    Bar(10, 2, 0, 0)

    Bar(2, 10, 0, 0)

end

function T.Icons.List(_, Bar) -- three rows with bullets: "all conversations"

    for i = -1, 1 do

        Bar(2, 2, -5, i * 4)

        Bar(8, 2, 1, i * 4)

    end

end

function T.Icons.Dots(_, Bar)

    for i = -1, 1 do Bar(2, 2, i * 4, 0) end

end

function T.Icons.Invite(_, Bar) -- a plus beside a person

    Bar(4, 4, -3, 3) Bar(8, 3, -3, -3) -- head, shoulders

    Bar(5, 1, 5, 1) Bar(1, 5, 5, 1)    -- plus

end

function T.Icons.Pin(f, Bar)
    local icon = Bar(18, 18, 0, 0)
    icon:SetTexture(T.MEDIA .. "Symbols\\PIN.tga")
    -- Keep artwork intact through hover, active-state and theme tint changes.
    function f:SetIconColor(c)
        icon:SetVertexColor(c[1], c[2], c[3], c[4] or 1)
    end
end

function T.Icons.PopOut(_, Bar) -- box with an arrow out of the corner

    Bar(8, 1, -2, -5) Bar(1, 8, -6, -1.5) Bar(3, 1, -4.5, 2) Bar(1, 3, 1.5, -3.5)

    Bar(4, 1, 4, 5) Bar(1, 4, 5.5, 3.5) Bar(1, 1, 3, 3) Bar(1, 1, 2, 2) Bar(1, 1, 1, 1)

end

function T.Icons.Bell(_, Bar)

    Bar(2, 2, 0, 6) Bar(6, 2, 0, 4) Bar(8, 5, 0, 0) Bar(12, 2, 0, -3.5) Bar(3, 2, 0, -6)

end

function T.Icons.Voice(_, Bar) -- a speaker with two sound waves
    Bar(4, 5, -5, 0) Bar(3, 9, -2, 0) Bar(2, 5, 4, 0) Bar(2, 9, 7, 0)
end

function T.Icons.Person(_, Bar)

    Bar(5, 5, 0, 3.5) Bar(10, 4, 0, -4)

end

function T.Icons.Tabs(_, Bar)

    Bar(4, 3, -4, 4) Bar(4, 3, 1, 4) Bar(12, 7, 0, -2)

end

function T.Icons.Reply(_, Bar)

    Bar(8, 2, 1, 1) Bar(2, 5, 5, -1.5) Bar(2, 2, -2, 3) Bar(2, 2, -3, 1) Bar(2, 2, -2, -1)

end

function T.Icons.Shield(_, Bar)

    Bar(10, 6, 0, 2) Bar(8, 2, 0, -2) Bar(6, 2, 0, -4) Bar(2, 2, 0, -6)

end

function T.Icons.Copy(_, Bar) -- two overlapping pages

    -- back page (top-right)

    Bar(8, 1, 2, 5) Bar(1, 8, 6, 1) Bar(1, 3, -2, 4)

    -- front page (bottom-left)

    Bar(8, 1, -2, 1) Bar(8, 1, -2, -6) Bar(1, 8, -6, -2.5) Bar(1, 8, 2, -2.5)

end

function T.Icons.Sliders(_, Bar) -- settings: three sliders with knobs

    for i, knob in ipairs({ -3, 3, -1 }) do

        local y = 5 - (i - 1) * 5

        Bar(12, 1, 0, y)

        Bar(3, 3, knob, y)

    end

end

function T.Icons.Lock(b, Bar) -- padlock; b:SetLockOpen(true) lifts the shackle

    Bar(10, 7, 0, -2)            -- body

    local hole = Bar(2, 2, 0, -2) -- keyhole, drawn in the background colour

    b.bars[#b.bars] = nil

    b.hole = hole

    local left = Bar(2, 4, -3, 3)

    local right = Bar(2, 4, 3, 3)

    local top = Bar(8, 2, 0, 6)

    function b:SetLockOpen(open)

        -- Open: shackle lifted, left leg still in the body, right leg free.

        left:SetHeight(open and 6 or 4)

        left:SetPoint("CENTER", -3, open and 4 or 3)

        right:SetHeight(open and 2 or 4)

        right:SetPoint("CENTER", 3, open and 6 or 3)

        top:SetPoint("CENTER", 0, open and 8 or 6)

    end

    hole:SetColorTexture(0.05, 0.05, 0.08, 1)

end



-- Single-line input with a placeholder.

function T.EditBox(parent, placeholder)

    local wrap = CreateFrame("Frame", nil, parent)

    wrap:SetHeight(30)

    T.Panel(wrap, T.INPUT_BG, T.INPUT_BORDER, 6)



    local e = CreateFrame("EditBox", nil, wrap)

    e:SetPoint("TOPLEFT", 10, 0)

    e:SetPoint("BOTTOMRIGHT", -10, 0)

    e:SetAutoFocus(false)

    e:SetMaxLetters(255)

    T.ApplyFont(e, 13, "")

    e:SetTextColor(T.WHISPER[1], T.WHISPER[2], T.WHISPER[3])

    e:SetShadowColor(0, 0, 0, 1)

    e:SetShadowOffset(1, -1)

    wrap.edit = e

    inputs[#inputs + 1] = wrap



    local ph = T.Text(wrap, 13, T.DIM)

    ph:SetPoint("LEFT", 10, 0)

    ph:SetText(placeholder or "")

    wrap.placeholder = ph



    local function refresh()

        ph:SetShown(e:GetText() == "" and not e:HasFocus())

    end

    e:HookScript("OnEditFocusGained", function()

        refresh()

        if not wrap.wsQuietFocus then T.SetBorderColor(wrap.border, T.ACCENT, 0.8) end

        ns.focusedEdit = e

    end)

    e:HookScript("OnEditFocusLost", function()

        refresh()

        T.SetBorderColor(wrap.border, T.INPUT_BORDER)

        if ns.focusedEdit == e then ns.focusedEdit = nil end

    end)

    e:HookScript("OnTextChanged", refresh)

    e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

    wrap:EnableMouse(true)

    wrap:SetScript("OnMouseDown", function() e:SetFocus() end)

    function wrap:SetPlaceholder(text) ph:SetText(text) end

    return wrap

end



---------------------------------------------------------------------------

-- Animation: a tiny tween driver (ease-out cubic), plus reveal/conceal

-- helpers that fade and slide a frame relative to its stored anchor.

---------------------------------------------------------------------------



local driver = CreateFrame("Frame")

local tweens = {}



local function EaseOut(t)

    local u = 1 - t

    return 1 - u * u * u

end



local function Step(_, elapsed)

    local finished

    for i = #tweens, 1, -1 do

        local a = tweens[i]

        a.t = a.t + elapsed

        local p = (a.d > 0) and math.min(a.t / a.d, 1) or 1

        a.apply(a.from + (a.to - a.from) * (a.ease or EaseOut)(p))

        if p >= 1 then

            table.remove(tweens, i)

            if a.done then

                finished = finished or {}

                finished[#finished + 1] = a.done

            end

        end

    end

    if finished then

        for _, f in ipairs(finished) do f() end

    end

    if #tweens == 0 then driver:SetScript("OnUpdate", nil) end

end



function T.StopTween(frame, key)

    for i = #tweens, 1, -1 do

        local a = tweens[i]

        if a.frame == frame and (key == nil or a.key == key) then

            table.remove(tweens, i)

        end

    end

end



function T.Tween(frame, key, duration, from, to, apply, done, ease)

    T.StopTween(frame, key)

    tweens[#tweens + 1] = { frame = frame, key = key, t = 0, d = duration, from = from, to = to, apply = apply, done = done, ease = ease }

    apply(from)

    driver:SetScript("OnUpdate", Step)

end



local function Offset(frame, dx, dy)

    local a = frame.wsAnchor

    if not a then return end

    frame:ClearAllPoints()

    frame:SetPoint(a[1], a[2], a[3], a[4] + dx, a[5] + dy)

end



-- Remember a frame's resting anchor so animations can slide around it.

function T.Place(frame, point, rel, relPoint, x, y)

    frame.wsAnchor = { point, rel, relPoint, x or 0, y or 0 }

    Offset(frame, 0, 0)

end



-- opts: dx, dy (start offset), dur, onStep(progress 0..1)

function T.Reveal(frame, opts)

    opts = opts or {}

    local from = (frame:IsShown() and frame.wsP) or 0

    local dx, dy = opts.dx or 0, opts.dy or 0

    frame.wsClosing = nil

    frame:Show()

    T.Tween(frame, "vis", (opts.dur or 0.22) * (1 - from), from, 1, function(v)

        frame.wsP = v

        frame:SetAlpha(v)

        Offset(frame, dx * (1 - v), dy * (1 - v))

        if opts.onStep then opts.onStep(v) end

    end)

end



function T.Conceal(frame, opts, done)

    opts = opts or {}

    if not frame:IsShown() then

        if done then done() end

        return

    end

    local from = frame.wsP or 1

    local dx, dy = opts.dx or 0, opts.dy or 0

    frame.wsClosing = true

    T.Tween(frame, "vis", (opts.dur or 0.18) * from, from, 0, function(v)

        frame.wsP = v

        frame:SetAlpha(v)

        Offset(frame, dx * (1 - v), dy * (1 - v))

        if opts.onStep then opts.onStep(v) end

    end, function()

        frame.wsClosing = nil

        frame:Hide()

        frame:SetAlpha(1)

        Offset(frame, 0, 0)

        if done then done() end

    end)

end



function T.IsOpen(frame)

    return frame:IsShown() and not frame.wsClosing

end



-- Re-read Horizon + class tint and repaint everything registered above.

-- LibSharedMedia (shipped by ElvUI, EllesmereUI and many others) for the

-- font list on the Look page.

function T.SharedMedia()

    return LibStub and LibStub("LibSharedMedia-3.0", true)

end



local function Col(c, a)

    return { c[1], c[2], c[3], a or c[4] or 1 }

end



-- The user's own choices from the Look page win over every theme source.

function T.ApplyLookOverrides()

    local L = ns.db and ns.db.look

    if not L then return end

    if L.font then

        local lsm = T.SharedMedia()

        local path = lsm and lsm:Fetch("font", L.font, true)

        if path then T.FONT = path end

    elseif L.gameFrames and type(STANDARD_TEXT_FONT) == "string" then

        T.FONT = STANDARD_TEXT_FONT -- the game's own font to go with its frames

    end

    if L.accent then T.ACCENT = Col(L.accent, 1) end

    -- L.classColors[key] = true: that chip follows the player's class colour (wins over a custom swatch).
    local cc = L.classColors
    local rc = cc and RAID_CLASS_COLORS and RAID_CLASS_COLORS[select(2, UnitClass("player"))]
    local function Pick(key, a)
        if rc and cc[key] then return { rc.r, rc.g, rc.b, a or 1 } end
        if L[key] then return Col(L[key], a) end
    end

    T.BACKDROP = Pick("backdrop", T.BACKDROP[4]) or T.BACKDROP

    if L.panelAlpha then T.BACKDROP[4] = L.panelAlpha end

    if rc and cc and cc.border then T.BORDER = { rc.r, rc.g, rc.b, L.border and L.border[4] or T.BORDER[4] or 1 }
    elseif L.border then T.BORDER = Col(L.border) end

    T.WHISPER = Pick("theirText", 1) or T.WHISPER

    T.YOURS = Pick("yourText", 1) or T.YOURS

    T.BNET = Pick("bnetText", 1) or T.BNET

end



-- Rounded border thicker than 1px: the base 1px ring stays put and ring i
-- (2..size) is added outside it, offset i-1 beyond the frame edge with radius
-- + (i-1), so the curve stays concentric and the content area is unchanged.
function T.OuterRings(frame, key, size, bc)
    local list = frame[key] or {}
    frame[key] = list
    local base = frame.wsRadius or 8
    for i = 2, size do
        local tex = list[i - 1]
        if not tex then
            tex = frame:CreateTexture(nil, "BORDER")
            list[i - 1] = tex
        end
        local out = i - 1
        tex:ClearAllPoints()
        tex:SetPoint("TOPLEFT", -out, out)
        tex:SetPoint("BOTTOMRIGHT", out, -out)
        T.Shape(tex, base + out, true)
        T.Color(tex, bc[1], bc[2], bc[3], bc[4] or 1)
        tex:Show()
    end
    return list
end

-- Settings window only: optional own background / border from
-- ns.db.look.settingsPanel = { bg = {r,g,b}, bgAlpha, border = {r,g,b,a}, borderSize }.
-- Any nil field keeps the theme value, so an empty table is the default look.
function T.ApplySettingsPanel(frame)
    local o = ns.db and ns.db.look and ns.db.look.settingsPanel
    local extra = frame.wsThickBorder
    if extra then for _, tex in ipairs(extra) do tex:Hide() end end
    local b = frame.border
    if b and #b == 4 then b[1]:SetHeight(1) b[2]:SetHeight(1) b[3]:SetWidth(1) b[4]:SetWidth(1) end
    if not o or frame.wsSkinned then return end
    if o.bg or o.bgAlpha then
        local c = o.bg or T.BACKDROP
        T.PaintSurface(frame, c[1], c[2], c[3], o.bgAlpha or T.BACKDROP[4] or 1)
    end
    if o.borderOff then
        for _, edge in ipairs(b or {}) do edge:Hide() end
        return
    end
    local bc = o.border or T.BORDER
    local cls = o.borderClass and RAID_CLASS_COLORS and RAID_CLASS_COLORS[select(2, UnitClass("player"))]
    if cls then
        bc = { cls.r, cls.g, cls.b, (o.border and o.border[4]) or 1 }
        T.SetBorderColor(frame.border, bc, bc[4])
    else
        T.SetBorderColor(frame.border, bc, o.border and (bc[4] or 1) or nil)
    end
    local size = math.max(1, math.min(6, math.floor((o.borderSize or 1) + 0.5)))
    if #b == 4 then -- square edges
        b[1]:SetHeight(size) b[2]:SetHeight(size) b[3]:SetWidth(size) b[4]:SetWidth(size)
    elseif size > 1 and b[1] then -- rounded ring: stack outward rings
        extra = T.OuterRings(frame, 'wsThickBorder', size, bc)
    end
end

-- Chat box / whisper windows: ns.db.look.chatBorderOff hides the border,
-- chatBorderSize (1-6) sets its thickness. nil for both = the theme's look.
-- Call after the frame's edges were last shown/hidden.
function T.ApplyChatBorder(frame)
    local b = frame and frame.border
    if not b or not b[1] then return end
    local L = ns.db and ns.db.look
    local extra = frame.wsChatThick
    if extra then for _, tex in ipairs(extra) do tex:Hide() end end
    if #b == 4 then b[1]:SetHeight(1) b[2]:SetHeight(1) b[3]:SetWidth(1) b[4]:SetWidth(1) end
    if not L or frame.wsSkinned then return end
    if L.chatBorderOff then
        for _, edge in ipairs(b) do edge:Hide() end
        return
    end
    local size = math.max(1, math.min(6, math.floor((L.chatBorderSize or 1) + 0.5)))
    if size == 1 then return end
    local bc = T.BORDER
    if #b == 4 then
        b[1]:SetHeight(size) b[2]:SetHeight(size) b[3]:SetWidth(size) b[4]:SetWidth(size)
    elseif b[1]:IsShown() then -- rounded ring: stack outward rings
        extra = T.OuterRings(frame, 'wsChatThick', size, bc)
    end
end

-- Re-shape everything for the current corner radius (Look page slider).
-- Runs from T.Refresh whenever the radius, Island look or capability changed;
-- pass force to redo it regardless.
function T.ApplyCorners(force)
    local island = ns.Island and ns.Island.Active and ns.Island.Active()
    local key = CornerValue() * 4 + (island and 1 or 0) + (T.canRound == false and 2 or 0)
    if not force and key == appliedCorner then return end
    appliedCorner = key
    local rounded = T.Rounded()
    for b in pairs(borders) do SwitchBorder(b, rounded and not b.wsFlat) end
    for tex in pairs(shaped) do Reskin(tex, rounded and not tex.wsFlat) end
    for mask in pairs(masks) do
        if mask.wsDesign then pcall(T.ShapeMask, mask, mask.wsDesign) end
    end
    for _, frame in ipairs(panels) do
        local sheen = frame.sheen
        if sheen then
            sheen:ClearAllPoints()
            if rounded and sheen.wsShaped then
                sheen:SetAllPoints()
                frame.sheenFull = true
            else
                sheen:SetPoint("TOPLEFT", 1, -1)
                sheen:SetPoint("BOTTOMRIGHT", frame, "RIGHT", -1, 0)
                frame.sheenFull = nil
            end
            local r = frame.wsRadius
            local inset = (r and rounded) and (r + 1) or 1
            frame.shine:ClearAllPoints()
            frame.shine:SetPoint("TOPLEFT", inset, -1)
            frame.shine:SetPoint("TOPRIGHT", -inset, -1)
        end
        if frame.strip and (frame == ns.Window or frame == ns.Hub) then
            local inset = (rounded and frame.wsRadius) and (frame.wsRadius + 1) or 0
            frame.strip:ClearAllPoints()
            frame.strip:SetPoint("TOPLEFT", inset, 0)
            frame.strip:SetPoint("TOPRIGHT", -inset, 0)
        end
    end
    for _, fn in ipairs(cornerHooks) do pcall(fn, rounded) end
end

function T.Refresh()

    T.ApplyCorners()

    for k, c in pairs(BASE) do T[k] = { c[1], c[2], c[3], c[4] } end

    ReadHorizon()

    T.ACCENT = { 0.48, 0.58, 0.82, 1 }

    if ns.db and ns.db.classTint then

        local _, classFile = UnitClass("player")

        local r, g, b = T.ClassColor(classFile)

        T.ACCENT = { r, g, b, 1 }

    end

    if ns.ElvUI then ns.ElvUI.ApplyTheme() end -- optional ElvUI look

    if ns.Ellesmere then ns.Ellesmere.ApplyTheme() end -- optional EllesmereUI look

    T.ApplyPresetPalette()

    if ns.Island then ns.Island.ApplyTheme() end -- optional Island XP look (wins over the suites)

    T.ApplyLookOverrides()

    for _, frame in ipairs(panels) do

        local a = math.max(T.BACKDROP[4] or 1, frame.wsMinAlpha or 0)
        if (frame==ns.Window or frame==ns.Hub) and ns.WhisperOpacity then a=ns.WhisperOpacity() end

        if frame.wsSkinned then a = 0 end -- the game's own frame is drawn behind it

        T.PaintSurface(frame, T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], a)

        T.SetBorderColor(frame.border, T.BORDER)

        for _, edge in ipairs(frame.border or {}) do edge:SetShown(not frame.wsSkinned) end

        if frame == ns.Settings then T.ApplySettingsPanel(frame) end

        if frame == ns.Window or frame == ns.Hub then T.ApplyChatBorder(frame) end

    end

    if ns.Chat and ns.Chat.border then
        T.SetBorderColor(ns.Chat.border, T.BORDER)
        if ns.Chat.smf then T.ApplyChatBorder(ns.Chat) end
    end

    for _, fs in ipairs(fontStrings) do

        T.StyleText(fs, fs.wsSize or 13, fs.wsFlags)

        local c = fs.wsColorKey and T[fs.wsColorKey]

        if c then fs:SetTextColor(c[1], c[2], c[3], c[4] or 1) end

    end

    for _, wrap in ipairs(inputs) do

        if not wrap.wsSkinned then

            T.Color(wrap.bg, T.INPUT_BG)

            T.SetBorderColor(wrap.border, (not wrap.wsQuietFocus and wrap.edit:HasFocus()) and T.ACCENT or T.INPUT_BORDER)

        end

        if wrap.wsComposerWell then T.PaintComposer(wrap.bg,wrap.border,wrap.wsComposerWell)end
        T.ApplyFont(wrap.edit, wrap.wsComposerWell and 14 or 13, "")

        wrap.edit:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])

    end

    for _, tex in ipairs(accentTextures) do

        T.Color(tex, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1)

    end

    for _, border in ipairs(accentBorders) do

        T.SetBorderColor(border, T.ACCENT)

    end

end



ReadHorizon()



-- Palette choices stay separate from manual colour overrides.

function T.ApplyPresetPalette()

    local L = ns.db and ns.db.look

    if L and L.preset == "forever" then
        -- Island's Forever finish (Island.lua FOREVER): dark bronze fill, bronze edges, parchment text.
        local edge, light = { 86/255, 53/255, 33/255 }, { 122/255, 87/255, 57/255 }
        local palette = {
            BACKDROP = { 44/255, 40/255, 37/255, 0.98 }, BORDER = { light[1], light[2], light[3], 0.9 },
            CARD = { 36/255, 32/255, 29/255, 1 }, CARD_BORDER = { edge[1], edge[2], edge[3], 0.9 },
            INPUT_BG = { 0.031, 0.027, 0.024, 0.85 }, INPUT_BORDER = { edge[1], edge[2], edge[3], 1 },
            DIVIDER = { edge[1], edge[2], edge[3], 0.7 }, TEXT = { 0.941, 0.875, 0.698, 1 },
            LABEL = { 0.85, 0.78, 0.63, 1 }, SECTION = { 0.749, 0.671, 0.537, 1 },
            DIM = { 0.55, 0.49, 0.40, 1 }, WHISPER = { 0.941, 0.875, 0.698, 1 },
            YOURS = { 0.941, 0.875, 0.698, 1 },
        }
        for key, value in pairs(palette) do T[key] = value end
        if not ns.db.classTint then T.ACCENT = { 208/255, 173/255, 125/255, 1 } end
        return
    end

    if not L or L.preset ~= "softsignal" then return end

    local palette = {

        BACKDROP = { 0.043, 0.047, 0.063, 0.98 }, BORDER = { 1, 1, 1, 0.045 },

        CARD = { 0.065, 0.070, 0.090, 1 }, CARD_BORDER = { 1, 1, 1, 0.045 },

        INPUT_BG = { 0.082, 0.090, 0.114, 1 }, INPUT_BORDER = { 1, 1, 1, 0.045 },

        DIVIDER = { 1, 1, 1, 0.045 }, TEXT = { 0.929, 0.933, 0.957, 1 },

        LABEL = { 0.83, 0.85, 0.90, 1 }, SECTION = { 0.576, 0.604, 0.663, 1 },

        DIM = { 0.45, 0.48, 0.54, 1 }, WHISPER = { 0.929, 0.933, 0.957, 1 },

        YOURS = { 0.859, 0.902, 1, 1 },

    }

    for key, value in pairs(palette) do T[key] = value end

    if not ns.db.classTint then T.ACCENT = { 0.616, 0.733, 1, 1 } end

end

-- Exact Lucide artwork used by the approved mockup; licence in Media/Symbols.

local SYMBOLS = {

    HUNTER=true, MAGE=true, ROGUE=true, DRUID=true, WARRIOR=true,

    PALADIN=true, PRIEST=true, SHAMAN=true, WARLOCK=true, DEATHKNIGHT=true,

    MONK=true, DEMONHUNTER=true, EVOKER=true,

}

-- Icons use the same live class colours as character names, without pastel remapping.
function T.ClassTileColor(class, r, g, b)
    -- These symbols should keep the familiar class hues even when another
    -- addon supplies a lighter nameplate/chat palette.
    if class == "WARRIOR" then return 199/255, 156/255, 110/255 end
    if class == "PALADIN" then return 245/255, 140/255, 186/255 end
    if class then return T.ClassColor(class) end
    return r, g, b
end

function T.ClassSymbol(tile, class, color)

    local f = tile.symbol

    if not f then

        f = CreateFrame("Frame", nil, tile)

        f:SetSize(20, 20) f:SetPoint("CENTER")

        f:SetFrameLevel(tile:GetFrameLevel() + 1)

        f:EnableMouse(false)

        f.icon = f:CreateTexture(nil, "ARTWORK")

        f.icon:SetAllPoints()

        tile.symbol = f

    end

    if not SYMBOLS[class] then f:Hide() return false end

    f:SetScale(tile:GetWidth() / 36)

    f.icon:SetTexture(T.MEDIA .. "Symbols\\" .. class .. ".tga")

    f.icon:SetVertexColor(color[1], color[2], color[3], color[4] or 1)

    f.class = class f:Show()

    return true

end



function T.Icons.Send(_, Bar)

    Bar(2, 12, 0, -1)

    local left = Bar(8, 2, -2.5, 3) left:SetRotation(math.pi/4)

    local right = Bar(8, 2, 2.5, 3) right:SetRotation(-math.pi/4)

end

function T.SendButton(parent, size)

    local b = T.IconButton(parent, size, T.Icons.Send, L["Send whisper"])

    T.Reshape(b, 10)

    b.iconColor = T.DARK_TEXT

    local function Paint(hover)

        T.Color(b.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], hover and 0.85 or 1)

        T.SetBorderColor(b.border, T.ACCENT, 0)

        local a = T.ACCENT

        local light = a[1]*0.299 + a[2]*0.587 + a[3]*0.114 > 0.55

        b:SetIconColor(light and T.DARK_TEXT or T.TEXT)

    end

    b:SetScript("OnEnter", function() Paint(true) end)

    b:SetScript("OnLeave", function() Paint(false) end)

    b.Paint = Paint

    Paint(false)

    return b

end


-- One outline family and optical size for all action controls. Media/Symbols/LICENSE.txt applies.
local function Control(name)
    return function(f, Bar)
        local size = f:GetWidth() > 28 and 18 or 16
        local tex = Bar(size, size, 0, 0)
        tex:SetTexture(T.MEDIA .. "Controls\\" .. name .. ".tga")
        tex.wsShaped = true
        f.controlIcon, f.controlName = tex, name
    end
end
for _, name in ipairs({"Plus","List","Dots","Invite","PopOut","Bell","Person","Tabs","Reply","Shield","Copy","Sliders","Star","Close","Emote","Send"}) do
    T.Icons[name] = Control(name)
end
T.Icons.Pin = function(f, Bar)
    local tex = Bar(16, 16, 0, 0)
    tex:SetTexture(T.MEDIA .. "Symbols\\PIN.tga") tex.wsShaped = true
    f.controlIcon, f.controlName = tex, "Pin"
end
T.Icons.Lock = function(f, Bar)
    Control("Lock")(f, Bar)
    function f:SetLockOpen(open)
        self.controlIcon:SetTexture(T.MEDIA .. "Controls\\" .. (open and "Unlock" or "Lock") .. ".tga")
    end
end

-- Circle halves and a straight center give settings controls true capsule ends,
-- matching Island without stretching a small rounded-rectangle slice.
function T.Pill(parent, height, color, layer)
    local f = CreateFrame("Frame",nil,parent)
    f:SetSize(height,height) f:EnableMouse(false)
    local left=f:CreateTexture(nil,layer or "ARTWORK") T.Circle(left)
    left:SetTexCoord(0,0.5,0,1) left:SetSize(height/2,height) left:SetPoint("LEFT")
    local right=f:CreateTexture(nil,layer or "ARTWORK") T.Circle(right)
    right:SetTexCoord(0.5,1,0,1) right:SetSize(height/2,height) right:SetPoint("RIGHT")
    local middle=f:CreateTexture(nil,layer or "ARTWORK")
    middle:SetPoint("TOPLEFT",left,"TOPRIGHT") middle:SetPoint("BOTTOMRIGHT",right,"BOTTOMLEFT")
    f.parts={left,middle,right} f.wsShaped=true f.wsPill=true
    function f:SetVertexColor(r,g,b,a)
        for _,tex in ipairs(self.parts) do T.Color(tex,r,g,b,a) end
    end
    T.Color(f,color or {1,1,1,1})
    return f
end

-- Island uses stiffness 256 and damping 20. This is that spring's response,
-- sampled by the shared animation driver, with an exact resting endpoint.
function T.Spring(frame, key, from, to, apply, done)
    T.Tween(frame, key, 0.7, from, to, apply, done, function(p)
        if p >= 1 then return 1 end
        local t, w = p * 0.7, math.sqrt(156)
        return 1 - math.exp(-10*t) * (math.cos(w*t) + 10/w * math.sin(w*t))
    end)
end


-- Layered composers: a dark outer frame, lighter text well and a separate
-- smile section. Regions stay on the input owner, below its text and controls.
function T.ComposerWell(parent)
    return T.ShapeFill(parent,T.INPUT_BG,12,"BACKGROUND",1)
end
function T.PaintComposer(bg,border,well,alpha)
    local c=T.INPUT_BG
    local a=alpha or c[4] or 1
    T.Color(bg,c[1]*.55,c[2]*.55,c[3]*.55,a)
    T.Color(well,math.min(1,c[1]+.065),math.min(1,c[2]+.065),math.min(1,c[3]+.065),a)
    T.SetBorderColor(border,T.INPUT_BORDER)
end

---------------------------------------------------------------------------
-- Resize grip: a faint three-dot corner (brighter under the mouse) that makes
-- `frame` resizable within bounds. opts = { minW, minH, maxW, maxH,
-- onSizing = fn(w, h) while dragging, onDone = fn(w, h) when released }.
-- Returns the grip button. The frame keeps its own anchors; callers re-flow
-- their content from the frame's OnSizeChanged.
---------------------------------------------------------------------------
function T.ResizeGrip(frame, opts)
    opts = opts or {}
    local minW, minH = opts.minW or 300, opts.minH or 200
    local maxW, maxH = opts.maxW or 1400, opts.maxH or 900
    frame:SetResizable(true)
    if frame.SetResizeBounds then
        frame:SetResizeBounds(minW, minH, maxW, maxH)
    else
        if frame.SetMinResize then frame:SetMinResize(minW, minH) end
        if frame.SetMaxResize then frame:SetMaxResize(maxW, maxH) end
    end
    local grip = CreateFrame("Button", nil, frame)
    grip:SetSize(22, 22)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:SetFrameLevel(frame:GetFrameLevel() + 30)
    grip.lines = {}
    for i, point in ipairs({ { -8, 8 }, { -13, 8 }, { -8, 13 } }) do
        local t = grip:CreateTexture(nil, "OVERLAY")
        T.Circle(t)
        t:SetSize(2.5, 2.5)
        t:SetPoint("CENTER", grip, "BOTTOMRIGHT", point[1], point[2])
        grip.lines[i] = t
    end
    local function Paint(hot)
        local c = hot and T.ACCENT or T.SECTION
        for _, t in ipairs(grip.lines) do t:SetVertexColor(c[1], c[2], c[3], hot and 0.95 or 0.35) end
    end
    Paint(false)
    grip:SetScript("OnEnter", function() Paint(true) end)
    grip:SetScript("OnLeave", function() if not grip.sizing then Paint(false) end end)
    grip:SetScript("OnMouseDown", function(_, button)
        if button ~= "LeftButton" then return end
        grip.sizing = true
        Paint(true)
        frame:StartSizing("BOTTOMRIGHT")
        if opts.onSizing then
            grip:SetScript("OnUpdate", function() opts.onSizing(frame:GetWidth(), frame:GetHeight()) end)
        end
    end)
    grip:SetScript("OnHide", function()
        if not grip.sizing then return end
        grip.sizing = nil
        grip:SetScript("OnUpdate", nil)
        frame:StopMovingOrSizing()
        Paint(false)
    end)
    grip:SetScript("OnMouseUp", function()
        if not grip.sizing then return end
        grip.sizing = nil
        grip:SetScript("OnUpdate", nil)
        frame:StopMovingOrSizing()
        if not grip:IsMouseOver() then Paint(false) end
        if opts.onDone then opts.onDone(math.floor(frame:GetWidth() + 0.5), math.floor(frame:GetHeight() + 0.5)) end
    end)
    return grip
end

---------------------------------------------------------------------------
-- Edge resizing: invisible thin frames along all four edges plus 8px corner
-- frames (above the edges) that start frame:StartSizing(<side>). Same opts as
-- T.ResizeGrip plus `inset` (hit thickness, default 6). Returns a table of
-- the edge/corner frames keyed LEFT/RIGHT/TOP/BOTTOM/TOPLEFT/... .
---------------------------------------------------------------------------
function T.ResizeEdges(frame, opts)
    opts = opts or {}
    local minW, minH = opts.minW or 300, opts.minH or 200
    local maxW, maxH = opts.maxW or 1400, opts.maxH or 900
    local th, cs = opts.inset or 6, 8
    frame:SetResizable(true)
    if frame.SetResizeBounds then
        frame:SetResizeBounds(minW, minH, maxW, maxH)
    else
        if frame.SetMinResize then frame:SetMinResize(minW, minH) end
        if frame.SetMaxResize then frame:SetMaxResize(maxW, maxH) end
    end
    local edges = {}
    local base = frame:GetFrameLevel()
    local function Cursor(on)
        if SetCursor then pcall(SetCursor, on and "UI_RESIZE_CURSOR" or nil) end
    end
    local function Make(side, level)
        local f = CreateFrame("Frame", nil, frame)
        f:SetFrameLevel(base + level)
        f:EnableMouse(true)
        f:SetScript("OnEnter", function() Cursor(true) end)
        f:SetScript("OnLeave", function() if not f.sizing then Cursor(false) end end)
        f:SetScript("OnMouseDown", function(_, button)
            if button ~= "LeftButton" then return end
            f.sizing = true
            frame:StartSizing(side)
            if opts.onSizing then
                f:SetScript("OnUpdate", function() opts.onSizing(frame:GetWidth(), frame:GetHeight()) end)
            end
        end)
        f:SetScript("OnHide", function()
            if not f.sizing then return end
            f.sizing = nil
            f:SetScript("OnUpdate", nil)
            frame:StopMovingOrSizing()
            Cursor(false)
        end)
        f:SetScript("OnMouseUp", function()
            if not f.sizing then return end
            f.sizing = nil
            f:SetScript("OnUpdate", nil)
            frame:StopMovingOrSizing()
            if not f:IsMouseOver() then Cursor(false) end
            if opts.onDone then opts.onDone(math.floor(frame:GetWidth() + 0.5), math.floor(frame:GetHeight() + 0.5)) end
        end)
        edges[side] = f
        return f
    end
    local l = Make("LEFT", 20); l:SetWidth(th)
    l:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -cs); l:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, cs)
    local r = Make("RIGHT", 20); r:SetWidth(th)
    r:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, -cs); r:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, cs)
    local t = Make("TOP", 20); t:SetHeight(th)
    t:SetPoint("TOPLEFT", frame, "TOPLEFT", cs, 0); t:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -cs, 0)
    local b = Make("BOTTOM", 20); b:SetHeight(th)
    b:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", cs, 0); b:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -cs, 0)
    for _, c in ipairs({ "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT", "BOTTOMRIGHT" }) do
        local f = Make(c, 25)
        f:SetSize(cs, cs)
        f:SetPoint(c, frame, c, 0, 0)
    end
    return edges
end
