# Pigeon changelog

## 1.9.1

- **/pigeon:** Typing `/pigeon` now opens the settings, which is what most people expect. The whisper hub is `/pigeon hub`. If you have `/pigeon` in a macro or keybind to open the hub, change it to `/pigeon hub`.
- **Settings button:** A settings button in the hub's header, and a Pigeon entry in the game's Options > AddOns list with a button that opens the settings.
- **Hub buttons:** Every icon button in the hub now hovers with the same soft wash as the text buttons.
- **Chinese, Japanese and Korean chat:** Channel chips and times now sit level with the words on lines that contain these characters. The game draws the whole line in a different font there, which had put them a couple of pixels off.

## 1.9.0

- **Settings reorganised:** Options now sit with the thing they change. Nothing is reset: every setting keeps its value.
- **Chat > Tab bar:** The tab bar options (Tab bar, Tab bar when hidden, Tab bar height, Tab text size, Tab background, Inactive tab opacity and the options/stack buttons) and Tab counters have their own tab. The channel chip sliders are in a new Channel chips section under Chat > Text.
- **Appearance:** Chat and Whisper background opacity are now under Look > Transparency, Text colours is on the Messages tab beside the text options, and Panel shape is part of Panels on the Layout tab.
- **Whispers and Alerts:** Hide whispers from the chat box is under Whispers > Notifications, and Censor swear words is under Alerts > Filters.
- **Settings:** The Interface text tooltip no longer names a settings page.

## 1.8.9

- **Animated emotes in chat:** Animated Twitch Emotes now play in the chat box, not only in whisper windows. The line under the mouse holds still, so you can click an emote to add it to your message. This is new, so tell me if anything looks off.
- **Times beside emotes:** With the separate time column, a line holding a big emote keeps its time level with the words and no longer flickers while the emote plays.
- **Channel chips:** The chips now centre themselves on the text for the font you use. The Channel chip position slider is a fine-tune on top of that; an old position you had set is cleared once, so it cannot push the chips off.
- **Settings:** Dropdown menus have a solid background, so the controls behind them no longer show through. The channel display choices are labelled with examples: Chips, Tag letters (T), Name (Trade), Number (2) and Number and name (2. Trade).

## 1.8.8

- **Animated emotes:** Clicking an animated emote in a whisper to add it to your message did nothing, because the emote's picture was being redrawn many times a second. An animated emote now holds still while the mouse is over its message, so the click works.

## 1.8.7

- **Envelope icon:** Importing a profile that had the envelope icon could leave it stuck on, with the switch off. The switch and the stack button now use the same saved setting, and a setting saved the other way is moved across.
- **Channel chips:** The chips now stay centred on the text line when you change their size. New Channel chip position slider (Chat > Text) to nudge them up or down to suit your font.
- **Settings:** "Tab bar when hidden" is greyed out, with the reason, unless Tab bar is set to Show on hover.

## 1.8.6

- **Stack button switch:** "Stack button in the tab bar" in the Whispers settings now works. It saved to a place the dock never read, so the button could not be moved out of the tab bar. Turn it off and reload to place the button yourself.
- **Envelope icon:** "Use envelope instead of bird" now works for the same reason.
- **Horizontal dock:** The switch is greyed out, with the reason, while the stack button is in the tab bar. With a free-standing horizontal dock, the whisper window now opens above the row of tiles instead of over them.
- **Colour wash:** 0 now turns the tint fully off in the Bubbles and Threads styles, and there is a Wash colour to recolour it. The wash settings are greyed out, with the reason, in styles that do not use them.
- **Outline:** Chat text and whisper text can be Off, Thin or Thick.
- **Chat text colours:** New section in Chat > Text with a colour for each kind of message. The swatches show the game's own colour until you pick one; right-click to go back to it.
- **Tabs:** New Tab text size, Tab background and Inactive tab opacity sliders in Chat > Text. Inactive tabs come back one at a time as the mouse passes over them, and an optional switch includes the options button and the stack button. "Tab bar: Show on hover" hides the whole tab bar until the mouse is over the chat.
- **Chat spacing and chips:** New Line spacing slider, and Channel chip size and Channel chip opacity sliders. Opacity dims the chips toward the dark chat background.
- **Sizes:** New Chat width and Chat height sliders. The whisper window now has width and height sliders in place of the scale slider; a scale you had set is converted to a size. New Distance from chat slider for a whisper window that opens above the chat.
- **Settings:** The message preview is taller, so every sample message shows without scrolling.

## 1.8.5

- **Voice chat panel:** The speaker button in the chat controls now opens a small voice panel: mute, deafen, push to talk or open mic, and who is talking in your voice channel. It has a button for the game's own Channels window. This is new, so tell me what is missing.
- **Interface text:** New Interface text slider in Look > Layout > Size makes the text in Pigeon's windows and settings larger or smaller. Chat message text keeps its own size.
- **Offline whispers:** Whispering a character who is offline now shows the game's note inside the conversation instead of only in General.
- **Who is this?:** Added to the menu on whisper tiles and in the hub. It opens the game's Who window with the search typed in; press Enter to search. The result also appears in the conversation. The old entry in the chat name menu uses the same route.
- **Send button:** When a typed command cannot be run from the button (such as /who), the hint now shows in the middle of the screen. Press Enter to run it.
- **Profiles:** Each saved profile has an Update button that replaces it with your current settings, after a confirmation.

## 1.8.4

- **Tab counters:** The switches now read the natural way round. Each kind of message is on by default, and turning one off stops it adding to the number on a tab. The wording and tooltips are clearer. Choices you made in 1.8.3 carry over.

## 1.8.3

- **Tab counters:** New Tab counters section in Settings > General > Behavior. Pick the kinds of message that arrive in floods (loot and crafting, progress, creature messages, PvP, system) and they stop adding to the number on a tab. They still show in the tab. Off by default.

## 1.8.2

- **Missing chat box:** New `/pigeon chatstatus` shows why the chat box is off, hidden or off screen, and `/pigeon chatreset` puts it back at its default place and size.
- **Startup:** If one part of Pigeon fails to start, it now says which part and why, and the rest still loads, instead of stopping everything.
- **Saved settings:** Upgrades of older saved settings now run from one tidy list. Nothing changes for you.

## 1.8.1

- **Joined channels:** On the General tab the joined channels (General, Trade, LocalDefense and so on) now show as on when the tab already shows them, and turning one off works.
- **Tab settings:** The Joined channels list no longer repeats the channels that have their own switch above it, such as General and Trade. It lists only your other channels.

## 1.8.0

- **Default button on every tab:** The General tab's reset button is now a smaller Default button, and it appears on every tab. It asks for confirmation, then sets the tab back to its shipped channels. A custom tab gets what its name would pick if you created it now.
- **Party tab:** New installs get a Party tab with party, raid and instance group chat, including leader messages and raid warnings. Existing tabs are left as they are.

## 1.7.9

- **Chat fade:** The idle and combat fades now also fade the emote button, the resize grip, the line beside the dock tiles and the jump-to-latest button, so nothing is left showing.

## 1.7.8

- **Combat fade:** While the chat is faded for combat, hovering it or a new message on the current tab now brings it back for a few seconds. New "Show chat for (in combat)" setting (Behavior > In combat) controls how long.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.7.7

- **Chat fade:** The idle and combat fades now fade the whole chat box together: the background, tabs, input box, messages and the dock tiles. The background now fades smoothly instead of staying until the end.
- **Chat fade:** Hovering the dock button or a tile wakes the chat. With "Fade old messages" on, old lines now come back when the chat wakes.
- **Debug:** `/pigeon fadedebug [seconds]` prints the fade state, for troubleshooting.

## 1.7.6

- **Dock:** Shift-clicking the Pigeon button now tucks the tiles away just for now, and a new whisper brings them back (turn this off with "Show tiles again when a whisper arrives"). The "Hide dock tiles" setting stays hidden until you turn it off.
- **Dock:** New "Tuck away" choice for the dock in combat, and a "Tuck the dock away in instances" toggle. The tiles and previews tuck away but the Pigeon button and its unread count stay.
- **Chat box:** New "Hide the messages too" option so the idle fade can hide the text as well; the combat fade now fades the whole chat box, text included. Fades are smoother and quicker. Hovering, typing, or a new message on the current tab brings the chat back.
- **Settings:** Search results now take over the settings panel (with a clear button) instead of a dropdown.
- **Settings:** Moved several options to more logical places: the dock options are together under Whispers > Dock, chat fading and text selection are under Behavior, Transparency sits with the other look options, and Send test whispers is under Notifications. The Chat > Fading tab is gone.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.7.5

- **Emotes:** Hover an emote in a message to see its name, and click it to add it to the message you're typing (in whisper windows and in Pigeon's chat box).
- **Emote drawer:** New Recent, Favorites and All tabs. Right-click an emote to favorite it.
- **Whispers:** Fixed the bottom of the newest line (the tail of g, y, p) being cut off in the Signal, Classic and Minimal styles.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.7.4

- **General tab:** New installs now start with a cleaner General tab: conversation, channels and system messages, without loot, XP, creature talk, battleground, pet battle, ping and addon lines (the Loot tab still has loot and progress). Existing tabs are not changed.
- **General tab:** A "Reset to recommended" button (Settings > Chat, on a tab named General) switches it to that cleaner set.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.7.3

- **Zone channels:** Fixed General and LocalDefense lines sometimes not showing after travelling to a new zone (seen in the Barrens). Pigeon now re-listens to your channels after zone and channel changes.

## 1.7.2

- **Channel menu:** Fixed a Lua error when opening the channel menu (it then would not close).
- **Channel menu:** The channel you pick now sticks even if you close the input box without sending.

## 1.7.1

- **Classic chat:** New option (Chat page, "Chat box" section) that makes the chat box look like the game's own chat: a plain dark panel with square corners, Blizzard-style tabs, outlined text without times or channel chips, a boxed input field, and the stock column of chat buttons (menu, scroll up, scroll down, jump to latest). It is off by default and fully reversible.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.7.0

- **Ignore from a whisper:** Right-click a whisper (or use the "..." menu in the hub) and choose Ignore. It asks first, then adds the player to your ignore list.
- **Animated emotes:** Twitch Emotes that animate now play in whisper bubbles, the tile tooltip and the emote drawer.
- **Emotes in previews:** The new-whisper popup and the tile tooltip show emotes as pictures instead of their names. The emote drawer is now opaque so it is easier to read.
- **Battle.net conversations are saved:** They now survive a reload and are matched back to the friend by BattleTag, including conversations where the friend has not replied.
- **Resizable tile window:** Drag any edge or corner of the whisper tile window to resize it; the size is remembered. The hub also gets edge grabs (its corner grip stays), and both windows can now be dragged shorter.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.6.3

- **Hub buttons:** The close button, the buttons beside the contact name and the select bar's cancel button now share the filled dark look of the hub's chips. The chat box buttons are unchanged.
- **Menus:** The hub's menus now stay above the hub and tile windows, so they no longer look dimmed or tucked behind the window while they close.

## 1.6.2

- **Highlight and copy in whispers:** Drag over text in the whisper hub and tile windows to highlight it (across messages too). The highlight stays until you click away, and Ctrl+C copies it. Right-click copies a message or the whole conversation, and Shift+drag selects whole messages. Turn it off with "Select text inside messages" (Appearance > Messages).
- **Copy automatically:** New option (General > Behavior) that uses the game's own selection in the chat box, hub and tiles, so text is copied as soon as you release the mouse. Useful if Ctrl+C is bound to something else. Needs a reload.
- **Hide dock tiles:** New option (and Shift-click on the stack button) that slides the whisper tiles away without closing any conversation. The stack button and its unread badge stay.
- **Resizable hub list:** Drag the divider between the list and the conversation to make the list wider (double-click to reset). Wider lists show Friends and Hidden as filter chips instead of under the "..." menu.
- **Quick replies** now match the hub's rounded chips.
- **Import setup:** Pasted setups with extra text or code-block backticks around them now import.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.6.1

- **Hub that fits every language:** The Select button and search box size to their text, the select bar is simpler (a select-all box, "N selected", Delete and a cancel button), and the filters are chips for All, Unread and Starred with a "..." menu for Friends and Hidden.
- **Hide conversations:** The x on a hub card now hides the chat instead of deleting it. Hidden chats get their own filter, return with their history when the person replies, and can be deleted from there. Delete in select mode or the right-click menu still asks first.
- **Resizable windows:** Drag the corner to resize the whisper hub and the settings window. Their sizes are remembered. The hub is also a little narrower by default.
- **Dark class artwork:** New option (Appearance > Layout > Tiles) that draws Pigeon's class icons in the class colour on a dark tile, like Class symbols.
- **Forever look:** New Forever preset in Theme that follows Island's Forever style.
- **Recent lines remembered:** The Up and Down arrow recall of lines you sent now survives a reload.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.6.0

- **Edit Mode:** The chat window and a free-standing dock now show up in WoW's Edit Mode, on Retail and Forever. Drag them there, and set the chat's width and height in the Edit Mode panel. Positions are saved per Edit Mode layout. With ElvUI, Pigeon still follows ElvUI's movers.
- **EllesmereUI:** The chat is placed with Edit Mode instead of `/unlock`. Shift-drag and the lock button work again.
- **Dock edge-aware:** A free-standing dock now opens its tiles toward whichever side of the screen has room, so they no longer run off screen. The whisper window also stays fully on screen.
- **Horizontal dock:** New Horizontal dock option (Chat > Placement) lines the tiles up sideways instead of up and down.
- **Chat history length:** New History settings (Chat > Text): choose how many lines are kept in the chat (up to 5,000) and how many are saved across reloads. Larger values use more memory and make the saved file bigger.
- **Lock button:** With ElvUI or EllesmereUI movers, the lock button now really locks (hiding the resize grip) and unlocking opens the mover. The stuck "Drag to move" overlay is gone.
- **Fixed:** A free-standing dock's position is kept across `/reload`.
- **Translations:** New strings are machine drafted, so corrections are welcome.

## 1.5.1

- **Fixed:** With EllesmereUI or ElvUI, the "Drag to move" overlay no longer gets stuck on the chat window. Those suites' move modes now own moving, so Pigeon hides its own overlay.

## 1.5.0

- **Delete conversations:** Hover a window or tile and click the x, or choose Delete conversation from its menu, to delete a whisper conversation for good. The old Close conversation is now Hide conversation.
- **Read dock tiles:** New setting that fades each dock tile once you have read its whisper. It returns to full opacity when a new whisper arrives or the mouse is over it. Works in the tab-bar rail too. Set it to 100% to turn this off.
- **Tile class icons:** The Game icons choice is retired. Profiles that used it now show the crests, which are labelled Class icons.
- **Option tooltips:** Most settings options explain what they do when you hover over them. Greyed-out options still show their tooltip, which says why they are unavailable.
- **Tidier settings:** General is now the first settings page. Settings pages use collapsible section bars with option counts, and the first section opens by default. Options that depend on another switch grey out while it is off, such as Fade after and the window border thickness. The settings scrollbar is fixed.
- **Options in their place:** Chat text size and outline moved to Chat > Text. Lock position, the tab-bar stack button and the envelope icon moved to Chat > Placement. Message rail width moved to Message details. Match Island's look and Reset look moved to Theme. Censor swear words moved to Text.
- **Clearer fade labels:** The two Faded to labels are now Faded to (in combat) and Faded to (when idle).
- **Dock settings:** Removed the Opens toward and Lock dock settings, along with the /pigeon side and /pigeon lock commands. If your dock was locked, Shift-drag it to move it.
- **Dock scale:** The dock scale slider is greyed out while the stack button sits in the chat tab bar.
- **Fewer duplicate options:** Removed the repeated chat font size, outlined text, chat opacity and accent options.
- **Corner radius:** The Corners dropdown is now a Corner radius slider from 0 (square) to 8 (the previous look, and the default). It updates live, so no reload is needed. Square profiles move to 0.
- New options and tooltips are translated (machine drafted; corrections welcome).

## 1.4.0

- **Friends whisper the right character:** Clicking a Battle.net friend in the hub now whispers the character they are playing when it can be reached (same realm on Forever), and falls back to Battle.net otherwise. Whispers from a Battle.net friend's character now show up under the Friends filter too, even after they log off.
- **Friends in the whisper hub:** A new Friends filter lists your conversations with friends, then the rest of your character and Battle.net friends, grouped Online and Offline. Click one to start a whisper.
- **Hub filter highlight:** The selected filter now uses the same rounded highlight as the chat tabs.
- **Clean up whispers:** Select mode in the whisper hub lets you tick conversations (or Select all) and delete them. The hub list now scrolls smoothly, and the filter highlight slides between tabs.

## 1.3.0

- **Translations:** Pigeon's text can now be translated. Included as machine-translated drafts: Simplified Chinese, Traditional Chinese, German, Spanish (Spain), Spanish (Latin America), French, Korean, Brazilian Portuguese and Russian. Tell us about anything that reads oddly.

## 1.2.1

- **Highlight in chat:** Dragging over a message that wraps onto several lines now highlights just the part you dragged, line by line, instead of covering the whole message.
- **Double-click to select:** Double-click a chat message to select all of it, then press Ctrl, then C to copy.
- **Move the chat from the bird button:** Shift-drag the bird button to move the chat box again. It works even while the chat is locked or when EllesmereUI is loaded.

## 1.2.0

- **Chat border:** New Show chat border switch and Chat border thickness (1 to 6) in Appearance. A thicker border grows outward, so it never covers your chat.
- **Settings window look:** Choose the settings window's background and border color, opacity and thickness, or hide its border. Reset window colours puts it back.
- **Class color:** Each color swatch in Appearance has a small Class button. Turn it on to use your class color for the chat background, chat border, whisper and your text, Battle.net text, or the window border.
- **Tidier Appearance page:** Settings are grouped into Colours, Chat window, Text colours and Settings window, and the opacity sliders now sit with the chat window options.
- **Chat edit box:** Press Up or Down to bring back lines you sent earlier.
- **Cleaner header:** Removed the thin divider lines beside the bird icon and under the tabs.

## 1.1.1

- Fixed the chat highlight running past the end of the text to the edge of the chat when you select several lines.

## 1.1.0

- **Highlight and copy in chat:** drag over any part of a chat line to highlight it. The highlight stays while you scroll with the mouse wheel or drag past the top or bottom edge. Press Ctrl, then C, to copy exactly what you highlighted. A plain click clears it, and links still click as before.
- Removed the copy button from the chat toolbar. Highlighting replaces it. The text window used for profile export and import now scrolls with the mouse wheel.

## 1.0.7

- No gameplay changes. Maintenance release to verify the CurseForge release pipeline.

## 1.0.6

- **Game version:** Pigeon now lists WoW Forever (1.60.1) only. Retail has not been tested yet, so it is no longer advertised. No code changes.

## 1.0.5

- No gameplay changes. Version bump to test the new automated release process.

## 1.0.4

- **Arrow-key editing:** Move the cursor in the main chat input with the arrow keys, without holding Alt.
- **Send arrow alignment:** Fixed the send icon gradually shifting downward when sending hides the input before the mouse button is released. Button icons now return to their original position after interrupted clicks.
- **Island theme matching:** Reads the active Island profile's settings when available, while retaining compatibility with older Island versions.

Existing settings and conversation history are retained.
