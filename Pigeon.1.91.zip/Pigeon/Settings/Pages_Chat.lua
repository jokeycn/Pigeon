--[[
    Pigeon - Settings: the Chat (layout and text) page. Split from Settings.lua.
]]

local _, ns = ...
local T = ns.Theme
local LT = ns.L
local K = ns.SettingsKit
local builders = K.builders
local ApplyChat, ChatDB, Choice, Heading, Note, S, Scroller, SetEnabled, SettingsButton, SettingsText, Slider, Stack, Swatch, Toggle = K.ApplyChat, K.ChatDB, K.Choice, K.Heading, K.Note, K.S, K.Scroller, K.SetEnabled, K.SettingsButton, K.SettingsText, K.Slider, K.Stack, K.Swatch, K.Toggle

function builders.chat(page)

    local db = ChatDB()

    local outer = page

    local content, done = Scroller(outer)

    page = content -- everything below builds on the scrolling content

    local st = Stack(page, 0, 0)

    if ns.Chat.blockedBy then

        local warn = SettingsText(page, 12, { 1, 0.6, 0.3, 1 })

        warn:SetWidth(440)

        warn:SetJustifyH("LEFT")

        warn:SetText(LT["%s is loaded, so the chat box is off. Disable %s and reload to use it."]:format(ns.Chat.blockedBy, ns.Chat.blockedBy))

        st:Add(warn, 10)

    end

    local reload = { Show = function() S:NeedReload() end } -- the header shows "Reload to apply"

    st:Head(LT["Chat box"])

    st:Add(Toggle(page, LT["Use the Pigeon chat box"], function() return db.enabled end,

        function(v) db.enabled = v reload:Show() end))

    st:Add(Choice(page, LT["Input box"], { { "inside", LT["Inside chat"] }, { "below", LT["Below chat"] }, { "above", LT["Above chat"] } },

        function() return db.editTop and "above" or (db.editInside and "inside" or "below") end,

        function(v)

            db.editTop = v == "above"

            db.editInside = v == "inside"

            ApplyChat()

        end))

    st:Add(Slider(page, LT["Input bar height"], 28, 44, 1, function() return db.inputHeight or 44 end,
        function(v) db.inputHeight=v ApplyChat() end, function(v) return LT["%d px"]:format(v) end))

    st:Add(Toggle(page, LT["Classic chat"], function() return db.classic and true or false end,
        function(v) db.classic = v and true or false ApplyChat() end, nil,
        LT["Makes the chat box look like the game's own chat: a plain dark panel, square tabs, outlined text without times or channel chips, and scroll buttons on the left."]))

    if ns.ElvUI.Loaded() then

        st:Head("ElvUI")

        if ns.ElvUI.CanFit() then

            st:Add(Toggle(page, LT["Fit to ElvUI's left chat panel"], function() return db.fitElvUI end, function(v)

                db.fitElvUI = v

                reload:Show() -- movers and anchors are set up at load

            end, nil, LT["Fits the chat box into ElvUI's left chat panel. Needs a reload."]))

        end

        st:Add(Toggle(page, LT["Use ElvUI's font and colours"], function() return ns.db.elvuiStyle end, function(v)

            ns.db.elvuiStyle = v

            T.Refresh()

            ns.Refresh()

            ApplyChat()

            reload:Show() -- a few panels only pick it up after a reload

        end))

        if ns.ElvUI.UsesMovers() then

            local note = SettingsText(page, 11, T.SECTION)

            note:SetWidth(280)

            note:SetJustifyH("LEFT")

            note:SetText(LT["Dock and chat are positioned with /moveui."])

            st:Add(note)

        end

    end

    if ns.Ellesmere.Loaded() then

        st:Head(LT["EllesmereUI"])

        st:Add(Toggle(page, LT["Use EllesmereUI's font and accent"], function() return ns.db.euiStyle end, function(v)

            ns.db.euiStyle = v

            T.Refresh()

            ns.Refresh()

            ApplyChat()

            reload:Show()

        end))


        if ns.EditMode and ns.EditMode.registered then

            local note = SettingsText(page, 11, T.SECTION)

            note:SetWidth(280)

            note:SetJustifyH("LEFT")

            note:SetText(LT["Chat and dock move in WoW's Edit Mode."])

            st:Add(note)

        end

    end



    st:Head(LT["Tab bar"])

    local hiddenAlpha -- greyed out unless the tab bar is set to hide
    st:Add(Choice(page, LT["Tab bar"], { { "always", LT["Always shown"] }, { "hover", LT["Show on hover"] } },

        function() return db.tabsMode == "hover" and "hover" or "always" end,

        function(v)
            db.tabsMode = v == "hover" and "hover" or nil
            ApplyChat()
            if hiddenAlpha then hiddenAlpha:Refresh() end
        end, 200,
        LT["Show on hover hides the tabs, the chat controls and the stack button in the tab bar until the mouse is over the chat or you are typing."]))

    hiddenAlpha = st:Add(Slider(page, LT["Tab bar when hidden"], 0, 0.8, 0.1, function() return db.tabsHiddenAlpha or 0 end,

        function(v) db.tabsHiddenAlpha = v ~= 0 and v or nil ApplyChat() end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, 200,
        LT["How visible the tab bar stays while hidden. 0 hides it completely."]))
    do
        local hiddenReason = LT["Set Tab bar to Show on hover to use this."]
        local refresh = hiddenAlpha.Refresh
        hiddenAlpha.Refresh = function(self, ...)
            if refresh then refresh(self, ...) end
            SetEnabled(self, db.tabsMode == "hover", hiddenReason)
        end
        SetEnabled(hiddenAlpha, db.tabsMode == "hover", hiddenReason)
    end

    st:Add(Slider(page, LT["Tab bar height"], 32, 80, 1, function() return db.tabBarHeight or 52 end,
        function(v) db.tabBarHeight = v ApplyChat() end, function(v) return LT["%d px"]:format(v) end))

    st:Add(Slider(page, LT["Tab text size"], 10, 22, 1, function() return db.tabFontSize or 14 end,

        function(v) db.tabFontSize = v ApplyChat() end, nil, 200,
        LT["Size of the tab names above the chat."]))

    st:Add(Slider(page, LT["Tab background"], 0, 1, 0.1, function() return db.tabBgAlpha or 1 end,

        function(v) db.tabBgAlpha = v ApplyChat() end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, 200,
        LT["How solid the highlight behind the selected tab is. 0 leaves only the tab text."]))

    st:Add(Slider(page, LT["Inactive tab opacity"], 0.2, 1, 0.1, function() return db.tabInactiveAlpha or 1 end,

        function(v) db.tabInactiveAlpha = v ~= 1 and v or nil ApplyChat() end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, 200,
        LT["How visible the tabs you are not on are. Each comes back when the mouse is over it."]))

    st:Add(Toggle(page, LT["Include the options and stack buttons"], function() return db.tabFadeExtras and true or false end,

        function(v) db.tabFadeExtras = v or nil ApplyChat() end, 200,
        LT["Also fades the options button and the stack button in the tab bar to the inactive tab opacity. Each comes back when the mouse is over it, and the stack button stays solid while you have unread whispers."]))

    st:Head(LT["Tab counters"])
    st:Add(Note(page, LT["The small number on a tab counts new messages you have not read. Switch a kind off to stop it adding to that number, which helps with kinds that arrive in floods. Its messages still appear in the tab."], 200), 10)
    do
        local noisy = { loot = true, xp = true, npcsay = true, bghorde = true, system = true }
        for _, group in ipairs(ns.CHAT_CATEGORY_GROUPS) do
            local keys = group[2]
            local isNoisy = false
            for _, k in ipairs(keys) do if noisy[k] then isNoisy = true end end
            if isNoisy then
                st:Add(Toggle(page, group[1], function()
                    local skip = ChatDB().noCount
                    return not (skip and skip[keys[1]])
                end, function(v)
                    local cdb = ChatDB()
                    cdb.noCount = cdb.noCount or {}
                    for _, k in ipairs(keys) do cdb.noCount[k] = (not v) or nil end
                end, 200, LT["On: new messages of this kind add to the tab's number. Off: they still show, but are not counted."]))
            end
        end
    end

    local col = st

    col:Head(LT["Text"])

    col:Add(Choice(page, LT["Time"], { { "off", LT["Off"] }, { "%H:%M", "21:04" }, { "%H:%M:%S", "21:04:05" }, { "%I:%M %p", "9:04 PM" }, { "%I:%M", LT["9:04 (12-hour)"] } },

        function() return db.timestamps end, function(v) db.timestamps = v ApplyChat() end, 200))

    col:Add(Choice(page, LT["Channels"], { { "tag", LT["Chips"] }, { "tagtext", LT["Tag letters (T)"] }, { "name", LT["Name (Trade)"] }, { "number", LT["Number (2)"] }, { "off", LT["Number and name (2. Trade)"] } },

        function() return db.shorten end, function(v) db.shorten = v ApplyChat() end, 200,
        LT["How the channel is shown in front of a chat line. Chips are small coloured pictures; the others are text, with the Trade channel as the example."]))

    col:Add(Toggle(page, LT["Brackets around names"], function() return db.nameBrackets end,

        function(v) db.nameBrackets = v ApplyChat() end, 200))

    col:Add(Slider(page, LT["Chat box text size"], 10, 20, 1, function() return db.fontSize end,

        function(v) db.fontSize = v ApplyChat() end, nil, 200))

    col:Add(Slider(page, LT["Line spacing"], 0, 12, 1, function() return db.lineSpacing or 4 end,

        function(v) db.lineSpacing = v ApplyChat() end, nil, 200,
        LT["Space between chat lines."]))

    col:Add(Choice(page, LT["Chat text outline"], { { "off", LT["Off"] }, { "thin", LT["Thin"] }, { "thick", LT["Thick"] } },

        function() return (not db.outline and "off") or (db.outlineThick and "thick" or "thin") end,

        function(v)
            db.outline = v ~= "off"
            db.outlineThick = v == "thick" or nil
            ApplyChat()
        end, 200,
        LT["An outline around the chat text. Thick is easier to read over busy backgrounds."]))

    col:Head(LT["Channel chips"])

    col:Add(Slider(page, LT["Channel chip size"], 0.6, 1.6, 0.1, function() return db.chipScale or 1 end,

        function(v) db.chipScale = v ~= 1 and v or nil ApplyChat() end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, 200,
        LT["Size of the channel tags shown in chat when Channels is set to Chips."]))

    col:Add(Slider(page, LT["Channel chip position"], -6, 6, 1, function() return db.chipNudge or 0 end,

        function(v) db.chipNudge = v ~= 0 and v or nil ApplyChat() end, function(v) return (v > 0 and "+" or "") .. math.floor(v) end, 200,
        LT["The channel tags centre themselves on the text. This moves them further up (+) or down (-)."]))

    col:Add(Slider(page, LT["Channel chip opacity"], 0.2, 1, 0.1, function() return db.chipAlpha or 1 end,

        function(v) db.chipAlpha = v ~= 1 and v or nil ApplyChat() end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, 200,
        LT["Dims the channel tags so they stand out less. They blend toward the dark chat background."]))

    col:Head(LT["History"])

    local HIST = { { 200, "200" }, { 600, "600 (" .. LT["default"] .. ")" }, { 1000, "1,000" }, { 2500, "2,500" }, { 5000, "5,000" } }
    col:Add(Choice(page, LT["Lines kept in chat"], HIST,
        function() return db.historyLines or 600 end, function(v) db.historyLines = v ApplyChat() end, 200,
        LT["How many chat lines Pigeon keeps to scroll back through. Higher values use more memory."]))
    col:Add(Choice(page, LT["Lines saved across reloads"], HIST,
        function() return db.historySaved or 200 end, function(v) db.historySaved = v ApplyChat() end, 200,
        LT["How many lines come back after a reload or relog. Never more than Lines kept in chat. Higher values make the saved file larger."]))

    local reset = SettingsButton(page, LT["Reset chat position"], 150, 24)

    reset:SetScript("OnClick", function()

        db.point = { "BOTTOMLEFT", "BOTTOMLEFT", 24, 60 }

        db.width, db.height = 520, 260

        if ns.Chat.smf then

            ns.Chat:ClearAllPoints()

            ns.Chat:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 24, 60)

            ns.Chat:SetSize(520, 260)

        end

    end)

    -- One colour per kind of message, for the chat text. Right-click a swatch to go back to
    -- the game's own colour.
    col:Head(LT["Chat text colours"])
    col:Add(Note(page, LT["Pick a colour for a kind of message. It applies to that kind everywhere in the chat box. Right-click a colour to go back to the game's own."], 200), 10)
    do
        local cdb = ns.db.chat
        local labels = {}
        for _, c in ipairs(ns.CHAT_CATEGORIES) do labels[c.key] = c.label end
        -- The game's own colour for this kind: the latest line of it you have seen, else the
        -- game's colour for its chat type. Shown until you pick your own.
        local CHANNEL_CATS = { general = true, trade = true, services = true, lfg = true, defense = true, newcomer = true, channel = true }
        local function Seen(key)
            local log = ns.Chat and ns.Chat.log
            if log then
                for i = #log, 1, -1 do
                    local e = log[i]
                    if e.cat == key and e.r then return { e.r, e.g, e.b } end
                end
            end
            local info = _G.ChatTypeInfo
            if info then
                if CHANNEL_CATS[key] and info.CHANNEL then return { info.CHANNEL.r, info.CHANNEL.g, info.CHANNEL.b } end
                local kinds = {}
                for kind, cat in pairs(ns.CHAT_EVENT_CAT or {}) do
                    if cat == key and info[kind] then kinds[#kinds + 1] = kind end
                end
                table.sort(kinds)
                local c = kinds[1] and info[kinds[1]]
                if c then return { c.r, c.g, c.b } end
            end
            return T.TEXT
        end
        for _, group in ipairs(ns.CHAT_CATEGORY_GROUPS) do
            col:Add(Heading(page, group[1]), 4)
            for _, key in ipairs(group[2]) do
                if labels[key] then
                    col:Add(Swatch(page, labels[key], function() return cdb.channelColors and cdb.channelColors[key] end,
                        function(c)
                            cdb.channelColors = cdb.channelColors or {}
                            cdb.channelColors[key] = c
                            if not c and next(cdb.channelColors) == nil then cdb.channelColors = nil end
                            if ns.Chat.smf then ns.Chat:ApplySettings() end
                        end, function() return Seen(key) end, false, 200))
                end
            end
        end
    end

    st:Head(LT["Placement"])

    st:Add(Toggle(page, LT["Lock position and size"], function() return db.locked end, function(v)

        if ns.Chat.smf then ns.Chat:SetLocked(v) else db.locked = v end

    end))

    st:Add(reset)

    outer.widgets = {}

    for _, w in ipairs(st.widgets) do outer.widgets[#outer.widgets + 1] = w end

    outer.labels = {}

    for _, l in ipairs(st.labels) do outer.labels[#outer.labels + 1] = l end

    done(math.max(st.y, col.y) + 8)

end



-- Category toggles grouped the way people think about chat.
