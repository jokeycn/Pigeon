--[[
    Pigeon - Settings: the Replies, Alerts, Behavior and Profiles pages. Split from Settings.lua.
]]

local _, ns = ...
local T = ns.Theme
local LT = ns.L
local K = ns.SettingsKit
local builders = K.builders
local ApplyChat, ChatDB, Choice, Heading, Note, S, Scroller, SetEnabled, SettingsButton, SettingsText, Slider, Stack, TextInput, Toggle = K.ApplyChat, K.ChatDB, K.Choice, K.Heading, K.Note, K.S, K.Scroller, K.SetEnabled, K.SettingsButton, K.SettingsText, K.Slider, K.Stack, K.TextInput, K.Toggle

function builders.replies(page)

    local db = ns.db

    local W = 440

    local content, done = Scroller(page)

    local st = Stack(content, 0, 0)



    st:Head(LT["Quick replies"])

    st:Add(Toggle(content, LT["Show quick replies above the whisper box"], function() return db.showQuickReplies ~= false end,

        function(v) db.showQuickReplies = v ns.Refresh() end, W))

    st:Add(Note(content, LT["Click one to send it, Shift-click to add it to what you're typing. Leave a box empty to drop it."], W), 10)

    for i = 1, 6 do

        st:Add(TextInput(content, nil, function() return db.quickReplies[i] end, function(v)

            db.quickReplies[i] = v ~= "" and v or nil

            -- keep the list without gaps

            local packed = {}

            for j = 1, 6 do if db.quickReplies[j] then packed[#packed + 1] = db.quickReplies[j] end end

            db.quickReplies = packed

            ns.Refresh()

            for _, w in ipairs(page.widgets or {}) do

                if w.box and not w.box.edit:HasFocus() then w:Refresh() end

            end

        end, W, LT["Reply %d"]:format(i),
            LT["A quick reply shown above the whisper box. Leave it empty to remove it."]), 4)

    end



    st:Head(LT["Away message"])

    st:Add(Toggle(content, LT["Answer whispers automatically"], function() return db.away.enabled end,

        function(v) db.away.enabled = v ns.Social.ResetAway() ns.Refresh() end, W))

    st:Add(TextInput(content, LT["Message"], function() return db.away.message end,

        function(v) if v ~= "" then db.away.message = v end end, W, LT["I'm away right now"],
        LT["The text sent as an automatic reply while you are away."]))

    st:Add(Choice(content, LT["Only when"], { { "always", LT["Always"] }, { "instance", LT["In an instance"] }, { "combat", LT["In combat"] } },

        function() return db.away.when end, function(v) db.away.when = v end, W))

    st:Add(Note(content, LT["Sent as \"<Away> your message\", at most once per person every 15 minutes. /pigeon away toggles it; /pigeon away <text> sets a new message."], W), 10)

    done(st.y + 8)

    page.widgets = st.widgets

    page.labels = st.labels

end



function builders.alerts(page)

    local c = ChatDB()

    local W = 440

    local content, done = Scroller(page)

    local st = Stack(content, 0, 0)



    st:Head(LT["Keyword alerts"])

    st:Add(TextInput(content, LT["Words to watch for (separate with commas)"], function() return c.alerts.words end,

        function(v) c.alerts.words = v if ns.Chat.smf then ns.Chat:Rerender() end end, W, LT["e.g. LFM, healer, Ragefire"]))

    st:Add(Toggle(content, LT["Include my character's name"], function() return c.alerts.myName end,

        function(v) c.alerts.myName = v end, W,
        LT["Your own character name counts as a watched word."]))

    st:Add(Toggle(content,LT["Open watched matches as conversations"],function()return c.alerts.openMatches~=false end,
        function(v)c.alerts.openMatches=v end,W,
        LT["A matching player message opens a whisper tile."]))
    st:Add(Note(content,LT["Custom watched words add a sender tile and open their whisper window. Public messages are labeled as keyword matches. An existing reply draft keeps its recipient."],W),6)

    st:Add(Toggle(content, LT["Play a soft ping"], function() return c.alerts.sound end,

        function(v) c.alerts.sound = v end, W))

    st:Add(Note(content, LT["Matches are highlighted in gold, and a tab that's not open turns gold when one comes in."], W), 10)



    st:Head(LT["Spam filter"])

    st:Add(Toggle(content, LT["Hide repeated lines (same person, same text, within a minute)"], function() return c.spam.dupes end,

        function(v) c.spam.dupes = v end, W))

    st:Add(Toggle(content, LT["Hide adverts (websites, gold selling, boosting)"], function() return c.spam.gold end,

        function(v) c.spam.gold = v end, W))

    local count = st:Add(Note(content, "", W), 10)

    count.Refresh = function(self)

        self:SetText(LT["Only public channels are filtered, never guild, group or whispers. Hidden this session: %d."]:format(ns.Chat.spamHidden or 0))

    end

    count:Refresh()

    st.widgets[#st.widgets + 1] = count

    -- The game's own mature language filter (swaps swear words for symbols).

    st:Add(Toggle(content, LT["Censor swear words"], function() return ns.ProfanityFilter() end, function(v) ns.SetProfanityFilter(v) end, W,
        LT["Uses the game's mature language filter."]))



    st:Head(LT["Group finding"])

    local function Rerender() if ns.Chat.smf then ns.Chat:Rerender() end end

    st:Add(Toggle(content, LT["Spot LFG / LFM messages"], function() return c.lfg.enabled end,

        function(v) c.lfg.enabled = v Rerender() end, W))

    st:Add(Toggle(content, LT["Colour roles (tank, healer, dps)"], function() return c.lfg.roles end,

        function(v) c.lfg.roles = v Rerender() end, W))

    st:Add(Toggle(content, LT["Add [w] whisper and [inv] invite buttons"], function() return c.lfg.buttons end,

        function(v) c.lfg.buttons = v Rerender() end, W))

    done(st.y + 8)

    page.widgets = st.widgets

    page.labels = st.labels

end



function builders.behavior(page)

    local db = ns.db

    local W = 440

    local content, done = Scroller(page)

    local st = Stack(content, 0, 0)

    local modes = { { "normal", LT["Stay"] }, { "fade", LT["Fade"] }, { "tuck", LT["Tuck away"] }, { "hide", LT["Hide"] } }



    st:Head(LT["In combat"])

    st:Add(Choice(content, LT["Dock and whisper window"], modes, function() return db.combat.whispers end,

        function(v) db.combat.whispers = v if ns.Dock.ApplyAutoHide then ns.Dock:ApplyAutoHide() end end, W,
        LT["Whether the dock and whisper window stay as they are, fade, or hide in combat. Tuck away slides the tiles in and holds back previews, but keeps the Pigeon button and its unread count."]))

    st:Add(Choice(content, LT["Chat box"], { { "normal", LT["Stay"] }, { "fade", LT["Fade"] } },

        function() return db.combat.chat end, function(v) db.combat.chat = v end, W,
        LT["Fade dims the whole chat box in combat: background, tabs, input and messages. A new message on the current tab or hovering the chat brings it back."]))

    st:Add(Slider(content, LT["Faded to (in combat)"], 0, 0.8, 0.05, function() return db.combat.alpha end,

        function(v) db.combat.alpha = v end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, W,
        LT["How see-through things become while faded in combat."]))

    st:Add(Slider(content, LT["Show chat for (in combat)"], 1, 15, 1, function() return db.combat.wake or 4 end,

        function(v) db.combat.wake = v end, function(v) return LT["%ds"]:format(v) end, W,
        LT["While faded in combat, hovering the chat or a new message on the current tab brings it back for this long."]))

    st:Add(Note(content, LT["Whispers still arrive and play their sound; everything comes back when combat ends."], W), 10)



    st:Head(LT["Chat box when idle"])

    st:Add(Slider(content, LT["Fade the background after"], 0, 120, 5, function() return ChatDB().idleFade end,

        function(v) ChatDB().idleFade = v end, function(v) return v == 0 and LT["Never"] or LT["%ds"]:format(v) end, W,
        LT["Idle seconds before the chat box background fades. 0 never fades."]))

    st:Add(Slider(content, LT["Faded to (when idle)"], 0, 0.8, 0.05, function() return ChatDB().idleAlpha end,

        function(v) ChatDB().idleAlpha = v end, function(v) return math.floor(v * 100 + 0.5) .. "%" end, W,
        LT["How see-through the chat box background becomes when idle."]))

    st:Add(Toggle(content, LT["Hide the messages too"], function() return ChatDB().idleHideText end,
        function(v) ChatDB().idleHideText = v or nil end, W,
        LT["When idle, the message text fades with the background. A new message on the current tab, hovering the chat, or typing brings it back."]))

    st:Add(Note(content, LT["Hover the chat or start typing and it comes straight back."], W), 10)

    st:Head(LT["Old messages"])

    local cdb = ChatDB()
    local fadeAfter
    st:Add(Toggle(content, LT["Fade old messages"], function() return cdb.fade end,
        function(v) cdb.fade = v ApplyChat() if fadeAfter then fadeAfter:Refresh() end end, W))

    fadeAfter = st:Add(Slider(content, LT["Fade after"], 10, 300, 10, function() return cdb.fadeAfter end,
        function(v) cdb.fadeAfter = v ApplyChat() end, function(v) return LT["%ds"]:format(v) end, W))
    do -- greyed while Fade old messages is off
        local refresh = fadeAfter.Refresh
        fadeAfter.Refresh = function(self, ...)
            refresh(self, ...)
            SetEnabled(self, cdb.fade, LT["Turn on Fade old messages."])
        end
        SetEnabled(fadeAfter, cdb.fade, LT["Turn on Fade old messages."])
    end



    st:Head(LT["Dock"])

    st:Add(Toggle(content, LT["Hide dock tiles"], function() return ns.db.hideTiles and true or false end,
        function(v) ns.Dock:SetTilesHidden(v) end, W,
        LT["Tucks the whisper tiles away without closing any conversation. The stack button stays and still shows unread whispers. Stays hidden until you turn it off. (Shift-clicking the stack button tucks them just for now.)"]))

    st:Add(Toggle(content, LT["Show tiles again when a whisper arrives"], function() return db.showTilesOnWhisper ~= false end,
        function(v) db.showTilesOnWhisper = v end, W,
        LT["After Shift-clicking the stack button to tuck the tiles away, a new whisper brings them back. (The Hide dock tiles setting stays hidden.)"]))

    st:Add(Toggle(content, LT["Tuck the dock away in instances"], function() return db.hideDockInstance end,
        function(v) db.hideDockInstance = v or nil if ns.Dock.ApplyAutoHide then ns.Dock:ApplyAutoHide() end end, W,
        LT["Tucks the tiles away and holds back previews in dungeons, raids, battlegrounds and arenas. The Pigeon button and its unread count stay."]))

    st:Head(LT["Copying text"])

    st:Add(Toggle(content, LT["Select text inside messages"], function() return not (db.look and db.look.bubbleSelect == false) end,
        function(v)
            db.look = db.look or {}
            db.look.bubbleSelect = v
            ns.ApplyLook()
        end, W))

    st:Add(Toggle(content, LT["Copy automatically when I release the mouse"], function() return db.look and db.look.selectAutoCopy and true or false end,
        function(v)
            db.look = db.look or {}
            db.look.selectAutoCopy = v or nil
            S:NeedReload() -- the message frames pick their selection mode when they load
        end, W,
        LT["Uses the game's own text selection: whatever you select is copied to the clipboard the moment you release the mouse (the highlight then disappears). Use this if Ctrl+C is bound to something else. Needs a /reload to take effect."]))

    st:Add(Note(content, LT["Applies to selecting text in the chat box, the whisper hub and the tile windows."], W), 10)



    st:Head(LT["Launcher"])

    st:Add(Toggle(content, LT["Minimap button"], function() return not db.minimap.hide end,

        function(v) db.minimap.hide = not v ns.Launcher.ApplyMinimap() end, W))

    st:Add(Note(content, LT["A \"Whispers\" entry with the unread count is also available to data bars that support LibDataBroker (ElvUI, EllesmereUI, Titan…)."], W), 10)

    done(st.y + 8)

    page.widgets = st.widgets

    page.labels = st.labels

end



function builders.profiles(page)

    local P = ns.Profiles

    local W = 440

    local content, done = Scroller(page)

    local st = Stack(content, 0, 0)



    StaticPopupDialogs.PIGEON_UPDATE_PROFILE = {
        text = LT["Replace profile %s with your current settings?"],
        button1 = YES, button2 = NO,
        OnAccept = function(_, data)
            if data and P.Save(data.name) then
                ns.Print(LT["updated profile |cffe6ebf5%s|r."]:format(data.name))
                if data.page then data.page:Render() end
            end
        end,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
    }

    st:Head(LT["Save this setup"])

    local nameInput = TextInput(content, nil, function() return "" end, function() end, W - 110, LT["Profile name"])

    st:Add(nameInput, 8)

    local save = SettingsButton(content, LT["Save"], 100, 28, true)

    save:SetPoint("LEFT", nameInput, "RIGHT", 10, 0)

    save:SetScript("OnClick", function()

        local name = strtrim(nameInput.box.edit:GetText() or "")

        if P.Save(name) then

            nameInput.box.edit:SetText("")

            nameInput.box.edit:ClearFocus()

            ns.Print(LT["saved profile |cffe6ebf5%s|r."]:format(name))

            page:Render()

        end

    end)

    st:Add(Note(content, LT["Settings are shared by all your characters. Profiles let you keep several setups and give a character its own."], W), 10)



    st:Head(LT["Profiles"])

    local card = st.card -- grows with the list below, sized in Render

    local X = st.x

    local listTop = st.y

    page.rows = {}

    local empty = SettingsText(content, 12, T.SECTION)

    empty:SetPoint("TOPLEFT", X, -listTop)

    empty:SetText(LT["No profiles saved yet."])



    local function Row(i)

        local r = page.rows[i]

        if r then return r end

        r = CreateFrame("Frame", nil, content)

        r:SetSize(W, 28)

        r.bg = r:CreateTexture(nil, "BACKGROUND")

        r.bg:SetAllPoints()

        r.bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.03 or 0)

        r.name = SettingsText(r, 12, T.TEXT)

        r.name:SetPoint("LEFT", 8, 0)

        r.name:SetPoint("RIGHT", -316, 0)

        r.name:SetJustifyH("LEFT")

        r.name:SetWordWrap(false)

        r.del = SettingsButton(r, LT["Delete"], 60, 22)

        r.del:SetPoint("RIGHT", -2, 0)

        r.del.label:SetTextColor(1, 0.55, 0.5)

        r.auto = SettingsButton(r, LT["Use here"], 90, 22)

        r.auto:SetPoint("RIGHT", r.del, "LEFT", -6, 0)

        r.load = SettingsButton(r, LT["Load"], 60, 22, true)

        r.load:SetPoint("RIGHT", r.auto, "LEFT", -6, 0)

        r.update = SettingsButton(r, LT["Update"], 70, 22)
        r.update:SetPoint("RIGHT", r.load, "LEFT", -6, 0)
        r.update:SetScript("OnClick", function()
            StaticPopup_Show("PIGEON_UPDATE_PROFILE", r.profile, nil, { name = r.profile, page = page })
        end)
        r.update:SetScript("OnEnter", function(b)
            GameTooltip:SetOwner(b, "ANCHOR_TOP")
            GameTooltip:AddLine(LT["Replace this profile with your current settings"])
            GameTooltip:Show()
        end)
        r.update:SetScript("OnLeave", function() GameTooltip:Hide() end)

        r.load:SetScript("OnClick", function()

            if P.Load(r.profile) then

                ns.Print(LT["loaded |cffe6ebf5%s|r. Some layout changes need a /reload."]:format(r.profile))

                page:Render()

            end

        end)

        r.auto:SetScript("OnClick", function()

            local mine = P.CharacterProfile() == r.profile

            P.SetCharacterProfile(not mine and r.profile or nil)

            page:Render()

        end)

        r.auto:SetScript("OnEnter", function(b)

            GameTooltip:SetOwner(b, "ANCHOR_TOP")

            GameTooltip:AddLine(LT["Load this profile whenever this character logs in"])

            GameTooltip:Show()

        end)

        r.auto:SetScript("OnLeave", function() GameTooltip:Hide() end)

        r.del:SetScript("OnClick", function()

            P.Delete(r.profile)

            page:Render()

        end)

        page.rows[i] = r

        return r

    end



    local share = Heading(content, LT["Share"])

    local exportBtn = SettingsButton(content, LT["Export setup"], 130, 28)

    exportBtn:SetScript("OnClick", function() P.ShowExport() end)

    local importBtn = SettingsButton(content, LT["Import setup"], 130, 28)

    importBtn:SetScript("OnClick", function() P.ShowImport() end)

    local shareNote = Note(content, LT["Export gives one line of text to paste to a friend; Import turns one back into a profile."], W)



    function page:Render()

        local names = P.List()

        local mine = P.CharacterProfile()

        local y = listTop

        for i, name in ipairs(names) do

            local r = Row(i)

            r.profile = name

            r:ClearAllPoints()

            r:SetPoint("TOPLEFT", X, -y)

            r.name:SetText(mine == name and LT["%s   |cff7a94d1(this character)|r"]:format(name) or name)

            r.auto.label:SetText(mine == name and LT["Stop using"] or LT["Use here"])

            r:Show()

            y = y + 30

        end

        for i = #names + 1, #self.rows do self.rows[i]:Hide() end

        empty:SetShown(#names == 0)

        if #names == 0 then y = y + 22 end

        y = y + 10

        share:ClearAllPoints()

        share:SetPoint("TOPLEFT", X, -(y + 6))

        y = y + 24

        exportBtn:ClearAllPoints()

        exportBtn:SetPoint("TOPLEFT", X, -y)

        importBtn:ClearAllPoints()

        importBtn:SetPoint("LEFT", exportBtn, "RIGHT", 10, 0)

        y = y + 36

        shareNote:ClearAllPoints()

        shareNote:SetPoint("TOPLEFT", X, -y)

        local bottom = y + (shareNote:GetStringHeight() or 12) + 12

        if card then

            card:SetWidth(W + 12 * 2)

            card:SetHeight(bottom - card.top)

        end

        done(bottom + 20)

    end

    page.widgets = {}

end
