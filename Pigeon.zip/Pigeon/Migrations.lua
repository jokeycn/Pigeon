--[[
    Pigeon - saved-variable migrations.

    db.migrated is the version of the saved settings. At login, Run applies every
    step above it, in order, then stores the newest number. A fresh profile runs
    them all on the defaults; an old profile runs only what it has not had yet.

    Rules for a step:
      * It converts or repairs what is already saved. It never adds tabs, and it
        never overwrites a value the user may have chosen (check before you write).
      * New settings get their default from DEFAULTS in Core.lua, which only fills
        keys that are missing. Do not copy new defaults onto existing users here.
      * Never edit a step that has shipped; add the next number instead.
      * Steps must be safe to run twice.
]]

local _, ns = ...

local M = {}
ns.Migrations = M

local steps = {}

-- 0.6: unlocking now shows the move overlay, so start everyone locked once.
steps[6] = function(db)
    db.chat.locked = true
end

-- 0.8 visual overhaul: flat solid tiles, short channel tags, input inside the chat.
steps[7] = function(db)
    db.look.tileAlpha = 1
    db.chat.shorten = "tag"
    db.chat.editInside = true
end

-- 0.9: Pigeon's own class icons become the standard look. Anyone still on the old
-- default (the game's icons) moves over once; any other choice is kept.
steps[8] = function(db)
    if db.look.classIcons == nil or db.look.classIcons == "game" then db.look.classIcons = "parley" end
end

-- Adopt the approved conversation design once; keep custom colours and artwork packs.
steps[9] = function(db)
    local look = db.look
    if look.preset == nil or look.preset == "horizon" then look.preset = "softsignal" end
    if look.whisperStyle == "rails" then look.whisperStyle = "signal" end
    look.tileStyle = "symbol"
    look.msgOutline = false
end

-- Existing Island selections should start with Island's own accent. Class tint is opt-in.
steps[10] = function(db)
    if db.look.preset == "island" then db.classTint = false end
end

-- Island is the default; retain other explicitly selected named themes.
steps[11] = function(db)
    if db.look.preset == "softsignal" or db.look.preset == "horizon" then
        db.look.preset = "island"
        db.islandStyle = true
        db.classTint = false
    end
end

-- Adopt the approved chat typography once; later user choices remain editable.
steps[12] = function(db)
    db.chat.outline = false
end

-- Shift-click used to save "tiles hidden" permanently, which would now read as the
-- "Hide dock tiles" setting. Clear that old state once so whispers can bring tiles back.
-- (tuckMigrated is the flag older versions used; honour it so nobody is cleared twice.)
steps[13] = function(db)
    if not db.tuckMigrated then
        db.tuckMigrated = true
        db.hideTiles = nil
    end
end

-- The whisper window is sized with a width and a height now instead of one scale. Fold an
-- existing scale into its size, so the window keeps looking the way it did.
steps[14] = function(db)
    local look = db.look
    local scale = look and tonumber(look.windowScale)
    if scale and scale ~= 1 then
        local base = type(db.windowSize) == "table" and db.windowSize or { 340, 390 }
        local w, h = tonumber(base[1]) or 340, tonumber(base[2]) or 390
        db.windowSize = { math.floor(w * scale + 0.5), math.floor(h * scale + 0.5) }
    end
    if look then look.windowScale = 1 end
end

-- The envelope switch briefly saved to the top level of the settings while the stack button read
-- it from the chat table, so a profile could end up with the icon stuck on. Keep one place.
steps[15] = function(db)
    if db.envelopeIcon then
        if type(db.chat) == "table" then db.chat.envelopeIcon = true end
    end
    db.envelopeIcon = nil
end

-- Channel chips centre themselves now, with Channel chip position as a fine-tune (chipNudge).
-- The old chipOffset made up for chips sitting high, so keeping it would push them off again.
steps[16] = function(db)
    if type(db.chat) == "table" then db.chat.chipOffset = nil end
end

M.steps = steps

local latest = 0
for v in pairs(steps) do if v > latest then latest = v end end
M.latest = latest

-- Apply every step the profile has not had. Returns true when all ran. A step that
-- errors stops the run and is tried again next login; the rest of Pigeon still loads.
function M.Run(db)
    local from = tonumber(db.migrated) or 0
    for v = from + 1, latest do
        local step = steps[v]
        if step then
            local ok, err = pcall(step, db)
            if not ok then
                if ns.Print then ns.Print("settings upgrade " .. v .. " failed: " .. tostring(err)) end
                return false
            end
        end
        db.migrated = v
    end
    return true
end
