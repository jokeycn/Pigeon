--[[
    Pigeon - Expanded window
    Clicking a tile opens the conversation next to the dock. The rounded
    card smoothly expands and collapses at its resting anchor, like Island.
    The "all" button hands off to the whisper hub.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local FULL_W, FULL_H = 340, 390 -- default size
local MIN_H = 250 -- the shortest it can be dragged (header, a few message lines, quick replies and the input)
local SEED = 44        -- the stack button's size: the window starts as that square
local PANEL_GAP = 12

local W = CreateFrame("Frame", "PigeonWindow", UIParent)
ns.Window = W
W:SetSize(FULL_W, FULL_H)
W:SetFrameStrata("DIALOG")
W:SetToplevel(true)
W:EnableMouse(true)
W:SetClipsChildren(true)
W:Hide()
W.growV = 0

local HEADER_H = 64 -- header height: tile, name, level/zone, note

-- Resize limits: the default size is the minimum; the maximum is capped to the screen.
local function Bounds()
    local uw, uh = UIParent:GetWidth() or 1400, UIParent:GetHeight() or 900
    return FULL_W, MIN_H, math.max(FULL_W, math.min(1000, uw - 40)), math.max(FULL_H, math.min(900, uh - 40))
end

-- The window's resting size: the saved size clamped to the limits.
function W:FullSize()
    local minW, minH, maxW, maxH = Bounds()
    local s = ns.db and ns.db.windowSize
    local w, h = type(s) == "table" and tonumber(s[1]), type(s) == "table" and tonumber(s[2])
    if not (w and h) then return minW, FULL_H end
    return math.max(minW, math.min(maxW, w)), math.max(minH, math.min(maxH, h))
end

function W:ApplyBounds()
    local minW, minH, maxW, maxH = Bounds()
    if self.SetResizeBounds then
        self:SetResizeBounds(minW, minH, maxW, maxH)
    else
        if self.SetMinResize then self:SetMinResize(minW, minH) end
        if self.SetMaxResize then self:SetMaxResize(maxW, maxH) end
    end
end

---------------------------------------------------------------------------
-- Rounded-card expansion
---------------------------------------------------------------------------

-- Where the window rests when fully open. Anchored to the dock, so it
-- follows the dock / chat box when they move.
function W:PlaceFinal()
    local fw, fh = self:FullSize()
    self:SetSize(fw, fh)
    self:ClearAllPoints()
    -- Where the window's bottom corner would land, in UIParent units, so it can
    -- be nudged back on screen (a dock near the top or an edge would push it off).
    local sc = (self:GetEffectiveScale() or 1) / (UIParent:GetEffectiveScale() or 1)
    local function Ref(f, xFrac, yFrac)
        local l, b2, w, h = f:GetRect()
        if not l then return nil end
        local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
        return (l + w * xFrac) * s, (b2 + h * yFrac) * s
    end
    local point, rel, relPoint, x, y, bx, by, toRight
    if ns.Dock.attached == "chat" then
        -- Tiles now live inside chat; the pop-out follows the outer left edge.
        local gap = tonumber(ns.db.look and ns.db.look.windowGap) or 0
        point, rel, relPoint, x, y = "BOTTOMLEFT", ns.Chat, "TOPLEFT", 0, gap
        bx, by = Ref(ns.Chat, 0, 1) toRight = true
        if bx then by = by + gap * sc end
    elseif ns.Dock.attached then
        -- External docks retain their existing clearance.
        point, rel, relPoint, x, y = "BOTTOMLEFT", ns.Dock, "BOTTOMLEFT", 36 + PANEL_GAP, (ns.Dock.size or SEED) + 6
        bx, by = Ref(ns.Dock, 0, 0) toRight = true
        if bx then bx, by = bx + x * sc, by + y * sc end
    elseif ns.db.dockHorizontal and ns.Dock.Dir then
        -- The tiles run sideways along the stack button's row, so open the window above
        -- that row (below it when there is no room above), never over the tiles.
        local goesRight = ns.Dock:Dir() == "right"
        local tx, ty = Ref(ns.Dock, goesRight and 0 or 1, 1)
        local _, by0 = Ref(ns.Dock, 0, 0)
        if tx and ty and by0 then
            local h = fh * sc
            local sh = UIParent:GetHeight()
            if ty + PANEL_GAP * sc + h <= sh - 8 then
                point, rel, relPoint, x, y = goesRight and "BOTTOMLEFT" or "BOTTOMRIGHT", ns.Dock, goesRight and "TOPLEFT" or "TOPRIGHT", 0, PANEL_GAP
                bx, by = tx, ty + PANEL_GAP * sc
            else
                point, rel, relPoint, x, y = goesRight and "TOPLEFT" or "TOPRIGHT", ns.Dock, goesRight and "BOTTOMLEFT" or "BOTTOMRIGHT", 0, -PANEL_GAP
                bx, by = tx, by0 - PANEL_GAP * sc - h
            end
            toRight = goesRight
        else
            point, rel, relPoint, x, y = "BOTTOMLEFT", ns.Dock, "BOTTOMRIGHT", PANEL_GAP, 0
        end
    elseif ns.Dock:Side() == "right" then
        point, rel, relPoint, x, y = "BOTTOMLEFT", ns.Dock, "BOTTOMRIGHT", PANEL_GAP, 0
        bx, by = Ref(ns.Dock, 1, 0) toRight = true
        if bx then bx = bx + PANEL_GAP * sc end
    else
        point, rel, relPoint, x, y = "BOTTOMRIGHT", ns.Dock, "BOTTOMLEFT", -PANEL_GAP, 0
        bx, by = Ref(ns.Dock, 0, 0)
        if bx then bx = bx - PANEL_GAP * sc end
    end
    if bx and by then
        local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
        local w, h, m = fw * sc, fh * sc, 8
        local left = toRight and bx or (bx - w)
        local dx, dy = 0, 0
        if by + h > sh - m then dy = (sh - m) - (by + h) end
        if by + dy < m then dy = m - by end
        if left + w > sw - m then dx = (sw - m) - (left + w) end
        if left + dx < m then dx = m - left end
        x, y = x + dx / sc, y + dy / sc
    end
    self:SetPoint(point, rel, relPoint, x, y)
end

-- A frame's rectangle in UIParent coordinates.
local function Rect(f)
    local l, b = f:GetLeft(), f:GetBottom()
    if not (l and b) then return nil end
    local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return { x = l * s, y = b * s, w = f:GetWidth() * s, h = f:GetHeight() * s }
end

-- Fallback when the client hasn't resolved a tile's position yet: dock
-- rectangle + the tile's own offsets (tiles sit BOTTOMLEFT on the dock).
local function TileRect(tile)
    local r = Rect(tile)
    if r then return r, "tile" end
    local d = Rect(ns.Dock)
    if d and tile.curY then
        local w = tile:GetWidth()
        return { x = d.x + (tile.curX or 0), y = d.y + tile.curY, w = w, h = tile:GetHeight() }, "tile (from anchor)"
    end
end

-- The square the window grows out of / shrinks back into: the conversation's
-- own tile when it has one, otherwise the stack button.
function W:OriginRect()
    local c = self.convo
    local tile = c and ns.Dock.byKey[c.key]
    local rect, source
    if tile and tile:IsShown() and tile.convo == c then
        rect, source = TileRect(tile)
    end
    if not rect then rect, source = Rect(ns.Dock), "stack button" end
    if ns.debugAnim and rect then
        ns.Print(("window %s the %s at %d, %d (%dx%d)"):format(self.wsClosing and "shrinks into" or "grows out of",
            source, rect.x, rect.y, rect.w, rect.h))
    end
    self.originColor = { ns.ConvoColor(c or {}) }
    return rect
end

-- Expand the actual rounded card at its resting anchor. Children are clipped
-- until there is room for them, rather than painted into a separate silhouette.
function W:ApplyGrow(v)
    self.growV = v
    local fw, fh
    if self == W then fw, fh = self:FullSize() end
    local w = self == W and fw or (self.toRect and self.toRect.w or self:GetWidth())
    local h = self == W and fh or (self.toRect and self.toRect.h or self:GetHeight())
    self:SetSize(w * (0.94 + 0.06 * v), math.max(1, 44 + (h - 44) * v))
    self:SetAlpha(math.max(0, math.min(1, v * 3)))
    if self.content then self.content:SetAlpha(math.max(0, math.min(1, (v - 0.18) / 0.82))) end
    if self == W then self:ShowEdges(v >= 1) end
    if v == 1 and self.convo then self.log:Render(self.convo) end
end

-- Size the content root and the log fallbacks to the window's resting size.
function W:SyncContent()
    if not self.content then return end
    local fw, fh = self:FullSize()
    if self:IsSizing() then fw, fh = self:GetWidth(), self:GetHeight() end
    self.content:SetSize(fw, fh)
    self.log.fallbackW = fw - 24
    self.log.fallbackH = fh - HEADER_H - 58 - (self.quickOn and 30 or 0)
end

-- Resize edges (any side or corner): hidden while the window grows open.
function W:IsSizing()
    for _, f in pairs(self.edges or {}) do
        if f.sizing then return true end
    end
    return false
end

function W:ShowEdges(v)
    for _, f in pairs(self.edges or {}) do f:SetShown(v and true or false) end
end

function W:Reanchor()
    if self:IsShown() and (self.growV or 1) >= 1 and not self:IsSizing() then self:PlaceFinal() end
end

---------------------------------------------------------------------------
-- Render
---------------------------------------------------------------------------

function W:Render()
    local c = self.convo
    if not c then self:Hide() return end

    ns.PaintTile(self.tile, c, false, false)
    -- Top strip: their class colour fading into your accent.
    local cr, cg, cb = ns.ConvoColor(c)
    if type(CreateColor) == "function" then
        self.strip:SetColorTexture(1, 1, 1, 1)
        self.strip:SetGradient("HORIZONTAL", CreateColor(cr, cg, cb, 1), CreateColor(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1))
    else
        self.strip:SetColorTexture(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1)
    end

    local r, g, b = ns.ConvoColor(c)
    local canInvite = c.kind == "wow"
    if self.canInvite ~= canInvite then
        self.canInvite = canInvite
        self.invite:SetShown(canInvite)
        self.name:SetPoint("RIGHT", canInvite and self.invite or self.hubBtn, "LEFT", -6, 0)
    end
    self.name:SetText(c.display or "?")
    self.name:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
    self.meta:SetText(ns.MetaLine(c))
    self.note:SetText(c.note and (L["Note: %s"]:format(c.note)) or "")
    self.input:SetPlaceholder(L["Message…"])
    local quickOn = ns.Social.QuickBarOn()
    if quickOn then self.quick:Refresh() end
    self.quick:SetShown(quickOn)
    if self.quickOn ~= quickOn then -- only re-anchor on a change (fresh anchors lay out a frame late)
        self.quickOn = quickOn
        self.log:ClearAllPoints()
        self.log:SetPoint("TOPLEFT", 10, -HEADER_H)
        self.log:SetPoint("BOTTOMRIGHT", -12, quickOn and 88 or 58)
        self.log.fallbackH = select(2, self:FullSize()) - HEADER_H - 58 - (quickOn and 30 or 0)
    end

    self.log:Render(c)
end

function W:Open(c, focus)
    if not c then return end
    local switching = T.IsOpen(self)
    self.convo = c
    self.log:Reset(c)
    c.hidden = nil
    c.hubHidden = nil
    c.unread = 0
    if ns.Dock.preview:IsShown() then T.Conceal(ns.Dock.preview, { dur = 0.12 }) end
    if switching then
        -- Already open: crossfade the content instead of regrowing.
        ns.Refresh()
        T.Tween(self.log, "swap", 0.18, 0, 1, function(v) self.log:SetAlpha(v) end)
    else
        local from = self:IsShown() and (self.growV or 0) or 0
        self.wsClosing = nil
        -- Expand at the resting anchor so the card never funnels across the screen.
        self:SetAlpha(0)
        self:ApplyBounds()
        self:Show()
        self:PlaceFinal()
        self:SyncContent()
        self.toRect = Rect(self)
        self.fromRect = self:OriginRect()
        self:ApplyGrow(from)
        ns.Refresh()
        T.Spring(self, "grow", from, 1, function(v) self:ApplyGrow(v) end)
    end
    if focus then self.input.edit:SetFocus() end
end

function W:Close(done)
    if not T.IsOpen(self) then
        if done then done() end
        return
    end
    self.input.edit:ClearFocus()
    self.wsClosing = true
    local from = self.growV or 1
    -- Collapse at the same anchor; reversing an opening starts from its current size.
    self.toRect = (from >= 1 and Rect(self)) or self.toRect
    self.fromRect = self:OriginRect()
    T.Spring(self, "grow", from, 0, function(v) self:ApplyGrow(v) end, function()
        self.wsClosing = nil
        self:Hide()
        if done then done() end
    end)
end

---------------------------------------------------------------------------
-- Build
---------------------------------------------------------------------------

function W:Init()
    T.Panel(self)
    T.Reshape(self, 22)
    tinsert(UISpecialFrames, "PigeonWindow") -- Escape closes it

    -- Top strip (class colour into accent), inset to clear the rounded corners.
    local inset = (T.Rounded() and self.wsRadius) and (self.wsRadius + 1) or 0
    self.strip = self:CreateTexture(nil, "ARTWORK")
    self.strip:SetPoint("TOPLEFT", inset, 0)
    self.strip:SetPoint("TOPRIGHT", -inset, 0)
    self.strip:SetHeight(2)
    self.strip:SetAlpha(0)
    self.strip:SetColorTexture(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1)


    local root = CreateFrame("Frame", nil, self)
    root:SetPoint("TOPLEFT", self, "TOPLEFT")
    root:SetSize(self:FullSize()) -- keep message wrapping stable during expansion
    self.content = root

    -- Compact header: tile, name, level · zone, your note. The dock already
    -- shows the other conversations, so there's no tile row in here.
    local tile = ns.MakeTile(root, 34)
    tile:SetPoint("TOPLEFT", 12, -12)
    tile:EnableMouse(false)
    self.tile = tile

    local close = T.GlyphButton(root, "x", 24)
    close:SetPoint("TOPRIGHT", -6, -10)
    close:SetScript("OnClick", function() W:Close() end)
    self.closeBtn = close

    local hub = T.IconButton(root, 22, T.Icons.List, L["Open in the whisper hub"])
    hub:SetPoint("RIGHT", close, "LEFT", -2, 0)
    hub:SetScript("OnClick", function()
        local c = W.convo
        W:Close(function() ns.Hub:Open(c) end)
    end)

    -- Invite to group (game characters only; hidden for Battle.net friends).
    local invite = T.IconButton(root, 22, T.Icons.Invite, L["Invite to group"])
    invite:SetPoint("RIGHT", hub, "LEFT", -2, 0)
    invite:SetScript("OnClick", function()
        local c = W.convo
        if not c or c.kind ~= "wow" then return end
        ns.Invite(ns.WhisperTarget(c), c.guid)
    end)
    self.invite = invite
    self.hubBtn = hub

    self.name = T.Text(root, 14)
    self.name:SetPoint("TOPLEFT", tile, "TOPRIGHT", 10, 1)
    self.name:SetPoint("RIGHT", invite, "LEFT", -6, 0)
    self.name:SetJustifyH("LEFT")
    self.name:SetWordWrap(false)
    self.meta = T.Text(root, 10, T.SECTION)
    self.meta:SetPoint("TOPLEFT", self.name, "BOTTOMLEFT", 0, -3)
    self.meta:SetPoint("RIGHT", -12, 0)
    self.meta:SetJustifyH("LEFT")
    self.meta:SetWordWrap(false)
    self.note = T.Text(root, 10, ns.Social.STAR)
    self.note:SetPoint("TOPLEFT", self.meta, "BOTTOMLEFT", 0, -2)
    self.note:SetPoint("RIGHT", -12, 0)
    self.note:SetJustifyH("LEFT")
    self.note:SetWordWrap(false)

    local div = root:CreateTexture(nil, "ARTWORK")
    div:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])
    div:SetHeight(1)
    div:SetPoint("TOPLEFT", 10, -(HEADER_H - 6))
    div:SetPoint("TOPRIGHT", -10, -(HEADER_H - 6))

    local nameHit = CreateFrame("Frame", nil, root)
    nameHit:SetPoint("TOPLEFT", tile, "TOPLEFT", -2, 2)
    nameHit:SetPoint("BOTTOMRIGHT",invite,"BOTTOMLEFT",-6,-12)
    nameHit:EnableMouse(true)
    nameHit:SetScript("OnEnter", function(f)
        ns.ShowPlayerTooltip(f, W.convo, { avoid = W }) -- beside the window, never over its buttons
    end)
    nameHit:SetScript("OnLeave", function() GameTooltip:Hide() end)
    nameHit:SetScript("OnMouseUp", function(f, button)
        if button == "RightButton" then ns.Social.Menu(f, W.convo) end
    end)

    local emote = ns.Emotes.Button(root, 30, function() return W.input and W.input.edit end)
    local input = T.Reshape(T.EditBox(root, L["Whisper…"]), 13)
    input.wsQuietFocus = true
    input:SetHeight(34)
    input:SetPoint("BOTTOMLEFT", 12, 12)
    input:SetPoint("BOTTOMRIGHT", -54, 12)
    input.edit:SetScript("OnEnterPressed", function(e)
        ns.Send(W.convo, e:GetText())
        e:SetText("")
        W.log.scroll = 0
    end)
    input.wsComposerWell=T.ComposerWell(input)
    input.wsComposerWell:SetPoint("TOPLEFT",input,"TOPLEFT",1,-1)
    input.wsComposerWell:SetPoint("BOTTOMRIGHT",input,"BOTTOMRIGHT",emote and -42 or -1,1)
    input.placeholder.wsChatText=true T.StyleText(input.placeholder,14,"")
    input.edit.wsChatText=true T.ApplyFont(input.edit,14,"") input.edit:SetShadowColor(0,0,0,0)
    input:SetPlaceholder(L["Message…"])
    T.PaintComposer(input.bg,input.border,input.wsComposerWell)
    self.input = input

    local send = T.SendButton(root, 34)
    self.sendBtn = send
    send:SetPoint("BOTTOMRIGHT", -12, 12)
    send:SetScript("OnClick", function()
        ns.Send(W.convo, input.edit:GetText())
        input.edit:SetText("")
    end)
    self.emoteBtn = emote
    if emote then
        ns.Emotes.Embed(emote,input,input.edit,input.placeholder)
        if emote.controlIcon then emote.controlIcon:SetSize(22,22)end
    end

    local foot = root:CreateTexture(nil, "ARTWORK")
    foot:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])
    foot:SetHeight(1)
    foot:SetAlpha(0)
    foot:SetPoint("BOTTOMLEFT", 0, 42)
    foot:SetPoint("BOTTOMRIGHT", 0, 42)

    local quick = ns.Social.QuickBar(root, function() return W.convo end,
        function() return W.input and W.input.edit end)
    quick:SetPoint("BOTTOMLEFT", 12, 56)
    quick:SetPoint("BOTTOMRIGHT", -12, 56)
    self.quick = quick

    local log = ns.NewBubbleLog(root, { widthFrac = 0.8, fontSize = 14 })
    log:SetPoint("TOPLEFT", 12, -HEADER_H)
    log:SetPoint("BOTTOMRIGHT", -12, 58)
    do local fw, fh = self:FullSize() log.fallbackW, log.fallbackH = fw - 24, fh - HEADER_H - 58 end -- its size inside a full window
    self.log = log

    self.scrollHint = T.Text(root, 10, T.SECTION)
    self.scrollHint:SetPoint("TOPRIGHT", -12, -(HEADER_H + 2))
    self.scrollHint:SetText(L["SCROLLED UP"])
    self.scrollHint:Hide()
    log.onScroll = function(scroll) self.scrollHint:SetShown(scroll > 0) end

    -- Edge grabs (every side and corner): drag to resize; the size is remembered in ns.db.windowSize.
    local minW, minH, maxW, maxH = Bounds()
    self.edges = T.ResizeEdges(self, {
        minW = minW, minH = minH, maxW = maxW, maxH = maxH,
        onDone = function(w, h)
            if ns.db then
                local cw = math.max(minW, math.min(select(3, Bounds()), w))
                local ch = math.max(minH, math.min(select(4, Bounds()), h))
                ns.db.windowSize = { math.floor(cw + 0.5), math.floor(ch + 0.5) }
            end
            self:PlaceFinal() -- StartSizing re-anchored the frame; return to the dock anchor
            self:SyncContent()
            self.log:Render(self.convo)
        end,
    })
    self:ShowEdges(false) -- shown once the window has finished growing open

    -- Keep the content and message wrapping in step with the window, once per burst.
    self:SetScript("OnSizeChanged", function(_, w, h)
        if (self.growV or 0) < 1 then return end
        self.content:SetSize(w, h)
        if self.resizeQueued then return end
        self.resizeQueued = true
        C_Timer.After(0.05, function()
            self.resizeQueued = nil
            self:SyncContent()
            if self:IsShown() and self.convo and (self.growV or 0) >= 1 then self.log:Render(self.convo) end
        end)
    end)

    self:SetScript("OnHide", function()
        self:ShowEdges(false)
        T.StopTween(self,"grow")
        self.growV=0
        self.input.edit:ClearFocus()
        ns.Refresh()
    end)
end
