--[[
    Pigeon - Chat box
    Replaces the default chat window with Pigeon's own: tabs with
    smart filters, fading, timestamps, shortened channel names, a movable and
    resizable frame, and the game's own input box re-skinned underneath.

    How messages arrive: the default chat frames still do all the formatting
    (links, colours, filters from other addons); we hook their AddMessage,
    which also hands us the chat event, so every line knows what kind of
    message it is. The default frames themselves are hidden.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L
local Chat = ns.Chat
local ChatText = ns.ChatText
local FontKey, Format, Measure, Tag = ns.FontKey, ns.Format, ns.Measure, ns.Tag

local WRAP_SLACK = 20 -- the message frame is this much narrower than its text area

local Categorize, TypeFromId, LooksLikeLoot, LooksLikeCrafting, LooksLikePetFeeding = ns.Categorize, ns.TypeFromId, ns.LooksLikeLoot, ns.LooksLikeCrafting, ns.LooksLikePetFeeding
local CombatName = ns.CombatName

---------------------------------------------------------------------------
-- Incoming messages
---------------------------------------------------------------------------

function Chat:Push(e)
    local log = self.log
    log[#log + 1] = e
    while #log > Chat.MAX_LOG do table.remove(log, 1) end
    local changed = false
    for i, tab in ipairs(self.db.tabs) do
        if ns.TabMatches(tab, e) then
            if i == self.active then
                if self.db.idleHideText or self.combatAlpha then ns.ChatX.Touch(self) end -- a new line on this tab wakes a hidden chat
                self:AddLine(e)
                if not self.smf:AtBottom() then self.jump:Show() end
            else
                local skip = self.db.noCount
                if not tab.all and not (skip and skip[e.cat]) then
                    self.unread[i] = (self.unread[i] or 0) + 1
                    changed = true
                end
                if e.alert then
                    self.alerted[i] = true
                    changed = true
                end
            end
        end
    end
    if changed then self:RenderTabs() end
end

local function OnAddMessage(frame, text, r, g, b, id, _, _, event, eventArgs)
    if not Chat.active or Chat.pushing then return end
    local readable = ns.Readable(text)
    if readable then
        if type(text) ~= "string" or text == "" then return end
        -- The same line can reach several default windows; keep one copy.
        local now = GetTime()
        if text == Chat.lastText and now - (Chat.lastTime or 0) < 0.05 then return end
        Chat.lastText, Chat.lastTime = text, now
    elseif frame ~= DEFAULT_CHAT_FRAME then
        return -- can't de-duplicate hidden text, so only take it from the main window
    end
    local ok, cat, chan = pcall(Categorize, text, id, event, eventArgs)
    if not ok then cat, chan = "system", nil end
    if ns.debugChat and Chat.smf then -- /pigeon chatdebug: how each line was filed
        local function S(v) return ns.Readable(v) and tostring(v) or "(hidden)" end
        Chat.smf:AddMessage(("|cff808080[ws] filed as %s  ·  event %s  ·  id %s  ·  from %s|r"):format(
            tostring(cat), S(event), S(id), frame.GetName and frame:GetName() or "?"))
    end
    local e = { text = text, r = r or 1, g = g or 1, b = b or 1, cat = cat, chan = chan, chatType = (type(event)=="string" and ns.Readable(event) and event) or TypeFromId(id), t = time(), secret = not readable or nil }
    if cat == "gmwhisper" then e.chatType="GM_WHISPER" end
    if readable then
        local okS, sender = pcall(ns.ChatX.Sender, text, eventArgs)
        e.sender = okS and sender or nil
        -- Remember the sender's GUID (class / race for name tooltips).
        local guid = type(eventArgs) == "table" and eventArgs[12]
        if e.sender and guid and ns.Readable(guid) and type(guid) == "string" and guid:find("^Player%-") then
            Chat.guids[e.sender] = guid
        end
        local okF, spam = pcall(ns.ChatX.IsSpam, e)
        if okF and spam then
            Chat.spamHidden = (Chat.spamHidden or 0) + 1
            return
        end
        pcall(ns.ChatX.CheckAlert, e)
    end
    Chat:Push(e)
end

---------------------------------------------------------------------------
-- Moving / sizing
---------------------------------------------------------------------------

function Chat:StartDrag(force)
    if ns.ElvUI.fitted then return end -- ElvUI's panel owns the position
    if not force and (self.db.locked or ns.ChatUsesMovers()) then return end -- locked, or a mover mode owns it
    -- Shift-drag from the stack button (force) moves it regardless; the saved point is what the movers read.
    self:SetMovable(true) -- LibEditMode switches this off when its selection box is deselected
    self:StartMoving()
    self.dragging = true
end

function Chat:StopDrag()
    if not self.dragging then return end
    self:StopMovingOrSizing()
    self.dragging = nil
    local p, _, rp, x, y = self:GetPoint()
    self.db.point = { p, rp, x, y }
    if ns.EditMode then ns.EditMode.NoteMoved("chat") end
    self:PlaceEditBox()
end

---------------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------------

-- Unlocked = move mode: an outlined overlay you can drag anywhere, plus the
-- resize corner. Locking ends it.
function Chat:SetLocked(v)
    self.db.locked = v and true or false
    self:ApplySettings()
    if not v then
        T.Tween(self.overlay, "in", 0.2, 0, 1, function(a) self.overlay:SetAlpha(a) end)
    end
end

function Chat:PaintLock()
    local b = self.lockBtn
    if not b then return end
    local open = not self.db.locked
    b:SetLockOpen(open)
    -- Unlocked = move mode: the button stays lit in the accent colour.
    b.active = open
    b.iconColor = open and T.ACCENT or T.LABEL
    b:SetIconColor(b.iconColor)
    T.SetBorderColor(b.border, open and T.ACCENT or T.INPUT_BORDER, open and 0.7 or nil)
end

-- Text size and background opacity can be set per tab (nil = chat default).
function Chat:ApplyTabStyle()
    if not self.smf then return end
    local db = self.db
    local tab = db.tabs[self.active] or {}
    local outlined = db.outline or db.classic
    T.ApplyFont(self.smf, tab.fontSize or db.fontSize, Chat.OutlineFlags())
    self.smf:SetShadowColor(0, 0, 0, outlined and 1 or 0)
    self.smf:SetSpacing(math.max(0, math.min(16, tonumber(db.lineSpacing) or 4)))
    self.smf:SetShadowOffset(1, -1)
    local fitted = ns.ElvUI.fitted
    -- Fitted into ElvUI's panel: let ElvUI's backdrop show instead of ours.
    local useElvBackdrop = fitted and ns.ElvUI.LeftBackdropShown()
    local ownOff = useElvBackdrop or self.wsSkinned -- ElvUI's or the game's frame is drawn instead
    -- Forever theme: the stock chat box, a see-through near-black pane with no border.
    local vanilla = ns.db.look and ns.db.look.preset == "forever"
    local bg = vanilla and { 0.02, 0.018, 0.016 } or T.BACKDROP
    local classic = self:FlattenClassic() -- classic chat: square panel (before it is painted)
    T.PaintSurface(self, bg[1], bg[2], bg[3], ownOff and 0 or (tab.bgAlpha or db.bgAlpha))
    for _, edge in ipairs(self.border) do edge:SetShown(not ownOff and not vanilla) end
    self.bgAlphaNow = tab.bgAlpha or db.bgAlpha or 1
    self:PaintClassic(classic, ownOff)
    self:SideButtons(classic and not ns.ElvUI.fitted)
    if ns.GameFrames then ns.GameFrames.ChatAlpha() end
    self:PaintInput()
end

-- The input line (resting bar and the real edit box) follows the chat's
-- background opacity instead of staying solid.
function Chat:PaintInput()
    local db = self.db
    local tab = db.tabs[self.active] or {}
    local a = math.min(T.INPUT_BG[4] or 1, tab.bgAlpha or db.bgAlpha or 1)
    self.inputAlpha = a
    if self.fakeInput then self.fakeInput:Refresh() self.fakeInput.send.Paint(false) end
    if self.eb and self.eb.wsSend then self.eb.wsSend.Paint(false) end
    if self.RestyleInput then self.RestyleInput() end
    if self.fakeInput and self.fakeInput.bg then
        T.PaintComposer(self.fakeInput.bg,self.fakeInput.border,self.fakeInput.textWell,a)
        if db.classic then self:PaintClassicInput(self.fakeInput.bg,self.fakeInput.border,self.fakeInput.textWell,a) end
    end
    if self.eb and self.eb.wsBg then
        T.PaintComposer(self.eb.wsBg,self.eb.wsBorder,self.eb.wsWell,a)
        if db.classic then self:PaintClassicInput(self.eb.wsBg,self.eb.wsBorder,self.eb.wsWell,a) end
    end
end

---------------------------------------------------------------------------
-- History across reloads
---------------------------------------------------------------------------

function Chat:SaveHistory()
    if not self.active then return end
    local out = {}
    for i = math.max(1, #self.log - Chat.SAVE_LOG + 1), #self.log do
        local e = self.log[i]
        if not e.secret then out[#out + 1] = e end
    end
    ns.hist.chat = out
end

---------------------------------------------------------------------------
-- Build
---------------------------------------------------------------------------

-- Hovering a link previews it: game links show their tooltip, names show
-- the player card (level, zone, guild, your note) the dock uses.
local NO_TOOLTIP = { channel = true, url = true, BNplayer = true, player = true, addon = true, garrmission = true,
    battlepet = true, journal = true, urlIndex = true, censoredmessage = true, clubTicket = true }
local function OnHyperlinkEnter(self, link, text)
    if type(link) ~= "string" or not ns.Readable(link) then return end
    local kind = link:match("^(%a+):")
    if kind == "player" then
        local name = link:match("^player:([^:]+)")
        if not name then return end
        local key = ns.FullName(name) or name
        local c = ns.GetConvo("w:" .. key) or { kind = "wow", name = key, display = (name:gsub("%-.*$", "")), messages = {} }
        local guid = Chat.guids[name] or Chat.guids[key] or c.guid
        -- The link carries the chat line's id; the game can turn that into the sender's GUID.
        local lineID = tonumber(link:match("^player:[^:]*:(%d+)"))
        if lineID and C_ChatInfo and C_ChatInfo.GetChatLineSenderGUID then
            local ok, g = pcall(C_ChatInfo.GetChatLineSenderGUID, lineID)
            if ok and g and ns.Readable(g) and type(g) == "string" and g ~= "" then guid = g end
        end
        local fromGuid = ns.InfoFromGUID(guid)
        if fromGuid then
            if not c.class then c.class = fromGuid.class end
            c.race = c.race or fromGuid.race
        end
        local s = ns.seen[key]
        if s then
            c.class = c.class or s.class
            c.race = c.race or s.race
        end
        if not c.class and ns.ResolveClass then pcall(ns.ResolveClass, c) end
        if not c.class then c.class = Chat:ClassFromLine(name) end -- the game's own class-coloured name
        ns.ShowPlayerTooltip(self, c, "ANCHOR_CURSOR", L["Click: target  ·  Right-click: menu"])
        Chat:PreparePlayerTarget(link, text)
        return
    end
    if kind == "addon" then
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        GameTooltip:AddLine(link:find(":w:", 1, true) and L["Whisper"]
            or link:find(":u:", 1, true) and L["Click to copy the link"]
            or L["Invite to group"])
        GameTooltip:Show()
        return
    end
    -- Profession links: the game opens the whole recipe window to "show" one,
    -- so hovering only names it and a click opens it.
    if kind == "trade" or kind == "tradeskill" then
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        GameTooltip:AddLine(L["Profession"])
        GameTooltip:AddLine(L["Click to open their recipes (if the game allows)"], T.SECTION[1], T.SECTION[2], T.SECTION[3])
        GameTooltip:Show()
        return
    end
    if kind == "tel" then -- a Twitch Emotes picture: show its name
        local name = link:match("^tel:(.+)$")
        if name then
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:SetText(name, 1, 0.82, 0)
            GameTooltip:AddLine(L["Click to add it to your message"], 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end
        return
    end
    if not kind or NO_TOOLTIP[kind] then return end
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    if pcall(GameTooltip.SetHyperlink, GameTooltip, link) then GameTooltip:Show() else GameTooltip:Hide() end
end

local function PlayerFromLink(link)
    if type(link) ~= "string" or not ns.Readable(link) then return nil end
    local kind, rest = link:match("^(%a+):(.*)$")
    if kind == "player" then
        local name = rest:match("^([^:]+)")
        if name and name ~= "" then return "wow", name end
    elseif kind == "BNplayer" then
        local bnID = tonumber(rest:match("^[^:]*:(%d+)"))
        if bnID then return "bn", bnID end
    end
end

local function OpenWhisper(kind, who)
    local c = (kind == "bn") and ns.BNetConvo(who) or ns.StartConvo(who)
    if c then ns.Window:Open(c, true) end
end

local function Act(fn, ...)
    if type(fn) == "function" then pcall(fn, ...) end
end

function Chat:ShowPlayerMenu(kind, who, guid, shown)
    if not (ns.Social and ns.Social.OpenMenu) then return false end
    local label = kind == "bn" and ((ns.BNetConvo(who) or {}).display or L["Battle.net friend"]) or who
    local entries = {{label=L["Whisper"], fn=function() OpenWhisper(kind, who) end}}
    if kind == "wow" then
        entries[#entries+1] = {label=L["Invite"], fn=function() ns.Invite(who, guid, shown) end}
        entries[#entries+1] = {label=L["Add friend"], fn=function() Act(C_FriendList and C_FriendList.AddFriend, who) end}
        entries[#entries+1] = {label=L["Who is this?"], fn=function() ns.WhoLookup(nil, who) end}
        entries[#entries+1] = {label=L["Ignore"], danger=true, divider=true, fn=function() Act(C_FriendList and C_FriendList.AddIgnore, who) end}
    else
        local game = C_BattleNet and C_BattleNet.GetAccountInfoByID and C_BattleNet.GetAccountInfoByID(who)
        local toon = game and game.gameAccountInfo
        if toon and toon.characterName and ns.Readable(toon.characterName) and toon.isOnline
            and toon.clientProgram == (BNET_CLIENT_WOW or "WoW") then
            local target = toon.characterName
            if toon.realmName and ns.Readable(toon.realmName) and toon.realmName ~= "" and toon.realmName ~= GetRealmName() then
                target = target .. "-" .. toon.realmName:gsub("%s", "")
            end
            entries[#entries+1] = {label=L["Invite"], fn=function() Act((C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit, target) end}
        end
    end
    return ns.Social.OpenMenu(self, label, entries, {cursor=true})
end

local function ResolvedPlayer(link, text)
    local kind, who = PlayerFromLink(link)
    if kind ~= "wow" then return kind, who end
    local guid = Chat.guids[who]
    local lineID = tonumber(link:match("^player:[^:]*:(%d+)"))
    if lineID and C_ChatInfo and C_ChatInfo.GetChatLineSenderGUID then
        local ok, value = pcall(C_ChatInfo.GetChatLineSenderGUID, lineID)
        if ok and type(value) == "string" and ns.Readable(value) and value ~= "" then guid = value end
    end
    local shown = type(text) == "string" and ns.Readable(text) and (text:match("|h(.-)|h") or text) or nil
    return kind, ns.StripOwnRealm(ns.BestName(who, guid, shown) or who), guid, shown
end

function Chat:PreparePlayerTarget(link, text)
    if InCombatLockdown and InCombatLockdown() then return end
    local kind, who, guid, shown = ResolvedPlayer(link, text)
    if kind ~= "wow" or not who or who == "" or who:find("[\r\n]") then return end
    if not GetCursorPosition or not RegisterStateDriver then return end
    local b = self.playerTarget
    if not b then
        -- This control receives the actual hardware click. Never call :Click()
        -- from an insecure hyperlink handler: that cannot authorize targeting.
        b = CreateFrame("Button", nil, UIParent, "SecureActionButtonTemplate,SecureHandlerStateTemplate")
        b:SetSize(24, math.max(20, (self.db.fontSize or 14) + 6))
        b:SetFrameStrata("DIALOG")
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
        b:SetAttribute("type1", "macro")
        b:SetAttribute("useOnKeyDown", false)
        for _,mods in ipairs({"shift-", "ctrl-", "alt-", "alt-ctrl-", "alt-shift-", "ctrl-shift-", "alt-ctrl-shift-"}) do
            b:SetAttribute(mods .. "type1", "")
        end
        -- A secure state change hides the target hit area before combat;
        -- it stays hidden when combat ends until a fresh name hover arms it.
        b:SetAttribute("_onstate-combat", "if newstate == '1' then self:Hide() end")
        RegisterStateDriver(b, "combat", "[combat]1;0")
        b:SetScript("PostClick", function(btn, button)
            if button == "RightButton" then
                Chat:ShowPlayerMenu("wow", btn.who, btn.guid, btn.displayText)
            elseif button ~= "LeftButton" or (IsModifiedClick and IsModifiedClick("CHATLINK"))
                or IsShiftKeyDown() or IsControlKeyDown() or IsAltKeyDown() then
                SetItemRef(btn.link, btn.linkText, button, DEFAULT_CHAT_FRAME)
            end
            if not (InCombatLockdown and InCombatLockdown()) then btn:Hide() end
        end)
        b:SetScript("OnLeave", function(btn)
            GameTooltip:Hide()
            if not (InCombatLockdown and InCombatLockdown()) then btn:Hide() end
        end)
        b:SetScript("OnUpdate", function(btn)
            if not (InCombatLockdown and InCombatLockdown()) and (not Chat:IsVisible() or not btn:IsMouseOver()) then
                btn:Hide()
            end
        end)
        self.playerTarget = b
    end
    b.link, b.linkText, b.who, b.guid, b.displayText = link, text, who, guid, shown
    b:SetAttribute("macrotext1", "/targetexact " .. who)
    local x, y = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    b:ClearAllPoints()
    b:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / scale, y / scale)
    b:Show()
end

function Chat:PlayerLinkClick(link, button, text)
    local kind, who, guid, shown = ResolvedPlayer(link, text)
    if not kind then return false end
    if IsModifiedClick and (IsModifiedClick("CHATLINK") or IsShiftKeyDown()) then return false end
    if button == "RightButton" then return self:ShowPlayerMenu(kind, who, guid, shown) end
    if button == "LeftButton" and kind == "bn" then OpenWhisper(kind, who) return true end
    if button == "LeftButton" then
        -- A real player-name hover uses the secure control above. If the game
        -- dispatched this callback instead, do not fall back to whisper or try
        -- to invoke a protected action from Lua.
        if InCombatLockdown and InCombatLockdown() then ns.Print(L["Targeting a chat name is unavailable during combat."]) end
        return true
    end
    return false
end

local function OtherChatAddon()
    if ns.ElvUI.ChatActive() then return L["ElvUI's chat"] end -- ElvUI with its chat module off is fine
    if ns.Ellesmere.ChatActive() then return "EllesmereUI Chat" end
    for _, name in ipairs({ "Chattynator", "Prat-3.0", "Chatter" }) do
        local loaded = (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded(name))
            or (IsAddOnLoaded and IsAddOnLoaded(name))
        if loaded then return name end
    end
end

function Chat:Init()
    self.db = ns.db.chat
    if not self.db.enabled then return end
    local other = OtherChatAddon()
    if other then
        ns.Print(L["%s is handling chat, so the Pigeon chat box stays off. Turn %s off to use it; whispers work either way."]:format(other, other))
        self.blockedBy = other
        return
    end

    local db = self.db
    for _,tab in ipairs(db.tabs)do ns.UpgradeChatFilters(tab)end
    Chat.TAB_H = math.max(32, math.min(80, tonumber(db.tabBarHeight) or 52))
    self.TAB_H, self.tabH = Chat.TAB_H, Chat.TAB_H
    self:SetSize(db.width, db.height)
    self:SetPoint(db.point[1], UIParent, db.point[2], db.point[3], db.point[4])
    ns.ElvUI.FitChat(self) -- ElvUI loaded with its chat off: fill its left chat panel
    self:SetMovable(true)
    self:SetResizable(true)
    if self.SetResizeBounds then self:SetResizeBounds(300, 140, 1000, 700) end
    self:SetClampedToScreen(true)
    self:SetFrameStrata("LOW")
    local radius = (not ns.ElvUI.fitted) and 22 or nil
    self.wsRadius = radius
    self.bg = T.ShapeFill(self, T.BACKDROP, radius)
    T.Glass(self)
    self.border = T.Border(self, T.BORDER, 1, radius)
    self.tabButtons = {}

    local bar = CreateFrame("Frame", nil, self)
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("TOPRIGHT")
    bar:SetHeight(Chat.TAB_H)
    bar:EnableMouse(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function() Chat:StartDrag() end)
    bar:SetScript("OnDragStop", function() Chat:StopDrag() end)
    self.bar = bar
    -- Quiet, flat header like the approved conversation concept.
    local div = self:CreateTexture(nil, "ARTWORK")
    self.divider = div
    div:Hide()   -- no line under the tab bar
    div:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])
    div:SetHeight(1)
    div:SetPoint("TOPLEFT", 10, -Chat.TAB_H)
    div:SetPoint("TOPRIGHT", -10, -Chat.TAB_H)

    -- Right-hand controls: lock, new tab, settings. Square outlined
    -- buttons so they read as controls, not as more tabs.
    local BTN, GAP = 30, 6 -- independent controls with room between them
    local gear = T.IconButton(bar, BTN, T.Icons.Sliders, L["Chat settings"])
    gear:SetPoint("RIGHT", -12, 0)
    gear:SetScript("OnClick", function() ns.Settings:Toggle("chat") end)
    local add = T.IconButton(bar, BTN, T.Icons.Plus, L["New tab"])
    add:SetPoint("RIGHT", gear, "LEFT", -GAP, 0)

    local lock = T.IconButton(bar, BTN, T.Icons.Lock, function()
        local hint = ns.MoverHint()
        if hint and not ns.ChatUsesMovers() then return hint end
        return Chat.db.locked and L["Unlock to move / resize"] or L["Lock chat"]
    end)
    lock:SetPoint("RIGHT", add, "LEFT", -GAP, 0)
    lock:SetScript("OnClick", function(btn)
        if ns.ElvUI.fitted and ns.ElvUI.ToggleMoveMode() then
            -- fitted: ElvUI's "Left Chat" mover places it
        elseif ns.ChatUsesMovers() then
            -- The lock really locks (resize grip hides); unlocking also opens
            -- ElvUI's /moveui or EllesmereUI's /unlock to place the chat.
            Chat:SetLocked(not Chat.db.locked)
            if not Chat.db.locked then ns.ToggleMoveMode() end
        else
            Chat:SetLocked(not Chat.db.locked)
        end
        if btn:IsMouseOver() then btn:GetScript("OnEnter")(btn) end
    end)
    self.lockBtn = lock

    -- The game's own channels and voice chat window, which hiding the default chat took away.
    local voice
    if _G.ChatFrameChannelButton or _G.ToggleChannelFrame or _G.ChannelFrame then
        voice = T.IconButton(bar, BTN, T.Icons.Voice, L["Channels & voice chat"])
        voice:SetPoint("RIGHT", lock, "LEFT", -GAP, 0)
        voice:SetScript("OnClick", function() ns.Voice.Toggle(voice) end)
        self.voiceBtn = voice
    end

    local indicator = T.IconButton(bar, BTN, function(_, Bar)
        -- Three offset cards make the collapsed controls read as a stack.
        Bar(12,1,0,5) Bar(1,7,-6,2) Bar(1,7,6,2) Bar(12,1,0,-1)
        Bar(10,1,1,-4) Bar(8,1,2,-7)
    end, L["Chat controls"])
    indicator:SetPoint("RIGHT",bar,"RIGHT",-12,0)
    self.toolbarIndicator = indicator

    -- Keep a bounding frame for crowded-tab measurement, without the old joined outline.
    local group = CreateFrame("Frame", nil, bar)
    local count = voice and 4 or 3
    local controlWidth = BTN * count + GAP * (count - 1)
    group:SetPoint("RIGHT", indicator, "LEFT", -GAP, 0)
    group:SetSize(controlWidth, BTN)
    group:SetClipsChildren(true)
    group:EnableMouse(false)
    local content = CreateFrame("Frame", nil, group)
    content:SetSize(controlWidth, BTN) content:SetPoint("RIGHT") content:EnableMouse(false)
    group.content = content
    for _, b in ipairs({voice or lock, lock, add, gear}) do b:SetParent(content) end
    gear:ClearAllPoints() gear:SetPoint("RIGHT", content, "RIGHT", 0, 0)
    group.border, group.seps = {}, {}
    self.controls = group
    group.buttons = voice and { voice, lock, add, gear } or { lock, add, gear }
    group.fullWidth = controlWidth
    self.toolbarReady = true
    self:SetupToolbar()

    if db.attachDock then
        local sep = bar:CreateTexture(nil, "ARTWORK")
        sep:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])
        sep:SetWidth(1)
        sep:SetPoint("TOPLEFT", Chat.TAB_H, -8)
        sep:SetPoint("BOTTOMLEFT", Chat.TAB_H, 8)
        self.stackSeparator = sep
        sep:Hide()   -- no line beside the dock icon
    end
    add:SetScript("OnClick", function() StaticPopup_Show("PIGEON_NEW_TAB") end)

    local smf = CreateFrame("ScrollingMessageFrame", nil, self)
    smf.wsChatText = true
    smf.wsNoScale = true -- chat messages follow their own size setting
    smf:SetPoint("TOPLEFT", 10, -(Chat.TAB_H + 6))
    smf:SetPoint("BOTTOMRIGHT", -(10 + WRAP_SLACK), 8)
    smf:SetJustifyH("LEFT")
    smf:SetMaxLines(Chat.MAX_LOG)
    smf:SetFadeDuration(3)
    if smf.SetIndentedWordWrap then smf:SetIndentedWordWrap(true) end
    smf:SetHyperlinksEnabled(true)

    -- Animated Twitch Emotes in the chat itself: step the emote frames ~30 times a second, but
    -- only while a visible line holds an animated emote (checked twice a second). A line holds
    -- still while the mouse is over it, because rewriting its text would swallow a click.
    do
        local animAcc, scanAcc, hasAnim = 0, 0, false
        local driver = CreateFrame("Frame", nil, smf)
        driver:SetScript("OnUpdate", function(_, dt)
            local lines = smf.visibleLines
            if type(lines) ~= "table" or not smf:IsShown() or not (ns.Emotes and ns.Emotes.Animate) then return end
            scanAcc = scanAcc + dt
            if scanAcc >= 0.5 then
                scanAcc = 0
                hasAnim = false
                -- Only emotes that really animate count: still pictures need no stepping.
                local meta = _G.TwitchEmotes_animation_metadata
                for _, fs in ipairs(lines) do
                    if type(meta) ~= "table" then break end
                    if type(fs) == "table" and fs.IsShown and fs:IsShown() then
                        local ok, txt = pcall(fs.GetText, fs)
                        if ok and type(txt) == "string" and ns.Readable(txt) and txt:find("TwitchEmotes\\Emotes", 1, true) then
                            for path in txt:gmatch("|T(Interface\\AddOns\\TwitchEmotes\\Emotes\\[^|:]+%.tga)") do
                                if meta[path] then hasAnim = true; break end
                            end
                            if hasAnim then break end
                        end
                    end
                end
            end
            if not hasAnim then return end
            animAcc = animAcc + dt
            if animAcc < 0.033 then return end
            animAcc = 0
            for _, fs in ipairs(lines) do
                if type(fs) == "table" and fs.IsShown and fs:IsShown() then
                    local over = fs.IsMouseOver and fs:IsMouseOver()
                    if not over then pcall(ns.Emotes.Animate, fs, true) end
                end
            end
        end)
    end
    smf:SetScript("OnHyperlinkClick", function(_, link, text, button)
        if ns.ChatX.HandleLink(link) then return end
        local emote = type(link) == "string" and ns.Readable(link) and link:match("^tel:(.+)$")
        if emote then -- a Twitch Emotes picture: add it to what you're typing
            if ns.Emotes and ns.Emotes.Pick then ns.Emotes.Pick(emote, false) end
            return
        end
        if Chat:PlayerLinkClick(link, button, text) then return end
        SetItemRef(link, text, button, DEFAULT_CHAT_FRAME)
    end)
    smf:SetScript("OnHyperlinkEnter", OnHyperlinkEnter)
    smf:SetScript("OnHyperlinkLeave", function()
        -- Entering the transparent secure hit area leaves the message frame;
        -- retain its player card until the hit area itself loses the mouse.
        C_Timer.After(0, function()
            local b = Chat.playerTarget
            if not (b and b:IsShown() and b:IsMouseOver()) then GameTooltip:Hide() end
        end)
    end)
    smf:EnableMouseWheel(true)
    smf:SetScript("OnMouseWheel", function(f, delta)
        if IsShiftKeyDown() then
            if delta > 0 then f:ScrollToTop() else f:ScrollToBottom() end
        elseif delta > 0 then
            f:ScrollUp()
        else
            f:ScrollDown()
        end
        Chat.jump:SetShown(not f:AtBottom())
    end)
    -- Pigeon's own highlight-and-copy (per character). Selections are kept as
    -- (message number, character offset), not screen rows, so they survive
    -- scrolling: the wheel, or dragging above/below the chat (which scrolls
    -- faster the further out the pointer is). Ctrl+C copies the selected text.
    -- Needs the message frame's visibleLines; otherwise the game's own
    -- selection is used (see WantSelecting).
    if type(smf.visibleLines) == "table" and not ns.NativeSelectCopy() then
        smf:EnableMouse(true)
        local Plain = ns.ChatX.Plain
        local sel = { active = false }
        local dragging, moved, downX, downY, pending, acc, accScroll = false, false, 0, 0, nil, 0, 0
        local pool = {}
        local lastClick
        local driver = CreateFrame("Frame", nil, smf)
        driver:Hide()
        local layer = CreateFrame("Frame", nil, self)
        layer:SetFrameLevel(smf:GetFrameLevel() + 2)
        layer:SetClipsChildren(true)
        layer:SetPoint("TOPLEFT", smf, "TOPLEFT", -120, 0)
        layer:SetPoint("BOTTOMRIGHT", smf, "BOTTOMRIGHT", WRAP_SLACK, 0)
        local keys = CreateFrame("Frame", nil, UIParent)
        keys:Hide()
        local eb = CreateFrame("EditBox", nil, UIParent)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetMaxLetters(0) -- no length cap, so long selections copy whole
        eb:SetMaxBytes(0)
        eb:SetSize(20, 20)
        eb:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", -200, -200)
        eb:SetFontObject(ChatFontNormal or GameFontNormal)
        eb:SetAlpha(0)
        eb:Hide()

        local function Unprime()
            if eb:IsShown() then
                eb:ClearFocus()
                eb:Hide()
            end
        end
        local function Clear()
            sel.active, sel.anchor, sel.cur, sel.hint = false, nil, nil, nil
            for _, t in ipairs(pool) do t:Hide() end
            keys:Hide()
            Unprime()
            if not dragging then driver:Hide() end
        end
        Chat.ClearSelection = Clear

        -- Text is split into "atoms": one UTF-8 character, a chip texture
        -- (plain form "[Gen]"), or a "||". plain = the copied text, disp = what
        -- the game draws (escapes other than textures removed, so a prefix of
        -- atoms can be measured without cutting inside an escape sequence).
        -- cum[k] = byte length of the plain text of the first k atoms.
        local atomCache, atomCount = {}, 0
        local function Atoms(text)
            local hit = atomCache[text]
            if hit then return hit end
            local plain, disp, cum = {}, {}, { [0] = 0 }
            local n, i, k, off = #text, 1, 0, 0
            while i <= n do
                local p, d, nxt
                if text:byte(i) == 124 then -- "|"
                    local nx = text:sub(i + 1, i + 1)
                    if nx == "c" and text:find("^%x%x%x%x%x%x%x%x", i + 2) then
                        nxt = i + 10
                    elseif nx == "r" or nx == "h" then
                        nxt = i + 2
                    elseif nx == "H" or nx == "A" then
                        local _, e = text:find(nx == "H" and "|h" or "|a", i + 2, true)
                        nxt = e and (e + 1) or (n + 1)
                    elseif nx == "T" then
                        local _, e = text:find("|t", i + 2, true)
                        if e then
                            local tok = text:sub(i, e)
                            local chip = tok:match("^|T[^|]-Tags\\Tag(%w+):[^|]*|t$")
                            p, d, nxt = chip and ("[" .. chip .. "]") or "", tok, e + 1
                        else
                            nxt = n + 1
                        end
                    elseif nx == "|" then
                        p, d, nxt = "||", "||", i + 2
                    else
                        p, d, nxt = "|", "||", i + 1
                    end
                else
                    local c = text:byte(i)
                    local len = (c >= 240 and 4) or (c >= 224 and 3) or (c >= 192 and 2) or 1
                    p = text:sub(i, i + len - 1)
                    d, nxt = p, i + len
                end
                if d then
                    k = k + 1
                    plain[k], disp[k] = p, d
                    off = off + #p
                    cum[k] = off
                end
                i = nxt
            end
            hit = { plain = table.concat(plain), disp = disp, cum = cum, n = k }
            atomCount = atomCount + 1
            if atomCount > 600 then wipe(atomCache); atomCount = 1 end
            atomCache[text] = hit
            return hit
        end

        -- Hidden FontString used to measure the width of the first k atoms of
        -- a line, in the line's own font. Widths are computed lazily and cached.
        local mf = driver:CreateFontString(nil, "OVERLAY")
        mf:SetWordWrap(false)
        mf:SetJustifyH("LEFT")
        local mfKey, dotW
        local mcache, mcount = {}, 0
        local function RawWidth(M, k)
            if k <= 0 then return 0 end
            local w = M.w[k]
            if w then return w end
            local key = M.path .. "|" .. tostring(M.size) .. "|" .. tostring(M.flags)
            if mfKey ~= key then
                local okF, setRes = pcall(mf.SetFont, mf, M.path, M.size, M.flags)
                if not okF or setRes == false then return nil end
                mfKey, dotW = key, nil
            end
            local ok, res = pcall(function()
                -- A trailing "." keeps trailing spaces counted in the width.
                if not dotW then
                    mf:SetText(".")
                    dotW = mf:GetStringWidth()
                end
                mf:SetText(table.concat(M.la.disp, "", 1, k) .. ".")
                return mf:GetStringWidth() - dotW
            end)
            if not (ok and type(res) == "number" and ns.Readable(res)) then return nil end
            M.w[k] = res
            return res
        end
        local function XAt(M, k)
            local w = RawWidth(M, k)
            return w and (w * M.ratio) or nil
        end
        local function Measure(fs, lt, la)
            local ok, path, size, flags = pcall(fs.GetFont, fs)
            if not (ok and path) then return nil end
            local key = tostring(path) .. "|" .. tostring(size) .. "|" .. tostring(flags) .. "|" .. lt
            local M = mcache[key]
            if M then
                if M.bad then return nil end
                return M
            end
            M = { path = path, size = size, flags = flags, la = la, w = {}, ratio = 1 }
            mcount = mcount + 1
            if mcount > 400 then wipe(mcache); mcount = 1 end
            mcache[key] = M
            local wn = la.n > 0 and RawWidth(M, la.n) or nil
            local okW, fw = pcall(fs.GetStringWidth, fs)
            if not (wn and wn > 0 and okW and type(fw) == "number" and ns.Readable(fw)) then
                M.bad = true
                return nil
            end
            local r = fw / wn
            if r > 1.1 then M.bad = true return nil end
            -- A wrapped message reports its widest row, not the whole text's
            -- width, so a much smaller ratio just means "wrapped": same font, 1:1.
            if r < 0.9 then r = 1 end
            M.ratio = r
            return M
        end
        -- Where a message's text wraps: rows of atoms { a = atoms before the
        -- row, b = last atom in it }, found greedily from measured widths.
        local function WrapRows(ln)
            local M, la = ln.M, ln.la
            local okW, W = pcall(ln.fs.GetWidth, ln.fs)
            if not (okW and type(W) == "number" and ns.Readable(W) and W > 0) then return nil end
            if M.rows and M.rowsW == W then return M.rows end
            local n, rows, a = la.n, {}, 0
            while a < n and #rows < 80 do
                local xa = XAt(M, a)
                if not xa then return nil end
                local lo, hi = a, n
                while lo < hi do
                    local mid = math.floor((lo + hi + 1) / 2)
                    local x = XAt(M, mid)
                    if not x then return nil end
                    if x - xa <= W + 0.5 then lo = mid else hi = mid - 1 end
                end
                local b = lo
                if b <= a then b = a + 1 end
                if b < n and la.disp[b + 1] ~= " " then
                    local j = b
                    while j > a and la.disp[j] ~= " " do j = j - 1 end
                    if j > a then b = j end
                end
                rows[#rows + 1] = { a = a, b = b }
                a = b
            end
            M.rows, M.rowsW = rows, W
            return rows
        end
        -- Largest atom index whose x is not past `off` (plain offset in the message).
        local function IndexForOffset(ln, off)
            local cum, rel = ln.la.cum, off - ln.base
            local k = ln.k0
            for j = ln.k0 + 1, ln.k1 do
                if cum[j] <= rel then k = j else break end
            end
            return k
        end
        -- Nearest atom boundary to x (relative to the line's left edge).
        -- A wrapped row covers atoms k0..k1 of its message's text.
        local function IndexForX(ln, relx)
            local M = ln.M
            relx = relx + ln.xoff
            local lo, hi = ln.k0, ln.k1
            while lo < hi do
                local mid = math.floor((lo + hi + 1) / 2)
                local x = XAt(M, mid)
                if not x then return nil end
                if x <= relx then lo = mid else hi = mid - 1 end
            end
            local k = lo
            if k < ln.k1 then
                local x0, x1 = XAt(M, k), XAt(M, k + 1)
                if x0 and x1 and (x1 - relx) < (relx - x0) then k = k + 1 end
            end
            return k
        end

        local function MsgAtoms(msg)
            return Atoms(msg)
        end

        -- Work out, for each line of a group, which part of the message's plain
        -- text it shows (ln.s .. ln.e) and how to measure it (ln.M, ln.la).
        local function ResolveLines(g)
            local P = g.msg and MsgAtoms(g.msg).plain
            local cursor = 1
            for _, ln in ipairs(g.lines) do
                ln.s, ln.e, ln.la, ln.M = cursor - 1, cursor - 1, nil, nil
                local ok, lt = pcall(ln.fs.GetText, ln.fs)
                if ok and type(lt) == "string" and ns.Readable(lt) and P then
                    local la = Atoms(lt)
                    if la.plain ~= "" then
                        local s = P:find(la.plain, cursor, true)
                        if s then
                            ln.s, ln.e, ln.la = s - 1, s - 1 + #la.plain, la
                            cursor = ln.e + 1
                            ln.M = Measure(ln.fs, lt, la)
                        end
                    end
                end
                ln.base, ln.k0, ln.k1, ln.xoff, ln.yoff = ln.s, 0, ln.la and ln.la.n or 0, 0, 0
            end
            -- Split a wrapped message into its visual rows, so highlights and
            -- hit-tests work row by row.
            local out = {}
            for _, ln in ipairs(g.lines) do
                local rows = ln.M and ln.la and WrapRows(ln)
                local okH, H = pcall(ln.fs.GetStringHeight, ln.fs)
                if rows and #rows > 1 and okH and type(H) == "number" and ns.Readable(H) and H > 0 then
                    local rh = H / #rows
                    for r, row in ipairs(rows) do
                        out[#out + 1] = {
                            fs = ln.fs, la = ln.la, M = ln.M, msg = ln.msg, base = ln.s,
                            s = ln.s + ln.la.cum[row.a], e = ln.s + ln.la.cum[row.b],
                            k0 = row.a, k1 = row.b, xoff = XAt(ln.M, row.a) or 0,
                            yoff = (r - 1) * rh, rh = rh,
                            top = ln.top - (r - 1) * rh, bottom = ln.top - r * rh,
                        }
                    end
                else
                    out[#out + 1] = ln
                end
            end
            g.lines = out
        end

        -- Visible lines top to bottom, grouped by message, each group resolved
        -- to a message number (seq) in the active tab's list.
        local function Groups()
            local lines = smf.visibleLines
            if type(lines) ~= "table" then return {} end
            local list = {}
            for _, fs in ipairs(lines) do
                if type(fs) == "table" and fs.IsShown and fs:IsShown() then
                    local top = fs:GetTop()
                    if top then
                        local info = fs.messageInfo
                        local msg = type(info) == "table" and info.message or nil
                        if msg == nil and fs.GetText then
                            local ok, t = pcall(fs.GetText, fs)
                            if ok then msg = t end
                        end
                        if msg ~= nil and not ns.Readable(msg) then msg = nil end
                        list[#list + 1] = { fs = fs, top = top, bottom = fs:GetBottom() or top, msg = msg }
                    end
                end
            end
            table.sort(list, function(a, b) return a.top > b.top end)
            if Chat.viewIdxVer ~= Chat.viewVer then
                local map = {}
                for _, it in ipairs(Chat.view) do
                    if it.raw then
                        local l = map[it.raw]
                        if not l then l = {}; map[it.raw] = l end
                        l[#l + 1] = it.seq
                    end
                end
                Chat.viewIdx, Chat.viewIdxVer = map, Chat.viewVer
            end
            local idx = Chat.viewIdx
            local groups, prev, cur = {}, nil, nil
            for _, ln in ipairs(list) do
                if cur and ln.msg ~= nil and cur.msg == ln.msg then
                    cur.lines[#cur.lines + 1] = ln
                    cur.bottom = ln.bottom
                else
                    cur = { msg = ln.msg, lines = { ln }, bottom = ln.bottom }
                    groups[#groups + 1] = cur
                    local c = ln.msg and idx[ln.msg]
                    if c then
                        local pick
                        if prev then
                            for _, s in ipairs(c) do if s > prev then pick = s break end end
                        else
                            local best
                            for _, s in ipairs(c) do
                                local d = sel.hint and math.abs(s - sel.hint) or -s
                                if not best or d < best then best, pick = d, s end
                            end
                        end
                        cur.seq = pick
                        if pick then prev = pick end
                    end
                end
            end
            for _, g in ipairs(groups) do
                if g.seq then pcall(ResolveLines, g) end
            end
            for _, g in ipairs(groups) do
                if g.seq then sel.hint = g.seq break end
            end
            return groups
        end

        -- Selection points are { seq, off }: message number and byte offset
        -- into that message's plain text.
        local function Before(a, b) -- a strictly before b
            return a.seq < b.seq or (a.seq == b.seq and a.off < b.off)
        end

        local function PointOnLine(g, ln, atEnd, cx)
            if atEnd == true then return { seq = g.seq, off = ln.e } end
            if atEnd == false then return { seq = g.seq, off = ln.s } end
            local left = ln.fs:GetLeft()
            if ln.M and left then
                local k = IndexForX(ln, cx / ln.fs:GetEffectiveScale() - left)
                if k then return { seq = g.seq, off = ln.base + ln.la.cum[k] } end
            end
            -- No exact positions: nearer half of the line decides.
            local c = ln.fs:GetCenter()
            if c and cx / ln.fs:GetEffectiveScale() > c then return { seq = g.seq, off = ln.e } end
            return { seq = g.seq, off = ln.s }
        end

        local function CursorPos(groups)
            local cx, cy = GetCursorPosition()
            cy = cy / smf:GetEffectiveScale()
            local top, bottom = smf:GetTop(), smf:GetBottom()
            local lastG, lastLn, firstG, firstLn
            for _, g in ipairs(groups) do
                if g.seq then
                    for _, ln in ipairs(g.lines) do
                        if not firstLn then firstG, firstLn = g, ln end
                        lastG, lastLn = g, ln
                        if cy >= ln.bottom then
                            if firstLn == ln and top and cy > top then
                                return PointOnLine(g, ln, false)
                            end
                            return PointOnLine(g, ln, nil, cx)
                        end
                    end
                end
            end
            if lastLn then
                if bottom and cy < bottom then return PointOnLine(lastG, lastLn, true) end
                return PointOnLine(lastG, lastLn, nil, cx)
            end
            return nil
        end

        local function Paint(groups)
            local used = 0
            if sel.active and sel.anchor and sel.cur then
                local lo, hi = sel.anchor, sel.cur
                if Before(hi, lo) then lo, hi = hi, lo end
                local col = Chat:StampColumn()
                for _, g in ipairs(groups) do
                    if g.seq and g.seq >= lo.seq and g.seq <= hi.seq then
                        local a = (g.seq == lo.seq) and lo.off or -1
                        local b = (g.seq == hi.seq) and hi.off or math.huge
                        for _, ln in ipairs(g.lines) do
                            local whole = a <= ln.s and b >= ln.e
                            local x0, x1
                            -- Lines that can't be measured exactly (no ln.M) fall back to the
                            -- line's own text width, so a highlight never spans the whole frame.
                            local okW, textW = pcall(ln.fs.GetStringWidth, ln.fs)
                            if not (okW and type(textW) == "number" and ns.Readable(textW) and textW > 0) then textW = nil end
                            if not whole and ln.e > ln.s and b > ln.s and a < ln.e then
                                if ln.la and not ln.M and textW and ln.la.cum[ln.la.n] > 0 then
                                    local total = ln.la.cum[ln.la.n]
                                    local function Frac(off) return textW * math.max(0, math.min(1, (off - ln.s) / total)) end
                                    x0 = a <= ln.s and 0 or Frac(a)
                                    x1 = b >= ln.e and textW or Frac(b)
                                elseif ln.la and ln.M then
                                    local xa = a <= ln.s and 0 or XAt(ln.M, IndexForOffset(ln, a))
                                    local xb
                                    if b < ln.e then
                                        xb = XAt(ln.M, IndexForOffset(ln, b))
                                    else
                                        -- runs to the end of the text, not the edge of the frame
                                        xb = XAt(ln.M, ln.k1)
                                    end
                                    if xa and xb then
                                        -- positions within a wrapped row are measured from its first atom
                                        if a > ln.s then xa = xa - ln.xoff end
                                        x0, x1 = xa, xb - ln.xoff
                                    end
                                end
                                if not x0 then whole = true end -- can't place it exactly
                            end
                            if whole and ln.la and ln.M and not x1 then
                                -- fully selected line: stop at the end of its text
                                local xe = XAt(ln.M, ln.k1)
                                if xe and xe - ln.xoff > 0 then x1 = xe - ln.xoff end
                            elseif whole and not x1 and textW then
                                x1 = textW -- unmeasured line: stop at the end of its text
                            end
                            if whole or x0 then
                                used = used + 1
                                local t = pool[used]
                                if not t then
                                    t = layer:CreateTexture(nil, "OVERLAY")
                                    t:SetColorTexture(0.25, 0.5, 0.95, 0.35)
                                    pool[used] = t
                                end
                                t:ClearAllPoints()
                                local lx = (whole or x0 <= 0) and (-col - 2) or x0
                                if ln.rh then
                                    -- one row of a wrapped message
                                    t:SetPoint("TOPLEFT", ln.fs, "TOPLEFT", lx, -ln.yoff)
                                    if x1 then
                                        t:SetPoint("TOPRIGHT", ln.fs, "TOPLEFT", x1, -ln.yoff)
                                    else
                                        t:SetPoint("TOPRIGHT", ln.fs, "TOPRIGHT", 2, -ln.yoff)
                                    end
                                    t:SetHeight(ln.rh)
                                else
                                    t:SetPoint("TOPLEFT", ln.fs, "TOPLEFT", lx, 0)
                                    t:SetPoint("BOTTOMLEFT", ln.fs, "BOTTOMLEFT", lx, 0)
                                    if x1 then
                                        t:SetPoint("TOPRIGHT", ln.fs, "TOPLEFT", x1, 0)
                                        t:SetPoint("BOTTOMRIGHT", ln.fs, "BOTTOMLEFT", x1, 0)
                                    else
                                        t:SetPoint("TOPRIGHT", ln.fs, "TOPRIGHT", 2, 0)
                                        t:SetPoint("BOTTOMRIGHT", ln.fs, "BOTTOMRIGHT", 2, 0)
                                    end
                                end
                                t:Show()
                            end
                        end
                    end
                end
            end
            for i = used + 1, #pool do pool[i]:Hide() end
        end

        local function SelectedText()
            if not (sel.anchor and sel.cur) then return nil end
            local view = Chat.view
            local first = view[1]
            if not first then return nil end
            local lo, hi = sel.anchor, sel.cur
            if Before(hi, lo) then lo, hi = hi, lo end
            local out = {}
            for s = lo.seq, hi.seq do
                local it = view[s - first.seq + 1]
                if it and it.raw then
                    local P = Atoms(it.raw).plain
                    local a = (s == lo.seq) and lo.off or 0
                    local b = (s == hi.seq) and hi.off or #P
                    local piece = P:sub(a + 1, b)
                    if piece ~= "" then
                        local lead = (it.stamp and P:sub(1, a):find("^%s*$")) and (Plain(it.stamp) .. " ") or ""
                        out[#out + 1] = lead .. piece
                    end
                end
            end
            if #out == 0 then return nil end
            return table.concat(out, "\n")
        end

        -- Without a clipboard API the copy goes through a focused, highlighted
        -- edit box: it is readied when Ctrl goes down, before C arrives.
        local function Prime()
            local text = SelectedText()
            if not text then return end
            eb:Show()
            eb:SetText(text)
            eb:SetFocus()
            eb:HighlightText()
            C_Timer.After(4, Unprime)
        end
        eb:SetScript("OnKeyUp", function(_, key)
            if key == "C" or key == "LCTRL" or key == "RCTRL" or key == "LMETA" or key == "RMETA" then Unprime() end
        end)
        eb:SetScript("OnEscapePressed", Unprime)
        eb:SetScript("OnEditFocusLost", function() eb:Hide() end)

        local function Propagate(on)
            if keys.SetPropagateKeyboardInput then pcall(keys.SetPropagateKeyboardInput, keys, on) end
        end
        keys:SetScript("OnShow", function() keys:EnableKeyboard(true) end)
        keys:SetScript("OnHide", function() keys:EnableKeyboard(false) end)
        keys:SetScript("OnKeyDown", function(_, key)
            if key == "ESCAPE" then
                Propagate(false)
                Clear()
                return
            end
            Propagate(true)
            local ctrl = IsControlKeyDown() or (IsMetaKeyDown and IsMetaKeyDown())
            -- (CopyToClipboard is protected, so addons can't use it: pressing
            -- Ctrl focuses a hidden, pre-highlighted edit box for the game's Ctrl+C.)
            if key == "LCTRL" or key == "RCTRL" or key == "LMETA" or key == "RMETA" then
                Prime()
            end
        end)
        keys:RegisterEvent("PLAYER_REGEN_DISABLED")
        keys:SetScript("OnEvent", Clear)

        driver:SetScript("OnUpdate", function(_, elapsed)
            if dragging and not IsMouseButtonDown("LeftButton") then dragging = false end
            if not dragging and not sel.active then
                driver:Hide()
                return
            end
            acc, accScroll = acc + elapsed, accScroll + elapsed
            if dragging and moved then
                local top, bottom = smf:GetTop(), smf:GetBottom()
                if top and bottom then
                    local _, cy = GetCursorPosition()
                    cy = cy / smf:GetEffectiveScale()
                    local over = cy > top and (cy - top) or (cy < bottom and (cy - bottom)) or 0
                    if over ~= 0 and accScroll >= math.max(0.03, 0.14 - math.abs(over) / 600) then
                        accScroll = 0
                        if over > 0 then smf:ScrollUp() else smf:ScrollDown() end
                        Chat.jump:SetShown(not smf:AtBottom())
                    end
                end
            end
            if acc < 0.03 then return end
            acc = 0
            local groups = Groups()
            if dragging then
                if not moved then
                    local x, y = GetCursorPosition()
                    if math.abs(x - downX) > 4 or math.abs(y - downY) > 4 then
                        moved = true
                        sel.active, sel.anchor, sel.cur = true, pending, pending
                        keys:Show()
                    end
                end
                if moved then
                    local okP, p = pcall(CursorPos, groups)
                    if okP and p then sel.cur = p end
                end
            end
            Paint(groups)
        end)

        pcall(smf.HookScript, smf, "OnMouseDown", function(_, button)
            if button and button ~= "LeftButton" then return end
            downX, downY = GetCursorPosition()
            moved, acc, accScroll = false, 0, 0
            local okP, p = pcall(CursorPos, Groups())
            pending = okP and p or nil
            if not pending then return end
            dragging = true
            driver:Show()
        end)
        pcall(smf.HookScript, smf, "OnMouseUp", function(_, button)
            if button and button ~= "LeftButton" then return end
            local was = dragging
            dragging = false
            if not (was and not moved) then return end
            -- Double-click selects the whole message (all its wrapped lines); a single click drops the selection.
            local now = GetTime()
            local cx, cy = GetCursorPosition()
            local dbl = lastClick and now - lastClick.t < 0.4
                and math.abs(cx - lastClick.x) < 8 and math.abs(cy - lastClick.y) < 8
            lastClick = { t = now, x = cx, y = cy }
            local first = Chat.view and Chat.view[1]
            local it = dbl and pending and first and Chat.view[pending.seq - first.seq + 1]
            if it and it.raw then
                local len = #Atoms(it.raw).plain
                sel.active, sel.anchor, sel.cur = true, { seq = pending.seq, off = 0 }, { seq = pending.seq, off = len }
                keys:Show()
                driver:Show()
                lastClick = nil
            else
                Clear()
            end
        end)
    end
    -- Lines with inline pictures (channel tags, the time-column spacer) can
    -- run a little past the wrap width. The message frame is therefore kept
    -- WRAP_SLACK narrower than the visible area (so lines wrap early), while
    -- the layer that actually draws and clips the text reaches the full
    -- width, so an overrun still shows instead of being cut off.
    -- Times in their own column when this client's message frame lets us
    -- see its lines (see LayoutStamps); otherwise they stay in the text.
    self.tabH = Chat.TAB_H
    if type(smf.visibleLines) == "table" then
        self.split = true
        if smf.SetIndentedWordWrap then smf:SetIndentedWordWrap(false) end -- wrapped lines start under the chip
        local layer = CreateFrame("Frame", nil, self)
        layer:SetFrameLevel(smf:GetFrameLevel() + 1)
        layer:SetClipsChildren(true)
        layer.labels = {}
        local acc = 0
        layer:SetScript("OnUpdate", function(_, elapsed)
            acc = acc + elapsed
            if acc < 0.03 then return end
            acc = 0
            Chat:LayoutStamps()
        end)
        self.stampLayer = layer
    end
    local holder = smf.FontStringContainer
    if type(holder) == "table" and holder.SetPoint then
        pcall(function()
            holder:ClearAllPoints()
            holder:SetPoint("TOPLEFT", smf, "TOPLEFT", 0, 0)
            holder:SetPoint("BOTTOMRIGHT", smf, "BOTTOMRIGHT", WRAP_SLACK, 0)
        end)
    end
    self.smf = smf

    local jump = T.Button(self, L["Latest"], 58, 22)
    jump:SetPoint("BOTTOMRIGHT", smf, "BOTTOMRIGHT", 2 + WRAP_SLACK, 0) -- rides above the input box when it's inside
    jump:SetFrameLevel(smf:GetFrameLevel() + 5)
    jump:SetScript("OnClick", function()
        smf:ScrollToBottom()
        jump:Hide()
    end)
    jump:Hide()
    self.jump = jump

    -- Resize corner: always there (faint), brighter under the mouse.
    local grip = CreateFrame("Button", nil, self)
    grip:SetSize(22, 22)
    grip:SetPoint("BOTTOMRIGHT", 0, 0)
    grip:SetFrameLevel(jump:GetFrameLevel() + 3)
    grip.lines = {}
    -- Three small round dots follow the corner; the hit area stays generous.
    for i, point in ipairs({ {-8,8}, {-13,8}, {-8,13} }) do
        local t = grip:CreateTexture(nil, "OVERLAY")
        T.Circle(t) T.Color(t,1,1,1,1)
        t:SetSize(2.5,2.5)
        t:SetPoint("CENTER",grip,"BOTTOMRIGHT",point[1],point[2])
        grip.lines[i] = t
    end
    local function PaintGrip(hot)
        local c = hot and T.ACCENT or T.SECTION
        for _, t in ipairs(grip.lines) do t:SetVertexColor(c[1], c[2], c[3], hot and 0.95 or 0.35) end
    end
    PaintGrip(false)
    grip:SetScript("OnEnter", function(g)
        PaintGrip(true)
        GameTooltip:SetOwner(g, "ANCHOR_TOPLEFT")
        GameTooltip:AddLine(L["Drag to resize"])
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", function() if not Chat.sizing then PaintGrip(false) end GameTooltip:Hide() end)
    grip:SetScript("OnMouseDown", function(_, button)
        if button ~= "LeftButton" then return end
        Chat.sizing = true
        PaintGrip(true)
        GameTooltip:Hide()
        Chat:StartSizing("BOTTOMRIGHT")
    end)
    grip:SetScript("OnMouseUp", function(g)
        if not Chat.sizing then return end
        Chat.sizing = nil
        Chat:StopMovingOrSizing()
        db.width, db.height = math.floor(Chat:GetWidth()), math.floor(Chat:GetHeight())
        -- Sizing re-anchors the frame: keep where it ended up.
        local p, _, rp, x, y = Chat:GetPoint()
        if p then db.point = { p, rp, x, y } if ns.EditMode then ns.EditMode.NoteMoved("chat") end end
        Chat:PlaceEditBox()
        Chat:ClearStampCache()
        if not g:IsMouseOver() then PaintGrip(false) end
    end)
    self.grip = grip

    -- Move mode overlay (shown while unlocked).
    local overlay = CreateFrame("Frame", nil, self)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(smf:GetFrameLevel() + 8)
    overlay:EnableMouse(true)
    overlay:RegisterForDrag("LeftButton")
    overlay:SetScript("OnDragStart", function() Chat:StartDrag() end)
    overlay:SetScript("OnDragStop", function() Chat:StopDrag() end)
    local ob = overlay:CreateTexture(nil, "BACKGROUND")
    ob:SetAllPoints()
    ob:SetColorTexture(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.10)
    T.AccentBorder(T.Border(overlay, T.ACCENT, 1))
    local ot = ChatText(overlay, 12, T.TEXT)
    ot:SetPoint("CENTER", 0, 6)
    ot:SetText(L["Drag to move"])
    local os2 = ChatText(overlay, 10, T.SECTION)
    os2:SetPoint("TOP", ot, "BOTTOM", 0, -4)
    os2:SetText(L["DRAG THE CORNER TO RESIZE  ·  CLICK THE LOCK WHEN DONE"])
    overlay:SetScript("OnShow", function(o)
        if ns.ChatUsesMovers and ns.ChatUsesMovers() then o:Hide() end
    end)
    overlay:Hide()
    self.overlay = overlay
    grip:SetFrameLevel(overlay:GetFrameLevel() + 2)
    bar:SetFrameLevel(overlay:GetFrameLevel() + 2) -- tab bar buttons stay clickable (lock!)

    self:AttachEditBox()
    self:BuildInputBar()
    self:HideBlizzard()

    for i = 1, NUM_CHAT_WINDOWS or 10 do
        local cf = _G["ChatFrame" .. i]
        if cf and i ~= 2 then hooksecurefunc(cf, "AddMessage", OnAddMessage) end -- 2 = combat log
    end
    -- Make sure loot, money, XP and the like reach us (now, and once the
    -- game has finished loading this character's chat settings).
    self:WatchModifier()
    pcall(self.EnsureGroups, self)
    C_Timer.After(3, function() pcall(Chat.EnsureGroups, Chat) end)
    self:RegisterEvent("CHANNEL_UI_UPDATE")
    -- Zone channels (General / LocalDefense - <zone>) are left and joined as you
    -- travel, and the game only adds them to its own chat window itself, so
    -- re-listen after each change or those lines never reach Pigeon.
    for _, ev in ipairs({ "CHAT_MSG_CHANNEL_NOTICE", "ZONE_CHANGED_NEW_AREA", "PLAYER_ENTERING_WORLD" }) do
        pcall(self.RegisterEvent, self, ev)
    end
    local ensurePending
    self:HookScript("OnEvent",function(_,event)
        if event=="CHANNEL_UI_UPDATE" then
            pcall(Chat.EnsureGroups,Chat)
            Chat:RefreshTabSettings()
        elseif event=="CHAT_MSG_CHANNEL_NOTICE" or event=="ZONE_CHANGED_NEW_AREA" or event=="PLAYER_ENTERING_WORLD" then
            if not ensurePending then
                ensurePending=true
                C_Timer.After(1.5,function()
                    ensurePending=nil
                    pcall(Chat.EnsureGroups,Chat)
                end)
            end
        end
    end)

    -- Restore the last session's lines.
    for _, e in ipairs(ns.hist.chat or {}) do
        ns.UpgradeChatHistoryEntry(e)
        self.log[#self.log + 1] = e
    end

    self.active = 1
    self:Show()
    self:ApplySettings()
    self:SelectTab(1)

    -- Idle fade (and combat fade) of the background and tabs.
    ns.ChatX.Touch(self)
    self:HookScript("OnUpdate", function(f, elapsed) ns.ChatX.IdleTick(f, elapsed) end)
end
