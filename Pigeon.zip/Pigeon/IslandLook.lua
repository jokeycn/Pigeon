-- Island's black palette and configured accent. Reading its settings never changes them.
local _, ns = ...
local T = ns.Theme
local Isl = {}
ns.Island = Isl
local FONTS = "Interface\\AddOns\\Island\\Media\\Fonts\\"
local FALLBACK = { 0.655, 0.545, 0.980, 1 }
local function IsLoaded(name)
    if C_AddOns and C_AddOns.IsAddOnLoaded then return C_AddOns.IsAddOnLoaded(name) end
    return IsAddOnLoaded and IsAddOnLoaded(name)
end
function Isl.Loaded()
    return IsLoaded("Island") == true or IsLoaded("IslandXP") == true
end
function Isl.Active()
    if not ns.db then return false end
    local preset = ns.db.look and ns.db.look.preset
    return preset == "island" or (preset ~= "softsignal" and preset ~= "forever" and ns.db.islandStyle ~= false and Isl.Loaded())
end
local function Color(c)
    if type(c) ~= "table" then return nil end
    local r, g, b = c[1] or c.r, c[2] or c.g, c[3] or c.b
    if not ns.Readable(r) or not ns.Readable(g) or not ns.Readable(b) then return nil end
    if type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number" then return nil end
    return { r, g, b, 1 }
end
local function ClassColor()
    if not UnitClass then return nil end
    local _, cls = UnitClass("player")
    if not ns.Readable(cls) or type(cls) ~= "string" then return nil end
    local c = (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[cls]) or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls])
    if not c and C_ClassColor and C_ClassColor.GetClassColor then
        local ok, value = pcall(C_ClassColor.GetClassColor, cls)
        if ok then c = value end
    end
    return Color(c)
end
function Isl.Settings()
    if not Isl.Loaded() then return nil end
    -- Island hands out the settings of the profile in use; older versions do not have this
    if type(_G.IslandSettings) == "function" then
        local ok, t = pcall(_G.IslandSettings)
        if ok and type(t) == "table" then return t end
    end
    local char = _G.IslandXPCharDB
    if type(char) == "table" and char.own and type(char.settings) == "table" then
        return char.settings
    end
    return type(_G.IslandXPDB) == "table" and _G.IslandXPDB or nil
end
function Isl.Opacity()
    local db = Isl.Settings()
    local a = db and db.opacity
    if ns.Readable(a) and type(a) == "number" then return math.max(0, math.min(1, a)) end
    return 1
end
function Isl.Color()
    local db = Isl.Settings()
    if type(db) ~= "table" then return Color(FALLBACK) end
    local bar = (db.barMode == "class" and ClassColor()) or Color(db.xpColor) or Color(FALLBACK)
    if db.accentMode == "custom" then return Color(db.accent) or bar end
    if db.accentMode == "class" then return ClassColor() or bar end
    return bar
end
local LOOK = {
    BACKDROP = {0,0,0,0.97}, BORDER = {1,1,1,0.20},
    CARD = {0.075,0.078,0.095,0.98}, CARD_BORDER = {1,1,1,0.12},
    INPUT_BG = {0.11,0.115,0.135,1}, INPUT_BORDER = {1,1,1,0.16},
    DIVIDER = {1,1,1,0.10}, TEXT = {0.925,0.933,0.957,1},
    WHISPER = {0.925,0.933,0.957,1}, YOURS = {0.925,0.933,0.957,1},
    LABEL = {0.86,0.87,0.90,1}, SECTION = {0.65,0.68,0.76,1}, DIM = {0.42,0.44,0.50,1},
}
function Isl.ApplyTheme()
    if not Isl.Active() then return end
    for k, c in pairs(LOOK) do T[k] = {c[1],c[2],c[3],c[4]} end
    T.BACKDROP[4] = Isl.Opacity()
    if Isl.Loaded() then
        T.FONT = IslandXP_FontPath and IslandXP_FontPath("bold") or (FONTS .. "OpenSans-Bold.ttf")
    end
    -- Theme colours are the default; the explicit class-colour option may override them.
    if not ns.db.classTint then T.ACCENT = Isl.Color() end
end
-- Created after login so it cannot interfere with the addon's event frame.
-- A low-frequency read also catches changes made through Island's own settings.
function Isl.StartWatching()
    if Isl.watcher then return end
    local f = CreateFrame("Frame")
    Isl.watcher = f
    local elapsed, last = 0
    f:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + dt
        if elapsed < 1 then return end
        elapsed = 0
        if not Isl.Active() then last = nil return end
        local c = Isl.Color()
        local signature = table.concat(c, ":") .. ":" .. Isl.Opacity() .. ":" .. tostring(Isl.Loaded())
        if signature ~= last then
            local changed = last ~= nil
            last = signature
            if changed then ns.ApplyLook() end
        end
    end)
end
local lsm = T.SharedMedia and T.SharedMedia()
if lsm and lsm.Register and Isl.Loaded() then
    pcall(lsm.Register, lsm, "font", "Island XP Medium", FONTS .. "OpenSans-Medium.ttf")
    pcall(lsm.Register, lsm, "font", "Island XP Bold", FONTS .. "OpenSans-Bold.ttf")
    pcall(lsm.Register, lsm, "font", "Island XP ExtraBold", FONTS .. "OpenSans-ExtraBold.ttf")
end
