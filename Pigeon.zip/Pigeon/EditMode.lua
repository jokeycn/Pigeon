-- Pigeon chat in WoW's Edit Mode (via the bundled LibEditMode).
-- Positions are saved per Edit Mode layout. Skipped when ElvUI movers own
-- placement, when ElvUI has fitted the chat, or when editMode is false.
-- With EllesmereUI, the chat uses Edit Mode (only the dock stays in /unlock).
-- /pigeon emdebug prints what happened.
local _, ns = ...
local EM = {}
ns.EditMode = EM

-- True when a UI suite's mover mode (not Edit Mode) places the chat.
function ns.ChatUsesMovers()
    if ns.ElvUI.UsesMovers() then return true end
    return ns.Ellesmere.UsesMovers() and not EM.registered
end
EM.status = "Setup has not run"

local function SavedFor()
    local c = ns.db and ns.db.chat
    if not c then return end
    c.editLayouts = c.editLayouts or {}
    return c.editLayouts
end

local function ApplyChat(pt)
    local chat = ns.Chat
    if not (chat and pt) then return end
    chat:ClearAllPoints()
    chat:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
    chat.db.point = { pt[1], pt[2], pt[3], pt[4] }
    if chat.PlaceEditBox then chat:PlaceEditBox() end
end

-- True when the library loaded fully and the client has Edit Mode.
function EM.Usable()
    local lib = ns.LibEditMode
    return lib and lib.AddFrame and EditModeManagerFrame and C_EditMode and ns.db.editMode ~= false and true or false
end

-- Position saved some other way (Shift-drag, the resize grip): keep the active
-- layout's entry in step, or the next login would restore the older spot.
function EM.NoteMoved(kind)
    local lib = ns.LibEditMode
    if not (EM.registered and lib and lib.GetActiveLayoutName) then return end
    local layout = lib:GetActiveLayoutName()
    if not layout then return end
    if kind == "chat" then
        local all, c = SavedFor(), ns.Chat and ns.Chat.db
        if all and c and c.point then all[layout] = { c.point[1], c.point[2], c.point[3], c.point[4] } end
    elseif kind == "dock" and ns.db.point then
        ns.db.dockLayouts = ns.db.dockLayouts or {}
        local p = ns.db.point
        ns.db.dockLayouts[layout] = { p[1], p[2], p[3], p[4] }
    end
end

function EM.Setup()
    local lib = ns.LibEditMode
    if not (lib and lib.AddFrame) then EM.status = "library did not load fully (no AddFrame)" return end
    if not (EditModeManagerFrame and C_EditMode) then EM.status = "this client has no Edit Mode" return end
    if EM.registered then EM.status = "already registered" return end
    if ns.db.editMode == false then EM.status = "turned off (db.editMode=false)" return end
    if ns.ElvUI.fitted then EM.status = "skipped: ElvUI fitted the chat" return end
    if ns.ElvUI.UsesMovers() then EM.status = "skipped: ElvUI movers" return end
    local chat = ns.Chat
    if not (chat and chat.smf) then EM.status = "skipped: chat frame not built" return end

    local d = chat.db.point or { "BOTTOMLEFT", "BOTTOMLEFT", 20, 120 }
    local ok, err = pcall(function()
        -- Register the layout callback first: the library's first AddFrame fires it at once.
        -- Switching Edit Mode layouts brings that layout's position along.
        lib:RegisterCallback("layout", function(layout)
            if not layout then return end
            local all = SavedFor()
            if not all or ns.ElvUI.UsesMovers() or ns.ElvUI.fitted then return end
            if all[layout] then
                ApplyChat(all[layout])
            else
                all[layout] = { unpack(chat.db.point or d) } -- first visit: adopt the current spot
            end
        end)
        lib:AddFrame(chat, function(_, layout, point, x, y)
            if not layout then return end
            ApplyChat({ point, point, x, y })
            local all = SavedFor()
            if all then all[layout] = { point, point, x, y } end
        end, { point = d[1], x = d[3], y = d[4] }, "Pigeon Chat")
    end)
    -- Width and height in the Edit Mode panel (the resize grip still works too).
    pcall(function()
        local ST = lib.SettingType
        local function Size(name, key, lo, hi)
            return {
                kind = ST.Slider, name = name, default = chat.db[key], minValue = lo, maxValue = hi, valueStep = 10,
                get = function() return chat.db[key] end,
                set = function(_, v)
                    chat.db[key] = math.floor(v)
                    chat:SetSize(chat.db.width, chat.db.height)
                    if chat.PlaceEditBox then chat:PlaceEditBox() end
                    if chat.ClearStampCache then chat:ClearStampCache() end
                end,
                formatter = function(v) return tostring(math.floor(v)) end,
            }
        end
        lib:AddFrameSettings(chat, { Size("Width", "width", 300, 1000), Size("Height", "height", 140, 700) })
    end)

    -- The dock (its stack button) when it has a place of its own; an attached
    -- dock rides along with the chat.
    local dock = ns.Dock
    if dock and not dock.attached then
        local dp = ns.db.point or { "BOTTOMLEFT", "BOTTOMLEFT", 20, 300 }
        local dok = pcall(function()
            lib:AddFrame(dock, function(_, layout, point, x, y)
                if not layout then return end
                ns.db.point = { point, point, x, y }
                dock:SetMovable(true)
                dock:ApplyPosition()
                ns.db.dockLayouts = ns.db.dockLayouts or {}
                ns.db.dockLayouts[layout] = { point, point, x, y }
            end, { point = dp[1], x = dp[3], y = dp[4] }, "Pigeon Dock")
            lib:RegisterCallback("layout", function(layout)
                if not layout then return end
                ns.db.dockLayouts = ns.db.dockLayouts or {}
                local pt = ns.db.dockLayouts[layout]
                if pt then
                    ns.db.point = { pt[1], pt[2], pt[3], pt[4] }
                    dock:ApplyPosition()
                else
                    ns.db.dockLayouts[layout] = { unpack(ns.db.point or dp) }
                end
            end)
        end)
        EM.dockRegistered = dok
    end

    if ok then
        EM.registered = true
        EM.status = "registered with Edit Mode (chat" .. (EM.dockRegistered and " + dock)" or ")")
    else
        EM.status = "ERROR: " .. tostring(err)
    end
end
