--[[
    Pigeon - EllesmereUI integration
    Only does anything when EllesmereUI is loaded:
      - Look: optional "EllesmereUI style" uses its global font and accent
        colour, and follows changes made in its options.
      - Unlock mode: the chat box and the dock show up in EllesmereUI's
        unlock mode (/unlock) and are positioned there instead of by drag.
        (ElvUI's /moveui wins if both are loaded.)
      - Chat: EllesmereUI Chat replaces the chat window, so while it's
        enabled the Pigeon chat box stays off. Whispers work either way.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local Eui = {}
ns.Ellesmere = Eui

local function Engine()
    local E = _G.EllesmereUI
    if type(E) ~= "table" or type(E.GetFontPath) ~= "function" then return nil end
    return E
end

local function IsLoaded(name)
    if C_AddOns and C_AddOns.IsAddOnLoaded then return C_AddOns.IsAddOnLoaded(name) end
    return IsAddOnLoaded and IsAddOnLoaded(name)
end

function Eui.Loaded()
    return Engine() ~= nil
end

function Eui.ChatActive()
    return Engine() ~= nil and IsLoaded("EllesmereUIChat") == true
end

function Eui.UsesMovers()
    return Eui.moversActive == true
end

function Eui.ToggleMoveMode()
    local E = Engine()
    if not E then return false end
    if type(E.ToggleUnlockMode) == "function" then
        return (pcall(E.ToggleUnlockMode, E))
    end
    if type(E._openUnlockMode) == "function" then
        return (pcall(E._openUnlockMode))
    end
    return false
end

---------------------------------------------------------------------------
-- Shared by the rest of the addon: whichever UI suite's mover mode is in
-- charge of positions (ElvUI first, then EllesmereUI).
---------------------------------------------------------------------------

function ns.UsesMovers()
    return ns.ElvUI.UsesMovers() or Eui.UsesMovers()
end

function ns.ToggleMoveMode()
    if ns.ElvUI.UsesMovers() then return ns.ElvUI.ToggleMoveMode() end
    if Eui.UsesMovers() then return Eui.ToggleMoveMode() end
    return false
end

function ns.MoverHint()
    if ns.ElvUI.fitted or ns.ElvUI.UsesMovers() then return L["Move with ElvUI (/moveui)"] end
    if Eui.UsesMovers() then return L["Move with EllesmereUI (/unlock)"] end
end

---------------------------------------------------------------------------
-- Look
---------------------------------------------------------------------------

local function Accent(E)
    local c = E.ACCENT_COLOR or E.ELLESMERE_GREEN
    if type(c) == "table" and c.r and c.g and c.b then return { c.r, c.g, c.b, 1 } end
end

-- Called from Theme's Refresh after Horizon (and ElvUI) values are read.
function Eui.ApplyTheme()
    if not (ns.db and ns.db.euiStyle) then return end
    local E = Engine()
    if not E then return end
    local ok, font = pcall(E.GetFontPath)
    if ok and type(font) == "string" and font ~= "" then T.FONT = font end
    local accent = Accent(E)
    if accent and not ns.db.classTint then T.ACCENT = accent end
end

---------------------------------------------------------------------------
-- Unlock mode
---------------------------------------------------------------------------

local function Element(E, key, label, order, frame, getPoint, setPoint, apply)
    return E.MakeUnlockElement({
        key = key,
        label = label,
        group = "Pigeon",
        order = order,
        noResize = true,
        getFrame = function() return frame end,
        getSize = function() return frame:GetWidth(), frame:GetHeight() end,
        isHidden = function() return not frame:IsShown() end,
        savePos = function(_, point, relPoint, x, y)
            setPoint({ point, relPoint or point, x, y })
            if not E._unlockActive then apply() end
        end,
        loadPos = function()
            local p = getPoint()
            if not p then return nil end
            return { point = p[1], relPoint = p[2], x = p[3], y = p[4] }
        end,
        clearPos = function() end,
        applyPos = function() apply() end,
    })
end

function Eui.Setup()
    local E = Engine()
    if not E then return end

    -- ElvUI's movers already own positions when both are loaded.
    if not ns.ElvUI.UsesMovers() and type(E.RegisterUnlockElements) == "function"
        and type(E.MakeUnlockElement) == "function" then
        local ok = pcall(function()
            local elements = {}
            if ns.Chat.smf and not ns.ElvUI.fitted and not (ns.EditMode and ns.EditMode.Usable() and not ns.ElvUI.fitted) then -- Edit Mode places the chat
                elements[#elements + 1] = Element(E, "WSTACK_Chat", "Pigeon Chat", 900, ns.Chat,
                    function() return ns.db.chat.point end,
                    function(p) ns.db.chat.point = p end,
                    function()
                        local p = ns.db.chat.point
                        ns.Chat:ClearAllPoints()
                        ns.Chat:SetPoint(p[1], UIParent, p[2], p[3], p[4])
                        ns.Chat:PlaceEditBox()
                    end)
            end
            if not ns.Dock.attached and not (ns.EditMode and ns.EditMode.Usable() and not ns.ElvUI.fitted) then -- Edit Mode places it; an attached dock rides along with the chat box
                elements[#elements + 1] = Element(E, "WSTACK_Dock", "Pigeon Dock", 901, ns.Dock,
                    function() return ns.db.point end,
                    function(p) ns.db.point = p end,
                    function()
                        local p = ns.db.point
                        ns.Dock:ClearAllPoints()
                        ns.Dock:SetPoint(p[1], UIParent, p[2], p[3], p[4])
                        ns.Dock:Relayout()
                    end)
            end
            if #elements > 0 then
                E:RegisterUnlockElements(elements, "Pigeon")
                Eui.moversActive = true
                if ns.Chat and ns.Chat.overlay then ns.Chat.overlay:Hide() end
            end
        end)
        if not ok then Eui.moversActive = nil end
    end

    -- Font or colour changes in EllesmereUI's options repaint us.
    local function Repaint()
        C_Timer.After(0, function()
            T.Refresh()
            ns.Refresh()
            if ns.Chat.smf then ns.Chat:ApplySettings() end
        end)
    end
    for _, fn in ipairs({ "InvalidateFontCache", "InvalidateColorCache" }) do
        if type(E[fn]) == "function" then hooksecurefunc(E, fn, Repaint) end
    end
end
