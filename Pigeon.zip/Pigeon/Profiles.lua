--[[
    Pigeon - Profiles, sharing, combat hiding and the launcher
      - Profiles: save the whole setup (look, tabs, chat, whispers, positions)
        under a name, load it later, and optionally have a character load one
        automatically at login. Settings are shared by all characters on the
        account; a profile is how one character gets a different setup.
      - Import / export: the setup as one line of text to paste to a friend
        (or another account). Nothing but plain values goes in or comes out.
      - Combat: fade or hide the whisper dock/window and fade the chat box
        while you're fighting.
      - Launcher: a LibDataBroker button (ElvUI / EllesmereUI data bars,
        Titan, ...) and a minimap button, with the unread count.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local P = {}
ns.Profiles = P

-- Everything in the saved settings except the profiles themselves.
local SKIP = { profiles = true, migrated = true, minimap = true }

local function Copy(v)
    if type(v) ~= "table" then return v end
    local out = {}
    for k, x in pairs(v) do out[k] = Copy(x) end
    return out
end

function P.Snapshot()
    local snap = {}
    for k, v in pairs(ns.db) do
        if not SKIP[k] then snap[k] = Copy(v) end
    end
    return snap
end

-- Fill dst with a copy of src, keeping dst itself (other code holds on to
-- tables like ns.db.chat and ns.db.look, so they must stay the same table).
local function Assign(dst, src)
    for k in pairs(dst) do dst[k] = nil end
    for k, v in pairs(src) do dst[k] = Copy(v) end
end

function P.Apply(snap)
    if type(snap) ~= "table" then return false end
    for k, v in pairs(ns.db) do
        if not SKIP[k] and snap[k] == nil then
            if type(v) == "table" then Assign(v, {}) else ns.db[k] = nil end -- defaults refill it
        end
    end
    for k, v in pairs(snap) do
        if not SKIP[k] then
            if type(ns.db[k]) == "table" and type(v) == "table" then Assign(ns.db[k], v) else ns.db[k] = Copy(v) end
        end
    end
    ns.FillDefaults()
    ns.ApplyLook()
    if ns.Chat.smf then
        ns.Chat.unread, ns.Chat.alerted = {}, {}
        ns.Chat:SelectTab(1)
    end
    return true
end

function P.List()
    local names = {}
    for name in pairs(ns.db.profiles or {}) do names[#names + 1] = name end
    table.sort(names, function(a, b) return a:lower() < b:lower() end)
    return names
end

function P.Save(name)
    name = strtrim(name or "")
    if name == "" then return false end
    ns.db.profiles = ns.db.profiles or {}
    ns.db.profiles[name] = P.Snapshot()
    return true
end

function P.Load(name)
    local snap = ns.db.profiles and ns.db.profiles[name]
    if not snap then return false end
    return P.Apply(snap)
end

function P.Delete(name)
    if ns.db.profiles then ns.db.profiles[name] = nil end
    if ns.hist and ns.hist.profile == name then ns.hist.profile = nil end
end

-- This character's auto-load profile (stored with its whisper history).
function P.CharacterProfile() return ns.hist and ns.hist.profile end
function P.SetCharacterProfile(name) if ns.hist then ns.hist.profile = name end end

function P.LoginLoad()
    local name = P.CharacterProfile()
    if name and ns.db.profiles and ns.db.profiles[name] then
        P.Load(name)
        return name
    end
end

---------------------------------------------------------------------------
-- Serializer: plain values only (strings, numbers, booleans, tables).
-- Format: n<num>;  s<len>:<bytes>  t (...) e  T/F booleans, all concatenated.
---------------------------------------------------------------------------

local function Ser(v, out)
    local t = type(v)
    if t == "string" then
        out[#out + 1] = "s" .. #v .. ":" .. v
    elseif t == "number" then
        out[#out + 1] = "n" .. string.format("%.10g", v) .. ";"
    elseif t == "boolean" then
        out[#out + 1] = v and "T" or "F"
    elseif t == "table" then
        out[#out + 1] = "t"
        for k, x in pairs(v) do
            local kt, xt = type(k), type(x)
            if (kt == "string" or kt == "number") and (xt == "string" or xt == "number" or xt == "boolean" or xt == "table") then
                Ser(k, out)
                Ser(x, out)
            end
        end
        out[#out + 1] = "e"
    end
end

local function Parse(s, i, depth)
    if depth > 20 then error("too deep") end
    local c = s:sub(i, i)
    if c == "s" then
        local len, rest = s:match("^(%d+):()", i + 1)
        len = tonumber(len)
        if not len then error("bad string") end
        local str = s:sub(rest, rest + len - 1)
        if #str ~= len then error("short string") end
        return str, rest + len
    elseif c == "n" then
        local num, rest = s:match("^([%d%.eE%+%-]+);()", i + 1)
        num = tonumber(num)
        if not num then error("bad number") end
        return num, rest
    elseif c == "T" then return true, i + 1
    elseif c == "F" then return false, i + 1
    elseif c == "t" then
        local tbl = {}
        i = i + 1
        while s:sub(i, i) ~= "e" do
            if i > #s then error("unterminated table") end
            local k, v
            k, i = Parse(s, i, depth + 1)
            if type(k) == "table" or type(k) == "boolean" then error("bad key") end
            v, i = Parse(s, i, depth + 1)
            tbl[k] = v
        end
        return tbl, i + 1
    end
    error("unexpected '" .. c .. "'")
end

local PREFIX = "WSTACK1:"

function P.Export()
    local out = {}
    Ser(P.Snapshot(), out)
    return PREFIX .. table.concat(out)
end

-- Returns the settings table, or nil and an error message.
function P.Decode(text)
    text = strtrim(text or ""):gsub("[\r\n]", "")
    -- Strings pasted from Discord or a forum often arrive wrapped in code-fence
    -- backticks or quotes: start at the prefix, ignore that wrapping at the end.
    local start = text:find(PREFIX, 1, true)
    if not start then return nil, L["That isn't a Pigeon setup string."] end
    text = text:sub(start)
    local ok, value, pos = pcall(Parse, text, #PREFIX + 1, 0)
    if not ok or type(value) ~= "table" then return nil, L["The string is damaged or incomplete."] end
    if pos <= #text and not text:sub(pos):match("^[%s`'\"]*$") then return nil, L["The string has extra text at the end."] end
    return value
end

function P.Import(text)
    local snap, err = P.Decode(text)
    if not snap then return nil, err end
    local name = "Imported " .. date("%m-%d %H:%M")
    ns.db.profiles = ns.db.profiles or {}
    ns.db.profiles[name] = snap
    P.Load(name)
    return name
end

function P.ShowExport()
    ns.ChatX.ShowText(L["Export setup"], P.Export(),
        { hint = L["Ctrl+A, Ctrl+C, then paste it anywhere. Import it with /pigeon import."] })
end

function P.ShowImport()
    ns.ChatX.ShowText(L["Import setup"], "", {
        editable = true,
        action = L["Import"],
        hint = L["Paste a Pigeon setup string (Ctrl+V). It's saved as a new profile and loaded."],
        onAccept = function(text)
            local name, err = P.Import(text)
            if name then
                ns.ChatX.HideText()
                ns.Print(L["imported as profile |cffe6ebf5%s|r. Some layout changes need a /reload."]:format(name))
                if ns.Settings:IsShown() and ns.Settings.current == "profiles" then ns.Settings:ShowPage("profiles") end
            else
                ns.Print("|cffff6666" .. err .. "|r")
            end
        end,
    })
end

---------------------------------------------------------------------------
-- Combat
---------------------------------------------------------------------------

local combatFrame = CreateFrame("Frame")
local hiddenForCombat = false

local function SetWhisperAlpha(a)
    for _, f in ipairs({ ns.Dock, ns.Window }) do
        if f and f.SetAlpha and f:IsShown() then
            if f == ns.Window and not T.IsOpen(ns.Window) then -- mid-animation: leave it
            else f:SetAlpha(a) end
        end
    end
end

function P.EnterCombat()
    local c = ns.db.combat
    if not c then return end
    if c.whispers == "fade" then
        SetWhisperAlpha(c.alpha or 0.25)
    elseif c.whispers == "hide" then
        hiddenForCombat = true
        ns.Dock:SetAlpha(0)
        ns.Dock:EnableMouse(false)
        if T.IsOpen(ns.Window) then ns.Window:SetAlpha(0) end
    end
    if ns.Chat.smf and c.chat == "fade" then ns.Chat.combatAlpha = c.alpha or 0.25 end
end

function P.LeaveCombat()
    if hiddenForCombat then
        hiddenForCombat = false
        ns.Dock:EnableMouse(true)
    end
    ns.Dock:SetAlpha(1)
    if T.IsOpen(ns.Window) then ns.Window:SetAlpha(1) end
    if ns.Chat.smf then ns.Chat.combatAlpha = nil end
end

combatFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
combatFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
combatFrame:SetScript("OnEvent", function(_, event)
    if not ns.db then return end
    if event == "PLAYER_REGEN_DISABLED" then P.EnterCombat() else P.LeaveCombat() end
end)

---------------------------------------------------------------------------
-- Launcher: LibDataBroker + minimap button
---------------------------------------------------------------------------

local Launcher = {}
ns.Launcher = Launcher
local MARK = T.MEDIA .. "Symbols\\BIRD.tga" -- the same little bird as the hub and settings

local function Tooltip(tip)
    tip:AddLine("Pigeon")
    local unread = {}
    for _, c in pairs(ns.convos) do
        if (c.unread or 0) > 0 then unread[#unread + 1] = c end
    end
    table.sort(unread, function(a, b) return (a.seq or 0) > (b.seq or 0) end)
    if #unread == 0 then
        tip:AddLine(L["No unread whispers"], T.SECTION[1], T.SECTION[2], T.SECTION[3])
    end
    for i, c in ipairs(unread) do
        if i > 8 then break end
        local r, g, b = ns.ConvoColor(c)
        tip:AddDoubleLine(c.display or "?", L["%d new"]:format(c.unread), r, g, b, T.WHISPER[1], T.WHISPER[2], T.WHISPER[3])
    end
    if ns.db.away and ns.db.away.enabled then tip:AddLine(L["Away message is on"], 1, 0.82, 0.2) end
    tip:AddLine(" ")
    tip:AddLine(L["Click: whisper hub  ·  Right-click: settings"], T.SECTION[1], T.SECTION[2], T.SECTION[3])
end

local function Click(_, button)
    if button == "RightButton" then ns.Settings:Toggle() else ns.Hub:Toggle() end
end

-- Our own minimap button, for when LibDBIcon isn't around.
local function OwnMinimapButton()
    if not Minimap then return nil end
    local b = CreateFrame("Button", "PigeonMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(22, 22)
    bg:SetPoint("CENTER")
    bg:SetColorTexture(T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], 0.9)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetPoint("CENTER")
    icon:SetTexture(MARK)
    icon.wsShaped=true
    T.AccentTexture(icon)
    T.Color(icon,T.ACCENT)
    b.icon=icon
    b.count = T.Text(b, 10, T.WHISPER)
    b.count:SetPoint("BOTTOMRIGHT", 1, 1)
    local function Place()
        local angle = math.rad(ns.db.minimap.angle or 200)
        local r = (Minimap:GetWidth() or 140) / 2 + 5
        b:ClearAllPoints()
        b:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * r, math.sin(angle) * r)
    end
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            ns.db.minimap.angle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            Place()
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", Click)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        Tooltip(GameTooltip)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    Place()
    return b
end

function Launcher.Init()
    ns.db.minimap = ns.db.minimap or { hide = false, angle = 200 }
    local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
    if LDB and type(LDB.NewDataObject) == "function" then
        Launcher.obj = LDB:NewDataObject("Pigeon", {
            type = "data source",
            label = L["Whispers"],
            text = "",
            icon = MARK,
            iconR = T.ACCENT[1], iconG = T.ACCENT[2], iconB = T.ACCENT[3],
            OnClick = Click,
            OnTooltipShow = Tooltip,
        })
    end
    local DBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
    if DBIcon and Launcher.obj and type(DBIcon.Register) == "function" then
        DBIcon:Register("Pigeon", Launcher.obj, ns.db.minimap)
        Launcher.dbicon = DBIcon
    else
        Launcher.button = OwnMinimapButton()
    end
    Launcher.ApplyMinimap()
end

function Launcher.ApplyMinimap()
    local hide = ns.db.minimap and ns.db.minimap.hide
    if Launcher.dbicon then
        if hide then Launcher.dbicon:Hide("Pigeon") else Launcher.dbicon:Show("Pigeon") end
    elseif Launcher.button then
        Launcher.button:SetShown(not hide)
    end
end

function Launcher.Update(unread)
    if Launcher.obj then
        Launcher.obj.text = unread > 0 and (L["%d new"]:format(unread)) or ""
        Launcher.obj.iconR,Launcher.obj.iconG,Launcher.obj.iconB=T.ACCENT[1],T.ACCENT[2],T.ACCENT[3]
    end
    if Launcher.button then Launcher.button.count:SetText(unread > 0 and (unread > 9 and "9+" or unread) or "") end
end
