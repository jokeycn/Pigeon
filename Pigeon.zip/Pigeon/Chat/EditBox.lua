--[[
    Pigeon - Chat edit box and default-chat takeover: hiding the game's chat
    windows, borrowing its input box, the channel menu and chip, the combat log,
    selection and copying. Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L
local Chat = ns.Chat
local ChatText = ns.ChatText
local Categorize, Tag = ns.Categorize, ns.Tag
local WRAP_SLACK = 20 -- the message frame is this much narrower than its text area

---------------------------------------------------------------------------
-- Default chat: hide it, borrow its input box
---------------------------------------------------------------------------

-- The game's combat log (ChatFrame2, with its filter buttons) shown inside
-- the chat box while a combat log tab is selected.
function Chat:ShowCombatLog(on)
    local cl = _G.ChatFrame2
    if not (cl and self.smf) then return end
    if on then
        if not _G.CombatLogQuickButtonFrame_Custom then
            local load = (C_AddOns and C_AddOns.LoadAddOn) or _G.LoadAddOn
            if load then pcall(load, "Blizzard_CombatLog") end
        end
        self.combatShown = true
        cl:SetParent(self)
        cl:SetFrameLevel(self:GetFrameLevel() + 3)
        for _, t in ipairs(CHAT_FRAME_TEXTURES or {}) do
            local tex = _G["ChatFrame2" .. t]
            if tex and tex.SetAlpha then tex:SetAlpha(0) end
        end
        local grip = _G.ChatFrame2ResizeButton
        if grip then grip:Hide() end
        if not self.clHooked then
            self.clHooked = true
            -- ChatFrame2 renders outside our normal tab filter. Apply the
            -- same crafting choice before forwarding to its native renderer.
            local add=cl.AddMessage
            cl.AddMessage=function(frame,text,r,g,b,id,...)
                local tab=Chat.db and Chat.db.tabs[Chat.active]
                if Chat.combatShown and ns.TabKeywordHidden(tab,{text=text})then return end
                if Chat.combatShown and tab and not tab.all and not (tab.cats and tab.cats.crafting)
                    and type(text)=="string" and ns.Readable(text) then
                    local event,args=select(3,...)
                    local ok,cat=pcall(Categorize,text,id,event,args)
                    if ok and cat=="crafting" then return end
                end
                return add(frame,text,r,g,b,id,...)
            end
            hooksecurefunc(cl, "SetPoint", function()
                if Chat.combatShown and not Chat.placingCL then Chat:PlaceCombatLog() end
            end)
        end
        self:SkinCombatScroll()
        self:PlaceCombatLog()
        cl:Show()
        if type(Blizzard_CombatLog_Refilter) == "function" then pcall(Blizzard_CombatLog_Refilter) end
        self.smf:Hide()
        if self.stampLayer then self.stampLayer:Hide() end
        if self.jump then self.jump:Hide() end
    elseif self.combatShown then
        self.combatShown = nil
        cl:SetParent(self.hider or cl:GetParent())
        local qb = _G.CombatLogQuickButtonFrame_Custom
        if qb and self.hider then qb:SetParent(self.hider) end
        self.smf:Show()
        if self.stampLayer and self.split then self.stampLayer:Show() end
    end
end

-- The combat log's own scroll bar, drawn like Pigeon's settings scroller: a
-- faint 3px track and an accent thumb, no arrow buttons.
local function HideTextures(frame, keep)
    if type(frame) ~= "table" or type(frame.GetRegions) ~= "function" then return end
    for _, r in ipairs({ frame:GetRegions() }) do
        if type(r) == "table" and r.GetObjectType and r:GetObjectType() == "Texture" and not keep[r] then r:SetAlpha(0) end
    end
end
local function Silence(btn)
    if type(btn) ~= "table" or type(btn.SetAlpha) ~= "function" then return end
    btn:SetAlpha(0)
    if btn.EnableMouse then btn:EnableMouse(false) end
end
function Chat:SkinCombatScroll()
    if self.clScrollSkinned then return end
    local cl = _G.ChatFrame2
    local bar = cl and cl.ScrollBar
    Silence(cl and cl.ScrollToBottomButton) -- Pigeon's own jump pill does this job
    if type(bar) ~= "table" or type(bar.GetRegions) ~= "function" then return end
    self.clScrollSkinned = true
    local keep = {}
    Silence(bar.Back)
    Silence(bar.Forward)
    HideTextures(bar, keep)
    local track = bar.Track
    if type(track) == "table" and track.CreateTexture then
        HideTextures(track, keep)
        local line = track:CreateTexture(nil, "BACKGROUND")
        line:SetWidth(3)
        line:SetPoint("TOP", 0, 0)
        line:SetPoint("BOTTOM", 0, 0)
        line:SetColorTexture(1, 1, 1, 0.05)
        keep[line] = true
        local thumb = track.Thumb
        if type(thumb) == "table" and thumb.CreateTexture then
            HideTextures(thumb, keep)
            local fill = T.AccentTexture(thumb:CreateTexture(nil, "OVERLAY"))
            fill:SetWidth(3)
            fill:SetPoint("TOP", 0, 0)
            fill:SetPoint("BOTTOM", 0, 0)
            keep[fill] = true
            -- Re-hide the game's thumb art if it repaints on hover.
            thumb:HookScript("OnEnter", function() HideTextures(thumb, keep) end)
            thumb:HookScript("OnLeave", function() HideTextures(thumb, keep) end)
        end
    end
    -- With the arrows gone, let the track use the whole height.
    if type(track) == "table" and track.ClearAllPoints then
        track:ClearAllPoints()
        track:SetPoint("TOPLEFT", bar, "TOPLEFT", 0, 0)
        track:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 0, 0)
    end
end

function Chat:PlaceCombatLog()
    local cl, smf = _G.ChatFrame2, self.smf
    if not (cl and smf) then return end
    self.placingCL = true
    local top = 0
    local qb = _G.CombatLogQuickButtonFrame_Custom
    if qb then
        qb:SetParent(self)
        qb:SetFrameLevel(self:GetFrameLevel() + 4)
        qb:ClearAllPoints()
        qb:SetPoint("TOPLEFT", smf, "TOPLEFT", -2, 0)
        qb:SetPoint("TOPRIGHT", smf, "TOPRIGHT", WRAP_SLACK, 0)
        qb:Show()
        top = (qb:GetHeight() or 24) + 2
    end
    cl:ClearAllPoints()
    cl:SetPoint("TOPLEFT", smf, "TOPLEFT", 0, -top)
    cl:SetPoint("BOTTOMRIGHT", smf, "BOTTOMRIGHT", WRAP_SLACK, 0)
    self.placingCL = nil
end

function Chat:HideBlizzard()
    local hider = CreateFrame("Frame")
    hider:Hide()
    self.hider = hider
    for i = 1, NUM_CHAT_WINDOWS or 10 do
        for _, suffix in ipairs({ "", "Tab", "ButtonFrame" }) do
            local f = _G["ChatFrame" .. i .. suffix]
            if f then f:SetParent(hider) end
        end
    end
    for _, name in ipairs({ "GeneralDockManager", "ChatFrameMenuButton", "ChatFrameChannelButton",
        "ChatFrameToggleVoiceDeafenButton", "ChatFrameToggleVoiceMuteButton", "QuickJoinToastButton" }) do
        local f = _G[name]
        if f then f:SetParent(hider) end
    end
    -- Pop-out whisper windows the default UI may create later.
    if type(FCF_OpenTemporaryWindow) == "function" then
        hooksecurefunc("FCF_OpenTemporaryWindow", function()
            for _, name in ipairs(CHAT_FRAMES or {}) do
                local f = _G[name]
                if f and f.isTemporary and f:GetParent() ~= hider then
                    f:SetParent(hider)
                    local tab = _G[name .. "Tab"]
                    if tab then tab:SetParent(hider) end
                end
            end
        end)
    end
end

-- The lines we show come from the default chat windows. If none of them
-- listens for a kind of message (loot, money, XP... can be switched off per
-- character in the default chat settings), nothing would ever reach us, so
-- switch any missing kind on for the main window.
local WANTED_GROUPS = {
    "ACHIEVEMENT",
    "AFK",
    "BG_ALLIANCE",
    "BG_HORDE",
    "BG_NEUTRAL",
    "BG_SYSTEM_ALLIANCE",
    "BG_SYSTEM_HORDE",
    "BG_SYSTEM_NEUTRAL",
    "BN_INLINE_TOAST_ALERT",
    "BN_INLINE_TOAST_BROADCAST",
    "BN_INLINE_TOAST_BROADCAST_INFORM",
    "BN_WHISPER",
    "BN_WHISPER_INFORM",
    "BN_WHISPER_PLAYER_OFFLINE",
    "CHANNEL",
    "CHANNEL_JOIN",
    "CHANNEL_LEAVE",
    "CHANNEL_LIST",
    "CHANNEL_NOTICE",
    "CHANNEL_NOTICE_USER",
    "COLLECTION",
    "COMBAT_FACTION_CHANGE",
    "COMBAT_HONOR_GAIN",
    "COMBAT_MISC_INFO",
    "COMBAT_XP_GAIN",
    "COMMUNITIES_CHANNEL",
    "CURRENCY",
    "DND",
    "EMOTE",
    "ERRORS",
    "FILTERED",
    "GUILD",
    "GUILD_ACHIEVEMENT",
    "GUILD_DISCORD",
    "GUILD_ITEM_LOOTED",
    "IGNORED",
    "INSTANCE_CHAT",
    "INSTANCE_CHAT_LEADER",
    "LOOT",
    "MONEY",
    "MONSTER_BOSS_EMOTE",
    "MONSTER_BOSS_WHISPER",
    "MONSTER_EMOTE",
    "MONSTER_PARTY",
    "MONSTER_SAY",
    "MONSTER_WHISPER",
    "MONSTER_YELL",
    "OFFICER",
    "OPENING",
    "PARTY",
    "PARTY_LEADER",
    "PET_BATTLE_COMBAT_LOG",
    "PET_BATTLE_INFO",
    "PET_INFO",
    "PING",
    "RAID",
    "RAID_BOSS_EMOTE",
    "RAID_BOSS_WHISPER",
    "RAID_LEADER",
    "RAID_WARNING",
    "RESTRICTED",
    "SAY",
    "SKILL",
    "SYSTEM",
    "TARGETICONS",
    "TEXT_EMOTE",
    "TRADESKILLS",
    "TRANSMOG",
    "VOICE_TEXT",
    "WHISPER",
    "WHISPER_INFORM",
    "YELL",
}
function Chat:EnsureGroups()
    local main = _G.ChatFrame1
    if not main then return 0 end
    local have = {}
    for i = 1, NUM_CHAT_WINDOWS or 10 do
        local f = _G["ChatFrame" .. i]
        local list = f and f.messageTypeList
        if type(list) == "table" and not (IsCombatLog and IsCombatLog(f)) then
            for _, g in pairs(list) do
                if type(g) == "string" then have[g] = true end
            end
        end
    end
    local add = (ChatFrameUtil and ChatFrameUtil.AddMessageGroup) or _G.ChatFrame_AddMessageGroup
    local added = 0
    for _, g in ipairs(WANTED_GROUPS) do
        if not have[g] and (not ChatTypeGroup or ChatTypeGroup[g]) then
            local ok
            if add then
                ok = pcall(add, main, g)
            elseif main.AddMessageGroup then
                ok = pcall(main.AddMessageGroup, main, g)
            end
            if ok then added = added + 1 end
        end
    end
    -- Joined channels may be disabled in Blizzard's hidden frames. Listen
    -- there so Pigeon's own per-tab channel switches can decide visibility.
    if type(ChatFrame_AddChannel)=="function" then
        for _,channel in ipairs(self:JoinedChannels())do pcall(ChatFrame_AddChannel,main,channel.name)end
    end
    return added
end

-- Game-frames look: the tab bar sits on the frame's narrow title strip, so
-- the tab highlight gets lower and the four controls lose their outlined
-- box (icons only), which would otherwise poke past the strip.
function Chat:SetSlim(on)
    on = on and true or false
    if self.slim == on then return end
    self.slim = on
    local group = self.controls
    if group then
        for _, edge in ipairs(group.border or {}) do edge:SetShown(not on) end
        for _, sep in ipairs(group.seps or {}) do sep:SetShown(not on) end
        for _, btn in ipairs(group.buttons or {}) do
            if btn.bg then btn.bg:SetShown(not on) end
        end
    end
    if self.smf then self:RenderTabs() end
end

-- Highlight and copy: dragging over the chat selects text and Ctrl+C copies
-- it (the game's own text selection for message frames).
-- Settings > General > Behavior "Copy automatically when I release the mouse": use the
-- game's own selection (copies on release, highlight clears) instead of Pigeon's.
function ns.NativeSelectCopy()
    local look = ns.db and ns.db.look
    return look and look.selectAutoCopy and true or false
end

function Chat:CanSelect()
    return self.smf ~= nil and type(self.smf.SetTextCopyable) == "function"
end

-- Selecting is always on: drag over the text, then Ctrl+C.
function Chat:WantSelecting()
    -- Pigeon's own selection (scroll-proof) replaces the game's when the
    -- message frame exposes its lines.
    return ns.NativeSelectCopy() or not (self.smf and type(self.smf.visibleLines) == "table")
end

function Chat:WatchModifier() end -- (selection used to need Ctrl held)

function Chat:SetSelecting(on)
    if not self:CanSelect() then return false end
    on = on and true or false
    local smf = self.smf
    if not pcall(smf.SetTextCopyable, smf, on) then return false end
    if on then smf:EnableMouse(true) end
    self.selecting = on
    return true
end

-- Room below the chat, in UIParent units.
function Chat:SpaceBelow()
    local bottom = self:GetBottom()
    if not bottom then return 999 end
    return bottom * self:GetEffectiveScale() / UIParent:GetEffectiveScale()
end

-- The game colours names in chat by class ("|cffff7c0aName|r" for a druid).
-- Find the newest line with this name and match its colour to a class.
function Chat:ClassFromLine(name)
    local colors = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)
    if not colors or not name then return nil end
    local plain = name:gsub("%-.*$", "")
    local esc = plain:gsub("[%^%$%(%)%.%[%]%*%+%-%?%%]", "%%%0")
    for i = #self.log, math.max(1, #self.log - 300), -1 do
        local t = self.log[i].text
        if type(t) == "string" and ns.Readable(t) and t:find(esc, 1) then
            local hex = t:match("|Hplayer:" .. esc .. "[^|]*|h%[?|c%x%x(%x%x%x%x%x%x)" .. esc)
            if hex then
                hex = hex:lower()
                for classFile, c in pairs(colors) do
                    local ch2 = c.colorStr and c.colorStr:sub(3):lower()
                        or ("%02x%02x%02x"):format(math.floor(c.r * 255 + 0.5), math.floor(c.g * 255 + 0.5), math.floor(c.b * 255 + 0.5))
                    if ch2 == hex then return classFile end
                end
                return nil
            end
        end
    end
end

function Chat:MakeRoomBelow(need)
    local space = self:SpaceBelow()
    if space >= need or space == 999 or ns.ElvUI.UsesMovers() then return end -- ElvUI's mover owns the anchor
    local p, rel, rp, x, y = self:GetPoint()
    if not p then return end
    local lift = (need - space) / (self:GetEffectiveScale() / UIParent:GetEffectiveScale())
    self:ClearAllPoints()
    self:SetPoint(p, rel or UIParent, rp or p, x or 0, (y or 0) + lift)
    self.db.point = { p, rp or p, x or 0, (y or 0) + lift }
end

function Chat:ApplyInputSize()
    local h=math.max(28,math.min(44,tonumber(self.db.inputHeight) or 44))
    local pad=4+(h-28)*6/16
    self.inputH,self.inputPad=h,pad
    -- The 22px resize hit area occupies the corner even in compact mode.
    self.inputRightPad=ns.ElvUI.fitted and pad or 24
    for _,input in pairs({self.eb,self.fakeInput})do
        input:SetHeight(h)
        local field=input.wsField or input.field
        if field then field:SetPoint("BOTTOMRIGHT",-(h+8),0)end
        local chip=input.wsChip or input.chip
        if chip then chip:SetHeight(math.min(34,h-8))end
        local send=input.wsSend or input.send
        if send then send:SetSize(h,h)end
    end
    if self.fakeInput then
        self.fakeInput:SetPoint("BOTTOMLEFT",self,"BOTTOMLEFT",pad+(self.railInset or 0),pad)
        self.fakeInput:SetPoint("BOTTOMRIGHT",self,"BOTTOMRIGHT",-self.inputRightPad,pad)
    end
    if self.emoteBtn then
        local size=math.min(28,h-8)
        self.emoteBtn:SetSize(size,size)
        if self.emoteBtn.controlIcon then self.emoteBtn.controlIcon:SetSize(math.min(22,h-12),math.min(22,h-12))end
    end
end

function Chat:PlaceEditBox()
    local eb = self.eb
    if not eb then return end
    self:ApplyInputSize()
    local h,pad=self.inputH,self.inputPad
    self.placing = true
    eb:ClearAllPoints()
    self.ebInside = false
    local dp = ns.ElvUI.fitted and ns.ElvUI.LeftDataPanel()
    if dp and not self.db.editTop then
        -- Like ElvUI's chat: the input box sits over the datatext bar.
        eb:SetAllPoints(dp)
    elseif self.db.editTop then
        eb:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 0, 4)
        eb:SetPoint("BOTTOMRIGHT", self, "TOPRIGHT", 0, 4)
        eb:SetHeight(h)
    elseif ns.ElvUI.fitted or self.db.editInside then
        -- Chat sits on the screen edge: keep the input box inside the frame,
        -- along its bottom, so what you type never ends up off-screen.
        eb:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", pad+(self.railInset or 0), pad)
        eb:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -self.inputRightPad, pad)
        eb:SetHeight(h)
        self.ebInside = true
    else
        -- "Below chat" is what was picked, so keep it below: if the chat sits
        -- too close to the bottom of the screen, lift the chat just enough.
        self:MakeRoomBelow(h+4)
        eb:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -4)
        eb:SetPoint("TOPRIGHT", self, "BOTTOMRIGHT", 0, -4)
        eb:SetHeight(h)
    end
    -- Keep dragging / clamping from pushing the input off the screen.
    if self.SetClampRectInsets then
        local below = not self.ebInside and not self.db.editTop and not ns.ElvUI.fitted
        local above = self.db.editTop and not ns.ElvUI.fitted
        self:SetClampRectInsets(0, 0, above and (h+4) or 0, below and -(h+4) or 0)
    end
    self.placing = false
    self:SideButtons(self.db.classic and not ns.ElvUI.fitted)
    self:UpdateMessageInset()
end

-- With the input box inside the frame, lift the messages above it while it's
-- showing (the default "IM" chat style only shows it while you type).
-- WRAP_SLACK (20) is defined at the top; see where the message frame is built
function Chat:UpdateMessageInset()
    if not self.smf then return end
    local lift = self.ebInside -- the input bar is always there when it's inside
    self.smf:SetPoint("TOPLEFT", 16 + (self.railInset or 0) + (self.sideInset or 0) + self:StampColumn(), -(self.tabH or 52) - 12)
    self.smf:SetPoint("BOTTOMRIGHT", -(16 + WRAP_SLACK), lift and ((self.inputH or 44)+(self.inputPad or 10)+12) or 14)
    if self.stampLayer then
        self.stampLayer:ClearAllPoints()
        self.stampLayer:SetPoint("TOPLEFT", self.smf, "TOPLEFT", -self:StampColumn(), 0)
        self.stampLayer:SetPoint("BOTTOMRIGHT", self.smf, "BOTTOMRIGHT", 0, 0)
    end
    if self.fakeInput then self.fakeInput:SetShown(self.ebInside and not (self.eb and self.eb:IsShown())) end
    if self.emoteBtn then
        local active = self.eb and self.eb:IsShown()
        local input = not active and self.ebInside and self.fakeInput or self.eb
        if input then
            ns.Emotes.Embed(self.emoteBtn,input.field or input.wsField)
            -- The native edit box can use a higher strata while focused.
            -- Frame levels only order controls within the same strata.
            self.emoteBtn:SetFrameStrata(input:GetFrameStrata())
            self.emoteBtn:SetFrameLevel(input:GetFrameLevel()+5)
        end
        -- In the outside/top layouts, defer hiding until mouse-down has
        -- dispatched the sibling button's click as well.
        if active or self.ebInside then self.emoteBtn:Show()
        else
            C_Timer.After(0,function()
                if not Chat.ebInside and not (Chat.eb and Chat.eb:IsShown()) then Chat.emoteBtn:Hide() end
            end)
        end
    end
end

-- The window keeps its outer size; only its reading/composer area makes room.
-- Starting from the current inset lets arrivals interrupt a closing spring.
function Chat:SetDockRail(open)
    if not self.smf then return end
    local target=open and 64 or 0
    if not self.tileRail then
        local rail=CreateFrame("Frame",nil,self)
        rail:SetPoint("TOPLEFT",6,-self.TAB_H-2)
        rail:SetPoint("BOTTOMLEFT",6,12) rail:SetWidth(56)
        rail:SetClipsChildren(true) rail:EnableMouse(false)
        self.tileRail=rail
        local divider=self:CreateTexture(nil,"ARTWORK")
        divider:SetColorTexture(T.DIVIDER[1],T.DIVIDER[2],T.DIVIDER[3],T.DIVIDER[4])
        divider:SetWidth(1) divider:SetPoint("TOPLEFT",64,-self.TAB_H-10)
        divider:SetPoint("BOTTOMLEFT",64,12)
        self.railDivider=divider
        hooksecurefunc(ns.Dock,"SetAlpha",function(_,alpha)
            rail:SetAlpha(alpha)
            rail:SetShown(alpha>0 and (Chat.railTarget or 0)>0)
        end)
        self:HookScript("OnSizeChanged",function()
            if ns.Dock and ns.Dock.attached=="chat" then ns.Dock:Update()end
        end)
    end
    if self.railTarget==target then return end
    self.railTarget=target
    if open then
        self.tileRail:SetAlpha(ns.Dock:GetAlpha())
        self.tileRail:SetShown(ns.Dock:GetAlpha()>0)
        self.railDivider:Show()
    end
    local function apply(v)
        self.railInset=math.max(0,v)
        self.railDivider:SetAlpha(math.max(0,math.min(1,v/64)))
        if self.fakeInput then
            self.fakeInput:SetPoint("BOTTOMLEFT",self,"BOTTOMLEFT",(self.inputPad or 10)+self.railInset,self.inputPad or 10)
        end
        if self.eb and self.ebInside then
            self.placing=true
            self.eb:SetPoint("BOTTOMLEFT",self,"BOTTOMLEFT",(self.inputPad or 10)+self.railInset,self.inputPad or 10)
            self.placing=false
        end
        self:UpdateMessageInset()
        if self.combatShown then self:PlaceCombatLog()end
    end
    T.Spring(self,"tileRail",self.railInset or 0,target,apply,function()
        apply(target)
        if target==0 then self.tileRail:Hide() self.railDivider:Hide()end
    end)
end

-- A resting input bar inside the chat, shown while the game's input box is
-- closed: the channel you'll talk in, a hint, and a click to start typing.
local TYPE_NAMES = {
    SAY = L["Say"], YELL = L["Yell"], PARTY = L["Party"], RAID = L["Raid"], GUILD = L["Guild"], OFFICER = L["Officer"],
    INSTANCE_CHAT = L["Instance"], WHISPER = L["Whisper"], BN_WHISPER = L["Whisper"], EMOTE = L["Emote"], CHANNEL = L["Channel"],
}
-- What the input box will talk in: label ("Party", "To Mav", "Gen") and colour.
function Chat:ChannelLabel()
    local eb = self.eb
    local kind = eb and eb.GetAttribute and eb:GetAttribute("chatType") or "SAY"
    if not ns.Readable(kind) or type(kind) ~= "string" then kind = "SAY" end
    local name = TYPE_NAMES[kind] or (kind:sub(1, 1) .. kind:sub(2):lower())
    local colorKey = kind
    if kind == "WHISPER" or kind == "BN_WHISPER" then
        local target = eb:GetAttribute("tellTarget")
        if target and ns.Readable(target) and type(target) == "string" and target ~= "" then
            name = L["To %s"]:format((Ambiguate and Ambiguate(target, "short")) or (target:gsub("%-.*$", "")))
        end
    elseif kind == "CHANNEL" then
        local target = tonumber(eb:GetAttribute("channelTarget"))
        if target and GetChannelName then
            local _, chanName = GetChannelName(target)
            if chanName and ns.Readable(chanName) then name = Tag(target .. ". " .. chanName) or chanName end
            colorKey = "CHANNEL" .. target
        end
    end
    local info = ChatTypeInfo and (ChatTypeInfo[colorKey] or ChatTypeInfo[kind]) or {}
    return name, info.r or 1, info.g or 1, info.b or 1, kind
end

local function PaintChipSurface(chip,hot)
    local a=Chat.bgAlphaNow or (Chat.db and Chat.db.bgAlpha) or 1
    T.Shape(chip.bg,chip:GetHeight()/2)
    if Chat.db and Chat.db.classic then T.Color(chip.bg,0,0,0,0) return end -- classic: just the coloured "Say:" label
    if hot then T.Color(chip.bg,.18,.20,.25,a)
    else T.Color(chip.bg,.14,.16,.21,a)end
end

local function PaintChip(chip, name, r, g, b)
    local classic = Chat.db and Chat.db.classic
    chip.text:SetText(classic and (name .. ":") or name)
    if classic then chip.text:SetTextColor(r or 1, g or 1, b or 1)
    else chip.text:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3]) end
    chip.chevron:SetVertexColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
    chip.color = { r, g, b }
    PaintChipSurface(chip,chip:IsMouseOver())
    chip.text:SetWordWrap(false)
    chip.text:SetJustifyH("LEFT")
    local available=math.max(40,math.min(140,Chat:GetWidth()*0.3))
    chip.text:SetWidth(0)
    local textWidth=math.min(available,chip.text:GetStringWidth() or (#name*7))
    chip.text:SetWidth(textWidth)
    chip:SetWidth(textWidth+34)
    if chip.composerWell then
        chip.composerWell:ClearAllPoints()
        chip.composerWell:SetPoint("TOPLEFT",chip.composerField,"TOPLEFT",chip:GetWidth()+13,-1)
        chip.composerWell:SetPoint("BOTTOMRIGHT",chip.composerField,"BOTTOMRIGHT",Chat.emoteBtn and -40 or -1,1)
    end
end

-- Switch channel the way typing does ("/p ", "/g ", "/2 "…), which keeps
-- the game's own chat box in charge of what gets sent.
-- The game puts the box back on its old channel when it closes unsent. Put the
-- channel picked from the menu back (until something is actually sent).
function Chat:ReapplyPick()
    local pick, eb = self.pick, self.eb
    if not (pick and eb and eb.SetAttribute) then return end
    local function apply()
        if not self.pick or self.pick ~= pick then return end
        if eb:GetText() ~= nil and eb:IsShown() and (eb:GetText() or "") ~= "" then return end -- typing: leave it
        if pick.kind == "CHANNEL" and pick.target then
            if eb.SetChannelTarget then pcall(eb.SetChannelTarget, eb, pick.target)
            else eb:SetAttribute("channelTarget", pick.target) end
        end
        if eb.SetChatType then pcall(eb.SetChatType, eb, pick.kind) else eb:SetAttribute("chatType", pick.kind) end
        if eb.SetStickyType then pcall(eb.SetStickyType, eb, pick.kind) else eb:SetAttribute("stickyType", pick.kind) end
        if self.fakeInput then self.fakeInput:Refresh() end
        if self.RestyleInput then self.RestyleInput() end
    end
    if C_Timer and C_Timer.After then
        for _, d in ipairs({ 0, 0.05, 0.25, 0.8 }) do C_Timer.After(d, apply) end
    else apply() end
end

local function OpenChatWith(prefix)
    local open = (ChatFrameUtil and ChatFrameUtil.OpenChat) or ChatFrame_OpenChat
    if open then pcall(open, prefix, DEFAULT_CHAT_FRAME) end
    -- Make the pick stick: the game drops back to the sticky channel when the box
    -- closes without sending, so move the sticky channel too.
    local boxes = { Chat.eb }
    if type(ChatEdit_GetActiveWindow) == 'function' then boxes[#boxes + 1] = ChatEdit_GetActiveWindow() end
    for _, eb in ipairs(boxes) do
        if type(eb) == 'table' and eb.GetAttribute then
            local kind = eb:GetAttribute('chatType')
            if type(kind) == 'string' and ns.Readable(kind) and kind ~= 'WHISPER' and kind ~= 'BN_WHISPER' then
                eb.stickyType = kind
                if eb.SetAttribute then pcall(eb.SetAttribute, eb, 'stickyType', kind) end
                if kind == 'CHANNEL' and eb.SetAttribute then
                    local ct = eb:GetAttribute('channelTarget')
                    if ct then pcall(eb.SetAttribute, eb, 'stickyChannel', ct) end
                end
            end
        end
    end
end

-- The channel menu expands as a rounded card above the chip, with tinted
-- pill rows in each channel's colour) and tuck itself away when the mouse
-- leaves.
local CM
local ROW_H, PAD = 22, 6

local function TypeColor(key)
    local info = ChatTypeInfo and ChatTypeInfo[key]
    if type(info) == "table" then return info.r or 1, info.g or 1, info.b or 1 end
    return 1, 1, 1
end

-- What the menu offers right now. Each entry: title / div / item.
-- The game sends with the edit box's languageID, set by its own
-- SetGameLanguage. Set it on every chat box so whichever one sends uses it.
function Chat.SetLanguage(name, id)
    local boxes, seen = {}, {}
    local function add(b) if type(b) == "table" and not seen[b] then seen[b] = true boxes[#boxes + 1] = b end end
    add(Chat.eb)
    if type(ChatEdit_GetActiveWindow) == "function" then add(ChatEdit_GetActiveWindow()) end
    if type(ChatEdit_GetLastActiveWindow) == "function" then add(ChatEdit_GetLastActiveWindow()) end
    for i = 1, (NUM_CHAT_WINDOWS or 10) do add(_G["ChatFrame" .. i .. "EditBox"]) end
    for _, b in ipairs(boxes) do
        if type(b.SetGameLanguage) == "function" then
            pcall(b.SetGameLanguage, b, name, id)
        else
            b.language, b.languageID = name, id
        end
        if type(b.UpdateHeader) == "function" then pcall(b.UpdateHeader, b) end
    end
    if Chat.RestyleInput then Chat.RestyleInput() end
end

-- " · Orcish" when speaking something other than your default language.
local NO_LANGUAGE = { WHISPER = true, BN_WHISPER = true, EMOTE = true }
function Chat.LanguageTag(box, kind)
    if not box or NO_LANGUAGE[kind or ""] then return "" end
    local lang = box.language
    if type(lang) ~= "string" or lang == "" then return "" end
    local default = type(GetDefaultLanguage) == "function" and GetDefaultLanguage() or nil
    if lang == default then return "" end
    return " · " .. lang
end

local function ChannelEntries(draft)
    local list = {}
    local eb = ns.Chat.eb
    local curKind = eb and eb.GetAttribute and eb:GetAttribute("chatType") or "SAY"
    local curChan = eb and eb.GetAttribute and tonumber(eb:GetAttribute("channelTarget")) or nil
    if not ns.Readable(curKind) then curKind = "SAY" end
    local function Item(label, key, prefix, noDraft)
        local r, g, b = TypeColor(key)
        local chan = tonumber(key:match("^CHANNEL(%d+)$"))
        local current = (chan and curKind == "CHANNEL" and curChan == chan) or (not chan and key == curKind)
        list[#list + 1] = { kind = "item", label = label, r = r, g = g, b = b, current = current,
            fn = function()
                OpenChatWith(prefix .. (noDraft and "" or draft))
                if key == "WHISPER" then Chat.pick = nil
                else Chat.pick = { kind = chan and "CHANNEL" or key, target = chan } end
            end }
    end
    list[#list + 1] = { kind = "title", label = L["Talk in"] }
    Item(L["Say"], "SAY", "/s ")
    Item(L["Yell"], "YELL", "/y ")
    if IsInGroup and IsInGroup() then Item(L["Party"], "PARTY", "/p ") end
    if IsInRaid and IsInRaid() then Item(L["Raid"], "RAID", "/raid ") Item(L["Raid warning"], "RAID_WARNING", "/rw ") end
    if IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then Item(L["Instance"], "INSTANCE_CHAT", "/i ") end
    if IsInGuild and IsInGuild() then
        Item(L["Guild"], "GUILD", "/g ")
        local officer = (C_GuildInfo and C_GuildInfo.IsGuildOfficer and C_GuildInfo.IsGuildOfficer())
            or (CanEditOfficerNote and CanEditOfficerNote())
        if officer then Item(L["Officer"], "OFFICER", "/o ") end
    end
    if GetChannelList then
        local chans = { GetChannelList() }
        local any = false
        for i = 1, #chans, 3 do
            local id, name, disabled = chans[i], chans[i + 1], chans[i + 2]
            if id and name and ns.Readable(name) and not disabled then
                if not any then list[#list + 1] = { kind = "div" } any = true end
                Item(id .. ". " .. name, "CHANNEL" .. id, "/" .. id .. " ")
            end
        end
    end
    list[#list + 1] = { kind = "div" }
    Item(L["Whisper…"], "WHISPER", "/w ", true) -- needs a name first

    -- Language (Orcish, Common, ...): what the default chat menu offered.
    local num = type(GetNumLanguages) == "function" and GetNumLanguages() or 0
    if type(GetLanguageByIndex) == "function" and num > 1 then
        local cur
        if eb and type(eb.GetLanguageID) == "function" then
            local ok, v = pcall(eb.GetLanguageID, eb)
            if ok then cur = v end
        end
        cur = cur or (eb and eb.languageID)
        list[#list + 1] = { kind = "div" }
        list[#list + 1] = { kind = "title", label = L["Language"] }
        for i = 1, num do
            local name, id = GetLanguageByIndex(i)
            if name and id then
                list[#list + 1] = { kind = "item", label = name, r = T.TEXT[1], g = T.TEXT[2], b = T.TEXT[3],
                    current = (cur == id or (cur == nil and i == 1)), keepOpen = false,
                    fn = function()
                        ns.Chat.SetLanguage(name, id)
                        ns.Print(L["speaking %s."]:format(name))
                    end }
            end
        end
    end
    return list
end

local function UIRectOf(f)
    local l, b = f:GetLeft(), f:GetBottom()
    if not (l and b) then return nil end
    local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return { x = l * s, y = b * s, w = f:GetWidth() * s, h = f:GetHeight() * s }
end

local function CloseChannelMenu(instant)
    if not CM or not CM:IsShown() or CM.closing then return end
    local W = ns.Window
    if instant or not (CM.toRect and W and W.ApplyGrow) then
        T.StopTween(CM, "grow")
        if CM.genie then CM.genie:Hide() end
        CM:Hide()
        return
    end
    CM.closing = true
    T.Spring(CM, "grow", CM.growV or 1, 0, function(v) W.ApplyGrow(CM, v) end, function()
        CM.closing = nil
        if CM.genie then CM.genie:Hide() end
        CM:Hide()
    end)
end

local function BuildChannelMenu()
    CM = CreateFrame("Frame", "PigeonChannelMenu", UIParent)
    CM:SetFrameStrata("DIALOG")
    CM:SetToplevel(true)
    CM:EnableMouse(true)
    CM:SetClampedToScreen(true)
    CM:Hide()
    CM:SetScript("OnHide",function() T.StopTween(CM,"grow") end)
    CM.bg = T.ShapeFill(CM, { T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], 0.97 }, 10)
    CM.tint = T.ShapeFill(CM, { 1, 1, 1, 0 }, 10, "BACKGROUND", 1)
    CM.border = T.Border(CM, T.INPUT_BORDER, 1, 10)
    CM.content = CreateFrame("Frame", nil, CM)
    CM.content:SetAllPoints()
    CM.rows, CM.titles, CM.divs = {}, {}, {}
    tinsert(UISpecialFrames, "PigeonChannelMenu") -- Escape closes it
    ns.Chat.channelMenu = CM

    -- Tucks itself away shortly after the mouse leaves (with a moment of
    -- grace to reach it first), and at once on a click elsewhere.
    CM:SetScript("OnUpdate", function(self, elapsed)
        if self.closing then return end
        self.age = (self.age or 0) + elapsed
        local chip = self.chip
        if self:IsMouseOver() or (chip and chip:IsVisible() and chip:IsMouseOver()) then
            self.entered, self.away = true, 0
            return
        end
        self.away = (self.away or 0) + elapsed
        if (self.entered and self.away > 0.4) or (not self.entered and self.age > 2.5) then CloseChannelMenu() end
    end)
    CM:RegisterEvent("GLOBAL_MOUSE_DOWN")
    CM:SetScript("OnEvent", function(self)
        if not self:IsShown() or self:IsMouseOver() then return end
        local chip = self.chip
        if chip and chip:IsVisible() and chip:IsMouseOver() then return end -- the chip's own click toggles
        if (self.age or 0) > 0.15 then CloseChannelMenu() end
    end)
end

local function MenuRow(i)
    local row = CM.rows[i]
    if row then return row end
    row = CreateFrame("Button", nil, CM.content)
    row:SetHeight(ROW_H)
    row.pill = T.ShapeFill(row, { 1, 1, 1, 0 }, ROW_H / 2 - 1)
    row.pill:ClearAllPoints()
    row.pill:SetPoint("TOPLEFT", 0, -1)
    row.pill:SetPoint("BOTTOMRIGHT", 0, 1)
    row.text = ChatText(row, 12, nil, "")
    row.text:SetPoint("LEFT", 10, 0)
    local function Paint(self, hot)
        local e = self.entry
        if not e then return end
        T.Color(self.pill, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], hot and 0.3 or (e.current and 0.24 or 0))
    end
    row.Paint = Paint
    row:SetScript("OnEnter", function(self) Paint(self, true) end)
    row:SetScript("OnLeave", function(self) Paint(self, false) end)
    row:SetScript("OnClick", function(self)
        local e = self.entry
        CloseChannelMenu(true)
        if e and e.fn then e.fn() end
    end)
    CM.rows[i] = row
    return row
end

local function ChannelMenu(chip)
    if not CM then BuildChannelMenu() end
    if CM:IsShown() then CloseChannelMenu() return end -- clicking the chip again closes it
    chip = chip or ns.Chat.fakeInput and ns.Chat.fakeInput.chip
    if not chip then return end

    -- Whatever was already typed is carried over to the channel picked.
    local draft = ""
    local eb = ns.Chat.eb
    if eb and eb:IsShown() then
        local t = eb:GetText()
        if type(t) == "string" and ns.Readable(t) and not t:find("^/") then draft = t end
    end

    -- Lay the rows out.
    local entries = ChannelEntries(draft)
    local y, widest, rows, titles, divs = PAD, 60, 0, 0, 0
    for _, e in ipairs(entries) do
        if e.kind == "item" then
            rows = rows + 1
            local row = MenuRow(rows)
            row.entry = e
            row.text:SetText(e.label)
            row.text:SetTextColor(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3])
            row:Paint(false)
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", PAD, -y)
            row:Show()
            widest = math.max(widest, math.ceil(row.text:GetStringWidth() or (#e.label * 7)) + 20)
            y = y + ROW_H
        elseif e.kind == "title" then
            titles = titles + 1
            local fs = CM.titles[titles]
            if not fs then
                fs = ChatText(CM.content, 9, T.DIM, "")
                CM.titles[titles] = fs
            end
            fs:SetText(e.label:upper())
            fs:ClearAllPoints()
            fs:SetPoint("TOPLEFT", PAD + 10, -(y + 4))
            fs:Show()
            y = y + 18
        else
            divs = divs + 1
            local d = CM.divs[divs]
            if not d then
                d = CM.content:CreateTexture(nil, "ARTWORK")
                d:SetHeight(1)
                CM.divs[divs] = d
            end
            d:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])
            d:ClearAllPoints()
            d:SetPoint("TOPLEFT", PAD + 6, -(y + 4))
            d:SetPoint("TOPRIGHT", -(PAD + 6), -(y + 4))
            d:Show()
            y = y + 9
        end
    end
    for i = rows + 1, #CM.rows do CM.rows[i]:Hide() end
    for i = titles + 1, #CM.titles do CM.titles[i]:Hide() end
    for i = divs + 1, #CM.divs do CM.divs[i]:Hide() end
    for i = 1, rows do CM.rows[i]:SetWidth(widest) end
    CM:SetSize(widest + PAD * 2, y + PAD)

    -- The chooser follows the UI accent independently of channel text colours.
    local r, g, b = T.ACCENT[1], T.ACCENT[2], T.ACCENT[3]
    T.Color(CM.tint, r, g, b, 0.08)
    T.SetBorderColor(CM.border, { r, g, b, 1 }, 0.45)

    -- Sits on the chip: bottom-left corner just above the chip's top-left.
    local from = UIRectOf(chip)
    CM:ClearAllPoints()
    if from then
        CM:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", from.x, from.y + from.h + 4)
    else
        CM:SetPoint("BOTTOMLEFT", ns.Chat, "BOTTOMLEFT", 12, 44)
    end
    CM.chip, CM.age, CM.away, CM.entered, CM.closing = chip, 0, 0, false, nil
    CM:Show()
    CM:Raise()

    CM.toRect = { w = CM:GetWidth(), h = CM:GetHeight() }
    CM:SetClipsChildren(true)
    T.Spring(CM, "grow", 0, 1, function(v) ns.Window.ApplyGrow(CM, v) end)
end

local function NewChip(parent)
    local chip = CreateFrame("Button", nil, parent)
    chip:SetHeight(34)
    chip.bg = T.ShapeFill(chip, { 1, 1, 1, 0.1 }, 17)
    chip.text = ChatText(chip, 13, T.TEXT, "")
    chip.text:SetPoint("LEFT", 9, 0)
    -- Draw the chevron; the previous text glyph is missing in some fonts.
    chip.chevron = {}
    for i=1,2 do
        local line=chip:CreateTexture(nil,"ARTWORK")
        line:SetColorTexture(1,1,1,1) line:SetSize(6,1.5)
        line:SetPoint("RIGHT",i==1 and -12 or -8,0)
        line:SetRotation(i==1 and -math.pi/4 or math.pi/4)
        chip.chevron[i]=line
    end
    function chip.chevron:SetVertexColor(r,g,b)
        for _,line in ipairs(self)do line:SetVertexColor(r,g,b)end
    end
    -- Act on the press, not the release: with nothing typed the game closes
    -- the chat box as soon as the mouse goes down elsewhere, which would
    -- hide this chip before a normal click could finish.
    chip:RegisterForClicks("LeftButtonDown", "RightButtonDown")
    chip:SetScript("OnClick", function(self) ChannelMenu(self) end)
    chip:SetScript("OnEnter", function(self)
        PaintChipSurface(self,true)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(L["Change channel"])
        GameTooltip:Show()
    end)
    chip:SetScript("OnLeave", function(self)
        PaintChipSurface(self,false)
        GameTooltip:Hide()
    end)
    return chip
end

function Chat:BuildInputBar()
    local f = CreateFrame("Button", nil, self)
    f:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 10+(self.railInset or 0), 10)
    f:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -10, 10)
    f:SetHeight(44)
    local field=CreateFrame("Frame",nil,f)
    field:SetPoint("TOPLEFT") field:SetPoint("BOTTOMRIGHT",-52,0)
    field:EnableMouse(false) f.field=field
    -- Regions belong to the containing frame so they cannot cover its controls.
    f.bg=T.ShapeFill(f,T.INPUT_BG,12)
    f.bg:ClearAllPoints() f.bg:SetAllPoints(field)
    f.border=T.Border(field,T.INPUT_BORDER,1,12)
    f.chip = NewChip(f)
    f.chip:SetPoint("LEFT", 5, 0)
    f.textWell=T.ComposerWell(f)
    f.chip.composerWell,f.chip.composerField=f.textWell,field
    f.hint = ChatText(f, 14, T.DIM, "")
    f.hint:SetJustifyH("LEFT") f.hint:SetWordWrap(false)
    f.hint:SetPoint("LEFT", f.chip, "RIGHT", 20, 0)
    f.send = T.SendButton(f, 44)
    f.send:SetPoint("RIGHT", 0, 0)
    f.send:SetScript("OnClick", function() OpenChatWith("") end)
    f.hint:SetPoint("RIGHT", f.send, "LEFT", self.emoteBtn and -48 or -20, 0)
    f:SetScript("OnEnter", function(b) T.SetBorderColor(b.border, Chat:InputBorderColor()) end)
    f:SetScript("OnLeave", function(b) T.SetBorderColor(b.border, Chat:InputBorderColor()) end)
    f:SetScript("OnClick", function()
        local open = (ChatFrameUtil and ChatFrameUtil.OpenChat) or ChatFrame_OpenChat
        if open then pcall(open, "") end
    end)
    function f:Refresh()
        local name, r, g, b, kind = Chat:ChannelLabel()
        PaintChip(self.chip, name, r, g, b)
        self.hint:SetText(L["Message…"])
    end
    f:Refresh()
    f:Hide()
    self.fakeInput = f
    self:ApplyInputSize()
    self:PaintInput()
    if self.eb then
        self.eb:HookScript("OnShow", function() f:Hide() end)
        self.eb:HookScript("OnHide", function()
            Chat:ReapplyPick()
            f:Refresh()
            Chat:UpdateMessageInset()
        end)
    end
    self:UpdateMessageInset()
end

function Chat:AttachEditBox()
    local eb = ChatFrame1EditBox
    if not eb then return end
    self.eb = eb
    -- Sending (Enter) settles the channel, so the menu pick no longer applies.
    eb:HookScript("OnEnterPressed", function() Chat.pick = nil end)
    eb:HookScript("OnShow", function() Chat:ReapplyPick() end)
    if eb.ResetChatTypeToSticky then
        hooksecurefunc(eb, "ResetChatTypeToSticky", function() Chat:ReapplyPick() end)
    end
    eb:SetParent(self)
    for _, region in ipairs({ eb:GetRegions() }) do
        if region:GetObjectType() == "Texture" then region:SetAlpha(0) end
    end
    local field=CreateFrame("Frame",nil,eb)
    field:SetPoint("TOPLEFT") field:SetPoint("BOTTOMRIGHT",-52,0)
    field:EnableMouse(false) eb.wsField=field
    eb.wsBg=T.ShapeFill(eb,T.INPUT_BG,12)
    eb.wsBg:ClearAllPoints() eb.wsBg:SetAllPoints(field)
    eb.wsBorder=T.Border(field,T.INPUT_BORDER,1,12)
    eb:HookScript("OnShow", function() Chat:UpdateMessageInset() end)
    eb:HookScript("OnHide", function() Chat:UpdateMessageInset() end)
    eb:HookScript("OnEditFocusGained", function() T.SetBorderColor(eb.wsBorder, Chat:InputBorderColor()) end)
    eb:HookScript("OnEditFocusLost", function() T.SetBorderColor(eb.wsBorder, Chat:InputBorderColor()) end)
    eb.wsChatText = true
    eb.wsNoScale = true
    T.ApplyFont(eb, 14, "")
    -- Twitch Emotes button at the right end of the input line.
    eb.wsSend = T.SendButton(eb, 44)
    eb.wsSend:SetPoint("RIGHT", 0, 0)
    eb.wsSend:RegisterForClicks("LeftButtonDown")
    eb.wsSend:SetScript("OnClick", function()
        -- A hint where you are looking: the middle of the screen, as the game's own errors are.
        local function Hint(msg)
            if UIErrorsFrame and UIErrorsFrame.AddMessage then UIErrorsFrame:AddMessage(msg, 1, 0.82, 0) else ns.Print(msg) end
        end
        local text = eb:GetText()
        if not ns.Readable(text) or not text or text == "" then eb:SetFocus() return end
        if InCombatLockdown and InCombatLockdown() then eb:SetFocus() Hint(L["Press Enter to send."]) return end
        -- Running the game's Enter handler from here taints it, and the game then
        -- blocks slash commands that use protected functions (/target, /cast...).
        -- Chat and whisper commands are safe; anything else waits for a real Enter.
        local cmd = text:match("^/(%S+)")
        if cmd then
            cmd = cmd:lower()
            local chatCmds = {
                s = 1, say = 1, y = 1, yell = 1, e = 1, em = 1, emote = 1, me = 1, p = 1, party = 1,
                raid = 1, ra = 1, rw = 1, i = 1, instance = 1, bg = 1, g = 1, guild = 1, o = 1, officer = 1,
                w = 1, whisper = 1, t = 1, tell = 1, r = 1, reply = 1, cw = 1, bn = 1,
            }
            if not (chatCmds[cmd] or cmd:match("^%d+$")) then
                eb:SetFocus()
                Hint(L["Press Enter to run commands."])
                return
            end
        end
        local send = eb:GetScript("OnEnterPressed")
        if send then send(eb) end
    end)
    -- Keep the smile independent of the native input's focus/visibility.
    local emote = ns.Emotes.Button(self, 28, nil)
    if emote then
        ns.Emotes.Embed(emote,eb.wsField)
        self.emoteBtn = emote
        if emote.controlIcon then emote.controlIcon:SetSize(22,22)end
    end

    -- Our channel chip replaces the game's "Say:" / "Tell Name:" label.
    eb.wsChip = NewChip(eb)
    eb.wsChip:SetPoint("LEFT", 5, 0)
    eb.wsWell=T.ComposerWell(eb)
    eb.wsChip.composerWell,eb.wsChip.composerField=eb.wsWell,field
    eb.wsHint = ChatText(eb, 14, T.DIM, "")
    eb.wsHint:SetJustifyH("LEFT") eb.wsHint:SetWordWrap(false)
    eb.wsHint:SetPoint("RIGHT",eb.wsSend,"LEFT",emote and -48 or -20,0)
    eb.wsHint:SetPoint("LEFT", eb.wsChip, "RIGHT", 20, 0)
    local insetting = false
    local function Inset(box, l, r, t, b)
        if insetting then return end
        local wantL = box.wsChip and box.wsChip:IsShown() and (box.wsChip:GetWidth() + 24) or l
        local wantR = (Chat.inputH or 44) + (emote and 60 or 20)
        if l == wantL and r == wantR then return end
        insetting = true
        box:SetTextInsets(wantL or 0, wantR or 0, t or 0, b or 0)
        insetting = false
    end
    hooksecurefunc(eb, "SetTextInsets", Inset)
    local function Restyle()
        -- Use ordinary arrow keys to edit the draft, without requiring Alt.
        eb:SetAltArrowKeyMode(false)
        -- Text insets only affect glyph layout. The native edit box otherwise
        -- still owns mouse clicks over the smile/send end of the composer.
        -- Leave that area to the separate controls while keeping one visual bar.
        eb:SetHitRectInsets(0, (Chat.inputH or 44) + (emote and 50 or 8), 0, 0)
        for _, key in ipairs({ "header", "headerSuffix", "languageHeader", "prompt" }) do
            local fs = eb[key]
            if fs and fs.SetAlpha then fs:SetAlpha(0) end
        end
        local name, r, g, b, kind = Chat:ChannelLabel()
        PaintChip(eb.wsChip, name .. Chat.LanguageTag(eb, kind), r, g, b)
        eb.wsHint:SetText(L["Message…"])
        eb.wsHint:SetShown((eb:GetText() or "") == "")
        if eb.GetTextInsets then Inset(eb, eb:GetTextInsets()) end
    end
    self.RestyleInput = Restyle
    if eb.UpdateHeader then hooksecurefunc(eb, "UpdateHeader", Restyle) end
    if type(ChatEdit_UpdateHeader) == "function" then
        hooksecurefunc("ChatEdit_UpdateHeader", function(box) if box == eb then Restyle() end end)
    end
    eb:HookScript("OnShow", Restyle)
    eb:HookScript("OnTextChanged", function() eb.wsHint:SetShown((eb:GetText() or "") == "") end)
    Restyle()
    self:PlaceEditBox()
    -- Blizzard and chat integrations can raise the edit box after OnShow.
    -- Keep the persistent sibling control above the active input as well.
    hooksecurefunc(eb,"SetFrameStrata",function() Chat:UpdateMessageInset() end)
    hooksecurefunc(eb,"SetFrameLevel",function() Chat:UpdateMessageInset() end)
    hooksecurefunc(eb,"Raise",function() Chat:UpdateMessageInset() end)
    eb:HookScript("OnEditFocusGained",function() eb:SetAltArrowKeyMode(false) Chat:UpdateMessageInset() end)
    -- Up/Down recall previously sent lines. Alt-arrow mode is off (so plain
    -- arrows move the cursor), which disables Blizzard's own history keys.
    -- Kept in this character's saved history, so Up/Down recall survives a reload.
    local sent, pos, draft = ns.hist.sent, nil, ""
    if type(sent) ~= "table" then sent = {} end
    for i = #sent, 1, -1 do if type(sent[i]) ~= "string" then table.remove(sent, i) end end
    while #sent > 50 do table.remove(sent, 1) end
    ns.hist.sent = sent
    if eb.AddHistoryLine then
        hooksecurefunc(eb, "AddHistoryLine", function(_, text)
            if type(text) ~= "string" or not ns.Readable(text) or text == "" then return end
            if sent[#sent] ~= text then
                sent[#sent + 1] = text
                if #sent > 50 then table.remove(sent, 1) end
            end
            pos = nil
        end)
    end
    local function ResetPos() pos = nil end
    eb:HookScript("OnEditFocusGained", ResetPos)
    eb:HookScript("OnHide", ResetPos)
    eb:HookScript("OnArrowPressed", function(self, key)
        if (key ~= "UP" and key ~= "DOWN") or IsAltKeyDown() or #sent == 0 then return end
        if key == "UP" then
            if not pos then draft = self:GetText() or "" pos = #sent + 1 end
            if pos > 1 then pos = pos - 1 end
        else
            if not pos then return end
            pos = pos + 1
        end
        local text = sent[pos] or draft
        if pos > #sent then pos = nil end
        self:SetText(text)
        self:SetCursorPosition(#text)
    end)
    -- The default UI re-anchors the box from time to time; put it back.
    hooksecurefunc(eb, "SetPoint", function()
        if not Chat.placing then Chat:PlaceEditBox() end
    end)
end
