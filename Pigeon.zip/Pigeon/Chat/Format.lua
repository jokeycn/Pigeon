--[[
    Pigeon - Chat message formatting: channel tags, timestamps, fonts and the
    per-line Format. Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L
local Chat = ns.Chat

---------------------------------------------------------------------------
-- Formatting
---------------------------------------------------------------------------

-- Short channel tags: [P] party, [G] guild, [T] trade, [Gen] general…
local GROUP_TAGS = {
    party = "P", ["party leader"] = "PL", raid = "R", ["raid leader"] = "RL", ["raid warning"] = "RW",
    guild = "G", officer = "O", instance = "I", ["instance leader"] = "IL",
}
local CHANNEL_TAGS = {
    general = "Gen", trade = "T", localdefense = "LD", ["local defense"] = "LD", lookingforgroup = "LFG",
    ["looking for group"] = "LFG", services = "S", newcomers = "N", ["newcomer chat"] = "N", worlddefense = "WD",
}
local function Tag(inner)
    local lower = inner:lower()
    if GROUP_TAGS[lower] then return GROUP_TAGS[lower] end
    local num, name = inner:match("^(%d+)%.%s*(.-)$")
    if num then
        local base = strtrim((name or ""):gsub("%s*%-.*$", "")):lower()
        return CHANNEL_TAGS[base] or CHANNEL_TAGS[base:gsub("%s", "")] or num
    end
end

-- Channel chips: small rounded images with the tag letters drawn in
-- (Media/Tags), tinted the line's colour, so they read like the mockup's
-- boxes. Widths are the chip's pixel width inside its 128x32 image.
local CHIP_W = {
    P = 27, PL = 40, R = 29, RL = 41, RW = 47, G = 30, O = 30, I = 26, IL = 32, Gen = 53, T = 26,
    LD = 41, LFG = 54, S = 27, N = 29, WD = 47,
    ["1"] = 26, ["2"] = 26, ["3"] = 26, ["4"] = 26, ["5"] = 26, ["6"] = 26, ["7"] = 26, ["8"] = 26, ["9"] = 26, ["10"] = 36,
}
-- The colour a line is drawn in: one you picked for its kind of message (Appearance >
-- Messages > Chat text colours), otherwise the one the game gave it.
function Chat.LineColor(e)
    local map = Chat.db and Chat.db.channelColors
    local c = map and e.cat and map[e.cat]
    if type(c) == "table" and c[1] then return c[1], c[2], c[3] end
    return e.r, e.g, e.b
end

-- How far below the middle of a text line its letters sit, as a share of the font size.
-- The game makes a line exactly as tall as the font size and hangs the letters from its
-- top by the font's full ascent (usWinAscent), so the descenders spill out below and the
-- letters sit low in the line. An inline picture is centred on the line itself, so a chip
-- as tall as the text sat clearly above the words. This is ascent - capHeight/2 - 1/2 per
-- font (from each file's OS/2 table), which puts the chip's middle on the middle of the
-- capital letters. Open Sans Medium was checked against a screenshot of the chat box.
local CHIP_DROP = {
    ["opensans-medium.ttf"] = 0.267, ["opensans-bold.ttf"] = 0.212, ["opensans-extrabold.ttf"] = 0.212,
    ["frizqt__.ttf"] = 0.115, ["frizqt___cyr.ttf"] = 0.064, ["arialn.ttf"] = 0.064, ["arial.ttf"] = 0.047,
    ["expressway.ttf"] = 0.108, ["montserrat-medium.ttf"] = 0.259,
}
local DROP_DEFAULT = 0.12 -- most other fonts land near this
local dropFont, dropK
local function ChipDrop()
    local smf = Chat.smf
    local font = smf and smf.GetFont and smf:GetFont() or T.FONT
    if font ~= dropFont then
        dropFont = font
        local file = type(font) == "string" and font:lower():match("([^\\/]+)$")
        dropK = file and CHIP_DROP[file] or DROP_DEFAULT
    end
    return dropK
end

local function Chip(tag, e)
    local w = CHIP_W[tag]
    if not w or not e then return nil end
    local tab = Chat.db.tabs[Chat.active] or {}
    -- Chip size follows the text size, scaled by Chat > Text > Channel chip size.
    local scale = math.max(0.5, math.min(2, tonumber(Chat.db.chipScale) or 1))
    local base = math.floor((tab.fontSize or Chat.db.fontSize or 14) + 0.5)
    local h = math.max(8, math.floor(base * scale + 0.5))
    local dw = math.floor(h * w / 32 + 0.5)
    -- Centred on the words automatically (see CHIP_DROP); the game centres the picture on the
    -- line at any chip size, so only the text size matters. Positive moves it up.
    -- Chat > Text > Channel chip position fine-tunes from there.
    local yoff = -math.floor(base * ChipDrop() + 0.5) + math.floor((tonumber(Chat.db.chipNudge) or 0) + 0.5)
    -- A picture in chat text cannot be made see-through, so "opacity" dims the chip's tint
    -- toward the dark chat background instead.
    local fade = math.max(0.1, math.min(1, tonumber(Chat.db.chipAlpha) or 1))
    local function b(v) return math.floor(math.max(0, math.min(1, v or 1)) * fade * 255 + 0.5) end
    local er, eg, eb = Chat.LineColor(e)
    local r, g, bl = b(er), b(eg), b(eb)
    local fmt = "|T%sTags\\Tag%s:%d:%d:0:%d:128:32:%d:%d:0:32:%d:%d:%d|t"
    local chip = fmt:format(T.MEDIA, tag, h, dw, yoff, 0, w, r, g, bl)
    if dw <= h then return chip end
    -- The game word-wraps as if an inline picture were as wide as it is tall,
    -- so a wide chip let the line run past the edge. Follow it with an
    -- invisible sliver that is 1px wide but as tall as the missing width:
    -- the game counts it as that wide, and the line wraps in time.
    return chip .. ("|T%sBlank:%d:1|t"):format(T.MEDIA, dw - h)
end
ns.ChannelChip = Chip

local function Shorten(text, e)
    local mode = Chat.db.classic and "off" or Chat.db.shorten -- classic: plain "[1. General - Dalaran]" like the game
    if mode == "off" or not ns.Readable(text) then return text end
    return (text:gsub("|Hchannel:([^|]+)|h%[([^%]]+)%]|h", function(link, inner)
        local short
        if mode == "tag" then
            local tag = Tag(inner)
            local chip = tag and Chip(tag, e)
            if chip then return "|Hchannel:" .. link .. "|h" .. chip .. "|h" end
            short = tag or inner
        elseif mode == "tagtext" then
            short = Tag(inner) or inner
        elseif mode == "number" then
            short = inner:match("^(%d+)")
        else
            short = inner:match("^%d+%.%s*([^%-]+)") or inner
            short = strtrim(short)
        end
        if (mode == "tag" or mode == "tagtext") and not Chat.db.nameBrackets then
            return "|Hchannel:" .. link .. "|h" .. (short or inner) .. "|h"
        end
        return "|Hchannel:" .. link .. "|h[" .. (short or inner) .. "]|h"
    end))
end

-- The game adds its own stamp when Interface > Chat > Timestamps is on
-- (CHAT_TIMESTAMP_FORMAT is set then); ours would double it up.
local function GameStampsOn()
    if type(CHAT_TIMESTAMP_FORMAT) == "string" and CHAT_TIMESTAMP_FORMAT ~= "" then return true end
    -- Newer clients keep the setting only in the showTimestamps CVar.
    local get = (C_CVar and C_CVar.GetCVar) or GetCVar
    local ok, v = pcall(get, "showTimestamps")
    return ok and type(v) == "string" and v ~= "" and v ~= "none"
end
ns.GameStampsOn = GameStampsOn

-- Dim time column with a fixed width: each time is measured in the chat's
-- font and padded with an invisible spacer up to the widest possible time,
-- so the chips and names after it line up on every line.
local measurer, widthCache, colCache = nil, {}, {}

-- "", "OUTLINE" (thin) or "THICKOUTLINE" for the chat message text.
function Chat.OutlineFlags()
    local db = Chat.db
    if not db then return "" end
    if db.classic then return "OUTLINE" end
    if not db.outline then return "" end
    return db.outlineThick and "THICKOUTLINE" or "OUTLINE"
end

local function FontKey()
    local tab = Chat.db.tabs[Chat.active] or {}
    return (tab.fontSize or Chat.db.fontSize or 14), Chat.OutlineFlags()
end
local function Measure(str)
    local size, flags = FontKey()
    local key = size .. flags .. T.FONT .. str
    local w = widthCache[key]
    if w then return w end
    if not measurer then
        -- Shown but invisible: the game doesn't report widths for hidden text.
        measurer = UIParent:CreateFontString(nil, "OVERLAY")
        measurer.wsChatText = true
        measurer.wsNoScale = true -- must match the chat text it measures
        measurer:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", -2000, -2000)
        measurer:SetAlpha(0)
        measurer:SetWordWrap(false)
    end
    T.ApplyFont(measurer, size, flags)
    measurer:SetText(str)
    w = (measurer.GetUnboundedStringWidth and measurer:GetUnboundedStringWidth()) or measurer:GetStringWidth() or 0
    if w <= 0 then w = measurer:GetStringWidth() or 0 end
    if w <= 0 then return #str * size * 0.55 end -- not laid out yet; don't cache
    widthCache[key] = w
    return w
end
local function ColumnWidth(str)
    local size, flags = FontKey()
    local shape = str:gsub("%d", "0")
    local key = size .. flags .. T.FONT .. shape
    local col = colCache[key]
    if col then return col end
    col = 0
    for d = 0, 9 do col = math.max(col, Measure((str:gsub("%d", tostring(d))))) end
    colCache[key] = col
    return col
end
function Chat:ClearStampCache()
    widthCache, colCache = {}, {}
    self.stampColStale = true -- re-measure the time column with the next line
end

-- Split mode (Chat.split): the time isn't part of the message text at all.
-- It's drawn in its own column left of the messages, so a long message
-- wraps under its own start (the channel chip), not under the time.
local function NoteColumn(str)
    local col = math.ceil(ColumnWidth(str))
    if Chat.stampColStale or col > (Chat.stampCol or 0) then
        local changed = col ~= Chat.stampCol
        Chat.stampColStale = nil
        Chat.stampCol = col
        if changed then Chat:UpdateMessageInset() end
    end
end

local function Stamp(str)
    local pad = math.floor(ColumnWidth(str) - Measure(str) + 0.5)
    -- Square, so the game measures it the same width it draws (see Chip).
    -- Never taller than the text either, so it can't stretch the line.
    local spacer = ""
    local tab = Chat.db.tabs[Chat.active] or {}
    local cap = math.max(6, math.floor((tab.fontSize or Chat.db.fontSize or 14) * 0.8))
    while pad > 0 do
        local n = math.min(pad, cap)
        spacer = spacer .. "|T" .. T.MEDIA .. "Blank:" .. n .. ":" .. n .. "|t"
        pad = pad - n
    end
    return "|cff6f7890" .. str .. "|r" .. spacer .. "  "
end

local function StripGameStamp(text)
    if type(text) ~= "string" or not ns.Readable(text) then return text end
    local clock="%[?%d%d?:%d%d[:%d]*%s?[AaPp]?[Mm]?%]?"
    -- A stamp may have its own color, or share a color with the whole line.
    text=text:gsub("^|c%x%x%x%x%x%x%x%x"..clock.."|r%s*", "",1)
    text=text:gsub("^(|c%x%x%x%x%x%x%x%x)"..clock.."%s+", "%1",1)
    return (text:gsub("^"..clock.."%s+", "",1))
end

local function Timestamp(fmt,at)
    local text=date(fmt,at)
    if fmt=="%I:%M"then text=text:gsub("^0","")end
    return text
end

local function Format(e)
    local text = ns.ChatX.Decorate(e, Shorten(StripGameStamp(e.text), e))
    if not ns.Readable(text) then return text end
    -- Names without brackets: [Name] -> Name (links keep working).
    if not Chat.db.nameBrackets and not Chat.db.classic then
        text = text:gsub("(|H[Bb]?[Nn]?player:[^|]*|h)%[(.-)%](|h)", "%1%2%3")
    end
    local fmt = Chat.db.timestamps
    if fmt and fmt ~= "off" and not Chat.db.classic then
        if Chat.split then
            local ok, stamp = pcall(Timestamp, fmt, e.t)
            if ok and type(stamp) == "string" then
                NoteColumn(stamp)
                return text, stamp
            end
            return text
        end
        local ok, line = pcall(function() return Stamp(Timestamp(fmt, e.t)) .. text end)
        if ok then return line end
    end
    return text
end

ns.FontKey, ns.Format, ns.Measure, ns.Tag = FontKey, Format, Measure, Tag
