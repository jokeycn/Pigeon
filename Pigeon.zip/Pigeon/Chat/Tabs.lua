--[[
    Pigeon - Chat tabs: tab buttons, classic tab art, selection, joined channels,
    the add-tab prompt. Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L
local Chat = ns.Chat
local ChatText = ns.ChatText
local CombatName = ns.CombatName
local FontKey, Format = ns.FontKey, ns.Format

---------------------------------------------------------------------------
-- Tabs
---------------------------------------------------------------------------

-- Tabs that are not selected can rest faded (Chat > Text > Inactive tab opacity) and come
-- back while the mouse is over that one tab.
function Chat.UpdateTabAlpha(b, instant)
    local ia = math.max(0.1, math.min(1, tonumber(Chat.db and Chat.db.tabInactiveAlpha) or 1))
    local target = (b.wsActive or b.wsHover or ia >= 1) and 1 or ia
    if instant or not T.Tween then
        if T.StopTween then T.StopTween(b, "tabFade") end
        b.wsTabA = target
        b:SetAlpha(target)
        return
    end
    local from = b.wsTabA or b:GetAlpha() or 1
    if math.abs(from - target) < 0.01 then b.wsTabA = target b:SetAlpha(target) return end
    T.Tween(b, "tabFade", 0.15, from, target, function(v) b.wsTabA = v b:SetAlpha(v) end)
end

local function TabButton(i)
    local b = Chat.tabButtons[i]
    if b then return b end
    b = CreateFrame("Button", nil, Chat.bar)
    b:SetHeight(Chat.TAB_H)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    -- Soft pill behind the active tab; unread count in a small bubble.
    b.pill = CreateFrame("Frame", nil, b)
    b.pill:SetPoint("LEFT", 2, 0)
    b.pill:SetPoint("RIGHT", -2, 0)
    b.pill:SetHeight(Chat.TAB_H - 8)
    b.pillBg = T.ShapeFill(b.pill, { 0, 0, 0, 0 }, (Chat.TAB_H - 8) / 2)
    b.pillBorder = T.Border(b.pill, T.ACCENT, 1, (Chat.TAB_H - 8) / 2)
    b.text = ChatText(b, 14, nil, "")
    b.text:SetPoint("LEFT", 12, 0)
    b.count = ns.MakeBadge(b, 16)
    b.count:SetPoint("LEFT", b.text, "RIGHT", 5, 0)
    -- The pill is a child frame, so it draws over the tab's own text: keep
    -- the label and badge on top of it (the selected pill is solid).
    b.text:SetParent(b.pill)
    b.text:SetDrawLayer("OVERLAY", 7)
    b.count:SetFrameLevel(b.pill:GetFrameLevel() + 2)
    b.line = b.pill -- kept for older code paths
    b:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            ns.Settings:Open("tabs", self.index)
        else
            Chat:SelectTab(self.index)
        end
    end)
    b:SetScript("OnDragStart", function() Chat:StartDrag() end)
    b:SetScript("OnDragStop", function() Chat:StopDrag() end)
    b:SetScript("OnEnter", function(self)
        local tab = Chat.db.tabs[self.index]
        -- Open upward from the tab's own left edge, so tabs near the screen
        -- edge never push it off screen; the width stays sensible.
        GameTooltip:SetOwner(self, "ANCHOR_NONE")
        GameTooltip:ClearAllPoints()
        GameTooltip:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 0, 6)
        GameTooltip:SetMinimumWidth(220)
        GameTooltip:AddLine(tab.name)
        GameTooltip:AddLine(L["Shows %s"]:format(ns.DescribeTab(tab, true)), T.SECTION[1], T.SECTION[2], T.SECTION[3], true)
        GameTooltip:AddLine(L["Right-click: settings  ·  Drag: move"], T.DIM[1], T.DIM[2], T.DIM[3], true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:HookScript("OnEnter", function(self)
        if self.artOn then self.artHover = true Chat:ShowTabArt(self, self.artActive, true) end
        self.wsHover = true
        Chat.UpdateTabAlpha(self)
    end)
    b:HookScript("OnLeave", function(self)
        if self.artOn then self.artHover = nil Chat:ShowTabArt(self, self.artActive, false) end
        self.wsHover = nil
        Chat.UpdateTabAlpha(self)
    end)
    Chat.tabButtons[i] = b
    return b
end

-- short: for tooltips, sums up long lists ("everything except Loot, System"
-- or "Say, Guild, Party and 9 more").
function ns.DescribeTab(tab, short)
    if tab.all then return L["everything"] end
    local parts, missing = {}, {}
    for _, c in ipairs(ns.CHAT_CATEGORIES) do
        if tab.cats and tab.cats[c.key] then parts[#parts + 1] = c.label else missing[#missing + 1] = c.label end
    end
    local chans = {}
    for chan in pairs(tab.channels or {}) do chans[#chans + 1] = L["%s channel"]:format(chan) end
    if #parts == 0 and #chans == 0 then return L["nothing yet"] end
    if short then
        if #missing > 0 and #missing <= 4 and #chans == 0 then
            return L["everything except %s"]:format(table.concat(missing, ", "))
        end
        for _, ch in ipairs(chans) do parts[#parts + 1] = ch end
        if #parts > 5 then
            return table.concat(parts, ", ", 1, 4) .. L[" and %d more"]:format(#parts - 4)
        end
        return table.concat(parts, ", ")
    end
    for _, ch in ipairs(chans) do parts[#parts + 1] = ch end
    return table.concat(parts, ", ")
end

-- Classic chat: copy the LIVE Blizzard tab art (ChatFrame1Tab, read only) in 3
-- slices per state. If any required piece cannot be read, no art is used and the
-- flat classic tabs stay. (Fields on Chat: locals limit.)
function Chat:FindTabPiece(tab, kind, part)
    local found
    pcall(function()
        local prefixes = kind == "bg" and { "" } or (kind == "sel" and { "Active", "Selected" } or { "Highlight" })
        local keyParts = { part }
        if part == "Middle" then keyParts = { "Middle", "Mid" } end
        for _, pre in ipairs(prefixes) do
            for _, kp in ipairs(keyParts) do
                local key = pre .. kp
                local obj = tab[key] or _G["ChatFrame1Tab" .. key]
                if obj and obj.GetObjectType and obj:GetObjectType() == "Texture" then found = obj return end
            end
        end
        for _, r in ipairs({ tab:GetRegions() }) do
            if r.GetObjectType and r:GetObjectType() == "Texture" then
                local n = r.GetName and r:GetName()
                for _, pre in ipairs(prefixes) do
                    for _, kp in ipairs(keyParts) do
                        if n and n == "ChatFrame1Tab" .. pre .. kp then found = r return end
                    end
                end
            end
        end
    end)
    return found
end

function Chat:ReadTexInfo(t)
    local info = {}
    pcall(function()
        local atlas = t.GetAtlas and t:GetAtlas()
        if type(atlas) == "string" and atlas ~= "" then info.atlas = atlas end
        local file = t:GetTexture()
        if file ~= nil and file ~= "" then info.file = file end
        info.coords = { t:GetTexCoord() }
        local w, h = t:GetSize()
        info.w, info.h = w, h
    end)
    if not (info.atlas or info.file) then return nil end
    if not info.atlas and #info.coords ~= 8 then info.coords = nil end
    return info
end

function Chat:ReadTabSpec()
    if self.tabSpec ~= nil then return self.tabSpec or nil end
    local tab = _G.ChatFrame1Tab
    local spec = {}
    local okAll = tab ~= nil
    if tab then
        for _, kind in ipairs({ "bg", "sel", "hl" }) do
            local set = {}
            for _, part in ipairs({ "Left", "Middle", "Right" }) do
                local obj = self:FindTabPiece(tab, kind, part)
                local info = obj and self:ReadTexInfo(obj)
                if info then set[part] = info end
            end
            if set.Left and set.Middle and set.Right then spec[kind] = set
            elseif kind ~= "hl" then okAll = false end
        end
    end
    if not okAll then self.tabSpec = false return nil end
    self.tabSpec = spec
    return spec
end

function Chat:BuildTabArt(b)
    if b.art then return true end
    local spec = self:ReadTabSpec()
    if not spec then return false end
    local art = {}
    local ok, good = pcall(function()
        for kind, set in pairs(spec) do
            local out = {}
            for part, info in pairs(set) do
                local t = b.pill:CreateTexture(nil, kind == "hl" and "ARTWORK" or "BACKGROUND", nil, kind == "sel" and 2 or 1)
                if info.atlas then
                    t:SetAtlas(info.atlas, false)
                else
                    t:SetTexture(info.file)
                    local c = info.coords
                    if c then t:SetTexCoord(c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[8]) end
                end
                if kind == "hl" then t:SetBlendMode("ADD") end
                if info.w and info.h and info.h > 0 then t.artRatio = info.w / info.h end
                t:Hide()
                out[part] = t
            end
            art[kind] = out
        end
        return true
    end)
    if not (ok and good) then
        for _, set in pairs(art) do for _, t in pairs(set) do pcall(t.Hide, t) end end
        return false
    end
    local okf, fill = pcall(function()
        local f = b.pill:CreateTexture(nil, "BACKGROUND", nil, 0)
        f:SetColorTexture(0.2, 0.1, 0.06, 0.9)
        f:Hide()
        return f
    end)
    b.artFill = okf and fill or nil
    b.art = art
    return true
end

-- Lay out and show the art for one tab (state: "bg" or "sel"); hide the other sets.
function Chat:ShowTabArt(b, active, hover)
    local art = b.art
    if not art then return end
    local h = math.min(32, Chat.TAB_H) + (active and 2 or 0)
    for kind, set in pairs(art) do
        local on = (kind == "sel" and active) or (kind == "bg" and not active) or (kind == "hl" and hover)
        for part, t in pairs(set) do
            t:ClearAllPoints()
            if on then
                local ew = t.artRatio and math.max(8, math.min(24, t.artRatio * h)) or 16
                t:SetHeight(h)
                if part == "Left" then
                    t:SetWidth(ew) t:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0)
                elseif part == "Right" then
                    t:SetWidth(ew) t:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
                else
                    local lw = set.Left and set.Left.artRatio and math.max(8, math.min(24, set.Left.artRatio * h)) or 16
                    local rw = set.Right and set.Right.artRatio and math.max(8, math.min(24, set.Right.artRatio * h)) or 16
                    t:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", lw, 0)
                    t:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -rw, 0)
                end
            end
            t:SetShown(on)
        end
    end
    local f = b.artFill
    if f then
        f:ClearAllPoints()
        f:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 3, 1)
        f:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -3, 1)
        f:SetHeight(math.max(1, h - 3))
        if active then f:SetColorTexture(0.42, 0.24, 0.08, hover and 1 or 0.95)
        elseif hover then f:SetColorTexture(0.28, 0.15, 0.09, 0.95)
        else f:SetColorTexture(0.20, 0.10, 0.06, 0.90) end
        f:Show()
    end
end

function Chat:HideTabArt(b)
    if not b.art then return end
    if b.artFill then b.artFill:Hide() end
    for _, set in pairs(b.art) do for _, t in pairs(set) do t:Hide() end end
end

function Chat:DebugTabs()
    local tab = _G.ChatFrame1Tab
    if not tab then ns.Print("tabdebug: ChatFrame1Tab not found") return end
    for _, r in ipairs({ tab:GetRegions() }) do
        local ot = r.GetObjectType and r:GetObjectType()
        if ot == "Texture" then
            local key
            for k, v in pairs(tab) do if v == r and type(k) == "string" then key = k break end end
            local atlas = r.GetAtlas and r:GetAtlas()
            local w, h = r:GetSize()
            ns.Print(("tab region %s key=%s atlas=%s file=%s coord=%s size=%sx%s"):format(
                tostring(r.GetName and r:GetName()), tostring(key), tostring(atlas), tostring(r:GetTexture()),
                table.concat({ r:GetTexCoord() }, ","), tostring(w), tostring(h)))
        end
    end
    self.tabSpec = nil
    local spec = self:ReadTabSpec()
    ns.Print("tab art: " .. (spec and "using live Blizzard art" or "unreadable, flat fallback"))
    if spec then
        for kind, set in pairs(spec) do
            for part, info in pairs(set) do
                ns.Print(("  %s %s from %s"):format(kind, part, info.atlas and ("atlas " .. info.atlas) or ("file " .. tostring(info.file))))
            end
        end
    end
end

function Chat:RenderTabs()
    local x = 10 + (self.db.attachDock and Chat.TAB_H + (self.stackInset or 0) + 2 or 0) -- leave the corner for the stack button
    for i, tab in ipairs(self.db.tabs) do
        local b = TabButton(i)
        b.index = i
        local active = i == self.active
        b.wsActive = active
        Chat.UpdateTabAlpha(b, true)
        b.text:SetText(tab.name)
        if self.alerted[i] and not active then
            local s = ns.Social.STAR -- a keyword came up in this tab
            b.text:SetTextColor(s[1], s[2], s[3])
        elseif active and ns.db.look and (ns.db.look.preset == "softsignal" or ns.db.look.preset == "island") then
            b.text:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
        elseif active then
            -- Solid accent pill (like the hub's filter): dark text on a light accent.
            local a = T.ACCENT
            if (0.299 * a[1] + 0.587 * a[2] + 0.114 * a[3]) > 0.6 then
                b.text:SetTextColor(0.06, 0.06, 0.08)
            else
                b.text:SetTextColor(1, 1, 1)
            end
        else
            b.text:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
        end
        -- Game-frames look: a low, squarer highlight that fits inside the
        -- frame's title strip instead of poking past its borders.
        local slim = self.slim and true or false
        local classic = self.db.classic and true or false
        if (b.wsClassic or false) ~= classic then
            -- Classic chat: plain rectangular tabs instead of rounded pills.
            b.wsClassic = classic
            T.Flatten(b.pillBg, classic)
            T.FlattenBorder(b.pillBorder, classic)
            b.wsTabHeight = nil -- redo the pill sizing below
        end
        b:SetHeight(Chat.TAB_H)
        T.StyleText(b.text,tonumber(self.db.tabFontSize) or math.max(12,math.min(18,14*Chat.TAB_H/52)),classic and "OUTLINE" or "")
        b.count:SetScale(math.max(.875,math.min(1.25,Chat.TAB_H/52)))
        if b.wsSlim ~= slim or b.wsTabHeight ~= Chat.TAB_H then
            b.wsSlim = slim
            b.wsTabHeight = Chat.TAB_H
            local h = slim and 16 or math.max(20, Chat.TAB_H - 18)
            b.pill:SetHeight(h)
            T.Shape(b.pillBg, slim and 4 or 8)
            if b.pillBorder[1] and b.pillBorder[1].wsShaped then T.Shape(b.pillBorder[1], slim and 4 or h / 2, true) end
        end
        local soft = ns.db.look and (ns.db.look.preset == "softsignal" or ns.db.look.preset == "island")
        local tabBg = math.max(0, math.min(1, tonumber(self.db.tabBgAlpha) or 1))
        if soft then T.Color(b.pillBg, T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],active and 0.42 * tabBg or 0)
        else T.Color(b.pillBg, T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],active and 0.9 * tabBg or 0) end
        T.SetBorderColor(b.pillBorder, T.ACCENT, 0)
        if classic then
            -- Stock look: dark tab, brighter when selected; yellow label for the
            -- selected one, grey for the others (keyword alerts keep their colour).
            if not (self.alerted[i] and not active) then
                if active then b.text:SetTextColor(1, 0.82, 0) else b.text:SetTextColor(0.62, 0.62, 0.62) end
            end
            if active then
                T.Color(b.pillBg, 0.22, 0.2, 0.16, 0.9)
                T.SetBorderColor(b.pillBorder, { 0.72, 0.64, 0.42 }, 0.95)
            else
                T.Color(b.pillBg, 0, 0, 0, 0.55)
                T.SetBorderColor(b.pillBorder, { 0.3, 0.3, 0.3 }, 0.8)
            end
            -- Stock tab art on top of that (falls back to the flat tabs above).
            if not self.tabArtBad and not b.art and not self:BuildTabArt(b) then self.tabArtBad = true end
            if not self.tabArtBad and b.art then
                if not (self.alerted[i] and not active) then
                    if active then b.text:SetTextColor(1, 0.82, 0) else b.text:SetTextColor(0.75, 0.62, 0.2) end
                end
                T.Color(b.pillBg, 0, 0, 0, 0)
                T.SetBorderColor(b.pillBorder, T.ACCENT, 0)
                b.pillBg:Hide() -- no flat shape behind the art
                for _, bt in ipairs(b.pillBorder) do bt:Hide() end
                b.artHid = true
                b.artOn, b.artActive = true, active
                self:ShowTabArt(b, active, b.artHover and true or false)
            end
        end
        if not (classic and b.art and not self.tabArtBad) then
            if b.artOn then b.artOn, b.artHover = nil, nil self:HideTabArt(b) end
        end
        if b.artHid and not b.artOn then
            b.artHid = nil
            b.pillBg:Show()
            for _, bt in ipairs(b.pillBorder) do bt:Show() end
        end
        local n = self.unread[i] or 0
        if n > 0 then
            b.count:SetCount(n)
            b.count:Show()
        else
            b.count:Hide()
        end
        b.text:SetWidth(0)
        b.wsTextW = (b.text.GetUnboundedStringWidth and b.text:GetUnboundedStringWidth()) or b.text:GetStringWidth()
        b.wsFixed = 24 + (n > 0 and (b.count:GetWidth() * (b.count:GetScale() or 1) + 5) or 0)
    end
    for i = #self.db.tabs + 1, #self.tabButtons do self.tabButtons[i]:Hide() end
    self:LayoutTabs(x)
end

-- Tabs share the room between the stack button and the controls on the
-- right: long names shorten first ("Combat L…"); if they still don't fit, the
-- strip scrolls (mouse wheel over the tabs) with arrows at the cut edges.
local MIN_TEXT = 56 -- shorten names to about "Combat L…" before scrolling
function Chat:LayoutTabs(x0)
    local n = #self.db.tabs
    local bar, controls = self.bar, self.controls
    local avail = math.huge
    local bl, cl = bar and bar:GetLeft(), controls and controls:GetLeft()
    if bl and cl then avail = cl - bl - x0 - 4 end
    if self.toolbarReady then
        local w = bar:GetWidth()
        if not w or w <= 0 then w = self:GetWidth() end
        avail = math.max(0, w - x0 - 16 - (self.controlExtent or 0) - (self.toolbarInset or 36))
    end
    local function total(cap)
        local t = 0
        for i = 1, n do
            local b = self.tabButtons[i]
            t = t + math.ceil(b.wsFixed + math.min(b.wsTextW, cap))
        end
        return t
    end
    local cap = math.huge
    if total(cap) > avail then
        local lo, hi = MIN_TEXT, 0
        for i = 1, n do hi = math.max(hi, self.tabButtons[i].wsTextW) end
        for _ = 1, 20 do -- biggest name width that still fits
            local mid = (lo + hi) / 2
            if total(mid) > avail then hi = mid else lo = mid end
        end
        cap = math.floor(lo)
    end
    local widths, sum = {}, 0
    for i = 1, n do
        local b = self.tabButtons[i]
        local tw = math.min(b.wsTextW, cap)
        b.text:SetWidth(tw < b.wsTextW and tw or 0)
        if b.text.SetWordWrap then b.text:SetWordWrap(false) end
        -- Whole pixels: a fractional width puts the highlight's right edge
        -- between pixels, where its 1px border line can vanish.
        widths[i] = math.ceil(b.wsFixed + tw)
        sum = sum + widths[i]
    end
    -- Still too wide: scroll, keeping the selected tab in view.
    local first = 1
    if sum > avail then
        first = math.max(1, math.min(self.tabScroll or 1, n))
        local function fits(from, to)
            local t = 0
            for i = from, to do t = t + widths[i] end
            return t <= avail - 24
        end
        if not self.tabScrollManual then
            local a = self.active or 1
            if a < first then first = a end
            while first < a and not fits(first, a) do first = first + 1 end
        end
        while first > 1 and fits(first - 1, n) do first = first - 1 end -- no empty space at the end
    end
    self.tabScroll = first
    local x, last = x0 + (first > 1 and 12 or 0), first - 1
    for i = 1, n do
        local b = self.tabButtons[i]
        if i < first or (sum > avail and x + widths[i] > x0 + avail - (i < n and 12 or 0)) then
            b:Hide()
        else
            b:SetWidth(widths[i])
            b:ClearAllPoints()
            b:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", x, 0)
            b:Show()
            x = x + widths[i]
            if i == last + 1 then last = i end
        end
    end
    self:TabArrows(first > 1, last < n, x0, x)
end

function Chat:TabArrows(left, right, x0, x)
    local bar = self.bar
    if not bar then return end
    if not self.tabArrowL then
        for _, side in ipairs({ "L", "R" }) do
            local a = CreateFrame("Button", nil, bar)
            a:SetSize(14, Chat.TAB_H)
            a:SetFrameLevel(bar:GetFrameLevel() + 6)
            a.text = ChatText(a, 14, T.SECTION)
            a.text:SetPoint("CENTER")
            a.text:SetText(side == "L" and "‹" or "›")
            a:SetScript("OnEnter", function() a.text:SetTextColor(1, 1, 1) end)
            a:SetScript("OnLeave", function() a.text:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3]) end)
            local step = side == "L" and -1 or 1
            a:SetScript("OnClick", function()
                Chat.tabScroll = math.max(1, (Chat.tabScroll or 1) + step)
                Chat.tabScrollManual = true
                Chat:RenderTabs()
            end)
            self["tabArrow" .. side] = a
        end
        bar:EnableMouseWheel(true)
        bar:SetScript("OnMouseWheel", function(_, delta)
            Chat.tabScroll = math.max(1, (Chat.tabScroll or 1) - delta)
            Chat.tabScrollManual = true
            Chat:RenderTabs()
        end)
        bar:HookScript("OnSizeChanged", function() Chat:RenderTabs() end)
    end
    self.tabArrowL:ClearAllPoints()
    self.tabArrowL:SetPoint("LEFT", bar, "LEFT", x0 - 2, 0)
    self.tabArrowL:SetShown(left)
    self.tabArrowR:ClearAllPoints()
    self.tabArrowR:SetPoint("LEFT", bar, "LEFT", x - 1, 0)
    self.tabArrowR:SetShown(right)
end

function Chat:Rerender()
    local tab = self.db.tabs[self.active]
    self.smf:Clear()
    wipe(self.stampOf)
    wipe(self.view)
    self.viewVer = self.viewVer + 1
    if self.ClearSelection then self.ClearSelection() end
    if not tab or ns.IsCombatTab(tab) then return end
    for _, e in ipairs(self.log) do
        if ns.TabMatches(tab, e) then self:AddLine(e) end
    end
    self.smf:ScrollToBottom()
    self.jump:Hide()
end

-- One log entry into the message frame (remembering its time for the
-- separate time column).
Chat.stampOf = {}
-- An animated emote's picture changes every frame, so a line's text is only the same line once the
-- emote pictures are cut back to their file names. Times are stored under that form too.
local function EmoteKey(text)
    return (text:gsub("|T(Interface\\AddOns\\TwitchEmotes\\Emotes\\[^|:]+%.tga)[^|]*|t", "|T%1|t"))
end
Chat.view, Chat.viewVer, Chat.seqNext = {}, 0, 0 -- the active tab's messages, numbered, for selecting
function Chat:AddLine(e)
    local text, stamp = Format(e)
    self.smf:AddMessage(text, Chat.LineColor(e))
    local view = self.view
    self.seqNext = self.seqNext + 1
    local readable = type(text) == "string" and ns.Readable(text)
    view[#view + 1] = { seq = self.seqNext, raw = readable and text or nil, stamp = readable and stamp or nil }
    while #view > Chat.MAX_LOG do table.remove(view, 1) end
    self.viewVer = self.viewVer + 1
    if stamp and type(text) == "string" and ns.Readable(text) then
        self.stampOf[text] = stamp
        if text:find("TwitchEmotes", 1, true) then self.stampOf[EmoteKey(text)] = stamp end
    end
end

-- Width of the time column in split mode (0 = no column).
function Chat:StampColumn()
    if not self.split or self.db.classic then return 0 end
    local fmt = self.db.timestamps
    if not (fmt and fmt ~= "off") then return 0 end
    local col = self.stampCol or 0
    return col > 0 and (col + 8) or 0
end

-- How tall a message's first wrapped line is. The game centres a line's words on any inline
-- picture taller than the text, so a big emote pushes its words down to the middle of that
-- line: the time has to sit on that middle, not on the line's top or bottom edge.
-- Only asked for lines holding Twitch Emotes pictures. msg is the line as it was added, key its
-- EmoteKey (the same whatever animation frame is showing).
local lineMeasurer
local firstLineCache, firstLineCount = {}, 0
local function FirstLineHeight(fs, msg, key)
    local okH, h = pcall(fs.GetStringHeight, fs)
    if not okH or type(h) ~= "number" or h <= 0 then return nil end
    local okN, n = pcall(fs.GetNumLines, fs)
    if okN and n == 1 then return h end -- one line: the whole string is that line
    local okF, font, size, flags = pcall(fs.GetFont, fs)
    local w = fs:GetWidth()
    if not (okF and font and size and w and w > 0) then return nil end
    local ck = key .. "\001" .. math.floor(w + 0.5) .. "\001" .. font .. size .. tostring(flags)
    local hit = firstLineCache[ck]
    if hit then return hit end
    if not lineMeasurer then
        -- Shown but invisible: the game doesn't lay out hidden text.
        lineMeasurer = UIParent:CreateFontString(nil, "OVERLAY")
        lineMeasurer:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", -4000, -4000)
        lineMeasurer:SetAlpha(0)
        lineMeasurer:SetJustifyH("LEFT")
        lineMeasurer:SetWordWrap(true)
    end
    lineMeasurer:SetFont(font, size, flags or "")
    if lineMeasurer.SetSpacing and fs.GetSpacing then lineMeasurer:SetSpacing(fs:GetSpacing() or 0) end
    if lineMeasurer.SetNonSpaceWrap and fs.CanNonSpaceWrap then lineMeasurer:SetNonSpaceWrap(fs:CanNonSpaceWrap() and true or false) end
    lineMeasurer:SetWidth(w)
    lineMeasurer:SetText("X")
    local first = lineMeasurer:GetStringHeight() or 0
    -- Grow the text one inline picture at a time while it still fits on one line; the tallest
    -- picture on that line sets its height.
    local pos = 1
    while true do
        local _, e = msg:find("|T.-|t", pos)
        if not e then break end
        lineMeasurer:SetText(msg:sub(1, e))
        if (lineMeasurer:GetNumLines() or 1) > 1 then break end
        first = math.max(first, lineMeasurer:GetStringHeight() or 0)
        pos = e + 1
    end
    lineMeasurer:SetText("")
    if first <= 0 then return nil end
    if firstLineCount > 300 then wipe(firstLineCache); firstLineCount = 0 end
    firstLineCache[ck] = first
    firstLineCount = firstLineCount + 1
    return first
end

-- Draw each visible message's time beside its first line.
local stampMisses = 0
function Chat:LayoutStamps()
    local layer, smf = self.stampLayer, self.smf
    if not (layer and smf and self.split) then return end
    local col = self:StampColumn()
    local lines = smf.visibleLines
    local used, seen, withInfo, readable = 0, 0, 0, 0
    if col > 0 and type(lines) == "table" then
        local size, flags = FontKey()
        for _, fs in ipairs(lines) do
            if type(fs) == "table" and fs.IsShown and fs:IsShown() then
                seen = seen + 1
                local info = fs.messageInfo
                local msg = type(info) == "table" and info.message or nil
                -- No record of the message on the line: its text is the same thing.
                if msg == nil and type(fs.GetText) == "function" then
                    local okT, shown = pcall(fs.GetText, fs)
                    if okT and shown ~= nil and shown ~= "" then msg = shown end
                end
                if msg ~= nil then withInfo = withInfo + 1 end
                if msg ~= nil and ns.Readable(msg) then readable = readable + 1 end
                local emote = msg and ns.Readable(msg) and msg:find("TwitchEmotes", 1, true)
                local key = emote and EmoteKey(msg)
                local stamp = msg and ns.Readable(msg) and (self.stampOf[msg] or (key and self.stampOf[key]))
                if stamp then
                    used = used + 1
                    local l = layer.labels[used]
                    if not l then
                        l = layer:CreateFontString(nil, "OVERLAY")
                        l.wsChatText = true
                        l.wsNoScale = true
                        l:SetJustifyH("LEFT")
                        l:SetWordWrap(false)
                        l:SetTextColor(0.435, 0.47, 0.565)
                        layer.labels[used] = l
                    end
                    if l.wsSize ~= size or l.wsFlags ~= flags or l.wsFont ~= T.FONT then
                        T.ApplyFont(l, size, flags)
                        l:SetShadowColor(0, 0, 0, 0)
                        l:SetShadowOffset(1, -1)
                        l.wsSize, l.wsFlags, l.wsFont = size, flags, T.FONT
                    end
                    l:SetText(stamp)
                    l:ClearAllPoints()
                    -- Level with the first line's words. A line holding an emote picture taller
                    -- than the text has its words centred on that picture, so the time is
                    -- centred on the first line's height there; other lines keep the top edge.
                    local first = key and FirstLineHeight(fs, msg, key)
                    if first then
                        l:SetPoint("LEFT", fs, "TOPLEFT", -col, -first / 2)
                    else
                        l:SetPoint("TOPLEFT", fs, "TOPLEFT", -col, 0)
                    end
                    l:SetAlpha(fs:GetAlpha() or 1)
                    l:Show()
                end
            end
        end
    end
    for i = used + 1, #layer.labels do layer.labels[i]:Hide() end
    layer:SetAlpha(smf:GetAlpha() or 1)
    -- This client's message frame doesn't tell us which message a line
    -- holds: go back to times inside the text.
    -- (Either the lines carry no message at all, or none of them matches a
    -- line we stamped for a couple of seconds running.)
    -- Only lines we can read count: a screen of lines with no time of their
    -- own must not be mistaken for a broken column.
    local lost = seen > 0 and col > 0 and (withInfo == 0 or (readable >= 3 and used == 0 and next(self.stampOf) ~= nil))
    if lost then
        stampMisses = stampMisses + 1
        if stampMisses > (withInfo == 0 and 20 or 200) then
            self.split = false
            layer:Hide()
            if smf.SetIndentedWordWrap then smf:SetIndentedWordWrap(true) end
            self:UpdateMessageInset()
            self:Rerender()
        end
    else
        stampMisses = 0
    end
end

function Chat:SelectTab(i)
    if not self.db.tabs[i] then i = 1 end
    self.active = i
    self.unread[i] = 0
    self.alerted[i] = nil
    self.tabScrollManual = nil
    self:ShowCombatLog(ns.IsCombatTab(self.db.tabs[i]))
    self:ApplyTabStyle()
    self:RenderTabs()
    self:Rerender()
    T.Tween(self.smf, "swap", 0.16, 0.2, 1, function(v) self.smf:SetAlpha(v) end)
end

function Chat:AddTab(name)
    name = strtrim(name or "")
    if name == "" then return end
    local cats, channels, summary = ns.SmartFilter(name)
    local tab = { name = name, all = (cats == nil and channels == nil) or nil, cats = cats, channels = channels }
    if CombatName(name) then tab.combat, tab.all = true, nil end
    table.insert(self.db.tabs, tab)
    self:SelectTab(#self.db.tabs)
    self:RefreshTabSettings(#self.db.tabs)
    ns.Print(L["new tab |cffe6ebf5%s|r shows %s. Right-click the tab to change it."]:format(name, summary))
end

-- Explicit channel tabs do not depend on the join event arriving synchronously.
local function ChannelKey(name)
    return strtrim(name):lower():gsub("%s+%-%s+.*$", "")
end
function Chat:JoinedChannels()
    local out={}
    if not GetChannelList then return out end
    local entries={GetChannelList()}
    for i=1,#entries,3 do
        local name=entries[i+1]
        if type(name)=="string" and ns.Readable(name) then
            out[#out+1]={id=entries[i],name=name,key=ChannelKey(name)}
        end
    end
    return out
end
function Chat:JoinTabChannel(name)
    if type(name)~="string" or not ns.Readable(name) then return end
    name=strtrim(name) if name=="" then return end
    local key=ChannelKey(name)
    local joined=false
    for _,entry in ipairs(self:JoinedChannels())do if entry.key==key then joined=true break end end
    if not joined then
        local join=JoinChannelByName or (C_ChatInfo and C_ChatInfo.JoinChannelByName)
        if type(join)~="function" then ns.Print(L["Channel joining is unavailable on this client."])return end
        local ok=pcall(join,name)
        if not ok then ns.Print(L["Couldn't join that channel. Check its name and try again."])return end
    end
    if type(ChatFrame_AddChannel)=="function" then pcall(ChatFrame_AddChannel,DEFAULT_CHAT_FRAME,name)end
    for i,tab in ipairs(self.db.tabs)do
        if not ns.IsCombatTab(tab) and not tab.all and tab.channels and tab.channels[key]then
            self:SelectTab(i) self:RefreshTabSettings(i)return i
        end
    end
    table.insert(self.db.tabs,{name=name,cats={},channels={[key]=true}})
    local index=#self.db.tabs
    self:SelectTab(index) self:RefreshTabSettings(index)
    return index
end

-- Keep an open settings page's tab list in step with the chat box.
function Chat:RefreshTabSettings(select)
    local S = ns.Settings
    local page = type(S) == "table" and type(S.pages) == "table" and S.pages.tabs
    if type(page) ~= "table" or type(page.Render) ~= "function" then return end
    if select then page.selected = select end
    if (page.selected or 1) > #self.db.tabs then page.selected = #self.db.tabs end
    pcall(page.Render, page)
end

function Chat:RemoveTab(i)
    if #self.db.tabs <= 1 then return end
    table.remove(self.db.tabs, i)
    self.unread = {}
    self.alerted = {}
    self:SelectTab(math.min(self.active, #self.db.tabs))
    self:RefreshTabSettings()
end

StaticPopupDialogs.PIGEON_NEW_TAB = {
    text = L["Name the new chat tab.\nNames like Guild, Trade, Party, Raid, Loot or Whispers filter themselves."],
    button1 = ACCEPT or "Create",
    button2 = CANCEL or "Cancel",
    hasEditBox = true,
    maxLetters = 24,
    OnAccept = function(self)
        local eb = (self.GetEditBox and self:GetEditBox()) or self.editBox or self.EditBox
        Chat:AddTab(eb and eb:GetText())
    end,
    EditBoxOnEnterPressed = function(self)
        Chat:AddTab(self:GetText())
        self:GetParent():Hide()
    end,
    EditBoxOnEscapePressed = function(self) self:GetParent():Hide() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}
