--[[
    Pigeon - voice chat panel: a small card opened from the speaker button in the chat
    controls. Mute, deafen, push-to-talk or open mic, and who is talking in your voice
    channel. Anything beyond that opens the game's own Channels window.

    Everything here reads the game's C_VoiceChat API defensively: a client without it
    (or with voice chat switched off) just gets the link to the game's window. Names and
    channel details can be unreadable ("secret") at times, so they are checked first.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local V = {}
ns.Voice = V

local MAX_ROWS = 8
local WIDTH = 250
local speaking = {} -- memberID -> true while that member is talking

local function Api() return C_VoiceChat end

local function Call(name, ...)
    local api = Api()
    local fn = api and api[name]
    if type(fn) ~= "function" then return nil end
    local ok, a, b = pcall(fn, ...)
    if ok then return a, b end
end

local function OpenMicValue()
    return (Enum and Enum.CommunicationMode and Enum.CommunicationMode.OpenMic) or 1
end

-- The game's own Channels and voice window.
function V.OpenGameWindow()
    local button = _G.ChatFrameChannelButton
    if button and button.Click then
        button:Click()
    elseif _G.ToggleChannelFrame then
        _G.ToggleChannelFrame()
    elseif _G.ChannelFrame and _G.ChannelFrame.Toggle then
        _G.ChannelFrame:Toggle()
    end
end

-- Current state, gathered once per refresh.
local function State()
    local s = { api = Api() ~= nil, members = {} }
    if not s.api then return s end
    s.enabled = Call("IsEnabled") ~= false
    s.muted = Call("IsMuted") and true or false
    s.deafened = Call("IsDeafened") and true or false
    s.openMic = Call("GetCommunicationMode") == OpenMicValue()
    local id = Call("GetActiveChannelID")
    if id then
        s.channelID = id
        local channel = Call("GetChannel", id)
        if type(channel) == "table" then
            if type(channel.name) == "string" and ns.Readable(channel.name) and channel.name ~= "" then s.channel = channel.name end
            if type(channel.members) == "table" then
                for _, m in ipairs(channel.members) do
                    local memberID = type(m) == "table" and m.memberID or m
                    if memberID ~= nil then
                        local name = Call("GetMemberName", memberID, id)
                        if type(name) ~= "string" or not ns.Readable(name) or name == "" then name = L["Someone"] end
                        s.members[#s.members + 1] = { id = memberID, name = name }
                    end
                end
            end
        end
    end
    return s
end

---------------------------------------------------------------------------
-- The card
---------------------------------------------------------------------------

local panel

local function SetOn(button, on, onText, offText)
    button.label:SetText(on and onText or offText)
    local c = on and T.ACCENT or T.LABEL
    button.label:SetTextColor(c[1], c[2], c[3], 1)
end

local function Row(i)
    local row = panel.rows[i]
    if row then return row end
    row = CreateFrame("Frame", nil, panel)
    row:SetSize(WIDTH - 24, 18)
    row.dot = row:CreateTexture(nil, "OVERLAY")
    row.dot:SetSize(8, 8)
    row.dot:SetPoint("LEFT", 2, 0)
    row.dot:SetColorTexture(1, 1, 1, 1)
    if T.Circle then T.Circle(row.dot) end
    row.name = T.Text(row, 12, T.TEXT)
    row.name:SetPoint("LEFT", 16, 0)
    row.name:SetPoint("RIGHT", 0, 0)
    row.name:SetJustifyH("LEFT")
    row.name:SetWordWrap(false)
    panel.rows[i] = row
    return row
end

function V.Refresh()
    if not panel or not panel:IsShown() then return end
    local s = State()
    local y = 10

    panel.title:ClearAllPoints()
    panel.title:SetPoint("TOPLEFT", 12, -y)
    y = y + 20

    if not s.api then
        panel.status:SetText(L["Voice chat is not available here."])
    elseif not s.enabled then
        panel.status:SetText(L["Voice chat is turned off in the game's settings."])
    elseif s.channelID then
        panel.status:SetText(s.channel or L["In a voice channel"])
    else
        panel.status:SetText(L["Not in a voice channel"])
    end
    panel.status:ClearAllPoints()
    panel.status:SetPoint("TOPLEFT", 12, -y)
    panel.status:SetPoint("TOPRIGHT", -12, -y)
    y = y + 22

    local controls = s.api and s.enabled
    panel.mute:SetShown(controls)
    panel.deafen:SetShown(controls)
    panel.mode:SetShown(controls)
    if controls then
        SetOn(panel.mute, s.muted, L["Muted"], L["Mute"])
        SetOn(panel.deafen, s.deafened, L["Deafened"], L["Deafen"])
        panel.mode.label:SetText(s.openMic and L["Open mic"] or L["Push to talk"])
        panel.mute:ClearAllPoints() panel.mute:SetPoint("TOPLEFT", 12, -y)
        panel.deafen:ClearAllPoints() panel.deafen:SetPoint("LEFT", panel.mute, "RIGHT", 6, 0)
        y = y + 32
        panel.mode:ClearAllPoints() panel.mode:SetPoint("TOPLEFT", 12, -y)
        y = y + 32
    end

    local shown = 0
    for i, m in ipairs(s.members) do
        if i > MAX_ROWS then break end
        local row = Row(i)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 12, -y)
        row.name:SetText(m.name)
        local talking = speaking[m.id]
        local c = talking and { 0.3, 0.85, 0.45, 1 } or { 1, 1, 1, 0.18 }
        row.dot:SetColorTexture(c[1], c[2], c[3], c[4])
        row:Show()
        y = y + 20
        shown = i
    end
    for i = shown + 1, #panel.rows do panel.rows[i]:Hide() end
    if #s.members > MAX_ROWS then
        panel.more:SetText((L["and %d more"]):format(#s.members - MAX_ROWS))
        panel.more:ClearAllPoints()
        panel.more:SetPoint("TOPLEFT", 28, -y)
        panel.more:Show()
        y = y + 18
    else
        panel.more:Hide()
    end
    if shown > 0 or #s.members > 0 then y = y + 4 end

    panel.window:ClearAllPoints()
    panel.window:SetPoint("TOPLEFT", 12, -y)
    y = y + 34
    panel:SetHeight(y)
end

local pending
local function Soon()
    if pending or not panel or not panel:IsShown() then return end
    pending = true
    C_Timer.After(0, function()
        pending = nil
        V.Refresh()
    end)
end

local function Build()
    panel = CreateFrame("Frame", "PigeonVoicePanel", UIParent)
    panel:SetSize(WIDTH, 160)
    panel:SetFrameStrata("DIALOG")
    panel:SetToplevel(true)
    panel:EnableMouse(true)
    panel:SetClampedToScreen(true)
    panel:Hide()
    panel.bg = T.ShapeFill(panel, { T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], 0.97 }, 10)
    panel.border = T.Border(panel, T.INPUT_BORDER, 1, 10)
    tinsert(UISpecialFrames, "PigeonVoicePanel") -- Escape closes it
    panel.rows = {}

    panel.title = T.Text(panel, 13, T.TEXT, "")
    panel.title:SetText(L["Voice chat"])
    panel.status = T.Text(panel, 12, T.DIM)
    panel.status:SetJustifyH("LEFT")
    panel.status:SetWordWrap(false)
    panel.more = T.Text(panel, 11, T.DIM)

    panel.mute = T.Button(panel, L["Mute"], 110, 26)
    panel.mute:SetScript("OnClick", function()
        Call("SetMuted", not Call("IsMuted"))
        Soon()
    end)
    panel.deafen = T.Button(panel, L["Deafen"], 110, 26)
    panel.deafen:SetScript("OnClick", function()
        Call("SetDeafened", not Call("IsDeafened"))
        Soon()
    end)
    panel.mode = T.Button(panel, L["Push to talk"], 226, 26)
    panel.mode:SetScript("OnClick", function()
        local openMic = Call("GetCommunicationMode") == OpenMicValue()
        local PTT = (Enum and Enum.CommunicationMode and Enum.CommunicationMode.PushToTalk) or 0
        Call("SetCommunicationMode", openMic and PTT or OpenMicValue())
        Soon()
    end)
    panel.window = T.Button(panel, L["Open channels window"], 226, 26)
    panel.window:SetScript("OnClick", function()
        panel:Hide()
        V.OpenGameWindow()
    end)

    -- Closes on a click anywhere else.
    panel:RegisterEvent("GLOBAL_MOUSE_DOWN")
    panel:SetScript("OnEvent", function(self, event)
        if event ~= "GLOBAL_MOUSE_DOWN" or not self:IsShown() or self:IsMouseOver() then return end
        local anchor = self.anchor
        if anchor and anchor:IsVisible() and anchor:IsMouseOver() then return end -- its own click toggles
        if (self.age or 0) > 0.15 then self:Hide() end
    end)
    panel:SetScript("OnUpdate", function(self, elapsed) self.age = (self.age or 0) + elapsed end)
    panel:SetScript("OnShow", function(self) self.age = 0 end)
end

-- Open (or close) the card under the voice button.
function V.Toggle(anchor)
    if not Api() then
        V.OpenGameWindow() -- nothing of ours to show on a client without the voice API
        return
    end
    if not panel then Build() end
    if panel:IsShown() then
        panel:Hide()
        return
    end
    panel.anchor = anchor
    panel:ClearAllPoints()
    panel:SetPoint("TOPRIGHT", anchor, "BOTTOMRIGHT", 0, -6)
    panel:Show()
    V.Refresh()
end

---------------------------------------------------------------------------
-- Events: keep the card up to date while it is open
---------------------------------------------------------------------------

local events = CreateFrame("Frame")
local function Listen(name)
    pcall(events.RegisterEvent, events, name)
end
for _, name in ipairs({
    "VOICE_CHAT_CHANNEL_MEMBER_SPEAKING_STATE_CHANGED", "VOICE_CHAT_CHANNEL_MEMBER_ADDED",
    "VOICE_CHAT_CHANNEL_MEMBER_REMOVED", "VOICE_CHAT_CHANNEL_JOINED", "VOICE_CHAT_CHANNEL_REMOVED",
    "VOICE_CHAT_CHANNEL_ACTIVATED", "VOICE_CHAT_CHANNEL_DEACTIVATED", "VOICE_CHAT_MUTED_CHANGED",
    "VOICE_CHAT_DEAFENED_CHANGED", "VOICE_CHAT_COMMUNICATION_MODE_CHANGED", "VOICE_CHAT_LOGIN",
    "VOICE_CHAT_LOGOUT",
}) do Listen(name) end

events:SetScript("OnEvent", function(_, event, memberID, _, isSpeaking)
    if event == "VOICE_CHAT_CHANNEL_MEMBER_SPEAKING_STATE_CHANGED" then
        if memberID ~= nil and ns.Readable(memberID) then speaking[memberID] = isSpeaking and true or nil end
    elseif event == "VOICE_CHAT_CHANNEL_MEMBER_REMOVED" then
        if memberID ~= nil and ns.Readable(memberID) then speaking[memberID] = nil end
    end
    Soon()
end)
