--[[
    Pigeon - Chat message categories: what kind of message a line is
    (event -> category, loot/crafting detection, channel names). Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

---------------------------------------------------------------------------
-- Message categories (what a tab can filter on)
---------------------------------------------------------------------------

ns.CHAT_CATEGORIES = {
    {key="say", label=L["Say"]},
    {key="yell", label=L["Yell"]},
    {key="emote", label=L["Emotes"]},
    {key="voice", label=L["Voice transcription"]},
    {key="guild", label=L["Guild chat"]},
    {key="officer", label=L["Officer chat"]},
    {key="guilddiscord", label=L["Guild Discord chat"]},
    {key="guildach", label=L["Guild announcements"]},
    {key="guildloot", label=L["Guild item loot"]},
    {key="party", label=L["Party"]},
    {key="partyleader", label=L["Party leader"]},
    {key="raid", label=L["Raid"]},
    {key="raidleader", label=L["Raid leader"]},
    {key="raidwarning", label=L["Raid warnings"]},
    {key="instance", label=L["Instance"]},
    {key="instanceleader", label=L["Instance leader"]},
    {key="whisper", label=L["Whispers"]},
    {key="gmwhisper", label=L["Blizzard whispers"]},
    {key="bnet", label=L["Battle.net whispers"]},
    {key="general", label=L["General channel"]},
    {key="trade", label=L["Trade channel"]},
    {key="services", label=L["Services channel"]},
    {key="lfg", label=L["LookingForGroup"]},
    {key="defense", label=L["LocalDefense"]},
    {key="newcomer", label=L["Newcomer channel"]},
    {key="channel", label=L["Other channels"]},
    {key="community", label=L["Communities"]},
    {key="loot", label=L["Item loot"]},
    {key="money", label=L["Money loot"]},
    {key="currency", label=L["Currency"]},
    {key="crafting", label=L["Crafting & tradeskills"]},
    {key="opening", label=L["Opening"]},
    {key="petinfo", label=L["Pet info & feeding"]},
    {key="xp", label=L["Experience"]},
    {key="honor", label=L["Honor"]},
    {key="reputation", label=L["Reputation"]},
    {key="skill", label=L["Skill-ups"]},
    {key="miscinfo", label=L["Misc combat info"]},
    {key="achievement", label=L["Achievement announcements"]},
    {key="appearance", label=L["Appearance collection"]},
    {key="npcsay", label=L["Say"]},
    {key="npcemote", label=L["Emote"]},
    {key="npcyell", label=L["Yell"]},
    {key="npcwhisper", label=L["Whisper"]},
    {key="npcparty", label=L["Party"]},
    {key="bossemote", label=L["Boss emote"]},
    {key="bosswhisper", label=L["Boss whisper"]},
    {key="bghorde", label=L["Battleground Horde"]},
    {key="bgalliance", label=L["Battleground Alliance"]},
    {key="bgneutral", label=L["Battleground neutral"]},
    {key="system", label=L["System messages"]},
    {key="errors", label=L["Errors & restrictions"]},
    {key="ignored", label=L["Ignored"]},
    {key="filtered", label=L["Filtered messages"]},
    {key="channelnotice", label=L["Channel notices"]},
    {key="targeticons", label=L["Target icons"]},
    {key="blizzardservices", label=L["Blizzard services alerts"]},
    {key="petbattlecombat", label=L["Pet battle combat"]},
    {key="petbattleinfo", label=L["Pet battle info"]},
    {key="ping", label=L["Ping"]},
    {key="addon", label=L["Addon messages"]},
}
ns.CHAT_CATEGORY_GROUPS = {
    {L["Chat"], {"say", "yell", "emote", "voice"}},
    {L["Guild"], {"guild", "officer", "guilddiscord", "guildach", "guildloot"}},
    {L["Group"], {"party", "partyleader", "raid", "raidleader", "raidwarning", "instance", "instanceleader"}},
    {L["Private"], {"whisper", "gmwhisper", "bnet"}},
    {L["Channels"], {"general", "trade", "services", "lfg", "defense", "newcomer", "channel", "community"}},
    {L["Loot & professions"], {"loot", "money", "currency", "crafting", "opening", "petinfo"}},
    {L["Progress"], {"xp", "honor", "reputation", "skill", "miscinfo", "achievement", "appearance"}},
    {L["Creature messages"], {"npcsay", "npcemote", "npcyell", "npcwhisper", "npcparty", "bossemote", "bosswhisper"}},
    {L["Player vs. player"], {"bghorde", "bgalliance", "bgneutral"}},
    {L["Other"], {"system", "errors", "ignored", "filtered", "channelnotice", "targeticons", "blizzardservices", "petbattlecombat", "petbattleinfo", "ping", "addon"}},
}
local CAT_LABEL = {}
for _, c in ipairs(ns.CHAT_CATEGORIES) do CAT_LABEL[c.key] = c.label end

local EVENT_CAT = {
    SAY = "say",
    YELL = "yell",
    EMOTE = "emote",
    TEXT_EMOTE = "emote",
    VOICE_TEXT = "voice",
    GUILD = "guild",
    OFFICER = "officer",
    GUILD_DISCORD = "guilddiscord",
    GUILD_ACHIEVEMENT = "guildach",
    GUILD_ITEM_LOOTED = "guildloot",
    PARTY = "party",
    PARTY_LEADER = "partyleader",
    RAID = "raid",
    RAID_LEADER = "raidleader",
    RAID_WARNING = "raidwarning",
    INSTANCE_CHAT = "instance",
    INSTANCE_CHAT_LEADER = "instanceleader",
    WHISPER = "whisper",
    WHISPER_INFORM = "whisper",
    AFK = "whisper",
    DND = "whisper",
    GM_WHISPER = "gmwhisper",
    BN_WHISPER = "bnet",
    BN_WHISPER_INFORM = "bnet",
    BN_WHISPER_PLAYER_OFFLINE = "bnet",
    CHANNEL = "channel",
    COMMUNITIES_CHANNEL = "community",
    LOOT = "loot",
    MONEY = "money",
    CURRENCY = "currency",
    TRADESKILLS = "crafting",
    OPENING = "opening",
    PET_INFO = "petinfo",
    COMBAT_XP_GAIN = "xp",
    COMBAT_HONOR_GAIN = "honor",
    COMBAT_FACTION_CHANGE = "reputation",
    SKILL = "skill",
    COMBAT_MISC_INFO = "miscinfo",
    ACHIEVEMENT = "achievement",
    TRANSMOG = "appearance",
    COLLECTION = "appearance",
    MONSTER_SAY = "npcsay",
    MONSTER_EMOTE = "npcemote",
    MONSTER_YELL = "npcyell",
    MONSTER_WHISPER = "npcwhisper",
    MONSTER_PARTY = "npcparty",
    RAID_BOSS_EMOTE = "bossemote",
    MONSTER_BOSS_EMOTE = "bossemote",
    RAID_BOSS_WHISPER = "bosswhisper",
    MONSTER_BOSS_WHISPER = "bosswhisper",
    BG_SYSTEM_HORDE = "bghorde",
    BG_HORDE = "bghorde",
    BG_SYSTEM_ALLIANCE = "bgalliance",
    BG_ALLIANCE = "bgalliance",
    BG_SYSTEM_NEUTRAL = "bgneutral",
    BG_NEUTRAL = "bgneutral",
    SYSTEM = "system",
    ERRORS = "errors",
    RESTRICTED = "errors",
    IGNORED = "ignored",
    FILTERED = "filtered",
    CHANNEL_NOTICE = "channelnotice",
    CHANNEL_NOTICE_USER = "channelnotice",
    CHANNEL_JOIN = "channelnotice",
    CHANNEL_LEAVE = "channelnotice",
    CHANNEL_LIST = "channelnotice",
    TARGETICONS = "targeticons",
    BN_INLINE_TOAST_ALERT = "blizzardservices",
    BN_INLINE_TOAST_BROADCAST = "blizzardservices",
    BN_INLINE_TOAST_BROADCAST_INFORM = "blizzardservices",
    PET_BATTLE_COMBAT_LOG = "petbattlecombat",
    PET_BATTLE_INFO = "petbattleinfo",
    PING = "ping",
    ADDON = "addon",
    ADDON_LOGGED = "addon",
}

ns.CHAT_EVENT_CAT = EVENT_CAT -- chat type -> category, for the colour pickers

local CHANNEL_KEYS = {
    { "trade", "trade" }, { "general", "general" }, { "services", "services" },
    { "lookingforgroup", "lfg" }, { "looking for group", "lfg" },
    { "localdefense", "defense" }, { "local defense", "defense" }, { "newcomer", "newcomer" },
}

-- The category a joined channel's lines fall under (key as ChannelKey makes it).
function ns.ChannelCategory(key)
    for _, p in ipairs(CHANNEL_KEYS) do
        if key == p[1] then return p[2] end
    end
    return "channel"
end

-- ChatTypeInfo id -> chat type, for clients that don't pass the event along
-- (loot, money, currency and system lines arrive with only the id). The game
-- hands out ids lazily, so a miss re-reads the table instead of trusting an
-- early snapshot, and the types we file are checked first so a shared id
-- can't be read as the wrong one.
local typeById, lastBuild = {}, 0
local function TypeFromId(id)
    if not id or type(ChatTypeInfo) ~= "table" or not ns.Readable(id) then return nil end
    for chatType in pairs(EVENT_CAT) do
        local info = ChatTypeInfo[chatType]
        if type(info) == "table" and info.id == id then return chatType end
    end
    local hit = typeById[id]
    if hit then return hit end
    local now = GetTime and GetTime() or 0
    if now - lastBuild >= 1 then
        lastBuild = now
        wipe(typeById)
        for chatType, info in pairs(ChatTypeInfo) do
            if type(info) == "table" and info.id then typeById[info.id] = chatType end
        end
    end
    return typeById[id]
end

-- Last resort for lines that come with no type at all: recognise loot,
-- money and roll messages by the game's own wording (any language).
local LOOT_STRINGS = {
    "LOOT_ITEM_SELF", "LOOT_ITEM_SELF_MULTIPLE", "LOOT_ITEM", "LOOT_ITEM_MULTIPLE",
    "LOOT_ITEM_PUSHED_SELF", "LOOT_ITEM_PUSHED_SELF_MULTIPLE", "LOOT_ITEM_PUSHED",
    "LOOT_ITEM_PUSHED_MULTIPLE", "LOOT_ITEM_CREATED_SELF", "LOOT_ITEM_CREATED_SELF_MULTIPLE",
    "LOOT_ITEM_BONUS_ROLL_SELF", "LOOT_ITEM_REFUND", "LOOT_ITEM_REFUND_MULTIPLE",
    "YOU_LOOT_MONEY", "YOU_LOOT_MONEY_GUILD", "LOOT_MONEY", "LOOT_MONEY_SPLIT", "LOOT_MONEY_SPLIT_GUILD",
    "LOOT_MONEY_REFUND", "CURRENCY_GAINED", "CURRENCY_GAINED_MULTIPLE", "CURRENCY_GAINED_MULTIPLE_BONUS",
    "LOOT_ROLL_WON", "LOOT_ROLL_YOU_WON", "LOOT_ROLL_WON_NO_SPAM_NEED", "LOOT_ROLL_WON_NO_SPAM_GREED",
    "LOOT_ROLL_NEED", "LOOT_ROLL_NEED_SELF", "LOOT_ROLL_GREED", "LOOT_ROLL_GREED_SELF",
    "LOOT_ROLL_PASSED", "LOOT_ROLL_PASSED_SELF", "LOOT_ROLL_PASSED_AUTO", "LOOT_ROLL_PASSED_AUTO_FEMALE",
    "LOOT_ROLL_ALL_PASSED", "LOOT_ROLL_DISENCHANT", "LOOT_ROLL_DISENCHANT_SELF",
    "LOOT_ROLL_ROLLED_NEED", "LOOT_ROLL_ROLLED_GREED", "LOOT_ROLL_ROLLED_DE",
    "LOOT_ROLL_TRANSMOG", "LOOT_ROLL_TRANSMOG_SELF", "LOOT_ROLL_ROLLED_TRANSMOG",
    "LOOT_ROLL_STARTED", "LOOT_ROLL_LOST_ROLL",
}
local lootPatterns
local function LootPatterns()
    if lootPatterns then return lootPatterns end
    lootPatterns = {}
    for _, key in ipairs(LOOT_STRINGS) do
        local fmt = _G[key]
        if type(fmt) == "string" and fmt ~= "" then
            local p = fmt:gsub("%%%d?%$?[sd]", "\001")            -- placeholders (incl. %1$s)
            p = p:gsub("([%^%$%(%)%.%[%]%*%+%-%?%%])", "%%%1")     -- escape the rest
            p = p:gsub("\001", ".-")
            local cat = key:find("MONEY",1,true) and "money" or (key:find("CURRENCY",1,true) and "currency" or "loot")
            lootPatterns[#lootPatterns + 1] = {pattern="^" .. p .. "$",cat=cat}
        end
    end
    local list = lootPatterns
    if #list == 0 then lootPatterns = nil end -- strings not there yet; look again next time
    return list
end

local function LooksLikeLoot(text)
    if type(text) ~= "string" or not ns.Readable(text) then return false end
    local plain = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
    -- The game's own timestamp ("09:26 ", "[9:26:01 PM] ") sits in front of the line.
    plain = plain:gsub("^%[?%d+:%d+:?%d*%s?[AaPp]?[Mm]?%]?%s+", "")
    for _, p in ipairs(LootPatterns()) do
        if plain:find(p.pattern) then return p.cat end
    end
    return false
end

-- Some Forever creation notices arrive as loot/system text, including nearby crafters.
-- Check only non-conversation events so ordinary player speech stays in its channel.
local creationKeys = { "LOOT_ITEM_CREATED_SELF", "LOOT_ITEM_CREATED_SELF_MULTIPLE",
    "LOOT_ITEM_CREATED", "LOOT_ITEM_CREATED_MULTIPLE", "LOOT_ITEM_CREATED_OTHER", "LOOT_ITEM_CREATED_OTHER_MULTIPLE" }
local creationPatterns = {}
local function LooksLikeCrafting(text)
    if type(text) ~= "string" or not ns.Readable(text) then return false end
    local plain = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
    plain = plain:gsub("^%[?%d+:%d+:?%d*%s?[AaPp]?[Mm]?%]?%s+", "")
    for _, key in ipairs(creationKeys) do
        local fmt = _G[key]
        if type(fmt) == "string" and fmt ~= "" then
            local pattern = creationPatterns[fmt]
            if not pattern then
                pattern = fmt:gsub("%%%d?%$?[sd]", "\001")
                pattern = pattern:gsub("([%^%$%(%)%.%[%]%*%+%-%?%%])", "%%%1"):gsub("\001", ".-")
                pattern = "^" .. pattern .. "$"
                creationPatterns[fmt] = pattern
            end
            if plain:find(pattern) then return true end
        end
    end
    -- Forever's nearby-player format has no corresponding stock global on some clients.
    return plain:match("^%S.- creates:? .+%.$") ~= nil
end

-- Forever can send nearby pet feeding with the loot id; it is pet activity.
local function LooksLikePetFeeding(text)
    if type(text) ~= "string" or not ns.Readable(text) then return false end
    local plain = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
    plain = plain:gsub("^%[?%d+:%d+:?%d*%s?[AaPp]?[Mm]?%]?%s+", "")
    plain = plain:gsub("’", "'")
    return plain:match("^%S.-'s pet begins eating .+") ~= nil
end

local function ChannelName(text, args)
    local name
    if type(args) == "table" then
        local base = args[9]
        if ns.Readable(base) and type(base) == "string" and base ~= "" then name = base end
    end
    if not name and ns.Readable(text) then
        local num = text:match("|Hchannel:[^|]-(%d+)|h")
        if num and GetChannelName then
            local _, n = GetChannelName(tonumber(num))
            if ns.Readable(n) then name = n end
        end
    end
    return name
end

-- Returns category, lowercase channel name (for channel lines).
local function Categorize(text, id, event, args)
    local kind = (type(event) == "string" and ns.Readable(event)) and event:gsub("^CHAT_MSG_", "") or TypeFromId(id)
    if (not kind or kind == "LOOT" or kind == "SYSTEM" or kind == "TRADESKILLS") and LooksLikeCrafting(text) then
        return "crafting"
    end
    if (not kind or kind == "LOOT" or kind == "SYSTEM" or kind == "PET_INFO" or kind == "OPENING" or kind == "COMBAT_MISC_INFO") and LooksLikePetFeeding(text) then
        return "petinfo"
    end
    if kind == "WHISPER" and type(args) == "table" and ns.Readable(args[6]) and args[6] == "GM" then return "gmwhisper" end
    -- No type, a system line, or a type we don't file: go by the wording.
    local known = kind and (EVENT_CAT[kind] or kind == "CHANNEL" or kind:match("^CHANNEL%d"))
    if not known or known == "system" then
        local loot = LooksLikeLoot(text)
        if loot then return loot end
        if not kind then return "addon" end
    end
    if kind == "CHANNEL" or kind:match("^CHANNEL%d") then
        local name = ChannelName(text, args)
        local lower = name and name:lower()
        if lower then
            for _, p in ipairs(CHANNEL_KEYS) do
                if lower:gsub("%s*%-.*$", "") == p[1] then return p[2], lower end
            end
        end
        return "channel", lower
    end
    return EVENT_CAT[kind] or "system"
end

ns.Categorize, ns.TypeFromId = Categorize, TypeFromId
ns.LooksLikeLoot, ns.LooksLikeCrafting, ns.LooksLikePetFeeding = LooksLikeLoot, LooksLikeCrafting, LooksLikePetFeeding
