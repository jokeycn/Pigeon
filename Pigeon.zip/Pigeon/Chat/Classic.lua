--[[
    Pigeon - Classic chat look and the layout/history settings applied with it.
    Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L
local Chat = ns.Chat

---------------------------------------------------------------------------
-- Classic chat: a look that imitates the game's own chat box (db.classic).
-- Everything here is skipped, and any shape it changed is put back, when
-- the option is off.
---------------------------------------------------------------------------

Chat.CLASSIC_BORDER = { 0.55, 0.5, 0.35, 0.8 } -- (a field, not a local: this file is near the 200-locals limit)

-- Border colour of the input boxes (focus/hover repaint it too).
function Chat:InputBorderColor()
    if self.db and self.db.classic then return self.CLASSIC_BORDER end
    return T.INPUT_BORDER
end

-- Flat dark box with a thin grey border, no separate text well.
function Chat:PaintClassicInput(bg, border, well, a)
    T.Color(bg, 0, 0, 0, math.min(a or 1, 0.6))
    T.Color(well, 0, 0, 0, 0)
    T.SetBorderColor(border, self.CLASSIC_BORDER)
end

-- Square the panel, its border and the input boxes (or give them their
-- rounded shape back). Run before the panel is painted. Returns classic.
function Chat:FlattenClassic()
    local classic = self.db.classic and true or false
    if classic or self.classicShaped then
        self.classicShaped = classic
        if self.bg then T.Flatten(self.bg, classic) end
        if self.sheen then T.Flatten(self.sheen, classic) end
        if self.border then T.FlattenBorder(self.border, classic) end
        local f, e = self.fakeInput, self.eb
        if f and f.bg then T.Flatten(f.bg, classic) T.Flatten(f.textWell, classic) T.FlattenBorder(f.border, classic) end
        if e and e.wsBg then T.Flatten(e.wsBg, classic) T.Flatten(e.wsWell, classic) T.FlattenBorder(e.wsBorder, classic) end
    end
    return classic
end

-- Panel colours: plain translucent black with a thin dark border.
function Chat:PaintClassic(classic, ownOff)
    if not classic then
        if self.classicPainted then
            self.classicPainted = nil
            T.SetBorderColor(self.border, T.BORDER)
        end
        return
    end
    self.classicPainted = true
    if self.sheen then self.sheen:Hide() end
    if self.shine then self.shine:Hide() end
    if ownOff then return end -- ElvUI's or the game's frame is drawn instead
    local db = self.db
    local tab = db.tabs[self.active] or {}
    local a = math.min(0.45, tab.bgAlpha or db.bgAlpha or 1)
    local bg = self.bg
    if bg.wsShaped then
        T.Color(bg, 0, 0, 0, a)
    elseif type(CreateColor) == "function" then
        bg:SetColorTexture(1, 1, 1, 1)
        local c = CreateColor(0, 0, 0, a)
        bg:SetGradient("VERTICAL", c, c)
    else
        bg:SetColorTexture(0, 0, 0, a)
    end
    T.SetBorderColor(self.border, { 1, 1, 1, 0.12 })
    for _, edge in ipairs(self.border) do edge:SetShown(true) end
end

-- Four small round buttons: menu, scroll up, scroll down, jump to the latest
-- message. They sit just outside the chat's left edge, or inside it (pushing
-- the messages right) when there is no room on the screen. Built on first use.
-- (fields on Chat, not locals: this file is near the 200-locals limit)
Chat.SIDE_SIZE, Chat.SIDE_GAP, Chat.GOLD = 26, 2, { 1, 0.82, 0 }
Chat.SIDE_PAD = 0 -- the legacy art carries its own frame: no strip padding

-- Blizzard's own chat button art, read (never touched) from the live buttons.
Chat.SIDE_SOURCES = {
    { "ChatFrameMenuButton", "ChatFrame1.MenuButton", "ChatFrame1ButtonFrame.MenuButton" },
    { "ChatFrame1UpButton", "ChatFrame1ButtonFrameUpButton", "ChatFrame1ButtonFrame.UpButton", "ChatFrame1.ScrollUpButton", "ChatFrame1.ScrollUp", "ChatFrameScrollUpButton" },
    { "ChatFrame1DownButton", "ChatFrame1ButtonFrameDownButton", "ChatFrame1ButtonFrame.DownButton", "ChatFrame1.ScrollDownButton", "ChatFrame1.ScrollDown", "ChatFrameScrollDownButton" },
    { "ChatFrame1BottomButton", "ChatFrame1ButtonFrameBottomButton", "ChatFrame1ButtonFrame.BottomButton", "ChatFrame1.ScrollToBottomButton", "ChatFrame1.ScrollToBottom", "ChatFrame1.ScrollBar.ScrollToBottomButton", "ChatFrame1.BottomButton", "ChatFrameScrollToBottomButton" },
}

function Chat:FindBlizzButton(i)
    for _, path in ipairs(self.SIDE_SOURCES[i] or {}) do
        local ok, obj = pcall(function()
            local o = _G
            for part in string.gmatch(path, "[^.]+") do
                if type(o) ~= "table" then return nil end
                o = o[part]
            end
            return o
        end)
        if ok and type(obj) == "table" and type(obj.GetNormalTexture) == "function" then return obj, path end
    end
end

-- /pigeon btndebug: which Blizzard chat buttons were found (names), and what art they use.
function Chat:DebugSideButtons()
    local names = { "menu", "up", "down", "bottom" }
    for i = 1, 4 do
        local obj, path = self:FindBlizzButton(i)
        local info = "not found"
        if obj then
            local t = obj:GetNormalTexture()
            local atlas = t and t.GetAtlas and t:GetAtlas()
            local file = t and t:GetTexture()
            info = ("%s  atlas=%s  file=%s"):format(tostring(path), tostring(atlas), tostring(file))
        end
        local btn = self.sideCol and self.sideCol.buttons and self.sideCol.buttons[i]
        local lg = btn and btn.legacy and (tostring(btn.legacyUp) .. " / " .. tostring(btn.legacyDown) .. (btn.liveSrc and " (live up)" or "")) or "fallback hand-drawn"
        ns.Print(("side button %d (%s): %s  legacy=%s"):format(i, names[i], info, lg))
    end
    local bf = _G.ChatFrame1ButtonFrame
    if bf and bf.GetChildren then
        for _, child in ipairs({ bf:GetChildren() }) do
            ns.Print("  ChatFrame1ButtonFrame child: " .. tostring(child.GetName and child:GetName() or "(unnamed)") .. " " .. tostring(child.GetObjectType and child:GetObjectType()))
        end
    else
        ns.Print("  ChatFrame1ButtonFrame: " .. tostring(bf))
    end
end

-- Copy src's normal art onto our texture tex; true if something was applied.
function Chat:CopyBlizzArt(tex, src)
    local ok, ret = pcall(function()
        local t = src:GetNormalTexture()
        if not t then return false end
        local atlas = t.GetAtlas and t:GetAtlas()
        if type(atlas) == "string" and atlas ~= "" then
            tex:SetAtlas(atlas)
        else
            local file = t:GetTexture()
            if file == nil or file == "" then return false end
            tex:SetTexture(file)
            if t.GetTexCoord then tex:SetTexCoord(t:GetTexCoord()) end
        end
        return true
    end)
    return ok and ret == true
end

-- Blizzard's legacy chat button art (32x32, frame built in), by button index: { up, down }.
Chat.LEGACY_NAMES = { { "Chat-Up", "Chat-Down" }, { "ScrollUp-Up", "ScrollUp-Down" }, { "ScrollDown-Up", "ScrollDown-Down" }, { "ScrollEnd-Up", "ScrollEnd-Down" } }
Chat.HILITE = "Interface" .. string.char(92) .. "Buttons" .. string.char(92) .. "UI-Common-MouseHilight"
function Chat:LegacyPath(name)
    local bs = string.char(92)
    return "Interface" .. bs .. "ChatFrame" .. bs .. "UI-ChatIcon-" .. name
end

-- Use the stock legacy art as the whole button face; on any failure keep the hand-drawn square.
function Chat:ApplyBlizzArt(b)
    if b.legacy then return end
    local i = b.sideIndex
    local names = self.LEGACY_NAMES[i]
    if not names then return end
    local upPath, downPath = self:LegacyPath(names[1]), self:LegacyPath(names[2])
    local ok, good = pcall(function()
        local f = b.face
        f:SetTexCoord(0, 1, 0, 1)
        f:SetTexture(upPath)
        if f:GetTexture() == nil then return false end
        local h = b.hilite
        h:SetTexture(Chat.HILITE or "")
        h:SetBlendMode("ADD")
        return true
    end)
    if not (ok and good) then
        pcall(function() b.face:SetTexture(nil) b.face:Hide() end)
        return
    end
    b.legacy, b.legacyUp, b.legacyDown = true, upPath, downPath
    -- Menu button: prefer the live Blizzard texture (file id works) when it can be read.
    if i == 1 then
        local src = self:FindBlizzButton(1)
        if src and self:CopyBlizzArt(b.face, src) and b.face:GetTexture() ~= nil then
            b.liveSrc = src
        else
            pcall(function() b.face:SetTexCoord(0, 1, 0, 1) b.face:SetTexture(upPath) end)
        end
    end
    b.face:Show()
    b.ring:Hide() b.lite:Hide() b.fill:Hide() b.gloss:Hide()
    for _, tex in ipairs(b.bars) do tex:Hide() end
    b:SetPressed(false)
end

function Chat:SideButton(parent, draw, tip)
    local SIDE_SIZE = self.SIDE_SIZE
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(SIDE_SIZE, SIDE_SIZE)
    -- 1px bevel: dark brown-gold full square, light gold over all but the right/bottom edge, near-black fill inside.
    local ring = b:CreateTexture(nil, "BACKGROUND", nil, 0)
    ring:SetAllPoints()
    local lite = b:CreateTexture(nil, "BACKGROUND", nil, 1)
    lite:SetPoint("TOPLEFT", 0, 0)
    lite:SetPoint("BOTTOMRIGHT", -1, 1)
    local fill = b:CreateTexture(nil, "BACKGROUND", nil, 2)
    fill:SetPoint("TOPLEFT", 1, -1)
    fill:SetPoint("BOTTOMRIGHT", -1, 1)
    local gloss = b:CreateTexture(nil, "ARTWORK", nil, -1)
    gloss:SetSize(SIDE_SIZE - 4, (SIDE_SIZE - 4) / 2)
    gloss:SetPoint("TOP", b, "TOP", 0, -2)
    T.Color(gloss, 1, 1, 1, 0.1)
    local face = b:CreateTexture(nil, "ARTWORK", nil, 2)
    face:SetAllPoints()
    face:Hide()
    local hilite = b:CreateTexture(nil, "OVERLAY", nil, 1)
    hilite:SetAllPoints()
    hilite:Hide()
    T.DrawIcon(b, draw)
    b.ring, b.lite, b.fill, b.gloss, b.face, b.hilite = ring, lite, fill, gloss, face, hilite
    -- Legacy art: swap to the -Down texture while pressed. Hand-drawn look: nudge the glyph 1px.
    function b:SetPressed(down)
        self.pressed = down
        local d = down and -1 or 0
        if self.legacy then
            pcall(function()
                if down then
                    self.face:SetTexCoord(0, 1, 0, 1)
                    self.face:SetTexture(self.legacyDown)
                elseif self.liveSrc then
                    if not Chat:CopyBlizzArt(self.face, self.liveSrc) then self.face:SetTexture(self.legacyUp) end
                else
                    self.face:SetTexture(self.legacyUp)
                end
            end)
            return
        end
        for _, tex in ipairs(self.bars) do
            local pt, rel, rp, x, y = tex:GetPoint()
            if pt then
                tex.baseY = tex.baseY or y or 0
                tex:ClearAllPoints()
                tex:SetPoint(pt, rel, rp, x, tex.baseY + d)
            end
        end
    end
    local GOLD = self.GOLD
    local function Paint(hot)
        if b.legacy then b.hilite:SetShown(hot) return end
        if hot then
            T.Color(ring, 0.55, 0.38, 0.1, 1)
            T.Color(lite, 1, 0.9, 0.45, 1)
            T.Color(fill, 0.1, 0.07, 0.05, 1)
            b:SetIconColor({ 1, 0.95, 0.6 })
        else
            T.Color(ring, 0.4, 0.26, 0.06, 1)
            T.Color(lite, 1, 0.82, 0.3, 1)
            T.Color(fill, 0.04, 0.03, 0.03, 1)
            b:SetIconColor(GOLD)
        end
    end
    b.Paint = Paint
    Paint(false)
    b:SetScript("OnEnter", function(self)
        Paint(true)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(tip)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function(self) Paint(false) self:SetPressed(false) GameTooltip:Hide() end)
    b:SetScript("OnMouseDown", function(self) self:SetPressed(true) end)
    b:SetScript("OnMouseUp", function(self) self:SetPressed(false) end)
    return b
end

-- Put the column outside the left edge, or inside when it would run off screen.
function Chat:PlaceSideColumn()
    local SIDE_SIZE = self.SIDE_SIZE
    local col = self.sideCol
    if not col or not col:IsShown() then return end -- hidden (classic off / ElvUI fitted): inset stays 0
    local left = self:GetLeft()
    local scale = self:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local inside = left ~= nil and left * scale < 30
    local inset = inside and (col:GetWidth() + 10) or 0
    col:ClearAllPoints()
    if inside then
        col:SetPoint("TOPLEFT", self, "TOPLEFT", 4, -((self.tabH or 52) + 8))
    else
        col:SetPoint("TOPRIGHT", self, "TOPLEFT", -2, -(self.tabH or 52))
    end
    if (self.sideInset or 0) ~= inset then
        self.sideInset = inset
        self:UpdateMessageInset()
    end
end

function Chat:SideButtons(on)
    local SIDE_SIZE, SIDE_GAP = self.SIDE_SIZE, self.SIDE_GAP
    local col = self.sideCol
    if not on then
        if col then col:Hide() end
        if (self.sideInset or 0) ~= 0 then
            self.sideInset = 0
            self:UpdateMessageInset()
        end
        return
    end
    if not (self.smf and self.bar) then return end
    if not col then
        local function IconUp(_, Bar) Bar(2, 2, 0, 3) Bar(6, 2, 0, 1) Bar(10, 2, 0, -1) end
        local function IconDown(_, Bar) Bar(10, 2, 0, 1) Bar(6, 2, 0, -1) Bar(2, 2, 0, -3) end
        local function IconBottom(_, Bar) Bar(10, 2, 0, 4) Bar(6, 2, 0, 2) Bar(2, 2, 0, 0) Bar(12, 1, 0, -4) end
        col = CreateFrame("Frame", nil, self)
        local PAD = self.SIDE_PAD
        col:SetSize(SIDE_SIZE + 2 * PAD, 4 * SIDE_SIZE + 3 * SIDE_GAP + 2 * PAD)
        col.bg = col:CreateTexture(nil, "BACKGROUND")
        col.bg:SetAllPoints()
        T.Color(col.bg, 0.17, 0.07, 0.06, 1)
        col:SetFrameLevel(self.bar:GetFrameLevel() + 2)
        local function Update() Chat.jump:SetShown(not Chat.smf:AtBottom()) end
        local defs = {
            { T.Icons.List, L["Chat menu"], function()
                -- Same as hovering the controls indicator; stay open a bit while the mouse travels there.
                Chat.toolbarAway = -2
                Chat:SetToolbarOpen(true)
            end },
            { IconUp, L["Scroll up"], function() Chat.smf:ScrollUp() Update() end },
            { IconDown, L["Scroll down"], function() Chat.smf:ScrollDown() Update() end },
            { IconBottom, L["Jump to latest"], function() Chat.smf:ScrollToBottom() Chat.jump:Hide() end },
        }
        col.buttons = {}
        for i, d in ipairs(defs) do
            local b = self:SideButton(col, d[1], d[2])
            b:SetPoint("TOP", col, "TOP", 0, -(PAD + (i - 1) * (SIDE_SIZE + SIDE_GAP)))
            b:SetScript("OnClick", d[3])
            b.sideIndex = i
            b:SetPressed(false)
            col.buttons[i] = b
        end
        self.sideCol = col
        self:HookScript("OnSizeChanged", function() if Chat.db.classic then Chat:PlaceSideColumn() end end)
    end
    local all = true
    for _, b in ipairs(col.buttons) do
        self:ApplyBlizzArt(b)
        if not b.legacy then all = false end
    end
    col.bg:SetShown(not all)
    col:Show()
    self:PlaceSideColumn()
end

function Chat:ApplyTabBarHeight()
    local h = math.max(32, math.min(80, tonumber(self.db.tabBarHeight) or 52))
    Chat.TAB_H, self.TAB_H, self.tabH = h, h, h
    self.stackInset=math.max(0,(52-h)/2)
    self.bar:SetHeight(h)
    if self.controls and self.toolbarIndicator then
        local scale=math.max(.75,math.min(1.35,h/52))
        self.toolbarScale=scale self.toolbarInset=36*scale
        self.toolbarIndicator:SetScale(scale)
        self.toolbarIndicator:SetPoint("RIGHT",self.bar,"RIGHT",-12/scale,0)
        for _,b in ipairs(self.controls.buttons)do b:SetScale(scale)end
        local width=#self.controls.buttons*36*scale -- 36 per button: 30 plus its gap
        self.controls.fullWidth=width
        self.controls:SetHeight(30*scale)
        self.controls.content:SetSize(width,30*scale)
        self.controls:SetPoint("RIGHT",self.toolbarIndicator,"LEFT",-6*scale,0)
    end
    self.divider:SetPoint("TOPLEFT", 10, -h)
    self.divider:SetPoint("TOPRIGHT", -10, -h)
    if self.stackSeparator then
        self.stackSeparator:SetPoint("TOPLEFT", h+self.stackInset, -8)
        self.stackSeparator:SetPoint("BOTTOMLEFT", h+self.stackInset, 8)
    end
    for _,a in ipairs({self.tabArrowL,self.tabArrowR}) do a:SetHeight(h) end
    if self.tileRail then self.tileRail:SetPoint("TOPLEFT",6,-h-2) end
    if self.railDivider then self.railDivider:SetPoint("TOPLEFT",64,-h-10) end
    local d = ns.Dock
    if d and d.attached == "chat" then
        d.size = h d:SetSize(h,h)
        d:SetPoint("TOPLEFT",self,"TOPLEFT",self.stackInset,0)
        if d.allBtn then
            if d.allBtn.tint then d.allBtn.tint:SetSize(math.floor(h*.72), math.floor(h*.72)) end
            d.allBtn.icon:SetSize(math.floor(h*.62), math.floor(h*.62))
        end
        d:Relayout()
        d:Update() -- a taller header changes the tile viewport capacity
    end
end

function Chat:SetToolbarOpen(open, instant)
    local group = self.controls
    if not group then return end
    open = open or not self.db.locked
    local target = open and 1 or 0
    if not instant and self.toolbarTarget == target then return end
    self.toolbarTarget = target
    group:Show()
    local function paint(p)
        p = math.max(0, math.min(1, p))
        self.toolbarProgress = p
        self.controlExtent = group.fullWidth * p
        group:SetWidth(math.max(.01, self.controlExtent)) group:SetAlpha(p)
        group.content:SetPoint("RIGHT",group,"RIGHT",(1-p)*20,0)
        for _,b in ipairs(group.buttons) do b:EnableMouse(p > .95) end
        if self.active then self:RenderTabs() end
    end
    local function done() if target == 0 then group:Hide() end end
    if instant then T.StopTween(group,"reveal") paint(target) done()
    else T.Tween(group,"reveal",.2,self.toolbarProgress or 0,target,paint,done) end
end

function Chat:SetupToolbar()
    local group = self.controls
    local indicator = self.toolbarIndicator
    indicator:HookScript("OnEnter",function() Chat.toolbarAway=0 Chat:SetToolbarOpen(true) end)
    indicator:SetScript("OnClick",function() Chat.toolbarAway=0 Chat:SetToolbarOpen(true) end)
    local function poll(_,dt)
        local overIndicator = indicator:IsMouseOver()
        if overIndicator then Chat:SetToolbarOpen(true) end
        local over = overIndicator or (group:IsShown() and group:IsMouseOver())
        if over then Chat.toolbarAway = 0
        elseif Chat.toolbarTarget == 1 then
            Chat.toolbarAway = (Chat.toolbarAway or 0) + dt
            if Chat.toolbarAway > .35 then Chat:SetToolbarOpen(false) end
        end
    end
    -- The always-visible header polls even while the sliding group is hidden.
    self.bar:HookScript("OnUpdate",poll)
    self:SetToolbarOpen(false,true)
end

function Chat:ApplySettings()
    if not self.smf then return end
    local keep = math.max(100, math.min(5000, tonumber(self.db.historyLines) or 600))
    Chat.MAX_LOG, self.MAX_LOG = keep, keep
    Chat.SAVE_LOG = math.min(keep, math.max(0, tonumber(self.db.historySaved) or 200))
    self.smf:SetMaxLines(Chat.MAX_LOG)
    while #self.log > Chat.MAX_LOG do table.remove(self.log, 1) end
    while #self.view > Chat.MAX_LOG do table.remove(self.view, 1) end self.viewVer = self.viewVer + 1
    self:ClearStampCache() -- font or size may have changed
    local db = self.db
    for _,tab in ipairs(db.tabs)do ns.UpgradeChatFilters(tab)end
    self:ApplyInputSize()
    self:ApplyTabBarHeight()
    self:SetToolbarOpen(self.toolbarTarget == 1, true)
    self:ApplyTabStyle()
    self.smf:SetFading(db.fade)
    self:SetSelecting(self:WantSelecting())
    self.smf:SetTimeVisible(db.fadeAfter)
    local fitted = ns.ElvUI.fitted
    -- A UI suite's mover mode (ElvUI, EllesmereUI) owns moving, so the
    -- overlay would stay stuck on; there the lock only governs resizing.
    local movers = ns.ChatUsesMovers and ns.ChatUsesMovers()
    self.grip:SetShown(not fitted and not (movers and db.locked)) -- resizing doesn't need unlocking (without movers)
    self.overlay:SetShown(not db.locked and not fitted and not movers)
    self:PaintLock()
    self:PlaceEditBox()
    self:RenderTabs()
    self:Rerender()
end
