--[[
    Pigeon - Chat base: creates the chat frame and its shared state first, so the
    other Chat files (and Chat.lua) can attach to it. Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L
local function ChatText(parent, size, color, flags)
    local text = T.Text(parent,size,color,flags or "")
    text.wsChatText = true
    T.ApplyFont(text,size,flags or "")
    return text
end

local Chat = CreateFrame("Frame", "PigeonChat", UIParent)
ns.Chat = Chat
Chat:Hide()
Chat.log = {}
Chat.unread = {}
Chat.alerted = {}
Chat.MAX_LOG = 600 -- lines kept (db.historyLines)
Chat.TAB_H = 52
Chat.SAVE_LOG = 200 -- lines saved across reloads (db.historySaved)
Chat.guids = {} -- sender name -> GUID, from recent chat lines
ns.ChatText = ChatText
