--[[
    Pigeon - Chat tab filters: smart filters from a tab's name, category matching,
    keyword hiding and saved-filter upgrades. Split from Chat.lua.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local Categorize, LooksLikeLoot, LooksLikeCrafting, LooksLikePetFeeding = ns.Categorize, ns.LooksLikeLoot, ns.LooksLikeCrafting, ns.LooksLikePetFeeding

---------------------------------------------------------------------------
-- Smart filters: a tab's name decides what it shows
---------------------------------------------------------------------------

local SMART = {
    { { "crafting", "crafts" }, { crafting = true } },
    { { "officer" }, { officer = true } },
    { { "guild" }, { guild = true, officer = true, guildach = true } },
    { { "raid" }, { raid = true, raidleader=true, raidwarning = true } },
    { { "party", "group", "dungeon", "instance", "delve" }, { party = true, partyleader=true, instance = true, instanceleader=true } },
    { { "trade", "auction", "wts", "wtb", "craft" }, { trade = true, services = true } },
    { { "lfg", "looking" }, { lfg = true } },
    { { "whisper", "tell", "dm", "pm", "message" }, { whisper = true, bnet = true } },
    { { "bnet", "battle", "friend" }, { bnet = true } },
    { { "loot", "money", "gold" }, { loot = true, money = true, currency = true } },
    { { "xp", "rep", "progress", "skill" }, { xp = true, honor = true, reputation = true, skill = true, achievement = true } },
    { { "achiev" }, { achievement = true, guildach = true } },
    { { "system", "log" }, { system = true, addon = true } },
    { { "npc", "quest", "boss", "monster" }, { npcsay=true, npcemote=true, npcyell=true, npcwhisper=true, npcparty=true, bossemote=true, bosswhisper=true } },
    { { "say", "local", "nearby", "emote" }, { say = true, yell = true, emote = true } },
    { { "defense", "defence", "pvp" }, { defense = true } },
    { { "newcomer", "new player" }, { newcomer = true } },
    { { "community", "club" }, { community = true } },
    { { "channel", "world" }, { general = true, trade = true, services = true, lfg = true, defense = true, newcomer = true, channel = true } },
}

local function JoinedChannel(lowerName)
    if not GetChannelList then return nil end
    local list = { GetChannelList() }
    for i = 1, #list, 3 do
        local name = list[i + 1]
        if ns.Readable(name) and type(name) == "string" and name:lower() == lowerName then return name:lower() end
    end
end

-- Returns cats, channels (nil, nil = show everything) and a readable summary.
-- A "Combat Log" tab shows the game's own combat log window instead of lines.
local function CombatName(name)
    local n = strtrim(name or ""):lower()
    return n == "combat" or n == "cl" or (n:find("combat", 1, true) ~= nil and n:find("log", 1, true) ~= nil)
end
function ns.IsCombatTab(tab)
    if type(tab) ~= "table" then return false end
    if tab.combat ~= nil then return tab.combat and true or false end
    return CombatName(tab.name)
end

function ns.SmartFilter(name)
    if CombatName(name) then return {}, nil, L["the game's combat log"] end
    local lower = strtrim(name or ""):lower()
    if lower == "" or lower:find("general", 1, true) or lower == "all" or lower == "main" then
        return nil, nil, L["everything"]
    end
    local joined = JoinedChannel(lower)
    if joined then
        return {}, { [joined] = true }, L["the %s channel"]:format(name)
    end
    -- On non-English clients a tab may be named with the translated category label
    -- (e.g. the localized "Guild"), so those labels count as keywords too.
    local localized = ns.LOCALE and ns.LOCALE ~= "enUS" and ns.LOCALE ~= "enGB"
    for _, rule in ipairs(SMART) do
        local words = rule[1]
        if localized then
            words = { unpack(words) }
            for _, c in ipairs(ns.CHAT_CATEGORIES) do
                if rule[2][c.key] and type(c.label) == "string" and c.label ~= "" then
                    words[#words + 1] = c.label:lower()
                end
            end
        end
        for _, word in ipairs(words) do
            if lower:find(word, 1, true) then
                local cats = {}
                local labels = {}
                for k in pairs(rule[2]) do cats[k] = true end
                for _, c in ipairs(ns.CHAT_CATEGORIES) do
                    if cats[c.key] then labels[#labels + 1] = c.label end
                end
                return cats, nil, table.concat(labels, ", ")
            end
        end
    end
    return nil, nil, L["everything (no filter matched the name; pick one in /pigeon config)"]
end

local LEGACY_CATEGORIES = {
    loot={"money","currency"}, progress={"xp","honor","reputation","skill","opening"},
    npc={"npcsay","npcemote","npcyell","npcwhisper","npcparty","bossemote","bosswhisper"},
    party={"partyleader"}, raid={"raidleader"}, instance={"instanceleader"},
    guildach={"guildloot"}, whisper={"gmwhisper"}, bnet={"blizzardservices"},
    system={"errors","ignored","filtered","channelnotice","targeticons","ping","voice","guilddiscord","miscinfo","appearance","bghorde","bgalliance","bgneutral","petbattlecombat","petbattleinfo"},
}
function ns.UpgradeChatFilters(tab)
    if not tab or tab.categoryVersion == 2 then return end
    local cats=tab.cats
    if cats then
        for old,keys in pairs(LEGACY_CATEGORIES)do
            if cats[old] then for _,key in ipairs(keys)do if cats[key]==nil then cats[key]=true end end end
        end
        cats.progress=nil cats.npc=nil
    end
    tab.categoryVersion=2
end

function ns.UpgradeChatHistoryEntry(e)
    if (e.cat == "loot" or e.cat == "system" or e.cat == "progress") and LooksLikeCrafting(e.text) then e.cat="crafting" end
    if (e.cat == "loot" or e.cat == "system" or e.cat == "progress" or e.cat == "opening" or e.cat == "miscinfo") and LooksLikePetFeeding(e.text) then e.cat="petinfo" end
    if e.cat == "loot" and not e.chatType then e.cat=LooksLikeLoot(e.text) or e.cat end
    if e.chatType then
        local ok,cat,chan=pcall(Categorize,e.text,nil,e.chatType)
        if ok then e.cat,e.chan=cat,chan or e.chan end
    end
end

local hideKeywordCache=setmetatable({},{__mode="k"})
function ns.TabKeywordHidden(tab,e)
    local raw=tab and tab.hideKeywords
    if type(raw)~="string" or raw=="" or not e or type(e.text)~="string" or not ns.Readable(e.text) then return false end
    local cache=hideKeywordCache[tab]
    if not cache or cache.raw~=raw then
        cache={raw=raw,words={}}
        for word in raw:gmatch("[^,\r\n]+")do
            word=strtrim(word):lower()
            if word~=""then cache.words[#cache.words+1]=word end
        end
        hideKeywordCache[tab]=cache
    end
    local plain=e.text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("|H.-|h(.-)|h","%1"):gsub("|T.-|t",""):gsub("|A.-|a",""):lower()
    for _,word in ipairs(cache.words)do if plain:find(word,1,true)then return true end end
    return false
end

function ns.TabMatches(tab, e)
    ns.UpgradeChatFilters(tab)
    if ns.TabKeywordHidden(tab,e)then return false end
    if ns.IsCombatTab(tab) then return false end
    if tab.all then return true end
    if tab.cats and tab.cats[e.cat] then return true end
    -- Older saved lines did not retain the event needed to split bundles.
    if tab.cats and (e.cat == "progress" or e.cat == "npc") then
        for _,key in ipairs(LEGACY_CATEGORIES[e.cat])do if tab.cats[key]then return true end end
    end
    if e.chan and tab.channels then
        if tab.channels[e.chan] then return true end
        local base=e.chan:match("^(.-)%s+%-%s+")
        if base and tab.channels[base] then return true end
    end
    return false
end

ns.CombatName = CombatName
