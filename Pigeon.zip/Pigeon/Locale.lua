-- Pigeon: translations.
-- Every piece of text the player sees goes through ns.L["English text"]. With no translation for
-- the player's language, the English comes back unchanged, so a half-done translation still works.
-- A translation lives in Locales/<code>.lua (koKR, zhCN, deDE, ...). Locales/Template.lua (generated) lists
-- every English text there is to translate.
local ADDON, ns = ...

local L = setmetatable({}, {
    __index = function(_, key) return key end,
})
ns.L = L
ns.LOCALE = (GetLocale and GetLocale()) or "enUS"


-- Locales/koKR.lua starts with:  local L = select(2, ...).NewLocale("koKR") if not L then return end
-- and then fills in lines like:   L["Size"] = "크기"
-- (lines left as "" are skipped, so a part-done file shows English for those)
local filler = setmetatable({}, {
    __index = L,
    __newindex = function(_, key, text)
        if type(text) == "string" and text ~= "" then rawset(L, key, text) end
    end,
})
function ns.NewLocale(code)
    if code ~= ns.LOCALE then return nil end
    return filler
end
