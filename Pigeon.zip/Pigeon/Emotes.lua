--[[
    Pigeon - Twitch Emotes integration
    Only does anything when the Twitch Emotes addon is loaded:
      - An emote button next to the send buttons (whisper window, hub) and
        inside the chat box's input line. A searchable drawer shows the
        installed emotes; picking one inserts its name into that input.
      - Whisper messages show the emote pictures, like the normal chat does.
        (The chat box gets them already: Twitch Emotes swaps them in before
        the text reaches it.)
    Emotes are sent as their plain names ("Pepega"), which is how Twitch
    Emotes users see them turn into pictures.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local Emo = {}
ns.Emotes = Emo

local function IsLoaded(name)
    if C_AddOns and C_AddOns.IsAddOnLoaded then return C_AddOns.IsAddOnLoaded(name) end
    return IsAddOnLoaded and IsAddOnLoaded(name)
end

function Emo.Available()
    return IsLoaded("TwitchEmotes") and type(_G.Emoticons_RunReplacement) == "function"
        and type(_G.TwitchEmotes_defaultpack) == "table"
end

-- Swap emote names for pictures in a whisper line, honouring Twitch Emotes'
-- own "Whisper" channel setting.
function Emo.Render(text, bnet)
    if type(text) ~= "string" or not ns.Readable(text) then return text end
    local run = _G.Emoticons_RunReplacement
    local settings = _G.Emoticons_Settings
    if type(run) ~= "function" or type(settings) ~= "table" then return text end
    if settings[bnet and "CHAT_MSG_BN_WHISPER" or "CHAT_MSG_WHISPER"] == false then return text end
    local ok, out = pcall(run, text)
    if ok and type(out) == "string" then return out end
    return text
end

-- Animated emotes: Twitch Emotes only animates its own chat frames (it rewrites the
-- emote's texture string every frame). This does the same for any fontstring Pigeon
-- owns, keeping the size the emote was drawn at.
-- keepInfo: leave the line's stored message alone (the chat box finds each line's time and its
-- place in the log from that text, so it must stay as it was added).
function Emo.Animate(fs, keepInfo)
    local getFrame = _G.TwitchEmotes_GetCurrentFrameNum
    local build = _G.TwitchEmotes_BuildEmoteFrameStringWithDimensions
    local meta = _G.TwitchEmotes_animation_metadata
    if type(getFrame) ~= "function" or type(build) ~= "function" or type(meta) ~= "table" then return end
    local ok, txt = pcall(fs.GetText, fs)
    if not ok or type(txt) ~= "string" or not ns.Readable(txt) then return end
    if not txt:find("TwitchEmotes\\Emotes", 1, true) then return end
    local changed
    local out = txt:gsub("|T(Interface\\AddOns\\TwitchEmotes\\Emotes\\[^|:]+%.tga)([^|]*)|t", function(path, rest)
        local anim = meta[path]
        if not anim then return nil end
        local a, b = rest:match("^:(%d+):(%d+)")
        if not a then return nil end
        changed = true
        return build(path, anim, getFrame(anim), tonumber(a), tonumber(b))
    end)
    if changed and out ~= txt then
        if not keepInfo and type(fs.messageInfo) == "table" then fs.messageInfo.message = out end
        fs:SetText(out)
    end
end

-- One shared, virtualized drawer: thousands of installed emotes need only 40 buttons.
local MAX_RECENT = 24
local function Recent()
    local db = ns.db
    if not db then return {} end
    db.emoteRecent = type(db.emoteRecent) == "table" and db.emoteRecent or {}
    return db.emoteRecent
end
local function Favs()
    local db = ns.db
    if not db then return {} end
    db.emoteFavs = type(db.emoteFavs) == "table" and db.emoteFavs or {}
    return db.emoteFavs
end
function Emo.IsFavorite(name) return Favs()[name] and true or false end
function Emo.ToggleFavorite(name)
    local favs = Favs()
    favs[name] = (not favs[name]) or nil
    return favs[name] and true or false
end
function Emo.AddRecent(name)
    local list = Recent()
    for i = #list, 1, -1 do if list[i] == name then table.remove(list, i) end end
    table.insert(list, 1, name)
    while #list > MAX_RECENT do table.remove(list) end
end

-- mode: nil/"all" = every emote, "recent" = last used (newest first), "favs" = favorites.
function Emo.Catalog(query, mode)
    local pack = _G.TwitchEmotes_defaultpack
    local list = {}
    query = (query or ""):lower()
    if (mode == "recent" or mode == "favs") and type(pack) == "table" then
        local function add(name)
            local texture = pack[name]
            if type(texture) == "string" and name:lower():find(query, 1, true) then
                list[#list+1] = {name=name, texture=texture}
            end
        end
        if mode == "recent" then
            for _, name in ipairs(Recent()) do add(name) end
        else
            for name in pairs(Favs()) do add(name) end
            table.sort(list, function(a,b) return a.name:lower() < b.name:lower() end)
        end
        return list
    end
    if type(pack) == "table" then
        for name, texture in pairs(pack) do
            if type(name) == "string" and type(texture) == "string" and name:lower():find(query, 1, true) then
                list[#list+1] = {name=name, texture=texture}
            end
        end
    end
    table.sort(list, function(a,b) return a.name:lower() < b.name:lower() end)
    return list
end

local function ResolveTarget(edit)
    if not edit then return end
    if edit == _G.ChatFrame1EditBox and not edit:IsShown() then
        local attrs = Emo.chatAttrs or {}
        local open = (ChatFrameUtil and ChatFrameUtil.OpenChat) or _G.ChatFrame_OpenChat
        if open then pcall(open, Emo.draft or "", DEFAULT_CHAT_FRAME) end
        for key, value in pairs(attrs) do edit:SetAttribute(key, value) end
    end
    return edit:IsVisible() and edit or nil
end

function Emo.Insert(name)
    local edit = ResolveTarget(Emo.target)
    if not edit then return end
    local text = edit:GetText() or ""
    if not ns.Readable(text) then return end
    edit:Insert((text ~= "" and not text:find("%s$") and " " or "") .. name .. " ")
    Emo.AddRecent(name)
    Emo.draft = edit:GetText()
    edit:SetFocus()
end

-- Clicking an emote in a message puts it in the box you're typing in: the whisper
-- window or hub input when the click was there, otherwise the chat input.
-- (An addon can't write the clipboard, so this stands in for "copy".)
function Emo.Pick(name, fromWhisper)
    if type(name) ~= "string" or name == "" or not ns.Readable(name) then return end
    local edit
    if fromWhisper then
        local hub, win = ns.Hub, ns.Window
        if hub and hub.input and hub.input.edit and hub.input.edit:IsVisible() and hub:IsMouseOver() then edit = hub.input.edit
        elseif win and win.input and win.input.edit and win.input.edit:IsVisible() and win:IsMouseOver() then edit = win.input.edit
        elseif hub and hub.input and hub.input.edit and hub.input.edit:IsVisible() then edit = hub.input.edit
        elseif win and win.input and win.input.edit and win.input.edit:IsVisible() then edit = win.input.edit end
    end
    edit = edit or _G.ChatFrame1EditBox
    Emo.target = edit
    if edit == _G.ChatFrame1EditBox then Emo.draft, Emo.chatAttrs = "", {} end
    Emo.Insert(name)
end

local function BuildDrawer()
    local d = CreateFrame("Frame", "PigeonEmoteDrawer", UIParent)
    d:SetFrameStrata("DIALOG") d:SetToplevel(true) d:EnableMouse(true)
    d:SetSize(320, 326) d:SetClipsChildren(true)
    -- Opaque, so the emotes are easy to read: it does not follow the addon's panel transparency.
    T.Panel(d, { T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], 1 }, T.BORDER) T.Reshape(d, 18)
    d:Hide()
    local body = CreateFrame("Frame", nil, d)
    body:SetPoint("BOTTOMLEFT") body:SetSize(320,326)
    d.body = body
    local title = T.Text(body, 13, T.TEXT, "")
    title.wsChatText=true T.StyleText(title,13,"")
    title:SetPoint("TOPLEFT",14,-13) title:SetText(L["Emotes"])
    local close = T.IconButton(body,22,T.Icons.Close,L["Close emotes"])
    close:SetPoint("TOPRIGHT",-10,-9)
    close:RegisterForClicks("LeftButtonDown")
    close:SetScript("OnClick",function() Emo.Close() end)
    d.search = T.EditBox(body,L["Find an emote…"])
    d.search.wsQuietFocus=true
    d.search.edit.wsChatText=true T.ApplyFont(d.search.edit,12,"") d.search.edit:SetShadowColor(0,0,0,0)
    d.search.placeholder.wsChatText=true T.StyleText(d.search.placeholder,12,"")
    d.search:SetPoint("TOPLEFT",12,-42) d.search:SetPoint("TOPRIGHT",-12,-42) d.search:SetHeight(30)
    -- Recent / Favorites / All
    d.mode="all"
    d.modeButtons={}
    local modes={{"recent",L["Recent"]},{"favs",L["Favorites"]},{"all",L["All"]}}
    local prevChip
    for _,m in ipairs(modes) do
        local chip=CreateFrame("Button",nil,body)
        chip:SetHeight(22)
        chip.bg=T.ShapeFill(chip,{1,1,1,0.06},11)
        chip.label=T.Text(chip,11,T.TEXT,"") chip.label:SetPoint("CENTER")
        chip.label:SetText(m[2]) chip:SetWidth(math.max(54,chip.label:GetStringWidth()+22))
        if prevChip then chip:SetPoint("LEFT",prevChip,"RIGHT",6,0) else chip:SetPoint("TOPLEFT",12,-78) end
        chip.mode=m[1]
        chip:RegisterForClicks("LeftButtonDown")
        chip:SetScript("OnClick",function() d:SetMode(m[1]) end)
        d.modeButtons[#d.modeButtons+1]=chip
        prevChip=chip
    end
    function d:SetMode(mode)
        self.mode=mode
        for _,chip in ipairs(self.modeButtons) do
            if chip.mode==mode then
                T.Color(chip.bg,T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],0.30)
            else
                T.Color(chip.bg,1,1,1,0.06)
            end
        end
        local query=self.search.edit:GetText()
        self.list=Emo.Catalog(ns.Readable(query) and query or "",mode) self.page=1 self:Render()
    end
    d.cells={}
    for i=1,40 do
        local cell=CreateFrame("Button",nil,body)
        cell:SetSize(34,34)
        cell:SetPoint("TOPLEFT",14+((i-1)%8)*37,-108-math.floor((i-1)/8)*37)
        cell.bg=T.ShapeFill(cell,{1,1,1,0},8)
        cell.picture=cell:CreateTexture(nil,"ARTWORK") cell.picture:SetSize(28,28) cell.picture:SetPoint("CENTER")
        cell.fav=cell:CreateTexture(nil,"OVERLAY") cell.fav:SetSize(7,7) cell.fav:SetPoint("TOPRIGHT",-2,-2)
        T.Circle(cell.fav) T.Color(cell.fav,1,0.82,0,1) cell.fav:Hide()
        cell:RegisterForClicks("LeftButtonDown","RightButtonUp")
        cell:SetScript("OnClick",function(self,button)
            if not self.entry then return end
            if button=="RightButton" then
                local on=Emo.ToggleFavorite(self.entry.name)
                self.fav:SetShown(on)
                if d.mode=="favs" then d:SetMode("favs") end
                if self:IsMouseOver() then self:GetScript("OnEnter")(self) end
            else
                Emo.Insert(self.entry.name)
            end
        end)
        cell:SetScript("OnEnter",function(self)
            T.Color(self.bg,T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],0.15)
            if self.entry then
                GameTooltip:SetOwner(self,"ANCHOR_TOP") GameTooltip:AddLine(self.entry.name)
                GameTooltip:AddLine(Emo.IsFavorite(self.entry.name) and L["Right-click to remove from favorites"] or L["Right-click to add to favorites"],T.SECTION[1],T.SECTION[2],T.SECTION[3])
                GameTooltip:Show()
            end
        end)
        cell:SetScript("OnLeave",function(self) T.Color(self.bg,1,1,1,0) GameTooltip:Hide() end)
        d.cells[i]=cell
    end
    d.status=T.Text(body,10,T.SECTION,"") d.status:SetPoint("BOTTOM",0,12)
    local prev=T.IconButton(body,22,T.Icons.Reply,L["Previous emotes"]) prev:SetPoint("BOTTOMLEFT",12,8)
    local nextPage=T.IconButton(body,22,T.Icons.Send,L["Next emotes"]) nextPage:SetPoint("BOTTOMRIGHT",-12,8)
    function d:Render()
        local pages=math.max(1,math.ceil(#self.list/40))
        self.page=math.max(1,math.min(pages,self.page))
        for i,cell in ipairs(self.cells) do
            local entry=self.list[(self.page-1)*40+i]
            cell.entry=entry cell.meta=nil cell:SetShown(entry~=nil)
            cell.fav:SetShown(entry~=nil and Emo.IsFavorite(entry.name))
            if entry then
                local path=entry.texture:match("^([^:]+)")
                cell.picture:SetTexture(path) cell.picture:SetTexCoord(0,1,0,1)
                local meta=type(TwitchEmotes_animation_metadata)=="table" and TwitchEmotes_animation_metadata[path]
                if meta then
                    cell.picture:SetTexCoord(0,meta.frameWidth/meta.imageWidth,0,meta.frameHeight/meta.imageHeight)
                    cell.meta=meta -- animated: stepped in the drawer's OnUpdate
                end
            end
        end
        local empty=L["No emotes found"]
        if #self.list==0 and (self.search.edit:GetText() or "")=="" then
            if self.mode=="recent" then empty=L["No recent emotes yet"]
            elseif self.mode=="favs" then empty=L["Right-click an emote to favorite it"] end
        end
        self.status:SetText(#self.list == 0 and empty or L["%d / %d  ·  %d emotes"]:format(self.page,pages,#self.list))
        prev:SetEnabled(self.page>1) nextPage:SetEnabled(self.page<pages)
    end
    function d:Page(delta) self.page=self.page+delta self:Render() end
    prev:RegisterForClicks("LeftButtonDown") nextPage:RegisterForClicks("LeftButtonDown")
    prev:SetScript("OnClick",function() d:Page(-1) end) nextPage:SetScript("OnClick",function() d:Page(1) end)
    d:EnableMouseWheel(true) d:SetScript("OnMouseWheel",function(_,delta) d:Page(delta>0 and -1 or 1) end)
    d.search.edit:HookScript("OnTextChanged",function(self)
        local query=self:GetText()
        if not ns.Readable(query) then return end
        d.list=Emo.Catalog(query,d.mode) d.page=1 d:Render()
    end)
    d.search.edit:SetScript("OnEscapePressed",function() Emo.Close() end)
    d:SetScript("OnUpdate",function(_,elapsed)
        d.age=(d.age or 0)+elapsed
        -- animated emotes play in the drawer too (~30 fps)
        d.animAcc=(d.animAcc or 0)+elapsed
        if d.animAcc>=0.033 then
            d.animAcc=0
            local frameOf,coords=_G.TwitchEmotes_GetCurrentFrameNum,_G.TwitchEmotes_GetTexCoordsForFrame
            if type(frameOf)=="function" and type(coords)=="function" then
                for _,cell in ipairs(d.cells) do
                    local meta=cell.meta
                    if meta and cell:IsShown() then
                        local ok,l,r,t,b=pcall(function() return coords(meta,frameOf(meta)) end)
                        if ok and l then cell.picture:SetTexCoord(l,r,t,b) end
                    end
                end
            end
        end
        local owner=Emo.owner
        if owner and not owner:IsVisible() then Emo.Close() end
    end)
    d:RegisterEvent("GLOBAL_MOUSE_DOWN")
    d:SetScript("OnEvent",function()
        if not d:IsShown() or (d.age or 0)<0.15 or d:IsMouseOver() then return end
        if Emo.anchor and Emo.anchor:IsMouseOver() then return end
        Emo.Close()
    end)
    tinsert(UISpecialFrames,"PigeonEmoteDrawer")
    d:SetScript("OnHide",function() T.StopTween(d,"drawer") d.search.edit:ClearFocus() end)
    Emo.drawer=d
    return d
end

function Emo.Close()
    local d=Emo.drawer
    if not d or not d:IsShown() or d.closing then return end
    d.closing=true
    d.search.edit:ClearFocus()
    T.Spring(d,"drawer",d.progress or 1,0,function(v)
        d.progress=v d:SetHeight(math.max(1,44+282*v)) d:SetAlpha(math.max(0,math.min(1,v*3)))
    end,function() d:Hide() d.closing=nil end)
end

function Emo.Open(anchor,edit)
    local d=Emo.drawer or BuildDrawer()
    if d.bg then T.Color(d.bg, T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], 1) end -- keep it opaque after palette changes
    if d:IsShown() and not d.closing and Emo.anchor==anchor then Emo.Close() return end
    Emo.target=edit or _G.ChatFrame1EditBox
    Emo.anchor=anchor
    -- The native chat input hides on outside mouse-down. The drawer belongs
    -- to the chat panel, and remembers its draft and destination for insertion.
    Emo.owner=Emo.target==_G.ChatFrame1EditBox and ns.Chat or anchor:GetParent()
    local draft=Emo.target and Emo.target:GetText() or ""
    Emo.draft=ns.Readable(draft) and draft or ""
    Emo.chatAttrs={}
    if Emo.target==_G.ChatFrame1EditBox then
        for _,key in ipairs({"chatType","tellTarget","channelTarget"}) do
            local value=Emo.target:GetAttribute(key)
            if value~=nil and ns.Readable(value) then Emo.chatAttrs[key]=value end
        end
    end
    d.closing=nil d.age=0 d.page=1 d.search.edit:SetText("") d:SetMode(#Recent()>0 and "recent" or "all")
    d:ClearAllPoints()
    d:SetPoint("BOTTOMRIGHT",anchor,"TOPRIGHT",5,10)
    d:SetClampedToScreen(true) d:Show() d:Raise()
    T.Spring(d,"drawer",0,1,function(v)
        d.progress=v d:SetHeight(math.max(1,44+282*v)) d:SetAlpha(math.max(0,math.min(1,v*3)))
    end)
    C_Timer.After(0,function()
        if d:IsShown() and not d.closing and Emo.anchor==anchor and not d.search.edit:HasFocus() then
            local target=ResolveTarget(Emo.target)
            if target then target:SetFocus() end
        end
    end)
end

function Emo.Button(parent, size, getEdit)
    if not Emo.Available() then return nil end
    local b=T.IconButton(parent,size,T.Icons.Emote,L["Twitch emotes"])
    -- The smile is part of the input, with no second button-shaped surface.
    b.bg:Hide()
    for _,edge in ipairs(b.border)do edge:Hide()end
    b:HookScript("OnEnter",function(self)self:SetIconColor(T.ACCENT)end)
    b.icon=b.controlIcon
    b:RegisterForClicks("LeftButtonDown")
    b:SetScript("OnClick",function(btn) Emo.Open(btn,getEdit and getEdit() or _G.ChatFrame1EditBox) end)
    return b
end

function Emo.Embed(button, field, edit, placeholder)
    if not button then return end
    -- Keep the native chat button on its persistent parent: the game hides
    -- an empty edit box on mouse-down before a child can receive its click.
    button:ClearAllPoints()
    button:SetPoint("RIGHT",field,"RIGHT",-6,0)
    button:SetFrameLevel(math.max(field:GetFrameLevel(),edit and edit:GetFrameLevel() or 0)+5)
    if edit then
        edit:SetPoint("BOTTOMRIGHT",field,"BOTTOMRIGHT",-button:GetWidth()-16,0)
    end
    if placeholder then
        placeholder:SetPoint("RIGHT",field,"RIGHT",-button:GetWidth()-16,0)
        placeholder:SetJustifyH("LEFT") placeholder:SetWordWrap(false)
    end
end
