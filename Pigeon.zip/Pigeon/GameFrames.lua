--[[
    Pigeon - Game frames
    Look > Panels > "Use the game's own window frames" (or the Forever theme)
    draws the whisper window, the hub, the settings and the copy window with
    the client's own frame art: its border, title bar, close button and, for
    the whisper window, the round portrait. Nothing is copied: the frame is
    built from the game's templates, so it looks like every other window and
    follows along if the game restyles them.

    The game frame sits behind our window and reaches a little past it (the
    title bar goes above). Our own background, border, title and close
    button step aside while it's on. If this client doesn't have a usable
    template, nothing changes and the option says so once.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local G = {}
ns.GameFrames = G

-- Tried in order; the first one this client really has wins.
local TEMPLATES = { "PortraitFrameTemplate", "ButtonFrameTemplate", "BasicFrameTemplateWithInset", "BasicFrameTemplate" }
local TITLE_H = 21      -- the game's title bar, which sits above our window
local SIDE, BOTTOM = 4, 5
local workingTemplate   -- remembered once one works
local noneWorks = false
local toldMissing = false

-- A template that doesn't exist still hands back a bare frame, so check
-- for the parts a real one has.
local function Part(f, key)
    local v = f and f[key]
    return type(v) == "table" and v or nil
end

local function LooksReal(f)
    return (Part(f, "NineSlice") or Part(f, "CloseButton") or Part(f, "TitleContainer") or Part(f, "TitleText") or Part(f, "Bg")) and true or false
end

local function Make(parent)
    if noneWorks then return nil end
    local list = workingTemplate and { workingTemplate } or TEMPLATES
    for _, tpl in ipairs(list) do
        local ok, f = pcall(CreateFrame, "Frame", nil, parent, tpl)
        if ok and LooksReal(f) then
            workingTemplate = tpl
            return f
        end
        if ok and f then f:Hide() end
    end
    noneWorks = true
    return nil
end

local function SetTitle(skin, text)
    text = text or ""
    if type(skin.SetTitle) == "function" and pcall(skin.SetTitle, skin, text) then return end
    local fs = Part(Part(skin, "TitleContainer"), "TitleText") or Part(skin, "TitleText")
    if fs and fs.SetText then fs:SetText(text) end
end

local function HidePortrait(skin)
    if type(ButtonFrameTemplate_HidePortrait) == "function" and pcall(ButtonFrameTemplate_HidePortrait, skin) then return end
    for _, key in ipairs({ "PortraitContainer", "portrait", "PortraitFrame" }) do
        local part = Part(skin, key)
        if part and part.Hide then part:Hide() end
    end
end

local function SetPortrait(skin, texture)
    if not texture then return end
    if type(skin.SetPortraitToAsset) == "function" and pcall(skin.SetPortraitToAsset, skin, texture) then return end
    local tex = Part(Part(skin, "PortraitContainer"), "portrait") or Part(skin, "portrait")
    if tex and tex.SetTexture then tex:SetTexture(texture) end
end

-- Our own close button and title step aside (the game's take over).
local function StepAside(target, aside)
    local close = target.closeBtn
    if close then
        if aside and not close.wsWidth then close.wsWidth = close:GetWidth() end
        close:SetAlpha(aside and 0 or 1)
        close:EnableMouse(not aside)
        close:SetWidth(aside and 1 or (close.wsWidth or 24))
    end
    local title = target.titleText
    if title then
        title:SetAlpha(aside and 0 or 1)
        title:SetWidth(aside and 1 or 0) -- 0 = size to the text again; what follows it slides left
    end
end

-- The windows we dress, and what each needs.
local function Targets()
    local list = {}
    if ns.Window then
        list[#list + 1] = {
            frame = ns.Window, portrait = true,
            title = function() local c = ns.Window.convo return c and c.display or L["Whisper"] end,
            icon = function()
                local c = ns.Window.convo
                if c and c.class then return "Interface\\Icons\\ClassIcon_" .. c.class end
                return "Interface\\Icons\\INV_Letter_15"
            end,
            close = function() ns.Window:Close() end,
        }
    end
    if ns.Hub then
        -- Our header row only held the title and close button, which the
        -- game's title bar now carries: lay the title bar over that row so
        -- no empty band is left under it.
        list[#list + 1] = { frame = ns.Hub, top = -20, title = function() return L["Whispers"] end, close = function() ns.Hub:Close() end }
    end
    if ns.Settings then
        list[#list + 1] = { frame = ns.Settings, title = function() return "Pigeon" end, close = function() ns.Settings:Close() end }
    end
    -- The chat box: no close button, and the frame follows the chat's own
    -- background opacity (0% = no frame at all).
    if ns.Chat and ns.Chat.smf and not (ns.ElvUI and ns.ElvUI.fitted) then
        -- No header: the frame's top strip sits behind our tab bar instead.
        -- The strip lines up with the tabs (which sit 6px down in their bar).
        list[#list + 1] = { frame = ns.Chat, chat = true, top = -6, title = function() return "" end }
    end
    local tw = ns.ChatX and ns.ChatX.textWindow
    if tw then
        list[#list + 1] = { frame = tw, top = -16, title = function() return tw.title and tw.title:GetText() or "Pigeon" end,
            close = function() tw:Hide() end }
    end
    return list
end

local function Dress(def)
    local target = def.frame
    local skin = target.wsSkin
    if not skin then
        skin = Make(target)
        if not skin then return false end
        target.wsSkin = skin
        skin:SetFrameLevel(target:GetFrameLevel()) -- behind everything of ours
        skin:ClearAllPoints()
        skin:SetPoint("TOPLEFT", target, "TOPLEFT", -SIDE, def.top or TITLE_H)
        skin:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", SIDE, -BOTTOM)
        -- The game puts its border and title far above everything (level
        -- 500), which would cover our tabs and other windows. Keep them
        -- just above our background instead.
        local base = target:GetFrameLevel()
        for _, key in ipairs({ "NineSlice", "TitleContainer", "PortraitContainer" }) do
            local part = Part(skin, key)
            if part and part.SetFrameLevel then
                pcall(part.SetFrameLevel, part, base + ((def.chat or key == "NineSlice") and 0 or 2))
            end
        end
        local inset = Part(skin, "Inset")
        if inset and inset.Hide then inset:Hide() end -- we bring our own inner panels
        if not def.portrait then HidePortrait(skin) end
        local closeBtn = Part(skin, "CloseButton")
        if closeBtn and closeBtn.SetScript then
            if def.close then closeBtn:SetScript("OnClick", def.close) else closeBtn:Hide() end
            -- Above our own header row, which would otherwise take the click.
            if closeBtn.SetFrameLevel then closeBtn:SetFrameLevel(target:GetFrameLevel() + 12) end
        end
        -- The title bar is outside our window: let it drag the window the
        -- same way our own header does (which also saves the position).
        skin:EnableMouse(not def.chat) -- the chat moves by its own tab bar
        skin:RegisterForDrag("LeftButton")
        local function Pass(script)
            return function()
                local h = target.dragHeader
                local fn = h and h:GetScript(script)
                if fn then pcall(fn, h) end
            end
        end
        skin:SetScript("OnDragStart", Pass("OnDragStart"))
        skin:SetScript("OnDragStop", Pass("OnDragStop"))
        target:HookScript("OnShow", function() if target.wsSkinned then G.Update(def) end end)
    end
    skin:Show()
    target.wsSkinned = true
    -- Our own background and border make way for the game's.
    if target.bg then T.PaintSurface(target, T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], 0) end
    for _, edge in ipairs(target.border or {}) do edge:Hide() end
    if target.strip then target.strip:Hide() end
    if def.portrait then
        -- The round portrait takes the place of our tile in the corner.
        if target.SetClipsChildren then target:SetClipsChildren(false) end
        if target.tile then target.tile:SetAlpha(0) end
    end
    StepAside(target, true)
    G.Update(def)
    if def.chat then
        G.ChatAlpha()
        if target.SetSlim then target:SetSlim(true) end
    end
    return true
end

local function Undress(def)
    local target = def.frame
    if not target.wsSkinned then return end
    target.wsSkinned = nil
    if target.wsSkin then target.wsSkin:Hide() end
    if target.bg then
        local a=(target==ns.Window or target==ns.Hub) and ns.WhisperOpacity() or math.max(T.BACKDROP[4] or 1, target.wsMinAlpha or 0)
        T.PaintSurface(target, T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], a)
    end
    for _, edge in ipairs(target.border or {}) do edge:Show() end
    if target.strip then target.strip:Show() end
    if def.portrait then
        if target.SetClipsChildren then target:SetClipsChildren(true) end
        if target.tile then target.tile:SetAlpha(1) end
    end
    StepAside(target, false)
    if def.chat then
        if target.SetSlim then target:SetSlim(false) end
        if target.divider and target.divider.SetAlpha then target.divider:SetAlpha(target.chromeAlpha or 1) end
    end
end

function G.Update(def)
    local skin = def.frame.wsSkin
    if not skin or not def.frame.wsSkinned then return end
    if def.frame==ns.Window or def.frame==ns.Hub then skin:SetAlpha(ns.WhisperOpacity()) end
    SetTitle(skin, def.title())
    if def.portrait and def.icon then SetPortrait(skin, def.icon()) end
    StepAside(def.frame, true) -- parts built after the first pass
end

-- The chat's frame is as see-through as the chat background, and fades
-- with it when the chat goes idle.
function G.ChatAlpha()
    local chat = ns.Chat
    local skin = chat and chat.wsSkin
    if not skin or not chat.wsSkinned then return end
    local a = (chat.bgAlphaNow or 1) * (chat.chromeAlpha or 1)
    skin:SetAlpha(a)
    skin:SetShown(a > 0.01)
    -- The frame's own top strip shows behind the tabs; our divider line
    -- under the tab bar would double up with it.
    if chat.divider and chat.divider.SetAlpha then chat.divider:SetAlpha(0) end
end

---------------------------------------------------------------------------
-- Smaller parts: buttons and the settings cards
---------------------------------------------------------------------------

local buttonWorks, cardWorks

local function ShowOwn(f, show)
    if f.bg then f.bg:SetShown(show) end
    for _, edge in ipairs(f.border or {}) do edge:SetShown(show) end
    if f.sheen and not show then f.sheen:Hide() f.shine:Hide() end
end

-- The game's standard button, drawn behind our click area.
function G.DressButton(b)
    if buttonWorks == false then return end
    local art = b.wsArt
    if not art then
        local ok, made = pcall(CreateFrame, "Button", nil, b, "UIPanelButtonTemplate")
        local fs = ok and made and type(made.GetFontString) == "function" and made:GetFontString()
        local real = ok and made and (type(fs) == "table" or Part(made, "Left") or Part(made, "Text"))
        if not real then
            buttonWorks = false
            if ok and made then made:Hide() end
            return
        end
        buttonWorks = true
        art = made
        b.wsArt = art
        art:SetAllPoints(b)
        art:SetFrameLevel(b:GetFrameLevel())
        art:EnableMouse(false)
        -- Our label would sit under the art, so the art carries the text.
        if b.label and b.label.SetText then
            hooksecurefunc(b.label, "SetText", function(_, t) if b.wsArt then b.wsArt:SetText(t or "") end end)
        end
    end
    art:SetText(b.label and b.label:GetText() or "")
    art:Show()
    if b.label then b.label:SetAlpha(0) end
    ShowOwn(b, false)
end

function G.UndressButton(b)
    if not b.wsArt then return end
    b.wsArt:Hide()
    if b.label then b.label:SetAlpha(1) end
    ShowOwn(b, true)
end

-- Settings cards become the game's recessed inner panel.
function G.DressCard(card)
    if cardWorks == false then return end
    local art = card.wsArt
    if not art then
        local ok, made = pcall(CreateFrame, "Frame", nil, card, "InsetFrameTemplate")
        if not (ok and made and (Part(made, "NineSlice") or Part(made, "Bg"))) then
            cardWorks = false
            if ok and made then made:Hide() end
            return
        end
        cardWorks = true
        art = made
        card.wsArt = art
        art:SetAllPoints(card)
        art:SetFrameLevel(card:GetFrameLevel())
        art:EnableMouse(false)
    end
    art:Show()
    ShowOwn(card, false)
end

function G.UndressCard(card)
    if not card.wsArt then return end
    card.wsArt:Hide()
    ShowOwn(card, true)
end

function G.On()
    return ns.db and ns.db.look and ns.db.look.gameFrames == true
end

-- True once we know this client has no frame template we can use.
function G.Unavailable() return noneWorks end

function G.Apply()
    local on = G.On()
    for _, def in ipairs(Targets()) do
        if on then
            if not Dress(def) then
                if not toldMissing then
                    toldMissing = true
                    ns.Print(L["this client doesn't offer its window frames to addons, so the regular look stays."])
                end
                break
            end
        else
            Undress(def)
        end
    end
    for _, b in ipairs(T.buttons or {}) do
        if on then G.DressButton(b) else G.UndressButton(b) end
    end
    for _, card in ipairs(T.cards or {}) do
        if on then G.DressCard(card) else G.UndressCard(card) end
    end
    if not G.chatHooked and ns.ChatX and ns.ChatX.ChromeAlpha then
        G.chatHooked = true
        hooksecurefunc(ns.ChatX, "ChromeAlpha", function() G.ChatAlpha() end)
    end
    if not G.hooked and ns.Window and ns.Window.Render then
        G.hooked = true
        hooksecurefunc(ns.Window, "Render", function()
            if not ns.Window.wsSkinned then return end
            for _, def in ipairs(Targets()) do
                if def.frame == ns.Window then G.Update(def) end
            end
        end)
    end
end
