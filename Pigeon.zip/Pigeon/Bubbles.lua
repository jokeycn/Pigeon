--[[
    Pigeon - Message log
    Five looks, picked in Settings > Look > Whisper style: accent rails
    (below), bubbles, threads, classic chat lines and minimal.
    The scrolling message list shared by the docked window and the hub.
    No boxes: each run of messages from one person starts with a small
    "Name · time" line, and every message carries a thin rail on its side
    (their class colour on the left, your accent on the right) with a soft
    colour wash fading away from it. Bottom-anchored, newest at the bottom;
    the mouse wheel scrolls back through history. New messages fade and
    rise into place.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local RAIL = 2
local PAD_X, PAD_Y = 10, 3
local LINE_GAP = 3        -- between messages in the same run
local HEAD_H = 14         -- the "Name · time" line
local HEAD_GAP = 3        -- header to first message
local RUN_GAP = 6         -- space above a header
local STAMP_H = 20
local STAMP_GAP = 15 * 60 -- a quiet gap this long gets a date separator
local RUN_BREAK = 5 * 60  -- same speaker after this long starts a new run
local WASH_THEIRS, WASH_YOURS = 0.10, 0.14
local GRADIENTS = type(CreateColor) == "function"
local BUB_X, BUB_Y = 11, 5  -- bubbles: text padding inside the bubble
local THREAD_TILE = 24     -- threads: tile size
local THREAD_X = 38        -- threads: text column (tile + gap)
local THREAD_GAP = 6       -- threads: space between runs

-- Whisper display style (Settings > Look): rails, bubbles, threads, classic, minimal.
local STYLES = { signal = true, rails = true, bubbles = true, threads = true, classic = true, minimal = true }
function ns.WhisperStyle()
    local s = ns.db and ns.db.look and ns.db.look.whisperStyle
    return STYLES[s] and s or "rails"
end

local function OnHyperlinkClick(_, link, text, button)
    local emote = type(link) == "string" and ns.Readable(link) and link:match("^tel:(.+)$")
    if emote then -- a Twitch Emotes picture: add it to what you're typing
        if ns.Emotes and ns.Emotes.Pick then ns.Emotes.Pick(emote, true) end
        return
    end
    if ns.ChatX and ns.ChatX.HandleLink(link) then return end -- web links and our own
    SetItemRef(link, text, button)
end

local function OnHyperlinkEnter(self, link)
    local kind = link:match("^(%a+):")
    if kind == "tel" then -- a Twitch Emotes picture: show its name
        local name = link:match("^tel:(.+)$")
        if name then
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:SetText(name, 1, 0.82, 0)
            GameTooltip:AddLine(L["Click to add it to your message"], 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end
        return
    end
    if kind == "item" or kind == "spell" or kind == "achievement" or kind == "quest" or kind == "currency" then
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        pcall(GameTooltip.SetHyperlink, GameTooltip, link)
        GameTooltip:Show()
    end
end

local function StampText(t)
    local day = (date("%Y%m%d", t) == date("%Y%m%d")) and L["Today"] or date("%b %d", t)
    return (day .. "  ·  " .. date("%H:%M", t)):upper()
end

-- Independent corner radii keep the conversation-side corner tucked in,
-- instead of turning short messages into symmetrical pills.
local function MessageFill(parent)
    local fill={parts={}}
    for i=1,9 do
        local t=parent:CreateTexture(nil,"BACKGROUND")
        fill.parts[i]=t
        if i<=4 then T.Circle(t) end
    end
    function fill:Hide() for _,t in ipairs(self.parts) do t:Hide() end end
    function fill:Show(out,r,g,b)
        self.out=out
        local radii={14,14,out and 14 or 4,out and 4 or 14}
        local anchors={"TOPLEFT","TOPRIGHT","BOTTOMLEFT","BOTTOMRIGHT"}
        local coords={{0,.5,0,.5},{.5,1,0,.5},{0,.5,.5,1},{.5,1,.5,1}}
        for i=1,4 do
            local t=self.parts[i] t:ClearAllPoints() t:SetPoint(anchors[i]) t:SetSize(radii[i],radii[i])
            t:SetTexCoord(unpack(coords[i])) t:SetVertexColor(r,g,b,1) t:Show()
        end
        local function rect(i,tl,br)
            local t=self.parts[i] t:ClearAllPoints()
            t:SetPoint("TOPLEFT",parent,"TOPLEFT",tl[1],tl[2])
            t:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",br[1],br[2])
            t:SetColorTexture(r,g,b,1) t:Show()
        end
        rect(5,{14,0},{-14,0})
        rect(6,{0,-14},{0,14})
        local left,right=self.parts[7],self.parts[8]
        left:ClearAllPoints() left:SetPoint("TOPLEFT",0,-14) left:SetPoint("BOTTOMLEFT",0,radii[3]) left:SetWidth(14)
        right:ClearAllPoints() right:SetPoint("TOPRIGHT",0,-14) right:SetPoint("BOTTOMRIGHT",0,radii[4]) right:SetWidth(14)
        for _,t in ipairs({left,right}) do t:SetColorTexture(r,g,b,1) t:Show() end
        local bottom=self.parts[9] bottom:ClearAllPoints()
        bottom:SetPoint("BOTTOMLEFT",radii[3],0) bottom:SetPoint("BOTTOMRIGHT",-radii[4],0) bottom:SetHeight(14)
        bottom:SetColorTexture(r,g,b,1) bottom:Show()
    end
    fill:Hide()
    return fill
end

-- Text is split into "atoms" for character selection: one UTF-8 character, a
-- texture (|T..|t / |A..|a, copies as nothing) or a "||". Colour codes and link
-- wrappers are skipped. keys compare a message's text with a wrapped line of it,
-- disp is what the game draws (measured for highlight positions), plain is what
-- gets copied.
local atomCache, atomCount = {}, 0
local function Atoms(text)
    if type(text) ~= "string" then text = "" end
    local hit = atomCache[text]
    if hit then return hit end
    local keys, disp, plain = {}, {}, {}
    local n, i, k = #text, 1, 0
    while i <= n do
        local key, d, p, nxt
        if text:byte(i) == 124 then -- "|"
            local nx = text:sub(i + 1, i + 1)
            if nx == "c" and text:find("^%x%x%x%x%x%x%x%x", i + 2) then
                nxt = i + 10
            elseif nx == "r" or nx == "h" then
                nxt = i + 2
            elseif nx == "H" then
                local _, e = text:find("|h", i + 2, true)
                nxt = e and (e + 1) or (n + 1)
            elseif nx == "T" or nx == "A" then
                local _, e = text:find(nx == "T" and "|t" or "|a", i + 2, true)
                if e then
                    local tok = text:sub(i, e)
                    key, d, p, nxt = tok, tok, "", e + 1
                else
                    nxt = n + 1
                end
            elseif nx == "|" then
                key, d, p, nxt = "||", "||", "|", i + 2
            else
                key, d, p, nxt = "|", "||", "|", i + 1
            end
        else
            local c = text:byte(i)
            local len = (c >= 240 and 4) or (c >= 224 and 3) or (c >= 192 and 2) or 1
            local ch = text:sub(i, i + len - 1)
            key, d, p, nxt = ch, ch, ch, i + len
        end
        if key then
            k = k + 1
            keys[k], disp[k], plain[k] = key, d, p
        end
        i = nxt
    end
    hit = { keys = keys, disp = disp, plain = plain, n = k, w = {} }
    atomCount = atomCount + 1
    if atomCount > 500 then wipe(atomCache) atomCount = 1 end
    atomCache[text] = hit
    return hit
end

function ns.NewBubbleLog(parent, opts)
    opts = opts or {}
    local log = CreateFrame("Frame", nil, parent)
    log:SetClipsChildren(true)
    log:EnableMouseWheel(true)
    log.bubbles, log.stamps, log.heads, log.tiles, log.cards = {}, {}, {}, {}, {}
    log.scroll = 0
    log.widthFrac = opts.widthFrac or 0.8
    log.fontSize = opts.fontSize or 14
    log.useStamps = opts.stamps

    -- Real in-message text selection: each message's text is also drawn by a
    -- one-message ScrollingMessageFrame with SetTextCopyable (drag to select
    -- characters, Ctrl+C). b.text stays as the (invisible) measuring FontString.
    -- Off: Settings > Look (look.bubbleSelect == false). Any failure falls back
    -- to the plain FontString for that message.
    -- Settings > General > Behavior: use the game's own selection, which copies to the
    -- clipboard the moment the mouse is released (the highlight then disappears).
    local function NativeCopy()
        local look = ns.db and ns.db.look
        return look and look.selectAutoCopy and true or false
    end

    local function SelectEnabled()
        local look = ns.db and ns.db.look
        return not (look and look.bubbleSelect == false)
    end

    local function MsgDown(b, button)
        if button ~= "LeftButton" or not b.msgIdx then return end
        -- plain drag on text: character selection; Shift (or no character mode): whole messages
        if not IsShiftKeyDown() and log:CharMode(b) then log:BeginChar(b) return end
        log:BeginSelect(b.msgIdx)
    end

    local function MsgUp(b, button)
        if button == "LeftButton" then log:EndSelect() return end
        if button ~= "RightButton" then return end
        local X, c = ns.ChatX, log.convo
        if not X or not X.ShowText then return end
        if IsShiftKeyDown() then log:CopyRange(1, c and #c.messages or 0, L["Copy conversation"]) return end
        if log.selLo or log:HasChar() then log:CopySelection() return end -- a highlighted selection: right-click opens it in the copy window
        ns.Social.OpenMenu(b, L["Copy"], {
            { label = L["Copy message"], fn = function() log:CopyRange(b.msgIdx, b.msgIdx, L["Copy message"]) end },
            { label = L["Copy conversation"], fn = function() log:CopyRange(1, c and #c.messages or 0, L["Copy conversation"]) end },
        })
    end

    local function Unhover(b)
        if not b:IsMouseOver() then b.hover:Hide() end
    end

    local function GetSMF(b)
        if b.smf ~= nil then return b.smf or nil end
        if log.noSMF then b.smf = false return nil end
        local ok, smf = pcall(function()
            local s = CreateFrame("ScrollingMessageFrame", nil, b)
            if type(s.SetTextCopyable) ~= "function" then
                s:Hide()
                log.noSMF = true
                error("no SetTextCopyable")
            end
            -- Pigeon draws its own (persistent) character selection when the
            -- lines are reachable; otherwise the game's native selection stays.
            s.charOK = type(s.visibleLines) == "table" and not NativeCopy()
            s:SetTextCopyable(not s.charOK)
            s:EnableMouse(true)
            s:SetFading(false)
            s:SetMaxLines(4)
            s:SetHyperlinksEnabled(true)
            pcall(s.SetInsertMode, s, "TOP")
            if s.SetSpacing then s:SetSpacing(0) end
            if s.SetIndentedWordWrap then s:SetIndentedWordWrap(false) end
            s:SetScript("OnHyperlinkClick", function(...)
                if log.suppressLink then return end
                OnHyperlinkClick(...)
            end)
            s:SetScript("OnHyperlinkEnter", OnHyperlinkEnter)
            s:SetScript("OnHyperlinkLeave", function() GameTooltip:Hide() end)
            s:EnableMouseWheel(true)
            s:SetScript("OnMouseWheel", function(_, delta)
                local h = log:GetScript("OnMouseWheel")
                if h then h(log, delta) end
            end)
            s:SetScript("OnEnter", function() b.hover:Show() end)
            s:SetScript("OnLeave", function() Unhover(b) end)
            -- A plain drag inside the text selects characters natively;
            -- Shift+drag still selects whole messages.
            s:SetScript("OnMouseDown", function(_, button)
                if s.charOK or IsShiftKeyDown() then MsgDown(b, button) end
            end)
            s:SetScript("OnMouseUp", function(_, button) MsgUp(b, button) end)
            return s
        end)
        if not ok or not smf then b.smf = false return nil end
        b.smf = smf
        return smf
    end

    -- Draw `body` in the message's SMF over b.text (already sized/anchored).
    -- Returns true when the SMF is showing the text.
    local function NativeText(b, body, tw, th)
        local smf = SelectEnabled() and type(body) == "string" and ns.Readable(body) and GetSMF(b)
        if smf then
            local ok = pcall(function()
                local char = type(smf.visibleLines) == "table" and not NativeCopy()
                if smf.charOK ~= char then
                    smf.charOK = char
                    smf:SetTextCopyable(not char)
                end
                local t = b.text
                local fo = t.GetFontObject and t:GetFontObject() or nil
                local file, size, fl = t:GetFont()
                local sig = tostring(fo) .. "|" .. tostring(file) .. "|" .. tostring(size) .. "|" .. tostring(fl)
                if smf.sig ~= sig then
                    if fo then smf:SetFontObject(fo) elseif file then smf:SetFont(file, size or 14, fl or "") end
                    if not smf:GetFont() and file then smf:SetFont(file, size or 14, fl or "") end
                    smf.sig, smf.sBody = sig, nil
                end
                local sr, sg, sb, sa = t:GetShadowColor()
                smf:SetShadowColor(sr or 0, sg or 0, sb or 0, sa or 0)
                local ox, oy = t:GetShadowOffset()
                smf:SetShadowOffset(ox or 1, oy or -1)
                local just = t:GetJustifyH() or "LEFT"
                if smf.sJust ~= just then smf:SetJustifyH(just) smf.sJust, smf.sBody = just, nil end
                local r, g, bl = t:GetTextColor()
                if smf.sBody ~= body or smf.sR ~= r or smf.sG ~= g or smf.sB ~= bl then
                    smf.sBody = nil
                    smf:Clear()
                    smf:AddMessage(body, r, g, bl)
                    smf.sBody, smf.sR, smf.sG, smf.sB = body, r, g, bl
                end
                local p, rel, rp, x, y = t:GetPoint(1)
                local w, h = tw + 3, th + 4
                if smf.sP ~= p or smf.sX ~= x or smf.sY ~= y or smf.sW ~= w or smf.sH ~= h then
                    smf:ClearAllPoints()
                    -- The frame draws its text from the bottom, so shift it up by its spare
                    -- height; the text then sits where the plain label would, not 4px lower.
                    smf:SetPoint(p, rel, rp, x, (y or 0) + (h - th))
                    smf:SetSize(w, h)
                    smf.sP, smf.sX, smf.sY, smf.sW, smf.sH = p, x, y, w, h
                end
            end)
            if ok then
                smf:Show()
                b.text:SetAlpha(0)
                return true
            end
        end
        if b.smf then b.smf:Hide() end
        b.text:SetAlpha(1)
        return false
    end

    -- Animated Twitch Emotes: step the emote frames ~30 times a second, only while the
    -- log is on screen and a message in it has an animated emote.
    local animDriver = CreateFrame("Frame", nil, log)
    local animAcc = 0
    animDriver:SetScript("OnUpdate", function(_, dt)
        animAcc = animAcc + dt
        if animAcc < 0.033 then return end
        animAcc = 0
        if not (ns.Emotes and ns.Emotes.Animate) then return end
        for _, b in ipairs(log.bubbles) do
            -- Rewriting a message's text resets the game's hyperlink tracking, which would
            -- swallow a click on an emote. So an emote holds still while the mouse is over its message.
            if b.anim and b:IsShown() and not b:IsMouseOver() then
                local smf = b.smf
                local vis = smf and smf:IsShown() and smf.visibleLines
                if type(vis) == "table" then
                    for _, fs in ipairs(vis) do
                        if type(fs) == "table" and fs.IsShown and fs:IsShown() then pcall(ns.Emotes.Animate, fs) end
                    end
                else
                    pcall(ns.Emotes.Animate, b.text)
                end
            end
        end
    end)

    -- One message line: rail + wash + text.
    local function Line(i)
        local b = log.bubbles[i]
        if b then return b end
        b = CreateFrame("Frame", nil, log)
        b.wash = b:CreateTexture(nil, "BACKGROUND")
        b.wash:SetAllPoints()
        b.rail = b:CreateTexture(nil, "BORDER")
        b.rail:SetWidth(RAIL)
        b.bubble = T.ShapeFill(b, { 1, 1, 1, 0 }, 10)
        b.bubble:Hide()
        b.signalFill=MessageFill(b)
        b.time = T.Text(b, 9, T.SECTION, "")
        b.time:SetPoint("BOTTOMRIGHT", -10, 6)
        b.time:Hide()
        b.text = T.Text(b, log.fontSize)
        b.time.wsChatText=true T.StyleText(b.time,10,"")
        b.text:SetWordWrap(true)
        if b.text.SetNonSpaceWrap then b.text:SetNonSpaceWrap(true) end
        if b.SetHyperlinksEnabled then
            b:SetHyperlinksEnabled(true)
            b:SetScript("OnHyperlinkClick", OnHyperlinkClick)
            b:SetScript("OnHyperlinkEnter", OnHyperlinkEnter)
            b:SetScript("OnHyperlinkLeave", function() GameTooltip:Hide() end)
        end
        -- Hover highlight; drag across messages to select them (release copies);
        -- right-click copies one message or the whole conversation.
        b.hover = b:CreateTexture(nil, "OVERLAY")
        b.hover:SetAllPoints()
        b.hover:SetColorTexture(1, 1, 1, 0) -- no hover box; selection shows its own highlight
        b.hover:Hide()
        b.sel = b:CreateTexture(nil, "OVERLAY")
        b.sel:SetAllPoints()
        b.sel:SetColorTexture(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.32)
        b.sel:Hide()
        b:EnableMouse(true)
        b:HookScript("OnEnter", function(f) f.hover:Show() end)
        b:HookScript("OnLeave", Unhover)
        b:SetScript("OnMouseDown", MsgDown)
        b:SetScript("OnMouseUp", MsgUp)
        log.bubbles[i] = b
        return b
    end

    local function Head(i)
        local h = log.heads[i]
        if h then return h end
        h = T.Text(log, 11, T.SECTION)
        h:SetWordWrap(false)
        log.heads[i] = h
        return h
    end

    -- Date separators: small text in a rounded outline ("TODAY · 21:02").
    local function Stamp(i)
        local s = log.stamps[i]
        if s then return s end
        local f = CreateFrame("Frame", nil, log)
        f:SetHeight(16)
        f.border = T.Border(f, T.INPUT_BORDER, 1, 8)
        f.text = T.Text(f, 9, T.SECTION)
        f.text:SetPoint("CENTER", 0, 0)
        function f:SetText(t)
            self.text:SetText(t)
            self:SetWidth(math.ceil(self.text:GetStringWidth() or (#t * 6)) + 18)
        end
        log.stamps[i] = f
        return f
    end

    local function Hex(c)
        return ("%02x%02x%02x"):format(math.floor(c[1] * 255 + 0.5), math.floor(c[2] * 255 + 0.5), math.floor(c[3] * 255 + 0.5))
    end

    -- Colours for one side: rail/wash colour, text colour.
    local function SideColors(c, out)
        if out then return T.ACCENT, T.YOURS end
        local r, g, b = ns.ConvoColor(c)
        local text = (c and c.kind == "bn") and T.BNET or T.WHISPER
        return { r, g, b, 1 }, text
    end

    -- The text a message is drawn with (emotes, web links, classic prefix).
    local function BuildBody(c, m, style, name)
        local body = ns.Emotes.Render(m.text, c and c.kind == "bn")
        if ns.ChatX and ns.ChatX.LinkURLs then body = ns.ChatX.LinkURLs(body) end
        if style == "classic" then
            local rail = SideColors(c, m.out)
            local who = "|cff" .. Hex(rail) .. "[" .. name .. "]|r"
            body = "|cff" .. Hex(T.DIM) .. date("%H:%M", m.t) .. "|r "
                .. (m.out and L["To %s: "]:format(who) or L["%s whispers: "]:format(who)) .. (body or "")
        end
        return body
    end

    -- Per style: text size / outline.
    local function Font(fs, size, flags)
        if fs.wsSize ~= size or fs.wsFlags ~= flags then T.StyleText(fs, size, flags) end
    end

    -- Paint one message line for the current style.
    local function Paint(b, style, out, rail, text)
        local L = ns.db and ns.db.look or {}
        local size, flags = L.msgSize or log.fontSize, (L.msgOutline == false) and "" or (L.msgOutlineThick and "THICKOUTLINE" or "OUTLINE")
        b.rail:Hide()
        b.wash:Hide()
        b.bubble:Hide()
        b.signalFill:Hide()
        b.text.wsChatText = style == "signal"
        b.time:SetShown(style == "signal")
        b.rail:ClearAllPoints()
        b.text:ClearAllPoints()
        local right = out and (style == "rails" or style == "bubbles" or style == "signal" or style == "minimal")
        b.text:SetJustifyH(right and "RIGHT" or "LEFT")

        if style == "rails" then
            Font(b.text, size, flags)
            b.rail:SetWidth(L.railWidth or RAIL)
            b.rail:SetColorTexture(rail[1], rail[2], rail[3], 1)
            b.rail:Show()
            b.wash:SetColorTexture(1, 1, 1, 1)
            b.wash:Show()
            local a = (out and WASH_YOURS or WASH_THEIRS) * (L.wash or 1)
            if out then
                b.rail:SetPoint("TOPRIGHT")
                b.rail:SetPoint("BOTTOMRIGHT")
                b.text:SetPoint("TOPRIGHT", -PAD_X, -PAD_Y)
            else
                b.rail:SetPoint("TOPLEFT")
                b.rail:SetPoint("BOTTOMLEFT")
                b.text:SetPoint("TOPLEFT", PAD_X, -PAD_Y)
            end
            local wc = L.washColor or rail
            if GRADIENTS then
                local strong = CreateColor(wc[1], wc[2], wc[3], a)
                local clear = CreateColor(wc[1], wc[2], wc[3], 0)
                if out then
                    b.wash:SetGradient("HORIZONTAL", clear, strong)
                else
                    b.wash:SetGradient("HORIZONTAL", strong, clear)
                end
            else
                b.wash:SetColorTexture(wc[1], wc[2], wc[3], a * 0.5)
            end
            b.text:SetTextColor(text[1], text[2], text[3])
            return RAIL + PAD_X, PAD_Y
        elseif style == "signal" then
            -- Medium-weight Island text, quiet accent wash and inside timestamps.
            T.StyleText(b.text, size, flags)
            local bg, a = T.INPUT_BG, T.ACCENT
            local mix = out and 0.32 or 0
            b.signalFill:Show(out,bg[1]*(1-mix)+a[1]*mix,bg[2]*(1-mix)+a[2]*mix,bg[3]*(1-mix)+a[3]*mix)
            b.text:SetTextColor(T.TEXT[1],T.TEXT[2],T.TEXT[3])
            b.text:SetJustifyH("LEFT")
            b.text:SetPoint("TOPLEFT",12,-9)
            b.time:SetPoint("BOTTOMRIGHT",-12,8)
            b.time:SetTextColor(T.SECTION[1],T.SECTION[2],T.SECTION[3])
            return 24, 9
        elseif style == "bubbles" then
            T.Shape(b.bubble, 10)
            -- Filled accent bubbles for you (dark text), soft grey for them.
            Font(b.text, size, out and "" or flags)
            b.bubble:Show()
            if out then
                T.Color(b.bubble, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.92)
                b.text:SetTextColor(0.05, 0.06, 0.1)
                b.text:SetPoint("TOPRIGHT", -BUB_X, -BUB_Y)
            else
                local wk = L.wash or 1
                local wc = L.washColor or { 1, 1, 1 }
                T.Color(b.bubble, wc[1], wc[2], wc[3], 0.09 * (wk <= 0 and 0 or math.max(0.5, wk)))
                b.text:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
                b.text:SetPoint("TOPLEFT", BUB_X, -BUB_Y)
            end
            return BUB_X * 2, BUB_Y
        elseif style == "classic" then
            Font(b.text, math.max(10, size - 1), flags)
            b.text:SetPoint("TOPLEFT")
            b.text:SetTextColor(text[1], text[2], text[3])
            return 0, 0
        elseif style == "minimal" then
            Font(b.text, size, "")
            local col = out and T.SECTION or T.TEXT
            b.text:SetTextColor(col[1], col[2], col[3])
            b.text:SetPoint(out and "TOPRIGHT" or "TOPLEFT")
            return 0, 1
        else -- threads
            Font(b.text, size, flags)
            b.text:SetPoint("TOPLEFT")
            b.text:SetTextColor(text[1], text[2], text[3])
            return 0, 1
        end
    end

    -- Threads: a small tile per run, and a soft card behind their runs.
    local function Tile(i)
        local t = log.tiles[i]
        if t then return t end
        t = CreateFrame("Frame", nil, log)
        t:SetSize(THREAD_TILE, THREAD_TILE)
        t.bg = T.ShapeFill(t, { 1, 1, 1, 1 }, 6)
        t.letter = T.Text(t, 11, nil, "")
        t.letter:SetPoint("CENTER", 0, 0)
        log.tiles[i] = t
        return t
    end
    local function Card(i)
        local f = log.cards[i]
        if f then return f end
        f = CreateFrame("Frame", nil, log)
        f:SetFrameLevel(log:GetFrameLevel())
        f.bg = T.ShapeFill(f, { 1, 1, 1, 0.035 }, 8)
        log.cards[i] = f
        return f
    end

    local EMOTE_BIG = 32 -- emote-only messages show their emotes at this height
    local function EmoteOnly(text)
        if type(text) ~= "string" or not ns.Readable(text) or not text:find("|T", 1, true) then return false end
        -- Twitch Emotes wraps each picture in a link (|Htemote:…|h…|h) and
        -- may colour it; only the pictures themselves may remain.
        local rest = text:gsub("|T.-|t", ""):gsub("|H.-|h", ""):gsub("|h", "")
            :gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        return rest:match("^%s*$") ~= nil
    end

    local function PlayerInitial()
        local n = UnitName and UnitName("player")
        if type(n) ~= "string" or not ns.Readable(n) then return "Y" end
        return n:match("^[%z\1-\127\194-\244][\128-\191]*") or "Y"
    end

    local function HeadFont(h, size, flags)
        if h.wsSize ~= size or h.wsFlags ~= flags then T.StyleText(h, size, flags) end
    end

    -- Message selection: whole messages (WoW cannot select inside a FontString).
    local driver = CreateFrame("Frame", nil, log)
    -- Ctrl+C copies the highlighted messages (the keys still reach the game).
    local keys = CreateFrame("Frame", nil, log)
    pcall(keys.SetPropagateKeyboardInput, keys, true)
    -- CopyToClipboard is protected, so (like the chat's own selection) pressing Ctrl
    -- focuses a hidden, pre-highlighted edit box and the game's Ctrl+C copies from it.
    local grab
    local function Unprime()
        if grab and grab:IsShown() then grab:ClearFocus() grab:Hide() end
    end
    local function Prime()
        local text = log:SelectionText()
        if not text then return end
        if not grab then
            grab = CreateFrame("EditBox", nil, UIParent)
            grab:SetSize(20, 20)
            grab:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -100, 100)
            grab:SetFontObject(ChatFontNormal or GameFontNormal)
            grab:SetAutoFocus(false)
            grab:SetMaxLetters(0)
            grab:SetScript("OnKeyUp", function(_, key)
                if key == "C" or key == "LCTRL" or key == "RCTRL" or key == "LMETA" or key == "RMETA" then Unprime() end
            end)
            grab:SetScript("OnEscapePressed", Unprime)
            grab:SetScript("OnEditFocusLost", function(f) f:Hide() end)
        end
        grab:Show()
        grab:SetText(text)
        grab:SetFocus()
        grab:HighlightText()
        C_Timer.After(4, Unprime)
    end
    keys:SetScript("OnKeyDown", function(_, key)
        pcall(keys.SetPropagateKeyboardInput, keys, true)
        if not (log.selLo or log:HasChar()) then return end
        if key == "ESCAPE" then
            log:ClearSelect()
            pcall(keys.SetPropagateKeyboardInput, keys, false) -- Escape only clears the highlight
            C_Timer.After(0, function() pcall(keys.SetPropagateKeyboardInput, keys, true) end)
        elseif key == "LCTRL" or key == "RCTRL" or key == "LMETA" or key == "RMETA" then
            Prime()
        end
    end)
    function log:PaintSel()
        local lo, hi = self.selLo, self.selHi
        for _, b in ipairs(self.bubbles) do
            b.sel:SetShown(lo ~= nil and b:IsShown() and b.msgIdx ~= nil and b.msgIdx >= lo and b.msgIdx <= hi)
        end
    end
    function log:ClearSelect()
        self.selLo, self.selHi, self.selAnchor, self.selDrag = nil, nil, nil, nil
        self:ClearChar()
        driver:SetScript("OnUpdate", nil)
        keys:EnableKeyboard(false)
        self:PaintSel()
    end
    function log:BeginSelect(idx)
        self:ClearSelect()
        self.selAnchor, self.selDrag, self.selMoved = idx, true, nil
        self.selX, self.selY = GetCursorPosition()
        driver:SetScript("OnUpdate", function()
            -- a plain click must not light the bubble: wait for a real drag
            local cx, cy = GetCursorPosition()
            if not log.selMoved then
                if math.abs(cx - log.selX) + math.abs(cy - log.selY) < 8 then return end
                log.selMoved = true
            end
            local hit
            for _, b in ipairs(log.bubbles) do
                if b:IsShown() and b.msgIdx and b:IsMouseOver() then hit = b.msgIdx break end
            end
            if not hit then return end
            local a = log.selAnchor
            local lo, hi = math.min(a, hit), math.max(a, hit)
            if lo ~= log.selLo or hi ~= log.selHi then
                log.selLo, log.selHi = lo, hi
                log:PaintSel()
            end
        end)
    end
    function log:RangeText(lo, hi)
        local X, c = ns.ChatX, self.convo
        if not (X and X.Plain and c) then return nil end
        local lines = {}
        for k = lo, hi do
            local m = c.messages[k]
            if m then
                local who = m.out and (UnitName and UnitName("player") or "?") or (c.display or "?")
                lines[#lines + 1] = date("%H:%M", m.t) .. "  " .. who .. ": " .. X.Plain(m.text)
            end
        end
        if lo == hi then
            local m = c.messages[lo]
            return X.Plain(m and m.text or "")
        end
        return table.concat(lines, string.char(10))
    end
    function log:SelectionText()
        if self:HasChar() then
            local ok, t = pcall(self.CharText, self)
            if ok and t then return t end
        end
        if not self.selLo then return nil end
        return self:RangeText(self.selLo, self.selHi)
    end
    function log:CopyRange(lo, hi, title)
        local X = ns.ChatX
        local text = self:RangeText(lo, hi)
        if X and X.ShowText and text then X.ShowText(title, text) end
    end
    function log:CopySelection()
        if self:HasChar() then
            local X, text = ns.ChatX, self:SelectionText()
            if X and X.ShowText and text then X.ShowText(L["Copy selection"], text) end
            return
        end
        if not self.selLo then return end
        self:CopyRange(self.selLo, self.selHi, self.selLo == self.selHi and L["Copy message"] or L["Copy selection"])
    end
    function log:EndSelect()
        self:EndChar()
        if not self.selDrag then return end
        self.selDrag = nil
        driver:SetScript("OnUpdate", nil)
        local lo, hi = self.selLo, self.selHi
        if not lo then return end -- a plain click: nothing selected
        keys:EnableKeyboard(true) -- the highlight stays; Ctrl+C copies it
    end

    -- Character selection: drag inside the text to highlight characters, across
    -- messages too. The highlight is drawn with our own textures over the
    -- wrapped lines of each message's ScrollingMessageFrame (smf.visibleLines),
    -- so it stays after release. Points are { idx = message number, k = atom
    -- boundary in that message's text }; they survive re-rendering and scrolling.
    local layer = CreateFrame("Frame", nil, log)
    layer:SetAllPoints(log)
    layer:SetFrameLevel(log:GetFrameLevel() + 20)
    local pool = {}
    local mf = driver:CreateFontString(nil, "OVERLAY")
    mf:SetWordWrap(false)
    mf:SetJustifyH("LEFT")
    local mfKey, dotW

    local function Before(a, b) -- a strictly before b
        return a.idx < b.idx or (a.idx == b.idx and a.k < b.k)
    end

    function log:CharMode(b)
        local s = b.smf
        return (s and s.charOK and b.body ~= nil and s:IsShown()) and true or false
    end

    function log:HasChar()
        local cs = self.csel
        if not (cs and cs.anchor and cs.cur) then return false end
        return cs.anchor.idx ~= cs.cur.idx or cs.anchor.k ~= cs.cur.k
    end

    -- Width of the first j atoms of a wrapped line, in the line's own font.
    local function WidthOf(ln, j)
        if j <= 0 then return 0 end
        local la = ln.la
        local wt = la.w[ln.fk]
        if not wt then wt = {} la.w[ln.fk] = wt end
        local w = wt[j]
        if w then return w end
        local ok, res = pcall(function()
            if mfKey ~= ln.fk then
                if mf:SetFont(ln.path, ln.size, ln.flags) == false then error("font") end
                mfKey, dotW = ln.fk, nil
            end
            if not dotW then
                mf:SetText(".")
                dotW = mf:GetStringWidth()
            end
            -- a trailing "." keeps trailing spaces counted
            mf:SetText(table.concat(la.disp, "", 1, j) .. ".")
            return mf:GetStringWidth() - dotW
        end)
        if not (ok and type(res) == "number" and ns.Readable(res)) then return nil end
        wt[j] = res
        return res
    end

    -- Where the line's text starts inside its fontstring (right-aligned lines).
    local function LineBase(ln)
        if ln.base then return ln.base end
        local base = 0
        pcall(function()
            local just = ln.fs:GetJustifyH()
            if just == "RIGHT" or just == "CENTER" then
                local w1, w0 = WidthOf(ln, ln.k1 - ln.lo), WidthOf(ln, ln.k0 - ln.lo)
                local full, fw = (w1 and w0) and (w1 - w0) or nil, ln.fs:GetWidth()
                if full and type(fw) == "number" and ns.Readable(fw) then
                    base = (just == "RIGHT") and (fw - full) or ((fw - full) / 2)
                    if base < 0 then base = 0 end
                end
            end
        end)
        ln.base = base
        return base
    end

    -- x of atom boundary j (an index into the line's own atoms, ln.la), measured
    -- from the left edge of the row (a wrapped message is split into rows).
    local function XOf(ln, j)
        local w = WidthOf(ln, j)
        if not w then return nil end
        return LineBase(ln) + w - (ln.xoff or 0)
    end

    -- Nearest atom boundary of the row to x (relative to the row's left edge);
    -- returns an offset from the row's first atom (0..row length).
    local function IndexForX(ln, relx)
        relx = relx - LineBase(ln) + (ln.xoff or 0)
        local base = ln.k0 - ln.lo
        local lo, hi = base, ln.k1 - ln.lo
        local m = hi
        while lo < hi do
            local mid = math.floor((lo + hi + 1) / 2)
            local w = WidthOf(ln, mid)
            if not w then return nil end
            if w <= relx then lo = mid else hi = mid - 1 end
        end
        if lo < m then
            local w0, w1 = WidthOf(ln, lo), WidthOf(ln, lo + 1)
            if w0 and w1 and (w1 - relx) < (relx - w0) then lo = lo + 1 end
        end
        return lo - base
    end

    -- The wrapped lines of one message, top to bottom, each matched to the
    -- atoms of the message it shows. nil when that can't be worked out.
    local function ResolveLines(b)
        local smf = b.smf
        local vis = smf and smf.visibleLines
        if type(vis) ~= "table" or b.body == nil then return nil end
        local list = {}
        for _, fs in ipairs(vis) do
            if type(fs) == "table" and fs.IsShown and fs:IsShown() then
                local top = fs:GetTop()
                if top then list[#list + 1] = { fs = fs, top = top, bottom = fs:GetBottom() or top } end
            end
        end
        table.sort(list, function(x, y) return x.top > y.top end)
        local B = Atoms(b.body)
        local p, out = 0, {}
        for _, ln in ipairs(list) do
            local ok, lt = pcall(ln.fs.GetText, ln.fs)
            if not (ok and type(lt) == "string" and ns.Readable(lt)) then return nil end
            local la = Atoms(lt)
            local m = la.n
            if m > 0 then
                local found
                for s = p, math.min(p + 4, B.n - m) do
                    local good = true
                    for q = 1, m do
                        if B.keys[s + q] ~= la.keys[q] then good = false break end
                    end
                    if good then found = s break end
                end
                if not found then return nil end
                local okF, path, size, flags = pcall(ln.fs.GetFont, ln.fs)
                if not (okF and path) then return nil end
                ln.la, ln.k0, ln.k1, ln.lo = la, found, found + m, found
                ln.path, ln.size, ln.flags = path, size, flags
                ln.fk = tostring(path) .. "|" .. tostring(size) .. "|" .. tostring(flags)
                out[#out + 1] = ln
                p = found + m
            end
        end
        if #out == 0 then return nil end
        -- A wrapped message is ONE fontstring holding several rows: split it into
        -- its visual rows (greedy by measured width) so highlights go row by row.
        local rowsOut = {}
        for _, ln in ipairs(out) do
            local rows
            local okW, W = pcall(ln.fs.GetWidth, ln.fs)
            local okH, H = pcall(ln.fs.GetStringHeight, ln.fs)
            if okW and okH and type(W) == "number" and type(H) == "number" and ns.Readable(W) and ns.Readable(H) and W > 0 and H > 0 then
                local la, n = ln.la, ln.la.n
                local first = WidthOf(ln, 1)
                if first and n > 1 then
                    rows = {}
                    local a = 0
                    while a < n and #rows < 60 do
                        local xa = WidthOf(ln, a) or 0
                        local lo, hi = a, n
                        while lo < hi do
                            local mid = math.floor((lo + hi + 1) / 2)
                            local x = WidthOf(ln, mid)
                            if not x then rows = nil break end
                            if x - xa <= W + 0.5 then lo = mid else hi = mid - 1 end
                        end
                        if not rows then break end
                        local bnd = lo
                        if bnd <= a then bnd = a + 1 end
                        if bnd < n and la.disp[bnd + 1] ~= " " then
                            local j = bnd
                            while j > a and la.disp[j] ~= " " do j = j - 1 end
                            if j > a then bnd = j end
                        end
                        rows[#rows + 1] = { a = a, b = bnd }
                        a = bnd
                    end
                end
                if rows and #rows > 1 then
                    local rh = H / #rows
                    for r, row in ipairs(rows) do
                        rowsOut[#rowsOut + 1] = {
                            fs = ln.fs, la = la, path = ln.path, size = ln.size, flags = ln.flags, fk = ln.fk,
                            lo = ln.lo, k0 = ln.lo + row.a, k1 = ln.lo + row.b,
                            xoff = WidthOf(ln, row.a) or 0, yoff = (r - 1) * rh, rh = rh,
                            top = ln.top - (r - 1) * rh, bottom = ln.top - r * rh,
                        }
                    end
                else
                    rowsOut[#rowsOut + 1] = ln
                end
            else
                rowsOut[#rowsOut + 1] = ln
            end
        end
        return rowsOut
    end

    -- Cursor (raw GetCursorPosition values) -> { idx, k } in the nearest message.
    local function HitAt(cx, cy)
        local sc = log:GetEffectiveScale()
        if not sc or sc == 0 then return nil end
        local x, y = cx / sc, cy / sc
        local best, bestD
        for _, b in ipairs(log.bubbles) do
            if b:IsShown() and b.msgIdx and b.body ~= nil then
                local top, bot = b:GetTop(), b:GetBottom()
                if top and bot then
                    local d = (y > top) and (y - top) or ((y < bot) and (bot - y) or 0)
                    if not bestD or d < bestD then best, bestD = b, d end
                end
            end
        end
        if not best then return nil end
        local b = best
        local n = Atoms(b.body).n
        local top, bot = b:GetTop(), b:GetBottom()
        if y > top then return { idx = b.msgIdx, k = 0 } end
        if y < bot then return { idx = b.msgIdx, k = n } end
        local lines = log:CharMode(b) and ResolveLines(b)
        if not lines then
            local l, r = b:GetLeft(), b:GetRight()
            return { idx = b.msgIdx, k = (l and r and x > (l + r) / 2) and n or 0 }
        end
        if y > lines[1].top then return { idx = b.msgIdx, k = lines[1].k0 } end
        local ln
        for _, l in ipairs(lines) do
            ln = l
            if y >= l.bottom then break end
        end
        if y < ln.bottom then return { idx = b.msgIdx, k = ln.k1 } end
        local left = ln.fs:GetLeft()
        local j
        if left then
            local okJ, res = pcall(IndexForX, ln, x - left)
            if okJ then j = res end
        end
        if not j then
            local c = ln.fs:GetCenter()
            j = (c and x > c) and (ln.k1 - ln.k0) or 0
        end
        return { idx = b.msgIdx, k = ln.k0 + j }
    end

    local function Quad(used)
        local t = pool[used]
        if not t then
            t = layer:CreateTexture(nil, "OVERLAY")
            t:SetColorTexture(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.35)
            pool[used] = t
        end
        t:ClearAllPoints()
        t:SetHeight(0)
        t:Show()
        return t
    end

    local function PaintBubble(b, a, e, used)
        local lines = log:CharMode(b) and ResolveLines(b)
        local whole = not lines
        if lines then
            local drawn = 0
            for _, ln in ipairs(lines) do
                local s, t = math.max(a, ln.k0), math.min(e, ln.k1)
                if t > s then
                    local x0, x1 = XOf(ln, s - ln.lo), XOf(ln, t - ln.lo)
                    if not (x0 and x1) then whole = true break end
                    used = used + 1
                    drawn = drawn + 1
                    local q = Quad(used)
                    if ln.rh then
                        q:SetPoint("TOPLEFT", ln.fs, "TOPLEFT", x0, -ln.yoff)
                        q:SetPoint("TOPRIGHT", ln.fs, "TOPLEFT", x1, -ln.yoff)
                        q:SetHeight(ln.rh)
                    else
                        q:SetPoint("TOPLEFT", ln.fs, "TOPLEFT", x0, 0)
                        q:SetPoint("BOTTOMRIGHT", ln.fs, "BOTTOMLEFT", x1, 0)
                    end
                end
            end
            if whole then used = used - drawn end
        end
        if whole then
            used = used + 1
            local q = Quad(used)
            q:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
            q:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
        end
        return used
    end

    function log:PaintChar()
        local used = 0
        local cs = self.csel
        if cs and cs.anchor and cs.cur then
            local lo, hi = cs.anchor, cs.cur
            if Before(hi, lo) then lo, hi = hi, lo end
            layer:SetFrameLevel(self:GetFrameLevel() + 20)
            for _, b in ipairs(self.bubbles) do
                local idx = b.msgIdx
                if b:IsShown() and idx and b.body ~= nil and idx >= lo.idx and idx <= hi.idx then
                    local n = Atoms(b.body).n
                    local a = (idx == lo.idx) and lo.k or 0
                    local e = (idx == hi.idx) and hi.k or n
                    a, e = math.max(0, a), math.min(n, e)
                    if e > a then
                        local ok, res = pcall(PaintBubble, b, a, e, used)
                        if ok and type(res) == "number" then used = res end
                    end
                end
            end
        end
        for i = used + 1, #pool do pool[i]:Hide() end
    end

    function log:ClearChar()
        self.csel = nil
        for _, t in ipairs(pool) do t:Hide() end
    end

    function log:BeginChar(b)
        self:ClearSelect()
        local cx, cy = GetCursorPosition()
        local cs = { dx = cx, dy = cy, lx = cx, ly = cy, drag = true, moved = false }
        self.csel = cs
        driver:SetScript("OnUpdate", function()
            if not IsMouseButtonDown("LeftButton") then log:EndChar() return end
            local x, y = GetCursorPosition()
            if not cs.moved then
                if math.max(math.abs(x - cs.dx), math.abs(y - cs.dy)) < 6 then return end
                local okA, p = pcall(HitAt, cs.dx, cs.dy)
                if not (okA and p) then return end
                cs.anchor, cs.moved = p, true
                log.suppressLink = true -- releasing over a link must not open it
            elseif x == cs.lx and y == cs.ly then
                return
            end
            cs.lx, cs.ly = x, y
            local okC, p = pcall(HitAt, x, y)
            if okC and p and (not cs.cur or p.idx ~= cs.cur.idx or p.k ~= cs.cur.k) then
                cs.cur = p
                log:PaintChar()
            end
        end)
    end

    function log:EndChar()
        local cs = self.csel
        if not (cs and cs.drag) then return end
        cs.drag = nil
        if self:HasChar() then
            keys:EnableKeyboard(true) -- the highlight stays; Ctrl+C copies it
            -- any new left click (on the log or elsewhere) clears it
            driver:SetScript("OnUpdate", function()
                if IsMouseButtonDown("LeftButton") then log:ClearSelect() end
            end)
        else
            self:ClearSelect()
        end
        if self.suppressLink then
            C_Timer.After(0.25, function() log.suppressLink = nil end)
        end
    end

    function log:CharText()
        local c, X = self.convo, ns.ChatX
        local cs = self.csel
        if not (c and cs and cs.anchor and cs.cur) then return nil end
        local lo, hi = cs.anchor, cs.cur
        if Before(hi, lo) then lo, hi = hi, lo end
        local style = ns.WhisperStyle()
        local name = c.display or "?"
        local out = {}
        for idx = lo.idx, hi.idx do
            local m = c.messages[idx]
            if m then
                local okB, body = pcall(BuildBody, c, m, style, name)
                if okB then
                    local A = Atoms(body)
                    local a = (idx == lo.idx) and lo.k or 0
                    local e = (idx == hi.idx) and hi.k or A.n
                    a, e = math.max(0, a), math.min(A.n, e)
                    if e > a then
                        local piece
                        if a == 0 and e == A.n and style ~= "classic" and X and X.Plain then
                            local okP, pl = pcall(X.Plain, m.text)
                            if okP and type(pl) == "string" then piece = pl end
                        end
                        out[#out + 1] = piece or table.concat(A.plain, "", a + 1, e)
                    end
                end
            end
        end
        if #out == 0 then return nil end
        return table.concat(out, string.char(10))
    end

    log:HookScript("OnHide", function() log:ClearSelect() end)

    -- Show a conversation from its newest message, with no entry animation.
    function log:Reset(c)
        self.convo = c
        self:ClearSelect()
        self.scroll = 0
        self.lastCount = c and #c.messages or 0
    end

    function log:Render(c)
        if c then self.convo = c end
        c = self.convo
        local msgs = c and c.messages or {}
        -- A frame shown (or moved) this very frame can report a 0 size until
        -- the game lays it out. Use the known size and lay out again next frame.
        local width, height = self:GetWidth() or 0, self:GetHeight() or 0
        if width < 40 or height < 40 then
            if not self.retryQueued then
                self.retryQueued = true
                C_Timer.After(0, function()
                    self.retryQueued = nil
                    if self:IsVisible() then self:Render() end
                end)
            end
            width = math.max(width, self.fallbackW or 0)
            height = math.max(height, self.fallbackH or 0)
            if width < 40 or height < 40 then return end
        end
        local style = ns.WhisperStyle()
        local textMax
        if style == "threads" then
            textMax = math.floor(width - THREAD_X - 6)
        elseif style == "classic" then
            textMax = math.floor(width)
        elseif style == "signal" then
            textMax = math.floor(width * 0.80) - 24
        elseif style == "bubbles" then
            textMax = math.floor(width * self.widthFrac) - BUB_X * 2
        else
            textMax = math.floor(width * self.widthFrac) - PAD_X - RAIL
        end
        local useStamps = self.useStamps and style ~= "classic" and style ~= "minimal"
        local name = c and c.display or "?"
        local y = (style == "threads" and 6 or 2) + 3 -- a little room so the newest line's descenders are not clipped by the log
        local used, headsUsed, stampsUsed, tilesUsed, cardsUsed = 0, 0, 0, 0, 0
        local runBottom

        for i = #msgs - self.scroll, 1, -1 do
            local m = msgs[i]
            local prev = msgs[i - 1]
            used = used + 1
            if not runBottom then runBottom = y end
            local b = Line(used)
            b.msg, b.msgIdx = m, i
            b.sel:SetShown(self.selLo ~= nil and i >= self.selLo and i <= self.selHi)
            local rail, text = SideColors(c, m.out)
            local padX, padY = Paint(b, style, m.out, rail, text)
            b.text:SetWidth(textMax)
            local body = BuildBody(c, m, style, name)
            -- A message that's only emotes: no bubble, wash or rail, a bit bigger.
            local emoteOnly = (style ~= "classic" and EmoteOnly(body)) or m.sys
            if m.sys then body = "|cff9aa0a6" .. (m.text or "") .. "|r" end
            if emoteOnly then
                body = body:gsub("(|T[^:|]+):(%d+):(%d+)", function(path, h, w)
                    h, w = tonumber(h) or 0, tonumber(w) or 0
                    local scale = (h > 0 and h < EMOTE_BIG) and (EMOTE_BIG / h) or 1
                    return ("%s:%d:%d"):format(path, math.floor(h * scale + 0.5), math.floor(w * scale + 0.5))
                end)
                b.bubble:Hide()
                b.signalFill:Hide()
                b.time:Hide()
                b.wash:Hide()
                b.rail:Hide()
                b.text:ClearAllPoints()
                b.text:SetPoint((m.out and style ~= "threads") and "TOPRIGHT" or "TOPLEFT")
                padX, padY = 0, 1
            end
            b.body = body
            b.anim = type(body) == "string" and ns.Readable(body) and body:find("TwitchEmotes\\Emotes", 1, true) and true or false
            b.text:SetText(body)
            local tw
            if style == "classic" or style == "threads" then
                tw = textMax
            else
                tw = b.text.GetUnboundedStringWidth and b.text:GetUnboundedStringWidth() or b.text:GetStringWidth()
                tw = math.min(math.ceil(tw) + 2, textMax)
            end
            b.text:SetWidth(tw)
            local th = math.ceil(b.text:GetStringHeight())
            NativeText(b, body, tw, th)
            local timeH = style == "signal" and not emoteOnly and 14 or 0
            if timeH > 0 then
                b.time:SetText(date("%H:%M", m.t))
                tw = math.max(tw, 34)
            end
            b:SetSize(tw + padX, th + padY * 2 + timeH)
            b:ClearAllPoints()
            b.baseY = y
            if style == "threads" then
                b:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", THREAD_X, y)
            elseif m.out and style ~= "classic" then
                b:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, y)
            else
                b:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, y)
            end
            b:Show()
            y = y + th + padY * 2 + timeH

            local newDay = useStamps and (not prev or (m.t - prev.t) >= STAMP_GAP)
            local newRun = not prev or prev.out ~= m.out or (m.t - prev.t) >= RUN_BREAK or newDay
            if style == "signal" then
                y = y + (newRun and 10 or 4)
                runBottom = nil
            elseif style == "classic" then
                y = y + 2
            elseif newRun then
                headsUsed = headsUsed + 1
                local h = Head(headsUsed)
                h:ClearAllPoints()
                local time = date("%H:%M", m.t)
                if style == "threads" then
                    HeadFont(h, 12, "OUTLINE")
                    local who = m.out and ("|cff" .. Hex(T.TEXT) .. L["You"] .. "|r") or ("|cff" .. Hex(rail) .. name .. "|r")
                    h:SetText(who .. "  |cff" .. Hex(T.DIM) .. time .. "|r")
                    h:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", THREAD_X, y + 2)
                    local top = math.max(y + 2 + HEAD_H, runBottom + THREAD_TILE)
                    tilesUsed = tilesUsed + 1
                    local t = Tile(tilesUsed)
                    t:ClearAllPoints()
                    t:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 6, top)
                    if m.out then
                        T.Color(t.bg, 0.17, 0.19, 0.25, 1)
                        t.letter:SetText(PlayerInitial())
                        t.letter:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
                    else
                        T.Color(t.bg, rail[1], rail[2], rail[3], 1)
                        t.letter:SetText(c and ns.Initial(c) or "?")
                        t.letter:SetTextColor(0.08, 0.08, 0.1)
                    end
                    t:Show()
                    if not m.out then
                        cardsUsed = cardsUsed + 1
                        local f = Card(cardsUsed)
                        f:ClearAllPoints()
                        f:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, runBottom - 4)
                        f:SetSize(width, top - runBottom + 8)
                        local wk = (ns.db and ns.db.look.wash) or 1
                        local wc = (ns.db and ns.db.look.washColor) or { 1, 1, 1 }
                        T.Color(f.bg, wc[1], wc[2], wc[3], 0.035 * (wk <= 0 and 0 or math.max(0.5, wk)))
                        f:Show()
                    end
                    y = top + 4 + THREAD_GAP
                elseif style == "minimal" then
                    HeadFont(h, 9, "")
                    h:SetText("|cff" .. Hex(T.DIM) .. time .. "|r")
                    h:SetPoint(m.out and "BOTTOMRIGHT" or "BOTTOMLEFT", self, m.out and "BOTTOMRIGHT" or "BOTTOMLEFT", 0, y + 3)
                    y = y + 3 + 10 + 10
                else
                    HeadFont(h, 11, "OUTLINE")
                    local stamp = "|cff" .. Hex(T.DIM) .. " · " .. time .. "|r"
                    if m.out then
                        h:SetText("|cff" .. Hex(T.LABEL) .. L["You"] .. "|r" .. stamp)
                        h:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, y + HEAD_GAP)
                    else
                        h:SetText("|cff" .. Hex(rail) .. name .. "|r" .. stamp)
                        h:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, y + HEAD_GAP)
                    end
                    y = y + HEAD_GAP + HEAD_H + RUN_GAP
                end
                h:Show()
                runBottom = nil
            else
                y = y + (style == "rails" and LINE_GAP or (style == "bubbles" and 3 or 2))
            end

            if newDay then
                stampsUsed = stampsUsed + 1
                local s = Stamp(stampsUsed)
                s:ClearAllPoints()
                s:SetPoint("BOTTOM", self, "BOTTOM", 0, y + 1)
                s:SetText(StampText(m.t))
                s:Show()
                y = y + STAMP_H
            end
            if y > height then break end
        end
        for i = used + 1, #self.bubbles do self.bubbles[i]:Hide() end
        for i = headsUsed + 1, #self.heads do self.heads[i]:Hide() end
        for i = stampsUsed + 1, #self.stamps do self.stamps[i]:Hide() end
        for i = tilesUsed + 1, #self.tiles do self.tiles[i]:Hide() end
        for i = cardsUsed + 1, #self.cards do self.cards[i]:Hide() end

        for i = 1, used do
            T.StopTween(self.bubbles[i], "in")
            self.bubbles[i]:SetAlpha(1)
        end
        -- A message that just arrived (or was just sent) rises into place.
        local count = #msgs
        if self.lastCount and count > self.lastCount and self.scroll == 0 and used > 0 then
            local b = self.bubbles[1]
            local point, rel, relPoint, x = b:GetPoint()
            local baseY = b.baseY or 2
            T.Tween(b, "in", 0.22, 0, 1, function(v)
                b:SetAlpha(v)
                b:ClearAllPoints()
                b:SetPoint(point, rel, relPoint, x, baseY - 8 * (1 - v))
            end)
        end
        self.lastCount = count
        if self.csel and self.csel.anchor then
            self:PaintChar()
            -- the message frames may only re-wrap next frame
            C_Timer.After(0, function() if self.csel and self:IsVisible() then self:PaintChar() end end)
        end
        if self.onScroll then self.onScroll(self.scroll) end
    end

    log:SetScript("OnMouseWheel", function(self, delta)
        local cc = self.convo
        if not cc then return end
        self.scroll = math.max(0, math.min(#cc.messages - 1, self.scroll + delta))
        self:Render()
    end)

    return log
end
