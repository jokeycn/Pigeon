--[[
    Pigeon - Social extras
      - Quick replies: a row of one-click answers ("inv", "omw", ...) above
        the input in the whisper window and the hub. Click sends, Shift-click
        types it into the box instead so you can add to it.
      - Away message: answers a whisper automatically, once per person per
        15 minutes, always or only in instances / combat.
      - Notes: a short note per player, shown in tooltips, the hub and the
        window header.
      - Star / pin: starred conversations get a gold ring; pinned ones stay
        at the top of the dock and hub.
      - History search helper for the hub.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local Social = {}
ns.Social = Social

local STAR = { 1, 0.82, 0.2, 1 }
Social.STAR = STAR

---------------------------------------------------------------------------
-- Quick replies
---------------------------------------------------------------------------

function Social.Replies()
    local out = {}
    for _, r in ipairs(ns.db.quickReplies or {}) do
        if type(r) == "string" and strtrim(r) ~= "" then out[#out + 1] = strtrim(r) end
    end
    return out
end

-- getConvo() -> the conversation to send to; getEdit() -> its input box.
function Social.QuickBar(parent, getConvo, getEdit)
    local bar = CreateFrame("Frame", nil, parent)
    bar:SetHeight(24)
    bar:SetClipsChildren(true)
    bar.chips = {}
    local function Chip(i)
        local b = bar.chips[i]
        if b then return b end
        b = CreateFrame("Button", nil, bar)
        b:SetHeight(24)
        -- same rounded rectangle as the hub's filter chips
        b.bg = T.ShapeFill(b, T.INPUT_BG, 8)
        b.border = T.Border(b, T.INPUT_BORDER, 1, 8)
        b.text = T.Text(b, 11, T.LABEL, "")
        b.text:SetPoint("CENTER")
        b:SetScript("OnEnter", function(self)
            T.Color(self.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.18)
            T.SetBorderColor(self.border, T.ACCENT, 0.8)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine(L["Click: send  ·  Shift-click: add to the box"], T.SECTION[1], T.SECTION[2], T.SECTION[3])
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function(self)
            T.Color(self.bg, T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], T.INPUT_BG[4] or 1)
            T.SetBorderColor(self.border, T.INPUT_BORDER)
            GameTooltip:Hide()
        end)
        b:SetScript("OnClick", function(self)
            local edit = getEdit and getEdit()
            if IsShiftKeyDown() and edit then
                local cur = edit:GetText() or ""
                edit:SetText((cur ~= "" and (cur:gsub("%s*$", "") .. " ") or "") .. self.reply)
                edit:SetFocus()
            else
                ns.Send(getConvo(), self.reply)
            end
        end)
        bar.chips[i] = b
        return b
    end
    function bar:Refresh()
        local replies = Social.Replies()
        local x = 0
        for i, reply in ipairs(replies) do
            local b = Chip(i)
            b.reply = reply
            b.text:SetText(reply)
            T.Color(b.bg, T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], T.INPUT_BG[4] or 1)
            local w = math.ceil(b.text:GetStringWidth() or (#reply * 6)) + 20
            b:SetWidth(w)
            b:ClearAllPoints()
            b:SetPoint("LEFT", bar, "LEFT", x, 0)
            b:Show()
            x = x + w + 4
        end
        for i = #replies + 1, #bar.chips do bar.chips[i]:Hide() end
        self.count = #replies
    end
    bar:Refresh()
    return bar
end

function Social.QuickBarOn()
    return ns.db.showQuickReplies ~= false and #Social.Replies() > 0
end

---------------------------------------------------------------------------
-- Away message
---------------------------------------------------------------------------

local lastAway = {}
local AWAY_EVERY = 15 * 60

local function InInstance()
    local inside, kind = IsInInstance and IsInInstance()
    return inside and kind ~= "none"
end

function Social.AwayActive()
    local a = ns.db.away
    if not a or not a.enabled or strtrim(a.message or "") == "" then return false end
    if a.when == "instance" then return InInstance() end
    if a.when == "combat" then return InCombatLockdown and InCombatLockdown() or false end
    return true
end

-- Called for every incoming whisper after it's been recorded.
function Social.OnIncoming(c, text, flags)
    if not c or flags == "GM" or c.kind == "test" then return end
    if not Social.AwayActive() then return end
    if type(text) == "string" and ns.Readable(text) and text:find("^%s*<") then return end -- another auto-reply
    if InChatMessagingLockdown and InChatMessagingLockdown() then return end
    local now = GetTime and GetTime() or 0
    if lastAway[c.key] and now - lastAway[c.key] < AWAY_EVERY then return end
    lastAway[c.key] = now
    ns.Send(c, "<Away> " .. strtrim(ns.db.away.message), true)
end

function Social.ResetAway() wipe(lastAway) end

---------------------------------------------------------------------------
-- Notes
---------------------------------------------------------------------------

StaticPopupDialogs.PIGEON_NOTE = {
    text = L["Note for %s\n(shown in tooltips and the whisper header)"],
    button1 = ACCEPT or "Save",
    button2 = CANCEL or "Cancel",
    hasEditBox = true,
    maxLetters = 80,
    OnShow = function(self, c)
        local eb = (self.GetEditBox and self:GetEditBox()) or self.editBox or self.EditBox
        if eb then eb:SetText((c and c.note) or "") eb:HighlightText() end
    end,
    OnAccept = function(self, c)
        local eb = (self.GetEditBox and self:GetEditBox()) or self.editBox or self.EditBox
        Social.SetNote(c, eb and eb:GetText())
    end,
    EditBoxOnEnterPressed = function(self, c)
        Social.SetNote(c, self:GetText())
        self:GetParent():Hide()
    end,
    EditBoxOnEscapePressed = function(self) self:GetParent():Hide() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

function Social.SetNote(c, text)
    if not c then return end
    text = strtrim(text or "")
    c.note = text ~= "" and text or nil
    ns.Refresh()
end

function Social.EditNote(c)
    if not c then return end
    StaticPopup_Show("PIGEON_NOTE", c.display or "?", nil, c)
end

---------------------------------------------------------------------------
-- Conversation menu (hub rows, window name, dock tiles)
---------------------------------------------------------------------------

-- A local menu keeps conversation actions visually consistent with the
-- channel chooser and avoids putting them through Blizzard's menu manager.
local conversationMenu
local function PaintMenuRow(row,hot)
    local entry=row.entry
    if not entry then return end
    local color=entry.danger and {1,.38,.38} or T.ACCENT
    row.text:SetTextColor(color[1],color[2],color[3])
    T.Color(row.bg,T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],hot and .3 or (entry.selected and .24 or 0))
end

function Social.CloseMenu(instant)
    local menu=conversationMenu
    if not menu or not menu:IsShown()then return end
    if instant then
        T.StopTween(menu,"menu") menu:Hide() menu.closing=nil return
    end
    if menu.closing then return end
    menu.closing=true
    T.Spring(menu,"menu",menu.progress or 1,0,function(v)
        menu.progress=v menu:SetHeight(math.max(1,20+(menu.fullHeight-20)*v))
        menu:SetAlpha(math.max(0,math.min(1,v*3)))
    end,function()menu:Hide()menu.closing=nil end)
end

local function BuildConversationMenu()
    local menu=CreateFrame("Frame","PigeonConversationMenu",UIParent)
    menu:SetFrameStrata("FULLSCREEN_DIALOG") menu:SetToplevel(true) menu:EnableMouse(true)
    menu:SetClipsChildren(true) menu:SetClampedToScreen(true)
    menu.bg=T.ShapeFill(menu,T.INPUT_BG,10)
    menu.tint=T.ShapeFill(menu,{1,1,1,0},10,"BACKGROUND",1)
    menu.border=T.Border(menu,T.ACCENT,1,10)
    local content=CreateFrame("Frame",nil,menu)
    content:SetPoint("TOPLEFT") menu.content=content
    menu.title=T.Text(content,10,T.SECTION,"")
    menu.title.wsChatText=true T.StyleText(menu.title,10,"")
    menu.title:SetPoint("TOPLEFT",16,-10) menu.title:SetWordWrap(false)
    menu.rows={}
    menu.divider=content:CreateTexture(nil,"ARTWORK") menu.divider:SetHeight(1)
    menu:SetScript("OnHide",function()T.StopTween(menu,"menu")menu.closing=nil end)
    menu:SetScript("OnUpdate",function(self,dt)
        self.age=(self.age or 0)+dt
        if self.owner and not self.owner:IsVisible()then Social.CloseMenu()end
        local entry=self.owner and self.owner.entry
        if entry and entry.convo and entry.convo~=self.convo then Social.CloseMenu()end
    end)
    menu:RegisterEvent("GLOBAL_MOUSE_DOWN")
    menu:SetScript("OnEvent",function(self)
        if not self:IsShown() or (self.age or 0)<.15 or self:IsMouseOver()then return end
        if not self.cursor and self.owner and self.owner:IsMouseOver()then return end
        Social.CloseMenu()
    end)
    tinsert(UISpecialFrames,"PigeonConversationMenu")
    menu:Hide() conversationMenu=menu Social.menu=menu
    return menu
end

-- Ignore the person behind a whisper conversation (asks first: it is easy to hit by mistake).
StaticPopupDialogs.PIGEON_IGNORE_PLAYER={
    text="%s",
    button1=YES,button2=NO,
    OnAccept=function(_,data)
        if not data then return end
        local ok=pcall(C_FriendList.AddIgnore,data.target)
        if ok then ns.Print(L["%s is now ignored."]:format(data.display)) end
    end,
    timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
}
function Social.AskIgnore(c)
    local target=ns.WhisperTarget(c)
    if not target or target=="" then return end
    local display=c.display or target
    StaticPopupDialogs.PIGEON_IGNORE_PLAYER.text=L["Ignore %s? You won't see their whispers or chat until you remove them from your ignore list."]
    StaticPopup_Show("PIGEON_IGNORE_PLAYER",display,nil,{target=target,display=display})
end

function Social.Menu(owner,c)
    if not c then return false end
    local entries={
        {label=c.pinned and L["Unpin"] or L["Pin to top"],selected=c.pinned,fn=function()
            c.pinned=not c.pinned or nil ns.Refresh()
        end},
        {label=c.starred and L["Remove star"] or L["Star (important)"],selected=c.starred,fn=function()
            c.starred=not c.starred or nil ns.Refresh()
        end},
        {label=c.note and L["Edit note"] or L["Add note"],fn=function()Social.EditNote(c)end},
    }
    if c.kind=="wow"then
        entries[#entries+1]={label=L["Invite"],fn=function()ns.Invite(ns.WhisperTarget(c),c.guid)end}
        entries[#entries+1]={label=L["Who is this?"],fn=function()ns.WhoLookup(c)end}
    end
    if c.hubHidden then
        entries[#entries+1]={label=L["Show conversation"],divider=true,fn=function()
            c.hubHidden=nil c.hidden=nil ns.Refresh()
        end}
    else
        -- Closes the tile only; the x on a hub card is what files a chat under Hidden.
        entries[#entries+1]={label=L["Close conversation"],divider=true,fn=function()
            c.hidden=true c.unread=0 ns.Refresh()
        end}
    end
    if c.kind=="wow" and C_FriendList and C_FriendList.AddIgnore then
        entries[#entries+1]={label=L["Ignore"],danger=true,fn=function()
            Social.AskIgnore(c)
        end}
    end
    entries[#entries+1]={label=L["Delete conversation"],danger=true,fn=function()
        ns.AskDeleteConvo(c)
    end}
    entries[#entries+1]={label=L["Clear history"],danger=true,fn=function()
        wipe(c.messages)c.unread=0 c.hidden=true ns.Refresh()
    end}
    return Social.OpenMenu(owner,c.display or "?",entries,{convo=c})
end

-- Shared renderer for conversation actions and player-name chat actions.
function Social.OpenMenu(owner,title,entries,opts)
    opts=opts or {}
    local menu=conversationMenu or BuildConversationMenu()
    if menu:IsShown() and not menu.closing and menu.owner==owner and menu.context==(opts.convo or title) then
        Social.CloseMenu() return true
    end
    T.StopTween(menu,"menu") menu.closing=nil
    menu.entries=entries menu.owner=owner menu.convo=opts.convo menu.context=opts.convo or title menu.cursor=opts.cursor menu.age=0
    menu.title:SetText(title)
    menu.divider:Hide()
    local width=math.max(190,math.min(280,(menu.title:GetStringWidth() or 0)+32))
    local y=30
    for i,entry in ipairs(entries)do
        if entry.divider then
            menu.divider:Show()
            menu.divider:ClearAllPoints()
            menu.divider:SetPoint("TOPLEFT",menu.content,"TOPLEFT",12,-y-5)
            menu.divider:SetPoint("TOPRIGHT",menu.content,"TOPRIGHT",-12,-y-5)
            menu.divider:SetColorTexture(T.DIVIDER[1],T.DIVIDER[2],T.DIVIDER[3],T.DIVIDER[4])
            y=y+12
        end
        local row=menu.rows[i]
        if not row then
            row=CreateFrame("Button",nil,menu.content) row:SetHeight(24)
            row.bg=T.ShapeFill(row,{1,1,1,0},10)
            row.text=T.Text(row,12,T.ACCENT,"") row.text.wsChatText=true T.StyleText(row.text,12,"")
            row.text:SetPoint("LEFT",10,0)row.text:SetPoint("RIGHT",-10,0)row.text:SetJustifyH("LEFT")
            row.text:SetWordWrap(false)
            row:SetScript("OnEnter",function(self)PaintMenuRow(self,true)end)
            row:SetScript("OnLeave",function(self)PaintMenuRow(self,false)end)
            row:SetScript("OnClick",function(self)
                local fn=self.entry and self.entry.fn
                Social.CloseMenu(true)
                if fn then fn()end
            end)
            menu.rows[i]=row
        end
        row.entry=entry row.text:SetText(entry.label)
        row:ClearAllPoints()row:SetPoint("TOPLEFT",6,-y)row:Show()
        PaintMenuRow(row,false)
        width=math.max(width,(row.text:GetStringWidth() or 0)+32)
        y=y+24
    end
    for i=#entries+1,#menu.rows do menu.rows[i]:Hide()end
    for _,row in ipairs(menu.rows)do row:SetWidth(width-12)end
    menu.title:SetWidth(width-32)
    menu.fullHeight=y+6 menu.content:SetSize(width,menu.fullHeight)
    menu:SetWidth(width)
    T.Color(menu.bg,T.INPUT_BG[1],T.INPUT_BG[2],T.INPUT_BG[3],.97)
    T.Color(menu.tint,T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],.08)
    T.SetBorderColor(menu.border,T.ACCENT,.45)
    menu.title:SetTextColor(T.SECTION[1],T.SECTION[2],T.SECTION[3])
    menu:ClearAllPoints()
    if opts.cursor and GetCursorPosition then
        local x,y=GetCursorPosition()
        local scale=UIParent:GetEffectiveScale()
        menu:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",x/scale+4,y/scale-4)
    else
        menu:SetPoint("TOPRIGHT",owner or UIParent,"BOTTOMRIGHT",0,-6)
    end
    GameTooltip:Hide() menu:Show()menu:Raise()
    T.Spring(menu,"menu",0,1,function(v)
        menu.progress=v menu:SetHeight(math.max(1,20+(menu.fullHeight-20)*v))
        menu:SetAlpha(math.max(0,math.min(1,v*3)))
    end)
    return true
end

---------------------------------------------------------------------------
-- History search
---------------------------------------------------------------------------

-- Newest message in c whose text contains q (lower-case); returns index, text.
function Social.FindInHistory(c, q)
    if not q or #q < 2 then return nil end
    for i = #c.messages, 1, -1 do
        local t = c.messages[i].text
        if type(t) == "string" and ns.Readable(t) then
            local plain = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|H.-|h(.-)|h", "%1"):gsub("|T.-|t", "")
            if plain:lower():find(q, 1, true) then return i, plain end
        end
    end
end
