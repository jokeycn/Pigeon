--[[
    Pigeon - Dock
    A permanent stack button with class-coloured tiles above it, newest on
    top, plus an Augment-style preview toast for new whispers.
      - Click a tile: open that conversation in the docked window.
      - Click the stack button: open the whisper hub.
    Panels open to the left or right of the dock; "auto" picks the side that
    faces the middle of the screen.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local TILE, GAP = 44, 6 -- TILE shrinks to 36 when the dock lives in the chat box's tab bar
local PANEL_GAP = 12
local SLIDE = 14

local function Over(f)
    if f.IsMouseOver then return f:IsMouseOver() end
    return MouseIsOver(f)
end

local Dock = CreateFrame("Frame", "PigeonDock", UIParent)
ns.Dock = Dock
Dock:SetSize(TILE, TILE)
Dock:SetMovable(true)
Dock:SetClampedToScreen(true)
Dock:SetFrameStrata("MEDIUM")
Dock.byKey = {}   -- convo key -> tile
Dock.pool = {}    -- released tiles
Dock.list = {}

---------------------------------------------------------------------------
-- Side: which way panels open from the dock
---------------------------------------------------------------------------

function Dock:Side()
    if self.attached then return "right" end -- in the chat's corner, panels open over the chat side
    local x = self:GetCenter()
    local w = UIParent:GetWidth()
    if x and w and w > 0 and x < w / 2 then return "right" end
    return "left"
end

-- Free-standing dock: which way the tiles grow from the stack button. Vertical
-- (default) stacks up or down, horizontal goes right or left, whichever way has
-- room on screen. Re-evaluated whenever the dock moves.
function Dock:Dir()
    if self.attached then return "up" end
    local horizontal = ns.db.dockHorizontal
    local l, b, w, h = self:GetRect()
    if not l then return self.dir or (horizontal and "right" or "up") end
    local s = self:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local need = ((ns.db.maxTiles or 6) * (TILE + GAP) + GAP) * s
    local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
    l, b, w, h = l * s, b * s, w * s, h * s
    if horizontal then
        local right, left = sw - (l + w), l
        return (right >= need or right >= left) and "right" or "left"
    end
    local above, below = sh - (b + h), b
    return (above >= need or above >= below) and "up" or "down"
end

function Dock:PlacePanel(frame)
    if self:Side() == "right" then
        T.Place(frame, "BOTTOMLEFT", self, "BOTTOMRIGHT", PANEL_GAP, 0)
    else
        T.Place(frame, "BOTTOMRIGHT", self, "BOTTOMLEFT", -PANEL_GAP, 0)
    end
end

-- Horizontal offset a panel starts from so it slides out of the dock.
function Dock:SlideX()
    return self:Side() == "right" and -SLIDE or SLIDE
end

---------------------------------------------------------------------------
-- Moving (Shift-drag any tile or the stack button)
---------------------------------------------------------------------------

local function StartMove()
    if Dock.attached == "elvui" then return end -- rides ElvUI's chat; move that with /moveui
    if Dock.attached then -- Shift-drag moves the chat box even while it is locked
        if IsShiftKeyDown() then ns.Chat:StartDrag(true) end
        return
    end
    if IsShiftKeyDown() and not ns.UsesMovers() then
        Dock:SetMovable(true) -- LibEditMode may have switched it off
        Dock:StartMoving()
        Dock.moving = true
    end
end

local function StopMove()
    if Dock.attached == "elvui" then return end
    if Dock.attached then ns.Chat:StopDrag() return end
    if not Dock.moving then return end
    Dock:StopMovingOrSizing()
    Dock.moving = nil
    local point, _, relPoint, x, y = Dock:GetPoint()
    ns.db.point = { point, relPoint, x, y }
    if ns.EditMode then ns.EditMode.NoteMoved("dock") end
    Dock:Relayout()
end

function Dock:ApplyPosition()
    if self.attached == "chat" then
        -- The stack button sits at the left end of the chat's tab bar.
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", ns.Chat, "TOPLEFT", ns.Chat.stackInset or 0, 0)
        self:Relayout()
        return
    elseif self.attached == "elvui" then
        -- Left end of ElvUI's tab strip, which sits 3px above its chat frame.
        self:ClearAllPoints()
        self:SetPoint("BOTTOMLEFT", ns.ElvUI.dockHost, "TOPLEFT", 0, 3)
        self:Relayout()
        return
    end
    if ns.UsesMovers() then self:Relayout() return end -- a UI suite's mover owns the position
    local p = ns.db.point
    self:ClearAllPoints()
    self:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    self:Relayout()
end

-- Re-anchor anything open after a move or a side change.
function Dock:Relayout()
    if self.allBtn and not self.attached then self:Update() end -- tile direction depends on where the dock is
    if not self.preview then return end
    ns.Window:Reanchor()
    if self.preview:IsShown() then self.preview:Hide() end
end

---------------------------------------------------------------------------
-- Tiles (shared with the window header and the hub list)
---------------------------------------------------------------------------

-- Shared Island-style counter: round ends, centered light text, no outer backing.
function ns.MakeBadge(parent, height)
    height = math.max(18, height or 18)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(height,height)
    f:EnableMouse(false)
    local left = f:CreateTexture(nil,"ARTWORK") T.Circle(left)
    left:SetTexCoord(0,0.5,0,1) left:SetSize(height/2,height) left:SetPoint("LEFT")
    local right = f:CreateTexture(nil,"ARTWORK") T.Circle(right)
    right:SetTexCoord(0.5,1,0,1) right:SetSize(height/2,height) right:SetPoint("RIGHT")
    local middle = f:CreateTexture(nil,"ARTWORK")
    middle:SetPoint("TOPLEFT",left,"TOPRIGHT") middle:SetPoint("BOTTOMRIGHT",right,"BOTTOMLEFT")
    -- Compatibility handles for callers; the old expanded outline is permanently hidden.
    f.outline = f:CreateTexture(nil,"BACKGROUND") f.outline:Hide()
    f.fill = left
    f.parts = {left,middle,right}
    f.text = T.Text(f,12,T.TEXT,"")
    f.text:SetAllPoints(f) f.text:SetJustifyH("CENTER") f.text:SetJustifyV("MIDDLE")
    function f:Refresh()
        for _,tex in ipairs(self.parts) do T.Color(tex,0,0,0,1) end
        self.text:SetTextColor(T.TEXT[1],T.TEXT[2],T.TEXT[3],1)
        self.outline:Hide()
    end
    function f:SetCount(n)
        local value = n > 99 and "99+" or tostring(n)
        self.text:SetText(value)
        -- Keep one digit circular; longer counts grow into a capsule.
        local w = #value == 1 and height or math.max(height,self.text:GetStringWidth()+10,#value*7+10)
        self:SetWidth(w)
        middle:SetShown(w > height)
        self:Refresh()
    end
    f:Refresh() middle:Hide() f:Hide()
    return f
end

local tiles = setmetatable({}, { __mode = "k" }) -- every tile, for live corner changes

-- The mask rounds the square class icon and banner; on = add it, off = take it away.
local function TileMask(b, on)
    if on then
        if b.maskOn then return end
        if not b.mask and b.CreateMaskTexture and b.icon.AddMaskTexture then
            local ok = pcall(function()
                b.mask = b:CreateMaskTexture()
                b.mask:SetAllPoints(b)
                T.ShapeMask(b.mask, (b.wsSlot and 4) or b.wsRadius) -- same corners as the tile itself
            end)
            if not ok then b.mask = nil end
        end
        if b.mask then
            b.icon:AddMaskTexture(b.mask)
            b.banner:AddMaskTexture(b.mask)
            b.maskOn = true
        end
    elseif b.maskOn then
        b.icon:RemoveMaskTexture(b.mask)
        b.banner:RemoveMaskTexture(b.mask)
        b.maskOn = nil
    end
end

-- Whisper / unread ring: two thin rounded lines, or one 2px square frame
-- when corners are off. Both are built once and swapped.
local function TileRing(b, rounded)
    local r = (b.wsSlot and 4) or b.wsRadius
    local target
    if rounded then
        if not b.ringRound then
            local outer = T.Border(b.ring, T.WHISPER, 1, r + 3, true)
            if outer[1] and outer[1].wsShaped then
                local inner = CreateFrame("Frame", nil, b.ring)
                inner:SetPoint("TOPLEFT", 1, -1)
                inner:SetPoint("BOTTOMRIGHT", -1, 1)
                local innerLine = T.Border(inner, T.WHISPER, 1, r + 2, true)
                for _, tex in ipairs(innerLine) do outer[#outer + 1] = tex end
            end
            b.ringRound = outer
        end
        target = b.ringRound
    else
        b.ringSquare = b.ringSquare or T.Border(b.ring, T.WHISPER, 2, r + 3, true)
        target = b.ringSquare
    end
    local cur = b.ringBorder
    if cur == target then return end
    if cur then
        local c = cur[1]
        for _, tex in ipairs(cur) do tex:Hide() end
        if c and c.wsR then T.SetBorderColor(target, { c.wsR, c.wsG, c.wsB, c.wsA }) end
    end
    for _, tex in ipairs(target) do tex:Show() end
    b.ringBorder = target
end

-- Flat rounded-square tile: class colour, initial, a ring for the open /
-- unread / starred conversation, a presence dot and an unread badge.
function ns.MakeTile(parent, size)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(size, size)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    local radius = math.max(4, math.floor(size * 0.28 + 0.5))
    b.fill = b:CreateTexture(nil, "BACKGROUND")
    b.fill:SetAllPoints()
    if not T.Shape(b.fill, radius) then
        b.edge = T.Border(b, { 0, 0, 0, 1 }, 1) -- square tiles keep their thin outline
    end
    b.wsRadius = radius
    -- "Game frames" look: the class icon in a dark slot, like an item slot.
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 2, -2)
    b.icon:SetPoint("BOTTOMRIGHT", -2, 2)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.icon:Hide()
    -- A dark banner along the bottom carries the person's initials.
    local bh = math.max(10, math.floor(size * 0.28 + 0.5))
    b.banner = b:CreateTexture(nil, "ARTWORK", nil, 2)
    b.banner:SetPoint("BOTTOMLEFT")
    b.banner:SetPoint("BOTTOMRIGHT")
    b.banner:SetHeight(bh)
    b.banner:SetColorTexture(0, 0, 0, 0.78)
    b.banner:Hide()
    b.tag = T.Text(b, math.max(8, math.floor(bh * 0.78)), T.TEXT, "")
    b.tag:SetPoint("BOTTOMLEFT", 0, 0)
    b.tag:SetPoint("BOTTOMRIGHT", 1, 0)
    b.tag:SetHeight(bh)
    b.tag:SetJustifyH("CENTER")
    b.tag:SetJustifyV("MIDDLE")
    b.tag:SetWordWrap(false)
    b.tag:Hide()
    -- The icon and banner are square; a mask rounds them to the tile's shape.
    if T.Rounded() then TileMask(b, true) end

    -- 2px ring with a 1px gap around the tile.
    b.ring = CreateFrame("Frame", nil, b)
    b.ring:SetPoint("TOPLEFT", -3, 3)
    b.ring:SetPoint("BOTTOMRIGHT", 3, -3)
    TileRing(b, T.Rounded())
    b.ring:Hide()
    tiles[b] = true

    -- Fill the tile and centre both ways, so the letter sits dead centre
    -- whatever the font's own metrics (a bare CENTER anchor drifts).
    b.letter = T.Text(b, math.floor(size * 0.42), T.DARK_TEXT, "")
    -- The game font leaves room after each glyph, so a centred single
    -- letter lands about 2px left of true centre. Nudge it back.
    -- Other fonts (a UI addon's, or one picked on the Look page) don't have
    -- that quirk, so the nudge is only applied for the game font; see
    -- CentreLetter, which re-checks whenever the tile is painted.
    b.wsNudge = math.max(1, math.floor(size * 0.05 + 0.5))
    b.letter:SetPoint("TOPLEFT", 0, 0)
    b.letter:SetPoint("BOTTOMRIGHT", 0, 0)
    b.letter:SetJustifyH("CENTER")
    b.letter:SetJustifyV("MIDDLE")
    b.letter:SetWordWrap(false)

    -- Presence dot (online / offline when the game knows).
    local ds = math.max(8, math.floor(size * 0.26 + 0.5))
    b.dot = CreateFrame("Frame", nil, b)
    b.dot:SetSize(ds, ds)
    b.dot:SetPoint("BOTTOMRIGHT", 3, -3)
    b.dot:SetFrameLevel(b:GetFrameLevel() + 2)
    b.dot.outline = b.dot:CreateTexture(nil, "BACKGROUND")
    b.dot.outline:SetPoint("TOPLEFT", -2, 2)
    b.dot.outline:SetPoint("BOTTOMRIGHT", 2, -2)
    T.Circle(b.dot.outline)
    T.Color(b.dot.outline, 0.08, 0.08, 0.12, 1)
    b.dot.fill = b.dot:CreateTexture(nil, "ARTWORK")
    b.dot.fill:SetAllPoints()
    T.Circle(b.dot.fill)
    b.dot:Hide()

    b.badge = ns.MakeBadge(b, 16)
    b.badge:SetPoint("TOPRIGHT", 7, 7)
    b.badge:SetFrameLevel(b:GetFrameLevel() + 3)
    b.badge.text:SetText("")

    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    T.Shape(hl, radius)
    T.Color(hl, 1, 1, 1, 0.14)
    b.hl = hl
    return b
end

local function CentreLetter(b)
    if b.wsLetterFont == T.FONT then return end
    b.wsLetterFont = T.FONT
    local font = tostring(T.FONT or ""):lower()
    local gameFont = (type(STANDARD_TEXT_FONT) == "string" and font == STANDARD_TEXT_FONT:lower()) or font:find("frizqt", 1, true) ~= nil
    local n = gameFont and (b.wsNudge or 0) or 0
    b.letter:ClearAllPoints()
    b.letter:SetPoint("TOPLEFT", n, 0)
    b.letter:SetPoint("BOTTOMRIGHT", n, 0)
end

-- Game-frames look squares the tile off like the game's item slots; the
-- regular look rounds it again.
local function ShapeTile(b, slot)
    if b.wsSlot == slot then return end
    b.wsSlot = slot
    local r = slot and 4 or b.wsRadius
    if b.mask then
        pcall(T.ShapeMask, b.mask, r)
    end
    T.Shape(b.fill, r)
    T.Shape(b.hl, r)
    local ring = b.ringRound -- kept up to date even while corners are off
    if ring and ring[1] and ring[1].wsDesign then T.Shape(ring[1], r + 3, true) end
    if ring and ring[2] and ring[2].wsDesign then T.Shape(ring[2], r + 2, true) end
end

-- Corner radius changed: mask, outline and ring follow (fill and highlight
-- are shaped textures and already re-shaped by T.ApplyCorners).
T.OnCorners(function(rounded)
    for b in pairs(tiles) do
        TileMask(b, rounded)
        TileRing(b, rounded)
        b.wsIconInset = nil
        if rounded then
            if b.edge then for _, tex in ipairs(b.edge) do tex:Hide() end end
        elseif not b.edge then
            b.edge = T.Border(b, { 0, 0, 0, 1 }, 1)
        else
            for _, tex in ipairs(b.edge) do tex:Show() end
        end
    end
end)

local ONLINE, OFFLINE = { 0.24, 0.81, 0.42, 1 }, { 0.45, 0.47, 0.52, 1 }

-- true / false when the game knows whether they're online, nil otherwise.
function ns.Presence(c)
    if not c or c.kind == "test" then return nil end
    local unit = ns.FindUnit and ns.FindUnit(c)
    if unit and UnitIsConnected then
        local ok, on = pcall(UnitIsConnected, unit)
        if ok and ns.Readable(on) then return on and true or false end
    end
    local ok, info = pcall(ns.LookupPlayer, c)
    if ok and info and info.online ~= nil then return info.online and true or false end
    return nil
end

---------------------------------------------------------------------------
-- Idle transparency (per dock tile): a read tile fades to look.idleTileAlpha;
-- unread, the conversation open in the window, or the mouse over it keep it
-- at full opacity. Reading it (or closing the window) fades it right away.
---------------------------------------------------------------------------

local function IdleTarget(b)
    local look = ns.db and ns.db.look
    local idle = (look and look.idleTileAlpha) or 1
    if idle >= 1 then return 1 end
    local c = b.convo
    if not c then return 1 end
    if (c.unread or 0) > 0 then return 1 end
    if T.IsOpen(ns.Window) and ns.Window.convo == c then return 1 end -- the open chat stays opaque
    if Over(b) then return 1 end
    return math.max(0.1, idle)
end

-- Re-set the alpha of the textures PaintTile tints, using b.idleMul.
local function ApplyTileAlpha(b)
    local mul = b.idleMul or 1
    local base = (ns.db and ns.db.look and ns.db.look.tileAlpha) or 1
    local a = base * mul
    b.fill:SetAlpha(mul)
    b.banner:SetAlpha(a)
    b.icon:SetAlpha(a)
    if b.symbol then b.symbol.icon:SetAlpha(mul) end
    b.tag:SetAlpha(mul)
    b.letter:SetAlpha(mul)
end

-- Start (or retarget) the fade for one dock tile.
function Dock:RefreshTile(b)
    if not b or not b.convo or not b.symbolDock then return end
    local target = IdleTarget(b)
    if b.idleMul == nil then
        b.idleMul, b.idleTarget = target, target
        ApplyTileAlpha(b)
        return
    end
    if b.idleTarget == target then return end
    b.idleTarget = target
    local cur = b.idleMul
    T.Tween(b, "idleMul", target > cur and 0.12 or 0.6, cur, target, function(v)
        b.idleMul = v
        ApplyTileAlpha(b)
    end)
end

-- A whisper arrived on c: bring its tile back to full opacity right away
-- (the unread count keeps it there until the conversation is read).
function Dock:NoteWhisper(c)
    local b = Dock.byKey and c and Dock.byKey[c.key]
    if b then Dock:RefreshTile(b) end
end

-- selected: draw the accent ring (used for the open conversation)
function ns.PaintTile(b, c, selected, showBadge)
    local r, g, bl = ns.ConvoColor(c)
    local alpha = (ns.db and ns.db.look and ns.db.look.tileAlpha) or 1
    local slot = ns.GameFrames ~= nil and ns.GameFrames.On()
    ShapeTile(b, slot)
    CentreLetter(b)
    -- Class icon with the person's initials on a banner; without a known
    -- class (some Battle.net friends) the initials stand alone on their colour.
    local kind, icon, crop = ns.ClassIcon(c.class)
    local inset = (slot or not b.maskOn) and 2 or 0
    if b.wsIconInset ~= inset then
        b.wsIconInset = inset
        b.icon:ClearAllPoints()
        b.icon:SetPoint("TOPLEFT", inset, -inset)
        b.icon:SetPoint("BOTTOMRIGHT", -inset, inset)
        b.banner:ClearAllPoints()
        b.banner:SetPoint("BOTTOMLEFT", inset, inset)
        b.banner:SetPoint("BOTTOMRIGHT", -inset, inset)
    end
    local symbols = not slot and ns.db.look.tileStyle ~= "artwork"
    if not symbols and b.symbol then b.symbol:Hide() end
    if symbols then
        r, g, bl = T.ClassTileColor(c.class, r, g, bl)
        -- The dock mockup uses a neutral tile; hub/header avatars have a faint class wash.
        if b.symbolDock then
            T.Color(b.fill, 17/255, 20/255, 27/255, alpha)
        else
            T.Color(b.fill, (22/255)*0.88+r*0.12, (25/255)*0.88+g*0.12, (31/255)*0.88+bl*0.12, alpha)
        end
        b.icon:Hide() b.banner:SetAlpha(alpha) b.banner:Show()
        b.tag:SetText(ns.Initials(c)) b.tag:Show()
        local drawn = T.ClassSymbol(b, c.class, { r, g, bl, alpha })
        b.letter:SetText("")
        if drawn then
            b.symbol:ClearAllPoints()
            b.symbol:SetPoint("CENTER",b,"CENTER",0,b.banner:GetHeight()/2)
            b.symbol:SetScale((b:GetWidth()-b.banner:GetHeight())/30)
        end
        b.letter:SetTextColor(r, g, bl)
    elseif icon then
        -- Rounded by the mask, the icon and banner are the whole tile: the
        -- fill behind them is hidden so no dark edge shows around the icon.
        -- (In the slot look the icon sits inset in a dark slot on purpose.)
        -- Dark artwork: Pigeon's own glyphs drawn in the class colour on a dark tile
        -- (like Class symbols) instead of the bright class-coloured square.
        local dark = ns.db.look.tileDark and kind == "file" and type(icon) == "string"
            and icon:find("Classes\\", 1, true) and not icon:find("Dark\\", 1, true)
        if dark then
            icon = icon:gsub("Classes\\", "Classes\\Dark\\")
            T.Color(b.fill, 17/255, 20/255, 27/255, alpha)
            b.icon:SetVertexColor(r, g, bl)
        else
            T.Color(b.fill, 0.04, 0.03, 0.02, (inset == 0) and 0 or alpha)
            b.icon:SetVertexColor(1, 1, 1)
        end
        if kind == "atlas" and b.icon.SetAtlas then
            b.icon:SetAtlas(icon)
        else
            b.icon:SetTexture(icon)
            if type(crop) == "table" then b.icon:SetTexCoord(crop[1] + 0.004, crop[2] - 0.004, crop[3] + 0.004, crop[4] - 0.004)
            elseif crop then b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) else b.icon:SetTexCoord(0, 1, 0, 1) end
        end
        b.icon:SetAlpha(alpha)
        b.icon:Show()
        b.banner:SetAlpha(alpha)
        b.banner:Show()
        b.tag:SetText(ns.Initials(c))
        b.tag:Show()
        b.letter:SetText("")
    else
        if slot then
            T.Color(b.fill, r * 0.55, g * 0.55, bl * 0.55, alpha) -- muted, to sit with the game's art
        else
            T.Color(b.fill, r, g, bl, alpha)
        end
        b.icon:Hide()
        b.banner:SetAlpha(alpha) b.banner:Show()
        b.tag:SetText(ns.Initials(c)) b.tag:Show()
        b.letter:SetText("")
        local lc = slot and { 1, 0.96, 0.84 } or T.DARK_TEXT
        b.letter:SetTextColor(lc[1], lc[2], lc[3])
    end
    local unread = c.unread or 0
    if selected then
        T.SetBorderColor(b.ringBorder, T.ACCENT)
        b.ring:Show()
    elseif unread > 0 and not symbols then
        T.SetBorderColor(b.ringBorder, T.WHISPER)
        b.ring:Show()
    elseif c.starred and not symbols then
        T.SetBorderColor(b.ringBorder, ns.Social.STAR)
        b.ring:Show()
    else
        b.ring:Hide()
    end
    if showBadge and unread > 0 then
        b.badge:SetCount(unread)
        b.badge:Show()
    else
        b.badge:Hide()
    end
    T.Color(b.dot.outline, T.BACKDROP[1], T.BACKDROP[2], T.BACKDROP[3], 1)
    local on = nil
    if not b.noDot then on = ns.Presence(c) end
    if on == nil or (on == false and b.hideOffline) then
        b.dot:Hide()
    else
        T.Color(b.dot.fill, on and ONLINE or OFFLINE)
        b.dot:Show()
    end
    if b.symbolDock then
        if b.idleMul == nil then
            b.idleMul = IdleTarget(b)
            b.idleTarget = b.idleMul
        end
        ApplyTileAlpha(b)
    end
end

local function Anchor()
    return Dock:Side() == "right" and "ANCHOR_RIGHT" or "ANCHOR_LEFT"
end

---------------------------------------------------------------------------
-- Player tooltip (dock tiles, window tiles, hub rows and header)
---------------------------------------------------------------------------

local function Grey(tip, text, wrap) tip:AddLine(text, T.SECTION[1], T.SECTION[2], T.SECTION[3], wrap ~= false) end

-- A frame's rectangle in UIParent units: left, bottom, right, top.
local function UIRect(f)
    local l, b, w, h = f:GetLeft(), f:GetBottom(), f:GetWidth(), f:GetHeight()
    if not (l and b and w and h) then return nil end
    local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return l * s, b * s, (l + w) * s, (b + h) * s
end

-- Put a shown tooltip next to owner without covering avoid (an open
-- window): left of the owner, right of it, beside the window, or above it.
function ns.PlaceTooltip(tip, owner, avoid)
    local tw, th = tip:GetWidth() or 0, tip:GetHeight() or 0
    local ts = tip:GetEffectiveScale() / UIParent:GetEffectiveScale()
    tw, th = tw * ts, th * ts
    local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
    local ol, ob, or_, ot = UIRect(owner)
    local al, ab, ar, at = UIRect(avoid)
    if not (ol and al) then
        tip:ClearAllPoints()
        tip:SetPoint("BOTTOMLEFT", owner, "TOPRIGHT", 0, 4)
        return
    end
    local G = 6
    local tries = {
        -- point, relative frame, relative point, x, y, resulting left, top
        { "TOPRIGHT", owner, "TOPLEFT", -G, 0, ol - G - tw, ot },
        { "TOPLEFT", owner, "TOPRIGHT", G, 0, or_ + G, ot },
        { "TOPLEFT", avoid, "TOPRIGHT", G, 0, ar + G, at },
        { "TOPRIGHT", avoid, "TOPLEFT", -G, 0, al - G - tw, at },
        { "BOTTOMLEFT", avoid, "TOPLEFT", 0, G, al, at + G + th },
    }
    local pick = tries[#tries]
    for _, t in ipairs(tries) do
        local l, top = t[6], t[7]
        local r, bot = l + tw, top - th
        local onScreen = l >= 0 and r <= sw and bot >= 0 and top <= sh
        local clear = r <= al or l >= ar or top <= ab or bot >= at
        if onScreen and clear then pick = t break end
    end
    tip:ClearAllPoints()
    tip:SetPoint(pick[1], pick[2], pick[3], pick[4], pick[5])
end

-- Animated emotes in the player tooltip: while it is up for the same owner, the message
-- line's emote frames are stepped ~30 times a second (see ns.Emotes.Animate).
local tipAnim = CreateFrame("Frame")
tipAnim:Hide()
local tipAnimAcc = 0
tipAnim:SetScript("OnUpdate", function(self, dt)
    tipAnimAcc = tipAnimAcc + dt
    if tipAnimAcc < 0.033 then return end
    tipAnimAcc = 0
    local tip = GameTooltip
    if not (tip:IsShown() and self.owner and tip:GetOwner() == self.owner and self.line) then
        self:Hide()
        return
    end
    local fs = _G["GameTooltipTextLeft" .. self.line]
    if fs and ns.Emotes and ns.Emotes.Animate then pcall(ns.Emotes.Animate, fs) end
end)

-- hint: optional "Click: … · Right-click: …" footer
-- anchor: an ANCHOR_* string, or { avoid = frame } to keep it off that frame.
function ns.ShowPlayerTooltip(owner, c, anchor, hint)
    if not c then return end
    local tip = GameTooltip
    local avoid = type(anchor) == "table" and anchor.avoid or nil
    if avoid and not avoid:IsShown() then avoid = nil end
    tip:SetOwner(owner, avoid and "ANCHOR_NONE" or (type(anchor) == "string" and anchor) or "ANCHOR_RIGHT")
    if tip.SetMinimumWidth then tip:SetMinimumWidth(190) end

    local unit = ns.FindUnit(c)
    local usedUnit = false
    if unit then
        usedUnit = pcall(tip.SetUnit, tip, unit) and tip:NumLines() > 0
    end

    local info = ns.LookupPlayer(c)
    if not usedUnit then
        local r, g, b = ns.ConvoColor(c)
        tip:AddDoubleLine(c.display or "?", info.online == true and L["Online"] or (info.online == false and L["Offline"] or " "),
            r, g, b, info.online and 0.25 or 0.55, info.online and 0.85 or 0.55, info.online and 0.35 or 0.55)
        local label = ns.ClassLabel(c)
        if c.kind == "bn" then
            if info.battleTag then Grey(tip, info.battleTag) end
            if info.character then
                local line = info.character
                if info.level and info.level > 0 then line = line .. "  ·  " .. L["Level %d"]:format(info.level) end
                tip:AddLine(line, 1, 1, 1)
            end
        else
            -- "Level 42 Troll Hunter" with whatever the game knows.
            local who = strtrim(((info.race or c.race) or "") .. " " .. label)
            local level = info.level or c.level
            if level and level > 0 then
                tip:AddLine(L["Level %d %s"]:format(level, who), 1, 1, 1)
            elseif who ~= "" then
                tip:AddLine(who, 1, 1, 1)
            end
        end
        if info.guild and not info.guildRank then tip:AddLine("<" .. info.guild .. ">", 0.25, 1, 0.25) end
        if info.zone and info.zone ~= "" then Grey(tip, info.zone) end
    end

    -- Extra context the unit tooltip doesn't have.
    if info.guildRank then
        tip:AddLine(L["Guildmate  ·  %s"]:format(info.guildRank), 0.25, 1, 0.25)
    elseif info.friend then
        tip:AddLine(L["Friend"], 0.25, 1, 0.25)
    end
    if info.note then tip:AddLine('"' .. info.note .. '"', 1, 0.82, 0, true) end
    if c.note then tip:AddLine(L["Your note: %s"]:format(c.note), 1, 0.82, 0.2, true) end
    if c.starred then tip:AddLine(L["Starred"], 1, 0.82, 0.2) end
    if c.gm then tip:AddLine(L["Game Master"], 0, 0.8, 1) end

    local last = c.messages[#c.messages]
    tipAnim:Hide()
    local animLine
    if last then
        tip:AddLine(" ")
        -- emotes show as pictures (tooltips draw |T...|t textures)
        local okE, body = pcall(ns.Emotes.Render, last.text, c.kind == "bn")
        if not (okE and type(body) == "string") then body = last.text end
        tip:AddLine(last.out and L["You: %s"]:format(body) or body, T.WHISPER[1], T.WHISPER[2], T.WHISPER[3], true)
        if type(body) == "string" and ns.Readable(body) and body:find("TwitchEmotes\\Emotes", 1, true) then animLine = tip:NumLines() end
        Grey(tip, ("%s  ·  %s%s"):format(date("%H:%M", last.t),
            (#c.messages == 1 and L["%d message"] or L["%d messages"]):format(#c.messages),
            c.pinned and ("  ·  " .. L["pinned"]) or ""))
    end
    if hint then
        tip:AddLine(" ")
        Grey(tip, hint, false)
    end
    tip:Show()
    if animLine then
        tipAnim.owner, tipAnim.line = owner, animLine
        tipAnim:Show()
    end
    if avoid and not pcall(ns.PlaceTooltip, tip, owner, avoid) then
        tip:ClearAllPoints()
        tip:SetPoint("BOTTOMLEFT", avoid, "TOPLEFT", 0, 6)
    end
end

-- Tuck the tiles away (or bring them back) without closing any conversation.
-- The stack button stays, with its unread badge.
function Dock:SetTilesHidden(v)
    ns.db.hideTiles = v and true or nil
    self.revealing = not v -- tiles coming back slide out instead of popping in
    self:Update()
    self.revealing = nil
end

-- Shift-click: tuck the tiles away for now. This is temporary (not saved) and a new
-- whisper brings them back; the "Hide dock tiles" setting is the permanent version.
function Dock:ToggleTiles()
    if self.tucked or ns.db.hideTiles then
        self.tucked = nil
        ns.db.hideTiles = nil
        self.revealing = true
        self:Update()
        self.revealing = nil
        ns.Print(L["tiles shown."])
    else
        self.tucked = true
        self:Update()
        ns.Print(L["tiles hidden. Shift-click the stack button to show them."])
    end
end

-- Close every conversation tile at once. Pinned ones stay; nothing is deleted.
function Dock:CloseAll()
    local closed = 0
    for _, c in pairs(ns.convos or {}) do
        if not c.hidden and not c.pinned then
            c.hidden = true
            c.unread = 0
            closed = closed + 1
        end
    end
    local open = ns.Window.convo
    if open and open.hidden and ns.Window:IsShown() then ns.Window:Close() end
    ns.Refresh()
    return closed
end

local function TileTooltip(self)
    local hint=L["Click: open  ·  Right-click: close  ·  Shift-drag: move"]
    if Dock.list and #Dock.list>(Dock.visibleCount or 0) then hint=hint..L["  ·  Scroll: more conversations"]end
    ns.ShowPlayerTooltip(self, self.convo, ns.Window:IsShown() and { avoid = ns.Window } or Anchor(), hint)
end

local function NewDockTile()
    local b = ns.MakeTile(Dock, TILE)
    b:RegisterForDrag("LeftButton")
    b:SetScript("OnDragStart", StartMove)
    b:SetScript("OnDragStop", StopMove)
    b:SetScript("OnClick", function(self, button)
        local c = self.convo
        if not c then return end
        if button == "RightButton" then
            c.hidden = true
            c.unread = 0
            if ns.Window.convo == c then ns.Window:Close() end
            ns.Refresh()
        elseif T.IsOpen(ns.Window) and ns.Window.convo == c then
            ns.Window:Close() -- clicking the open conversation's tile tucks it away
        else
            ns.Window:Open(c)
        end
    end)
    b:SetScript("OnEnter", TileTooltip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:HookScript("OnEnter", function(self) Dock:RefreshTile(self) end)
    b:HookScript("OnLeave", function(self) C_Timer.After(0.05, function() Dock:RefreshTile(self) end) end)
    b:EnableMouseWheel(true)
    b:SetScript("OnMouseWheel",function(_,delta)Dock:Scroll(delta)end)
    return b
end

-- y / dx left nil keep their current value, so the fade-in slide and the
-- reorder glide can run on the same tile at once. Tiles line up with the
-- dock's left edge (the chat box's edge when attached).
local function PlaceTile(b, y, dx)
    if y then b.curY = y end
    if dx then b.curX = dx end
    b:ClearAllPoints()
    if Dock.attached=="chat" and ns.Chat.tileRail then
        b:SetParent(ns.Chat.tileRail)
        b:SetPoint("TOPLEFT",ns.Chat.tileRail,"TOPLEFT",4+(b.curX or 0),b.curY or 0)
    else
        -- curY runs along the stack, curX is the sideways slide.
        local dir, x, y = Dock.dir or "up", b.curX or 0, b.curY or 0
        b:SetParent(Dock)
        if dir == "down" then b:SetPoint("TOPLEFT", Dock, "TOPLEFT", x, -y)
        elseif dir == "right" then b:SetPoint("BOTTOMLEFT", Dock, "BOTTOMLEFT", y, x)
        elseif dir == "left" then b:SetPoint("BOTTOMRIGHT", Dock, "BOTTOMRIGHT", -y, x)
        else b:SetPoint("BOTTOMLEFT", Dock, "BOTTOMLEFT", x, y) end
    end
end

-- Height of tile i (1 = newest, on top) above the dock's bottom edge.
local function TileY(i, n)
    if Dock.attached=="chat" then return -10-(i-1)*(TILE+GAP) end
    local gap = GAP + ((ns.GameFrames and ns.GameFrames.On()) and 4 or 0) -- slots want a little air
    if (Dock.dir or "up") == "up" then return (Dock.size or TILE) + gap + (n - i) * (TILE + gap) end
    return (Dock.size or TILE) + gap + (i - 1) * (TILE + gap) -- newest nearest the button
end

local function AcquireTile()
    local b = table.remove(Dock.pool) or NewDockTile()
    T.StopTween(b)
    b:EnableMouse(true)
    b:SetAlpha(1)
    b.idleMul, b.idleTarget = nil, nil
    return b
end

-- tuck: the tiles are being hidden (not closed). In the chat's tab bar they slide
-- back under the chat edge; on a free-standing dock they slide into the stack button.
local function ReleaseTile(b, tuck)
    b.convo = nil
    b:EnableMouse(false) -- fading-out tiles must not cover the next scroll page
    T.StopTween(b, "y")
    T.StopTween(b, "idleMul")
    b.idleMul, b.idleTarget = nil, nil
    if tuck then
        T.StopTween(b, "a")
        local function finish()
            b:Hide()
            table.insert(Dock.pool, b)
        end
        if Dock.attached == "chat" then
            local x0 = b.curX or 0
            T.Tween(b, "tuck", 0.26, 0, 1, function(v)
                PlaceTile(b, nil, x0 + (-60 - x0) * v)
                b:SetAlpha(1 - v * v)
            end, finish)
        else
            local y0 = b.curY or 0
            T.Tween(b, "tuck", 0.26, 0, 1, function(v)
                PlaceTile(b, y0 * (1 - v), nil)
                b:SetAlpha(1 - v)
            end, finish)
        end
        return
    end
    T.Tween(b, "a", 0.18, b:GetAlpha(), 0, function(v) b:SetAlpha(v) end, function()
        b:Hide()
        table.insert(Dock.pool, b)
    end)
end

---------------------------------------------------------------------------
-- Preview toast
---------------------------------------------------------------------------

local function BuildPreview()
    local pv = CreateFrame("Button", nil, UIParent)
    pv:SetSize(240, 54)
    pv:SetFrameStrata("MEDIUM")
    T.Panel(pv)
    pv.name = T.Text(pv, 13)
    pv.name:SetPoint("TOPLEFT", 10, -8)
    pv.count = T.Text(pv, 10, T.WHISPER)
    pv.count:SetPoint("TOPRIGHT", -10, -9)
    pv.text = T.Text(pv, 13, T.WHISPER)
    pv.text:SetPoint("TOPLEFT", pv.name, "BOTTOMLEFT", 0, -3)
    pv.text:SetPoint("RIGHT", -10, 0)
    pv.text:SetJustifyH("LEFT")
    pv.text:SetWordWrap(true)
    pv.text:SetMaxLines(2)

    pv:SetScript("OnClick", function(self)
        if self.convo then ns.Window:Open(self.convo) end
        self:Hide()
    end)
    pv:SetScript("OnEnter", function(self)
        self.token = nil -- pause the auto-hide while hovered
        T.Reveal(self, { dur = 0.12 })
    end)
    pv:SetScript("OnLeave", function() Dock:SchedulePreviewHide(2) end)
    pv:Hide()
    return pv
end

function Dock:SchedulePreviewHide(seconds)
    local pv = self.preview
    local token = {}
    pv.token = token
    C_Timer.After(seconds, function()
        if pv.token == token and T.IsOpen(pv) then
            T.Conceal(pv, { dur = 0.4 })
        end
    end)
end

function Dock:OnIncoming(c)
    -- Tiles tucked away: a new whisper brings them back (unless turned off), even when another addon shows the preview.
    if self.tucked and ns.db.showTilesOnWhisper ~= false then
        self.tucked = nil
        self.revealing = true
        self:Update()
        self.revealing = nil
    end
    if PigeonAPI and PigeonAPI.externalPreview then return end -- another addon shows the preview
    if T.IsOpen(ns.Window) or T.IsOpen(ns.Hub) then return end
    if self:AutoHidden() then return end -- tucked in combat / instances: no preview (the button's count still updates)
    local tile = self.byKey[c.key]
    if not tile then return end
    local pv = self.preview
    pv.convo = c
    local r, g, b = ns.ConvoColor(c)
    pv.name:SetText(c.display or "?")
    pv.name:SetTextColor(r, g, b)
    local unread = c.unread or 0
    pv.count:SetText(unread > 1 and (L["%d NEW"]:format(unread)) or "")
    local last = c.messages[#c.messages].text
    -- emotes show as pictures, like in the hub, instead of raw emote names
    local okE, shown = pcall(ns.Emotes.Render, last, c.kind == "bn")
    pv.text:SetText(okE and type(shown) == "string" and shown or last)
    pv:SetHeight(math.max(54, 30 + pv.text:GetStringHeight()))
    -- Anchored to the tile itself, so it rides along while the tile glides up.
    if self:Side() == "right" then
        T.Place(pv, "LEFT", tile, "RIGHT", 8, 0)
    else
        T.Place(pv, "RIGHT", tile, "LEFT", -8, 0)
    end
    T.Reveal(pv, { dx = self:SlideX(), dur = 0.28 })
    self:SchedulePreviewHide(ns.db.previewSeconds or 6)
end

---------------------------------------------------------------------------
-- Reply key: jump into the newest unread (or most recent) conversation
---------------------------------------------------------------------------

function Dock:ReplyNewest()
    local list = self.list
    local target = list[1]
    for _, c in ipairs(list) do
        if (c.unread or 0) > 0 then target = c break end
    end
    if not target then
        ns.Hub:Open()
        return
    end
    ns.Window:Open(target, true)
end

---------------------------------------------------------------------------
-- Layout
---------------------------------------------------------------------------

function Dock:PaintStackIcon()
    local b=self.allBtn
    if not b then return end
    local envelope=ns.db.chat.envelopeIcon and true or false
    if b.wsEnvelope~=envelope then
        T.StopTween(b,"birdHover")
        b.birdLift,b.birdAngle=0,0
        b.icon:ClearAllPoints() b.icon:SetPoint("CENTER",b,"CENTER",0,0)
        b.icon:SetRotation(0)
        b.icon:SetTexture(T.MEDIA .. (envelope and "Envelope" or "Symbols\\BIRD.tga"))
        b.wsEnvelope=envelope
    end
end

function Dock:AnimateBird(hover)
    local b=self.allBtn
    if not b or b.wsEnvelope then return end
    local lift,angle=b.birdLift or 0,b.birdAngle or 0
    T.Tween(b,"birdHover",hover and .55 or .18,0,1,function(p)
        local hop=hover and math.sin(math.pi*p)*3 or 0
        local tilt=hover and math.sin(math.pi*2*p)*.10 or 0
        b.birdLift=(1-p)*lift+hop b.birdAngle=(1-p)*angle+tilt
        if p>=1 then b.birdLift,b.birdAngle=0,0 end
        b.icon:ClearAllPoints() b.icon:SetPoint("CENTER",b,"CENTER",0,b.birdLift)
        b.icon:SetRotation(b.birdAngle)
    end)
end

function Dock:Scroll(delta)
    if not delta or delta==0 then return false end
    local count=self.list and #self.list or 0
    local visible=self.visibleCount or 0
    if visible==0 then return false end
    local offset=math.max(0,math.min(math.max(0,count-visible),(self.scrollOffset or 0)-(delta>0 and 1 or -1)))
    if offset==(self.scrollOffset or 0)then return false end
    self.scrollOffset=offset self.scrollTopKey=nil
    GameTooltip:Hide()
    self:Update()
    return true
end

function Dock:UpdateScrollHint(total,visible,offset)
    local rail=ns.Chat.tileRail
    if self.attached~="chat" or not rail then
        if self.scrollTrack then self.scrollTrack:Hide()self.scrollThumb:Hide()end
        return
    end
    if not self.scrollTrack then
        local track=rail:CreateTexture(nil,"ARTWORK")track:SetWidth(2)
        track:SetPoint("TOPRIGHT",-1,-10)track:SetPoint("BOTTOMRIGHT",-1,10)
        track:SetColorTexture(1,1,1,.08)self.scrollTrack=track
        local thumb=rail:CreateTexture(nil,"OVERLAY")thumb:SetWidth(2)self.scrollThumb=thumb
    end
    local overflow=visible>0 and total>visible
    self.scrollTrack:SetShown(overflow)self.scrollThumb:SetShown(overflow)
    if overflow then
        local height=math.max(1,rail:GetHeight()-20)
        local size=math.min(height,math.max(12,height*visible/total))
        self.scrollThumb:SetHeight(size)
        self.scrollThumb:SetPoint("TOPRIGHT",rail,"TOPRIGHT",-1,-10-(height-size)*offset/(total-visible))
        self.scrollThumb:SetColorTexture(T.ACCENT[1],T.ACCENT[2],T.ACCENT[3],.65)
    end
    if not rail.wsScrollDock then
        rail.wsScrollDock=true rail:EnableMouse(true)rail:EnableMouseWheel(true)
        rail:SetScript("OnMouseWheel",function(_,delta)Dock:Scroll(delta)end)
    end
end

function Dock:Update()
    if not self.allBtn then return end
    self:PaintStackIcon()
    local list = ns.List()
    if (self.scrollOffset or 0)>0 and self.scrollTopKey then
        for i,c in ipairs(list)do if c.key==self.scrollTopKey then self.scrollOffset=i-1 break end end
    end
    self.list = list
    local dir = self:Dir()
    local dirChanged = dir ~= self.dir
    self.dir = dir
    local n = math.min(#list, ns.db.maxTiles or 6)
    local tuck = (ns.db.hideTiles or self.tucked or self:AutoHidden()) and true or false
    if tuck then n = 0 end -- tiles tucked away; conversations stay open (the stack button and its badge stay)
    if self.attached=="chat" then
        -- Additional conversations remain accessible through the stack button.
        -- Cap to the actual body height so tiles never escape the panel.
        local capacity=math.max(0,math.floor((ns.Chat:GetHeight()-ns.Chat.TAB_H-24)/(TILE+GAP)))
        n=math.min(n,capacity)
        ns.Chat:SetDockRail(n>0)
    elseif ns.Chat.SetDockRail then ns.Chat:SetDockRail(false) end
    self.visibleCount=n
    local offset=n>0 and math.max(0,math.min(self.scrollOffset or 0,#list-n)) or 0
    self.scrollOffset=offset
    self.scrollTopKey=offset>0 and list[offset+1] and list[offset+1].key or nil
    self:UpdateScrollHint(#list,n,offset)
    local keep = {}

    for i = 1, n do
        local c = list[offset+i]
        local y = TileY(i, n)
        local b = self.byKey[c.key]
        keep[c.key] = true
        if not b then
            -- New tile: fade in while sliding out of the dock.
            b = AcquireTile()
            self.byKey[c.key] = b
            b.symbolDock = true
            b.convo = c
            b.targetY = y
            if self.revealing then
                -- Un-hiding: slide out from under the chat edge, or out of the stack button.
                b:SetAlpha(0)
                if self.attached == "chat" then
                    PlaceTile(b, y, -60)
                    b:Show()
                    T.Tween(b, "tuck", 0.28, -60, 0, function(v) PlaceTile(b, nil, v) end)
                else
                    PlaceTile(b, 0, 0)
                    b:Show()
                    T.Tween(b, "tuck", 0.28, 0, y, function(v) PlaceTile(b, v, nil) end)
                end
                T.Tween(b, "a", 0.22, 0, 1, function(v) b:SetAlpha(v) end)
            else
                local sx = self:SlideX()
                PlaceTile(b, y, sx)
                b:Show()
                T.Spring(b, "a", 0, 1, function(v)
                    b:SetAlpha(math.max(0, math.min(1, v * 2)))
                    b:SetHeight(math.max(1, TILE * (0.35 + 0.65 * v)))
                    PlaceTile(b, nil, sx * 0.35 * (1 - v))
                end)
            end
        else
            b.symbolDock = true
            b.convo = c
            if dirChanged then
                T.StopTween(b, "y")
                b.targetY = y
                PlaceTile(b, y, 0)
            elseif b.targetY ~= y then
                -- Existing tile: glide to its new slot (e.g. bumped to the top).
                b.targetY = y
                T.Tween(b, "y", 0.25, b.curY or y, y, function(v) PlaceTile(b, v, nil) end)
            end
        end
        ns.PaintTile(b, c, T.IsOpen(ns.Window) and ns.Window.convo == c, true)
        self:RefreshTile(b)
    end

    for key, b in pairs(self.byKey) do
        if not keep[key] then
            self.byKey[key] = nil
            ReleaseTile(b, tuck)
        end
    end

    -- Stack button: dim when empty, "+N" for conversations past the tile
    -- limit, and a badge with every unread whisper (tiles shown or not).
    local totalUnread = 0
    for _, c in pairs(ns.convos) do
        if not c.temp or #c.messages > 0 then totalUnread = totalUnread + (c.unread or 0) end
    end
    self.totalUnread = totalUnread
    self.allBtn.icon:SetAlpha(#list == 0 and 0.6 or 1)
    if self.allBtn.tint then
        T.Color(self.allBtn.tint, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 0.16)
        T.SetBorderColor(self.allBtn.tintBorder, T.ACCENT, 0.4)
    end
    self.allBtn.icon:SetVertexColor(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3])
    self.allBtn.more:SetText(#list > n and ("+" .. (#list - n)) or "")
    self.allBtn.more:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
    if totalUnread > 0 then
        self.allBtn.badge:SetCount(totalUnread)
        self.allBtn.badge:Show()
    else
        self.allBtn.badge:Hide()
    end
    if ns.Launcher then ns.Launcher.Update(totalUnread) end

    if T.IsOpen(self.preview) and (not self.preview.convo or self.preview.convo.hidden) then
        T.Conceal(self.preview, { dur = 0.12 })
    end
end

-- Tuck the tiles away (and hold back previews) while in combat or in an instance,
-- if those options are on. The Pigeon button stays, so its unread count is still
-- visible; the tiles slide back out afterwards.
function Dock:AutoHidden()
    local db = ns.db
    if not db then return false end
    if db.combat and db.combat.whispers == "tuck" and (self.inCombat or (InCombatLockdown and InCombatLockdown())) then return true end
    if db.hideDockInstance and IsInInstance then
        local inside = IsInInstance()
        if inside then return true end
    end
    return false
end

function Dock:ApplyAutoHide()
    if not self.allBtn then return end
    local hide = self:AutoHidden()
    if hide == self.autoTucked then return end
    self.autoTucked = hide
    if hide and self.preview and self.preview:IsShown() then self.preview:Hide() end
    self.revealing = not hide -- tiles coming back slide out instead of popping in
    self:Update()
    self.revealing = nil
end

Dock:RegisterEvent("PLAYER_REGEN_DISABLED")
Dock:RegisterEvent("PLAYER_REGEN_ENABLED")
Dock:RegisterEvent("PLAYER_ENTERING_WORLD")
Dock:RegisterEvent("ZONE_CHANGED_NEW_AREA")
Dock:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_REGEN_DISABLED" then self.inCombat = true
    elseif event == "PLAYER_REGEN_ENABLED" then self.inCombat = false end
    self:ApplyAutoHide()
end)

function Dock:Init()
    -- Attach to a chat panel's tab bar: ours if it's running, else ElvUI's.
    -- self.attached is "chat", "elvui" or false.
    self.attached = false
    if ns.db.chat.attachDock then
        if ns.Chat.smf then
            self.attached = "chat"
            self.size = ns.Chat.TAB_H
            self:SetSize(self.size, self.size)
        elseif ns.ElvUI.AttachDock(self) then
            self.attached = "elvui" -- AttachDock sized us to ElvUI's tab strip
        end
    end
    if self.attached then
        TILE = self.attached=="chat" and 44 or 36
        self:SetFrameStrata("MEDIUM")
    else
        self.size = TILE
        self:SetSize(self.size, self.size)
    end

    local all = CreateFrame("Button", nil, self)
    all:SetAllPoints()
    local radius = math.max(6, math.floor(self.size * 0.28 + 0.5))
    if self.attached then
        -- Part of the chat's tab bar: no panel of its own, so it always
        -- matches the chat's background and opacity (and fades with it).
        all.bg = T.ShapeFill(all, { 1, 1, 1, 0 }, radius)
        all.border = {}
    else
        T.Panel(all, nil, nil, radius)
    end
    all:RegisterForDrag("LeftButton")
    all:SetScript("OnDragStart", StartMove)
    all:SetScript("OnDragStop", StopMove)
    if self.attached then
        -- In the tab bar: a small accent-tinted rounded square, like the tabs.
        local s = math.floor(self.size * 0.72)
        all.tint = all:CreateTexture(nil, "BACKGROUND", nil, 1)
        all.tint:SetSize(s, s)
        all.tint:SetPoint("CENTER")
        T.Shape(all.tint, 6)
        all.tintLine = CreateFrame("Frame", nil, all)
        all.tintLine:SetAllPoints(all.tint)
        all.tintBorder = T.Border(all.tintLine, T.ACCENT, 1, 6)
    end
    all.icon = all:CreateTexture(nil, "ARTWORK")
    local iconSize = math.floor(self.size * (self.attached and 0.62 or 0.66))
    all.icon:SetSize(iconSize, iconSize)
    all.icon:SetPoint("CENTER")
    all.icon:SetTexture(T.MEDIA .. "Symbols\\BIRD.tga")
    all.icon:SetVertexColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
    all.more = T.Text(all, 10, T.SECTION)
    all.more:SetPoint("BOTTOMRIGHT", -3, 3)
    all.badge = ns.MakeBadge(all, 16)
    if all.tint then
        all.badge:SetPoint("CENTER", all.tint, "TOPRIGHT", -1, -1)
    else
        all.badge:SetPoint("TOPRIGHT", 6, 6)
    end
    all.badge:SetFrameLevel(all:GetFrameLevel() + 4)
    local hl = all:CreateTexture(nil, "HIGHLIGHT")
    -- Match the inset rounded tile, not the square hit area at the corner.
    hl:SetAllPoints(all.tint or all)
    T.Shape(hl, all.tint and 6 or radius)
    T.Color(hl, 1, 1, 1, 0.08)
    all:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    all:SetScript("OnClick", function(btn, button)
        if button ~= "RightButton" then
            if IsShiftKeyDown() then
                Dock:ToggleTiles()
                return
            end
            ns.Hub:Toggle()
            return
        end
        -- Double right-click: close every tile (pinned ones stay; history is kept).
        local now = GetTime and GetTime() or 0
        if btn.lastRight and now - btn.lastRight <= 0.4 then
            btn.lastRight = nil
            Dock:CloseAll()
        else
            btn.lastRight = now
        end
    end)
    all:SetScript("OnEnter", function(btn)
        Dock:AnimateBird(true)
        GameTooltip:SetOwner(btn, Anchor())
        GameTooltip:AddLine("Pigeon")
        GameTooltip:AddLine(L["Click: whisper hub  ·  Shift-click: hide or show tiles  ·  Double right-click: close all tiles"], T.SECTION[1], T.SECTION[2], T.SECTION[3])
        GameTooltip:AddLine(L["Shift-drag: move  ·  /pigeon for options"], T.SECTION[1], T.SECTION[2], T.SECTION[3])
        if Dock.list and #Dock.list>(Dock.visibleCount or 0)then
            GameTooltip:AddLine(L["Scroll: conversations %d–%d of %d"]:format((Dock.scrollOffset or 0)+1,(Dock.scrollOffset or 0)+(Dock.visibleCount or 0),#Dock.list),T.SECTION[1],T.SECTION[2],T.SECTION[3])
        end
        GameTooltip:Show()
    end)
    all:SetScript("OnLeave", function() GameTooltip:Hide() Dock:AnimateBird(false) end)
    all:EnableMouseWheel(true)
    all:SetScript("OnMouseWheel",function(_,delta)Dock:Scroll(delta)end)
    all:SetScript("OnHide",function(btn)
        T.StopTween(btn,"birdHover") btn.birdLift,btn.birdAngle=0,0
        btn.icon:ClearAllPoints() btn.icon:SetPoint("CENTER",btn,"CENTER",0,0) btn.icon:SetRotation(0)
    end)
    self.allBtn = all -- always visible, even with no conversations
    self:PaintStackIcon()

    self.preview = BuildPreview()
    self:ApplyPosition()
    self:ApplyAutoHide()
end
