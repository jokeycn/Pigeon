--[[
    Pigeon - Core
    Whisper capture, conversation storage, sending, slash commands, test mode.
]]

local ADDON, ns = ...
local T = ns.Theme
local L = ns.L

BINDING_HEADER_WHISPERSTACK = "Pigeon" -- binding names keep the old prefix so your keys stay bound
BINDING_NAME_WHISPERSTACK_REPLY = L["Reply to latest whisper"]
BINDING_NAME_WHISPERSTACK_HUB = L["Open whisper hub"]

local DEFAULTS = {
    point = { "BOTTOMRIGHT", "BOTTOMRIGHT", -40, 220 },
    hubPoint = { "CENTER", "CENTER", 0, 60 },
    hideFromChat = false, -- whispers still show in the normal chat frame by default
    classTint = false,
    previewSeconds = 6,
    maxTiles = 6,
    showTilesOnWhisper = true, -- tiles tucked away come back when a whisper arrives
    hideDockInstance = false,  -- hide the whole dock while in an instance
    history = 60,         -- messages kept per player
    sound = "chime",      -- "chime", "pop", "tell" or "off"
    elvuiStyle = true,    -- with ElvUI loaded: use its font, colours and borders
    euiStyle = true,      -- with EllesmereUI loaded: use its font and accent colour
    islandStyle = true,   -- with Island XP loaded: match its black, rounded look
    soundBNet = true,
    soundCombat = true,   -- false = stay quiet while in combat
    quickReplies = { "inv", "omw", "one sec", "full, sorry", "ty!" },
    showQuickReplies = true,
    away = { enabled = false, message = "I'm away right now, I'll get back to you soon.", when = "always" },
    combat = { whispers = "normal", chat = "normal", alpha = 0.25, wake = 4 }, -- "normal", "fade" or "hide" (chat: fade only)
    minimap = { hide = false, angle = 200 },
    profiles = {},
    -- Look page. A colour left nil follows the theme (a UI addon's /
    -- EllesmereUI / class tint); set, it wins over all of them.
    look = {
        font = nil,           -- LibSharedMedia font name; nil = theme font
        accent = nil, backdrop = nil, border = nil,
        theirText = nil, yourText = nil, bnetText = nil,
        panelAlpha = nil,     -- window / hub / settings background opacity; nil = theme
        tileAlpha = 1,
        idleTileAlpha = 1,    -- opacity of dock tiles once read (1 = off)
        wash = 1,             -- strength of the colour wash behind messages
        railWidth = 2,
        msgSize = 14,
        msgOutline = false,
        windowScale = 1, hubScale = 1, dockScale = 1, uiTextScale = 1,
        panelStyle = "flat",  -- "flat" or "glass"
        corners = "rounded",  -- legacy; cornerRadius (0-8, nil = 8, or 0 for old "square" profiles) replaces it
        glass = 0.5,          -- glass shine strength
        whisperStyle = "signal", -- signal, rails, bubbles, threads, classic, minimal
        preset = "island",
        tileStyle = "symbol", -- symbol or artwork
        gameFrames = false,   -- draw windows with the game's own frame art
        classIcons = "parley", -- tile class icons: parley, game, crest, shared, horizon, rondo
    },
    chat = {
        enabled = true,
        point = { "BOTTOMLEFT", "BOTTOMLEFT", 24, 60 },
        width = 520,
        height = 260,
        locked = true,
        fontSize = 14,
        tabBarHeight = 52,
        outline = false,
        timestamps = "%H:%M",
        shorten = "tag",       -- channel names: "tag" (P, G, T…), "name", "number" or "off"
        fade = true,
        fadeAfter = 120,
        bgAlpha = 0.85,
        editTop = false,
        attachDock = true,     -- the whisper stack button lives in the chat's tab bar
        fitElvUI = true,       -- ElvUI (chat module off): fill its left chat panel
        editInside = true,     -- the input box sits inside the bottom of the chat
        nameBrackets = false,  -- [Name] vs Name in chat lines
        idleFade = 0,          -- seconds before the background/tabs fade out (0 = never)
        idleAlpha = 0.2,
        idleHideText = false,  -- also fade the messages (not just the background) while idle
        spam = { dupes = true, gold = true },
        alerts = { words = "", myName = true, sound = true },
        lfg = { enabled = true, roles = true, buttons = true },
        tabs = {
            -- Conversation and channels, not the game's background noise (loot, xp,
            -- creature talk, battleground and pet battle lines, pings, notices).
            { name = "General", categoryVersion = 2, cats = {
                say=true, yell=true, emote=true, guild=true, officer=true, guildach=true,
                party=true, partyleader=true, raid=true, raidleader=true, raidwarning=true,
                instance=true, instanceleader=true, whisper=true, gmwhisper=true, bnet=true,
                general=true, trade=true, services=true, lfg=true, defense=true, newcomer=true,
                channel=true, community=true, system=true, blizzardservices=true,
            } },
            { name = "Guild", cats = { guild = true, officer = true, guildach = true } },
            { name = "Party", cats = { party = true, partyleader = true, raid = true, raidleader = true, raidwarning = true, instance = true, instanceleader = true } },
            { name = "Trade", cats = { trade = true, services = true } },
            { name = "Loot", cats = { loot=true, money=true, currency=true, xp=true, honor=true, reputation=true, skill=true }, categoryVersion=2 },
        },
    },
}

ns.convos = {}

local function Print(msg)
    print("|cff7a94d1Pigeon|r: " .. msg)
end
ns.Print = Print

-- Midnight-era clients can hand addons "secret" values; never store or compare those.
local function Readable(v)
    if v == nil then return false end
    if issecretvalue and issecretvalue(v) then return false end
    return true
end
ns.Readable = Readable

local function DeepCopy(v)
    if type(v) ~= "table" then return v end
    local t = {}
    for k, x in pairs(v) do t[k] = DeepCopy(x) end
    return t
end

-- A fresh copy of the recommended General tab (Settings > Chat > Reset).
function ns.DefaultGeneralTab() return DeepCopy(DEFAULTS.chat.tabs[1]) end

-- The shipped tab with this name (General, Guild, Trade, Loot), or nil for a custom tab.
function ns.DefaultTabByName(name)
    name = strtrim(name or ""):lower()
    for _, t in ipairs(DEFAULTS.chat.tabs) do
        if t.name:lower() == name then return DeepCopy(t) end
    end
end

-- Fill in missing keys. Nested option tables (chat) are merged key by key;
-- list-like tables (points, tabs) are copied whole only when absent.
local function ApplyDefaults(db, defaults)
    for k, v in pairs(defaults) do
        if db[k] == nil then
            db[k] = DeepCopy(v)
        elseif type(v) == "table" and type(db[k]) == "table" and v[1] == nil and k ~= "tabs" then
            ApplyDefaults(db[k], v)
        end
    end
end

---------------------------------------------------------------------------
-- Conversations
---------------------------------------------------------------------------

local function NextSeq()
    ns.hist.seq = (ns.hist.seq or 0) + 1
    return ns.hist.seq
end

function ns.GetConvo(key, create)
    local c = ns.convos[key]
    if not c and create then
        c = { key = key, messages = {}, unread = 0, seq = 0 }
        ns.convos[key] = c
    end
    return c
end

-- Conversations shown in the dock, newest activity first.
function ns.List()
    local list = {}
    for _, c in pairs(ns.convos) do
        if not c.hidden and #c.messages > 0 then
            list[#list + 1] = c
        end
    end
    -- Pinned conversations stay on top, newest activity first within each group.
    table.sort(list, function(a, b)
        if (a.pinned and true or false) ~= (b.pinned and true or false) then return a.pinned and true or false end
        return (a.seq or 0) > (b.seq or 0)
    end)
    return list
end

function ns.Initial(c)
    local name = c.display or "?"
    return name:match("^[%z\1-\127\194-\244][\128-\191]*") or "?"
end

---------------------------------------------------------------------------
-- Class icons for the tiles. Besides the game's own two sets, icon packs
-- that other addons *offer for sharing* can be used: anything registered
-- with LibSharedMedia as "classicon", and Horizon Suite's sets through its
-- own lookup. (Art that an addon's licence keeps to itself is left alone.)
---------------------------------------------------------------------------

local PIGEON_CLASSES = {
    WARRIOR = true, PALADIN = true, HUNTER = true, ROGUE = true, PRIEST = true, DEATHKNIGHT = true, SHAMAN = true,
    MAGE = true, WARLOCK = true, MONK = true, DRUID = true, DEMONHUNTER = true, EVOKER = true,
}

local function HorizonIcons()
    local hs = _G.HorizonSuite
    return type(hs) == "table" and type(hs.ResolveClassIconDisplay) == "function" and hs or nil
end

local function SharedIcons()
    local lsm = LibStub and LibStub("LibSharedMedia-3.0", true)
    if not lsm then return nil end
    local ok, list = pcall(lsm.HashTable, lsm, "classicon")
    if ok and type(list) == "table" and next(list) then return lsm end
    return nil
end

-- { key, label } for every source usable right now.
function ns.ClassIconSources()
    -- "game" (the per-class ClassIcon_* files) is retired; it reads as "crest" below.
    local list = { { "parley", L["Pigeon icons"] }, { "crest", L["Class icons"] } }
    if SharedIcons() then list[#list + 1] = { "shared", L["Shared media pack"] } end
    if HorizonIcons() then
        list[#list + 1] = { "horizon", L["Horizon Suite"] }
        list[#list + 1] = { "rondo", "RondoMedia" }
    end
    return list
end

-- Returns kind ("file" | "atlas"), value, crop (true for the game's square
-- icons, which have a border to trim).
function ns.ClassIcon(class)
    if not class then return nil end
    local source = (ns.db and ns.db.look and ns.db.look.classIcons) or "parley"
    if source == "game" then source = "crest" end -- retired option; the crests are the game's own icons
    if source == "parley" then
        -- Pigeon's own flat set: a simple glyph on the class colour.
        if PIGEON_CLASSES[class] then return "file", ns.Theme.MEDIA .. "Classes\\" .. class, false end
    elseif source == "crest" then
        local atlas = (type(GetClassAtlas) == "function" and GetClassAtlas(class)) or ("classicon-" .. class:lower())
        local known = not (C_Texture and C_Texture.GetAtlasInfo) or C_Texture.GetAtlasInfo(atlas) ~= nil
        if known then return "atlas", atlas, false end
    elseif source == "shared" then
        local lsm = SharedIcons()
        if lsm then
            local ok, path = pcall(lsm.Fetch, lsm, "classicon", class, true)
            if ok and type(path) == "string" and path ~= "" then return "file", path, false end
        end
    elseif source == "horizon" or source == "rondo" then
        local hs = HorizonIcons()
        if hs then
            local ok, res = pcall(hs.ResolveClassIconDisplay, class, source == "horizon" and "custom" or "rondomedia")
            if ok and type(res) == "table" then
                if res.kind == "file" and res.path then return "file", res.path, false end
                if res.kind == "atlas" and res.atlas then return "atlas", res.atlas, false end
            end
        end
    end
    -- The class sheet ships with every client and has a cell for every class
    -- (the per-class ClassIcon_* files are missing for some).
    local tc = _G.CLASS_ICON_TCOORDS and _G.CLASS_ICON_TCOORDS[class]
    if type(tc) == "table" and #tc >= 4 then return "file", "Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES", tc end
    return "file", "Interface\\Icons\\ClassIcon_" .. class, true
end

-- "Manbear Thunderhoof" -> "MT", "Brisa" -> "B" (the realm isn't counted).
function ns.Initials(c)
    local name = (c.display or "?"):gsub("%-[^%s]*$", "")
    local letters = {}
    for word in name:gmatch("%S+") do
        letters[#letters + 1] = word:match("^[%z\1-\127\194-\244][\128-\191]*")
    end
    if #letters == 0 then return "?" end
    local out = letters[1]
    if #letters > 1 then out = out .. letters[#letters] end
    return out:upper()
end

function ns.ConvoColor(c)
    if c.kind == "bn" and not c.class then
        return T.BNET[1], T.BNET[2], T.BNET[3]
    end
    return T.ClassColor(c.class)
end

function ns.ClassLabel(c)
    if c.class then
        local names = LOCALIZED_CLASS_NAMES_MALE
        if names and names[c.class] then return names[c.class] end
        return c.class
    end
    if c.kind == "bn" then return "Battle.net" end
    return ""
end

-- "ROGUE  ·  GM  ·  LAST 21:06"
function ns.MetaLine(c)
    local bits = {}
    local label = ns.ClassLabel(c)
    -- Level and zone, whenever the game knows them (group, guild, friends).
    local ok, info = pcall(ns.LookupPlayer, c)
    info = ok and info or {}
    local unit = ns.FindUnit and ns.FindUnit(c)
    if unit and UnitLevel then
        local lvl = UnitLevel(unit)
        if ns.Readable(lvl) and type(lvl) == "number" and lvl > 0 then info.level = lvl end
    end
    if type(info.level) == "number" and info.level > 0 then c.level = info.level end
    if c.level then label = L["Level %d %s"]:format(c.level, label) end
    label = strtrim(label)
    if label ~= "" then bits[#bits + 1] = label end
    if type(info.zone) == "string" and info.zone ~= "" and ns.Readable(info.zone) then bits[#bits + 1] = info.zone end
    if c.gm then bits[#bits + 1] = L["GM"] end
    local last = c.messages[#c.messages]
    if last then bits[#bits + 1] = L["Last %s"]:format(date("%H:%M", last.t)) end
    return table.concat(bits, "  ·  "):upper()
end

-- Is this conversation on screen right now (so new messages count as read)?
function ns.IsViewing(c)
    if ns.Window and T.IsOpen(ns.Window) and ns.Window.convo == c then return true end
    if ns.Hub and T.IsOpen(ns.Hub) and ns.Hub.convo == c then return true end
    return false
end

-- Re-apply everything on the Look page: colours, fonts, scales.
-- The game's mature language filter is a game setting (a "CVar"), shared by
-- every chat addon and the default chat.
function ns.ProfanityFilter()
    local get = (C_CVar and C_CVar.GetCVar) or GetCVar
    if not get then return true end
    local ok, v = pcall(get, "profanityFilter")
    return not ok or v ~= "0"
end

function ns.SetProfanityFilter(on)
    local set = (C_CVar and C_CVar.SetCVar) or SetCVar
    if not set then return false end
    pcall(set, "profanityFilter", on and "1" or "0")
    if ns.ProfanityFilter() ~= (on and true or false) then
        ns.Print(L["the game wouldn't change the mature language filter (some regions and accounts lock it)."])
        return false
    end
    return true
end

function ns.BackgroundOpacity()
    return ns.db.look.panelAlpha or T.BACKDROP[4] or ns.db.chat.bgAlpha or .85
end

function ns.ChatOpacity()
    return ns.db.look.chatAlpha or ns.BackgroundOpacity()
end
function ns.WhisperOpacity()
    return ns.db.look.whisperAlpha or ns.BackgroundOpacity()
end
function ns.SetChatOpacity(value)
    if type(value)~="number" or not ns.Readable(value)then return end
    ns.db.look.chatAlpha=math.max(0,math.min(1,value))
    for _,tab in ipairs(ns.db.chat.tabs or {})do tab.bgAlpha=nil end
    ns.ApplyLook()
end
function ns.SetWhisperOpacity(value)
    if type(value)~="number" or not ns.Readable(value)then return end
    ns.db.look.whisperAlpha=math.max(0,math.min(1,value))
    ns.ApplyLook()
end

function ns.SetBackgroundOpacity(value)
    if type(value)~="number" or not ns.Readable(value)then return end
    value=math.max(0,math.min(1,value))
    ns.db.look.panelAlpha=value
    ns.db.look.chatAlpha=nil ns.db.look.whisperAlpha=nil
    -- A global opacity change also replaces any older per-tab override.
    for _,tab in ipairs(ns.db.chat.tabs or {})do tab.bgAlpha=nil end
    ns.ApplyLook()
end

function ns.ApplyLook()
    local L = ns.db.look
    if L.preset=="midnight" or L.preset=="glass"then
        for _,key in ipairs({"panelStyle","glass","panelAlpha","backdrop","border","accent","gameFrames"})do L[key]=nil end
        L.preset="island" ns.db.islandStyle=true
    end
    T.Refresh()
    ns.db.chat.bgAlpha=ns.ChatOpacity()
    if ns.Window and ns.Window.log then ns.Window:SetScale(L.windowScale or 1) end
    if ns.Hub and ns.Hub.log then ns.Hub:SetScale(L.hubScale or 1) end
    if ns.Dock and ns.Dock.allBtn then
        -- Riding the chat's tab bar, the stack keeps the bar's size.
        ns.Dock:SetScale(ns.Dock.attached and 1 or (L.dockScale or 1))
    end
    if ns.GameFrames then ns.GameFrames.Apply() end
    if ns.Window.sendBtn then ns.Window.sendBtn.Paint(false) end
    if ns.Hub.sendBtn then ns.Hub.sendBtn.Paint(false) end
    if ns.Hub.PaintChips then ns.Hub:PaintChips() end
    if ns.Settings.RefreshChrome then ns.Settings:RefreshChrome() end
    if ns.Chat and ns.Chat.smf then ns.Chat:ApplySettings() end
    ns.Refresh()
end

function ns.Refresh()
    if ns.Dock and ns.Dock.Update then ns.Dock:Update() end
    if ns.Window and ns.Window:IsShown() then ns.Window:Render() end
    if ns.Hub and ns.Hub:IsShown() then ns.Hub:Render() end
end

function ns.AddMessage(c, outgoing, text, options)
    local msgs = c.messages
    local sys = options and options.sys or nil
    msgs[#msgs + 1] = { t = time(), out = (outgoing and not sys) or nil, text = text, sys = sys }
    local limit = (ns.db and ns.db.history) or 60
    while #msgs > limit do table.remove(msgs, 1) end
    c.seq = NextSeq()
    c.hidden = nil
    c.hubHidden = nil
    if not outgoing then
        if ns.IsViewing(c) then
            c.unread = 0
        else
            c.unread = (c.unread or 0) + 1
        end
    end
    if not outgoing and ns.Dock and ns.Dock.NoteWhisper then ns.Dock:NoteWhisper(c) end
    ns.Refresh()
    if not outgoing and ns.Dock then
        ns.Dock:OnIncoming(c)
        if not (options and options.silent) and (c.kind ~= "bn" or ns.db.soundBNet) then ns.PlayWhisperSound() end
    end
end

---------------------------------------------------------------------------
-- Whisper sound
---------------------------------------------------------------------------

local CHIME = "Interface\\AddOns\\" .. ADDON .. "\\Sounds\\whisper.ogg"
local lastSound = 0

-- preview = true: play regardless of combat / throttle (settings "Play" button)
function ns.PlayWhisperSound(preview)
    local choice = ns.db.sound or "chime"
    if choice == "off" then return end
    if not preview then
        if ns.ElvUI.PlaysWhisperSound() then return end -- ElvUI chat already dings
        if ns.db.soundCombat == false and InCombatLockdown and InCombatLockdown() then return end
        if GetTime() - lastSound < 1.5 then return end -- one sound for a burst of messages
    end
    lastSound = GetTime()
    if choice == "chime" then
        if not PlaySoundFile(CHIME, "Master") and SOUNDKIT then
            PlaySound(SOUNDKIT.TELL_MESSAGE) -- file not found until the game restarts
        end
    elseif choice == "pop" and SOUNDKIT then
        PlaySound(SOUNDKIT.UI_BNET_TOAST or SOUNDKIT.TELL_MESSAGE, "Master")
    elseif SOUNDKIT then
        PlaySound(SOUNDKIT.TELL_MESSAGE, "Master")
    end
end

-- The default chat plays its own "tell" ding, gated by each frame's tellTimer.
-- Parking that timer far in the future leaves our sound as the only one.
local function SilenceDefaultTell()
    for i = 1, NUM_CHAT_WINDOWS or 10 do
        local cf = _G["ChatFrame" .. i]
        if cf then cf.tellTimer = math.huge end
    end
end

function ns.MarkRead(c)
    if c and (c.unread or 0) > 0 then
        c.unread = 0
        ns.Refresh()
    end
end

local function ClassFileFromLocalized(localized)
    if not localized then return nil end
    for _, tbl in ipairs({ LOCALIZED_CLASS_NAMES_MALE or {}, LOCALIZED_CLASS_NAMES_FEMALE or {} }) do
        for file, name in pairs(tbl) do
            if name == localized then return file end
        end
    end
end

local function WowConvo(name, guid)
    if not Readable(name) or name == "" then return nil end
    local full = name
    if not full:find("-", 1, true) then
        local realm = GetNormalizedRealmName and GetNormalizedRealmName()
        if realm and realm ~= "" then full = full .. "-" .. realm end
    end
    local c = ns.GetConvo("w:" .. full, true)
    c.kind = "wow"
    c.name = full
    c.target = name -- exactly as the server sent it (see ns.WhisperTarget)
    c.display = (Ambiguate and Ambiguate(full, "none")) or full
    if guid and Readable(guid) and guid ~= "" and guid ~= UnitGUID("player") then
        c.guid = guid
    end
    if not c.class then ns.ResolveClass(c) end
    return c
end

---------------------------------------------------------------------------
-- Class lookup. A whisper's GUID only resolves once the client has seen that
-- player (and can arrive hidden on newer clients), so fall back to anything
-- else that knows the player: group, guild roster, friends list.
---------------------------------------------------------------------------

local function SameName(a, b)
    if not a or not b or not Readable(a) then return false end
    if a == b then return true end
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    if realm and not a:find("-", 1, true) then a = a .. "-" .. realm end
    return a == b
end

local function ClassFromGUID(guid)
    if not guid or not Readable(guid) then return nil end
    if GetPlayerInfoByGUID then
        local ok, _, classFile = pcall(GetPlayerInfoByGUID, guid)
        if ok and classFile and Readable(classFile) and classFile ~= "" then return classFile end
    end
    if C_PlayerInfo and C_PlayerInfo.GetClass and PlayerLocation and PlayerLocation.CreateFromGUID then
        local ok, _, classFile = pcall(function()
            return C_PlayerInfo.GetClass(PlayerLocation:CreateFromGUID(guid))
        end)
        if ok and classFile and Readable(classFile) and classFile ~= "" then return classFile end
    end
end

local function ClassFromGroup(full)
    local n = GetNumGroupMembers and GetNumGroupMembers() or 0
    if n == 0 then return nil end
    local prefix = IsInRaid and IsInRaid() and "raid" or "party"
    for i = 1, n do
        local unit = prefix .. i
        if UnitExists(unit) then
            local name, realm = UnitName(unit)
            if name and Readable(name) then
                if realm and Readable(realm) and realm ~= "" then name = name .. "-" .. realm end
                if SameName(name, full) then
                    local _, classFile = UnitClass(unit)
                    return classFile
                end
            end
        end
    end
end

local function ClassFromGuild(full)
    if not (IsInGuild and IsInGuild()) or not GetGuildRosterInfo then return nil end
    for i = 1, (GetNumGuildMembers and GetNumGuildMembers() or 0) do
        local name, _, _, _, _, _, _, _, _, _, classFile = GetGuildRosterInfo(i)
        if SameName(name, full) and classFile then return classFile end
    end
end

local function ClassFromFriends(full)
    if not (C_FriendList and C_FriendList.GetNumFriends and C_FriendList.GetFriendInfoByIndex) then return nil end
    for i = 1, (C_FriendList.GetNumFriends() or 0) do
        local info = C_FriendList.GetFriendInfoByIndex(i)
        if info and SameName(info.name, full) and info.className then
            return ClassFileFromLocalized(info.className)
        end
    end
end

---------------------------------------------------------------------------
-- Player details for tooltips: whatever the client knows right now.
---------------------------------------------------------------------------

-- A unit token for this player if they're targetable right now.
---------------------------------------------------------------------------
-- People we've seen: whenever the game shows us a player (mouseover,
-- target, nameplates, group), remember their level, guild, race and class
-- for this session, so name tooltips in chat can show them later.
---------------------------------------------------------------------------

ns.seen = {}
local seenCount = 0

local function FullName(name, realm)
    if not name or not Readable(name) or name == "" then return nil end
    if realm and Readable(realm) and realm ~= "" then return name .. "-" .. realm:gsub("%s", "") end
    if name:find("-", 1, true) then return name end
    local mine = GetNormalizedRealmName and GetNormalizedRealmName()
    return mine and (name .. "-" .. mine) or name
end
ns.FullName = FullName

function ns.RememberUnit(unit)
    if not unit or not UnitExists or not UnitExists(unit) or not UnitIsPlayer(unit) then return end
    local ok, name, realm = pcall(UnitName, unit)
    if not ok then return end
    local full = FullName(name, realm)
    if not full then return end
    local s = ns.seen[full]
    if not s then
        if seenCount > 600 then wipe(ns.seen) seenCount = 0 end
        s = {}
        ns.seen[full] = s
        seenCount = seenCount + 1
    end
    local lvl = UnitLevel and UnitLevel(unit)
    if Readable(lvl) and type(lvl) == "number" and lvl > 0 then s.level = lvl end
    local guild = GetGuildInfo and GetGuildInfo(unit)
    if Readable(guild) and type(guild) == "string" and guild ~= "" then s.guild = guild end
    local race = UnitRace and UnitRace(unit)
    if Readable(race) and type(race) == "string" then s.race = race end
    local _, classFile = UnitClass(unit)
    if Readable(classFile) and type(classFile) == "string" then s.class = classFile end
    s.t = time()
end

-- Class and race from a player GUID (chat lines carry one).
function ns.InfoFromGUID(guid)
    if not guid or not Readable(guid) or type(guid) ~= "string" or not GetPlayerInfoByGUID then return nil end
    local ok, _, classFile, race = pcall(GetPlayerInfoByGUID, guid)
    if not ok or not classFile or not Readable(classFile) then return nil end
    return { class = classFile, race = Readable(race) and race or nil }
end

---------------------------------------------------------------------------
-- Exact names. Two players can share a first name ("Dagobi Foreverpvp" and
-- "Dagobi Экслайнер"), and a chat link may only carry the first name, so an
-- invite or whisper by that alone can land on the wrong one. Use the fullest
-- name on hand: the one the game holds for the sender's GUID, the name as
-- shown in the chat line, or failing those the name we were given.
---------------------------------------------------------------------------

local function Words(name)
    local n = 0
    for _ in tostring(name):gsub("%-[^%s]*$", ""):gmatch("%S+") do n = n + 1 end
    return n
end

-- "Name-OurRealm" -> "Name". Invites to a two-word name fail with the realm
-- attached, and it is never needed for someone on our own realm.
function ns.StripOwnRealm(name)
    if type(name) ~= "string" then return name end
    local base, realm = name:match("^(.+)%-([^%-%s]+)$")
    if not base then return name end
    local function norm(r) return (tostring(r or ""):gsub("[%s%-']", ""):lower()) end
    local mine = GetNormalizedRealmName and GetNormalizedRealmName()
    if (not mine or mine == "") and GetRealmName then mine = GetRealmName() end
    if mine and mine ~= "" and norm(realm) == norm(mine) then return base end
    if Ambiguate then
        local ok, short = pcall(Ambiguate, name, "none")
        if ok and type(short) == "string" and short ~= "" and #short < #name then return short end
    end
    -- WoW: Forever names are "First Last" and unique across the region, so a
    -- tag after them is always a realm and the game rejects the name with it.
    if ns.IsForever() and base:find("%S%s+%S") then return base end
    return name
end

function ns.IsForever()
    if ns.isForever == nil then
        local iface = GetBuildInfo and select(4, GetBuildInfo())
        ns.isForever = type(iface) == "number" and iface >= 16000 and iface < 20000
    end
    return ns.isForever
end

function ns.NameFromGUID(guid)
    if type(guid) ~= "string" or not Readable(guid) or not GetPlayerInfoByGUID then return nil end
    local ok, _, _, _, _, _, name, realm = pcall(GetPlayerInfoByGUID, guid)
    if not ok or type(name) ~= "string" or not Readable(name) or name == "" then return nil end
    if type(realm) == "string" and Readable(realm) and realm ~= "" and not ns.IsForever() then name = name .. "-" .. realm end
    return name
end

-- shown: the name as displayed (may carry colour codes / brackets).
function ns.BestName(name, guid, shown)
    local best = name
    if type(shown) == "string" and Readable(shown) then
        local plain = shown:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("^%s*%[", ""):gsub("%]%s*$", "")
        plain = strtrim(plain)
        -- Only trust it when it is this same person's name with more of it showing.
        local first = tostring(name or ""):match("^(%S+)") or ""
        if plain ~= "" and first ~= "" and plain:sub(1, #first) == first and Words(plain) > Words(best or "") then
            best = plain
        end
    end
    local exact = ns.NameFromGUID(guid)
    if exact and Words(exact) >= Words(best or "") then best = exact end
    return best
end

function ns.Invite(name, guid, shown)
    local inv = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
    if not inv then return end
    local target = ns.BestName(name, guid, shown)
    if not target or target == "" then return end
    target = ns.StripOwnRealm(target)
    if ns.debugChat then
        Print(("inviting \"%s\"  (given \"%s\", shown \"%s\", from id \"%s\")"):format(
            tostring(target), tostring(name), tostring(shown), tostring(ns.NameFromGUID(guid))))
    end
    -- Two-word names: the plain invite only reads the first word, so prefer the
    -- game's own character-invite command when this client has one.
    local slashes = ns.InviteSlashes()
    if ns.debugChat then ns.InviteReport(slashes) end
    if target:find("%s") then
        for _, s in ipairs(slashes) do
            if s.character and type(SlashCmdList) == "table" and type(SlashCmdList[s.key]) == "function" then
                if ns.debugChat then Print("using " .. s.cmd) end
                if pcall(SlashCmdList[s.key], target) then return end
            end
        end
    end
    pcall(inv, target)
end

-- Every invite slash command this client defines; character = true for the
-- ones that take a full character name (the invite cousin of /cw).
function ns.InviteSlashes()
    if ns.inviteSlashes then return ns.inviteSlashes end
    local seen, out = {}, {}
    for k, v in pairs(_G) do
        if type(k) == "string" and type(v) == "string" then
            local key = k:match("^SLASH_(.-)%d+$")
            if key and key:find("INV", 1, true) and not seen[key] then
                seen[key] = true
                out[#out + 1] = { key = key, cmd = v, character = key:find("CHAR", 1, true) ~= nil }
            end
        end
    end
    table.sort(out, function(a, b) return a.key < b.key end)
    ns.inviteSlashes = out
    return out
end

function ns.InviteReport(slashes)
    local names = {}
    for _, s in ipairs(slashes) do names[#names + 1] = s.cmd .. " (" .. s.key .. ")" end
    Print("invite commands: " .. (#names > 0 and table.concat(names, ", ") or "none"))
    local fns = {}
    if type(C_PartyInfo) == "table" then
        for k, v in pairs(C_PartyInfo) do
            if type(k) == "string" and type(v) == "function" and k:find("Invite", 1, true) then fns[#fns + 1] = k end
        end
    end
    table.sort(fns)
    Print("invite functions: " .. (#fns > 0 and table.concat(fns, ", ") or "none"))
end

function ns.FindUnit(c)
    if c.kind ~= "wow" then return nil end
    local units = { "target", "focus", "mouseover" }
    local n = GetNumGroupMembers and GetNumGroupMembers() or 0
    local prefix = IsInRaid and IsInRaid() and "raid" or "party"
    for i = 1, n do units[#units + 1] = prefix .. i end
    for _, unit in ipairs(units) do
        if UnitExists(unit) and UnitIsPlayer(unit) then
            local name, realm = UnitName(unit)
            if name and Readable(name) then
                if realm and realm ~= "" then name = name .. "-" .. realm end
                if SameName(name, c.name) then return unit end
            end
        end
    end
end

function ns.LookupPlayer(c)
    local info = {}
    if c.kind == "bn" then
        local acct = C_BattleNet and C_BattleNet.GetAccountInfoByID and C_BattleNet.GetAccountInfoByID(c.bnID)
        if acct then
            info.battleTag = acct.battleTag
            info.note = acct.note ~= "" and acct.note or nil
            local g = acct.gameAccountInfo
            if g then
                info.online = g.isOnline
                info.character = g.characterName
                info.level = g.characterLevel
                info.zone = g.areaName ~= "" and g.areaName or g.richPresence
                info.game = g.clientProgram
            end
        end
        return info
    end
    if c.kind ~= "wow" then return info end

    if IsInGuild and IsInGuild() and GetGuildRosterInfo then
        for i = 1, (GetNumGuildMembers and GetNumGuildMembers() or 0) do
            local name, rank, _, level, _, zone, note, _, online = GetGuildRosterInfo(i)
            if SameName(name, c.name) then
                info.guildRank = rank
                info.level = level
                info.zone = zone
                info.online = online and true or false
                info.note = note ~= "" and note or nil
                info.guild = GetGuildInfo and GetGuildInfo("player")
                break
            end
        end
    end
    local s = c.name and ns.seen[c.name]
    if s then
        info.level = info.level or s.level
        info.guild = info.guild or s.guild
        info.race = s.race
    end
    if C_FriendList and C_FriendList.GetNumFriends and C_FriendList.GetFriendInfoByIndex then
        for i = 1, (C_FriendList.GetNumFriends() or 0) do
            local f = C_FriendList.GetFriendInfoByIndex(i)
            if f and SameName(f.name, c.name) then
                info.friend = true
                info.level = info.level or f.level
                info.zone = info.zone or f.area
                if info.online == nil then info.online = f.connected and true or false end
                info.note = info.note or (f.notes ~= "" and f.notes or nil)
                break
            end
        end
    end
    return info
end

-- Returns the class file and which source found it (for /pigeon classes).
function ns.ResolveClass(c)
    if c.kind ~= "wow" or c.class then return c.class end
    local sources = {
        { "guid", function() return ClassFromGUID(c.guid) end },
        { "group", function() return ClassFromGroup(c.name) end },
        { "guild", function() return ClassFromGuild(c.name) end },
        { "friends", function() return ClassFromFriends(c.name) end },
    }
    for _, s in ipairs(sources) do
        local ok, classFile = pcall(s[2])
        if ok and classFile then
            c.class = classFile
            c.classSource = s[1]
            return classFile
        end
    end
end

-- Try every conversation that is still missing a class; repaint if any resolved.
function ns.ResolveAll()
    local changed = false
    for _, c in pairs(ns.convos) do
        if c.kind == "wow" and not c.class and ns.ResolveClass(c) then changed = true end
    end
    if changed then ns.Refresh() end
end

-- Start (or reopen) a conversation by typed name, e.g. from the hub search.
function ns.StartConvo(name)
    name = strtrim(name or "")
    if name == "" then return nil end
    name = name:gsub("^%l", string.upper)
    local c = WowConvo(name)
    if c then c.hidden = nil c.hubHidden = nil end
    return c
end

local function BNetConvo(bnID)
    if not bnID or not Readable(bnID) or bnID == 0 then return nil end
    local c = ns.GetConvo("b:" .. bnID, true)
    c.kind = "bn"
    c.bnID = bnID
    local info = C_BattleNet and C_BattleNet.GetAccountInfoByID and C_BattleNet.GetAccountInfoByID(bnID)
    if info then
        local tag = info.battleTag
        if tag and Readable(tag) then
            c.display = tag:match("^[^#]+") or tag
            c.battleTag = tag -- saved with the conversation; the ID is re-found from it after a reload
        end
        local game = info.gameAccountInfo
        if game and game.className and Readable(game.className) then
            c.class = ClassFileFromLocalized(game.className) or c.class
        end
    end
    c.display = c.display or "Battle.net"
    return c
end
ns.BNetConvo = BNetConvo

-- Battle.net conversations are saved. A friend's ID can change between sessions, so after
-- login (and when the friend list changes) each saved conversation is matched to its
-- friend by BattleTag and moved to the friend's current ID, merging with any conversation
-- already started under that ID this session.
function ns.RelinkBNet()
    if not (BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo) then return end
    local n = BNGetNumFriends()
    if type(n) ~= "number" or n <= 0 then return end
    local byTag = {}
    for i = 1, n do
        local ok, info = pcall(C_BattleNet.GetFriendAccountInfo, i)
        if ok and type(info) == "table" and info.bnetAccountID and info.battleTag and Readable(info.battleTag) then
            byTag[info.battleTag] = info.bnetAccountID
        end
    end
    local moves = {}
    for key, c in pairs(ns.convos) do
        if c.kind == "bn" and c.battleTag and byTag[c.battleTag] and c.bnID ~= byTag[c.battleTag] then
            moves[#moves + 1] = { key = key, c = c, id = byTag[c.battleTag] }
        end
    end
    for _, m in ipairs(moves) do
        local newKey = "b:" .. m.id
        local old, other = m.c, ns.convos[newKey]
        ns.convos[m.key] = nil
        if other and other ~= old then
            -- the same friend already has a conversation this session: merge the two
            for _, msg in ipairs(old.messages or {}) do other.messages[#other.messages + 1] = msg end
            table.sort(other.messages, function(a, b) return (a.t or 0) < (b.t or 0) end)
            other.pinned = other.pinned or old.pinned
            other.starred = other.starred or old.starred
            other.note = other.note or old.note
            other.battleTag = other.battleTag or old.battleTag
            other.seq = math.max(other.seq or 0, old.seq or 0)
        else
            old.key, old.bnID = newKey, m.id
            ns.convos[newKey] = old
        end
    end
    if #moves > 0 and ns.Refresh then ns.Refresh() end
end
ns.ClassFileFromLocalized = ClassFileFromLocalized

-- Friends: Battle.net conversations always are; WoW ones are matched against
-- the character friends list (name set cached until the list changes).
local friendSet, friendBuilt
local bnCount, bnLoaded = 0, false
function ns.InvalidateFriends() friendSet = nil end

local function FriendSet()
    if friendSet then return friendSet end
    local set = {}
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    if C_FriendList and C_FriendList.GetNumFriends and C_FriendList.GetFriendInfoByIndex then
        for i = 1, (C_FriendList.GetNumFriends() or 0) do
            local ok, f = pcall(C_FriendList.GetFriendInfoByIndex, i)
            local name = ok and f and f.name
            if name and Readable(name) and type(name) == "string" and name ~= "" then
                set[name] = true
                if realm and realm ~= "" and not name:find("-", 1, true) then set[name .. "-" .. realm] = true end
            end
        end
    end
    -- Characters that Battle.net friends play (remembered so a friend who logs off still counts).
    local function AddBN(g)
        if type(g) ~= "table" then return end
        local prog = g.clientProgram
        if Readable(prog) and prog ~= (BNET_CLIENT_WOW or "WoW") then return end
        local char, r = g.characterName, g.realmName
        if not (Readable(char) and type(char) == "string" and char ~= "") then return end
        if not (Readable(r) and type(r) == "string") then r = "" end
        r = r:gsub("%s", "")
        if r == "" then r = realm or "" end
        local full = r ~= "" and (char .. "-" .. r) or char
        set[full] = true
        if r == realm then set[char] = true end
        local store = ns.db and ns.db.bnChars
        if ns.db and not store then store = {}; ns.db.bnChars = store end
        if store and not store[full] then
            if not bnLoaded then bnLoaded = true; bnCount = 0; for _ in pairs(store) do bnCount = bnCount + 1 end end
            if bnCount >= 200 then wipe(store); bnCount = 0 end
            store[full] = true
            bnCount = bnCount + 1
        end
    end
    if BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo then
        for i = 1, (BNGetNumFriends() or 0) do
            local ok, info = pcall(C_BattleNet.GetFriendAccountInfo, i)
            if ok and type(info) == "table" then
                AddBN(info.gameAccountInfo)
                if C_BattleNet.GetFriendNumGameAccounts and C_BattleNet.GetFriendGameAccountInfo then
                    for j = 1, (C_BattleNet.GetFriendNumGameAccounts(i) or 0) do
                        local ok2, ga = pcall(C_BattleNet.GetFriendGameAccountInfo, i, j)
                        if ok2 then AddBN(ga) end
                    end
                end
            end
        end
    end
    local store = ns.db and ns.db.bnChars
    if store then
        for full in pairs(store) do
            set[full] = true
            if realm and realm ~= "" and full:sub(-#realm - 1) == "-" .. realm then set[full:sub(1, -#realm - 2)] = true end
        end
    end
    friendSet = set
    friendBuilt = GetTime()
    return set
end

local function InSet(set, name)
    if set[name] then return true end
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    if realm and realm ~= "" and name:sub(-#realm - 1) == "-" .. realm then
        return set[name:sub(1, -#realm - 2)] and true or false
    end
    return false
end

function ns.IsFriend(c)
    if not c then return false end
    if c.kind == "bn" then return true end
    if c.kind ~= "wow" or not c.name then return false end
    if InSet(FriendSet(), c.name) then return true end
    -- A brand-new sender may not be cached yet; rebuild at most every 5 seconds.
    if friendBuilt and GetTime() - friendBuilt > 5 then
        friendSet = nil
        return InSet(FriendSet(), c.name)
    end
    return false
end

---------------------------------------------------------------------------
-- Sending
---------------------------------------------------------------------------

local TEST_REPLIES = { "sounds good", "omw", "lol yes", "give me 5 min", "perfect, ty!" }

-- The name to whisper. Conversations are keyed "Name-Realm" so the same
-- player is never split in two, but the realm is only added for that key.
-- Some servers (WoW: Forever / the Classic beta, where names can contain
-- spaces) don't accept "Name-Realm" at all, so whisper players on our own
-- realm by the plain name the server gave us.
function ns.WhisperTarget(c)
    if c.target then return c.target end
    local name = c.name or ""
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    if realm and realm ~= "" then
        local suffix = "-" .. realm
        if name:sub(-#suffix) == suffix then name = name:sub(1, -#suffix - 1) end
    end
    return name
end

-- In combat (encounters, PvP...) the game stops addons from sending chat;
-- only its own chat box may. So when our send is refused, hand the message
-- to that box, already addressed and typed: one press of Enter sends it.
local function ChatLocked()
    local f = (C_ChatInfo and C_ChatInfo.InChatMessagingLockdown) or _G.InChatMessagingLockdown
    if type(f) ~= "function" then return false end
    local ok, locked = pcall(f)
    return ok and locked == true
end
ns.ChatLocked = ChatLocked

-- WoW: Forever whispers a character with "/cw First Last" (two-word names);
-- everywhere else it's "/w".
function ns.WhisperCommand()
    for _, key in ipairs({ "CHARACTER_WHISPER", "CHARWHISPER" }) do
        local cmd = _G["SLASH_" .. key .. "1"]
        if type(cmd) == "string" and cmd ~= "" then return cmd end
    end
    local iface = GetBuildInfo and select(4, GetBuildInfo())
    if type(iface) == "number" and iface >= 16000 and iface < 20000 then return "/cw" end
    return "/w"
end

local handOffHint
function ns.HandOff(c, text)
    if not c or c.kind == "test" then return false end
    local ok = false
    if c.kind == "bn" then
        local tell = (ChatFrameUtil and ChatFrameUtil.SendBNetTell) or _G.ChatFrame_SendBNetTell
        if tell and c.display then
            ok = pcall(tell, c.display)
            local eb = _G.ChatFrame1EditBox
            if ok and eb and eb:IsShown() then eb:Insert(text) end
        end
    else
        local open = (ChatFrameUtil and ChatFrameUtil.OpenChat) or _G.ChatFrame_OpenChat
        if open then ok = pcall(open, ns.WhisperCommand() .. " " .. ns.WhisperTarget(c) .. " " .. text) end
    end
    if ok and not handOffHint then
        handOffHint = true
        Print(L["the game only lets its own chat box send during combat. Your message is typed there: press Enter to send it."])
    end
    return ok
end

-- The game can refuse a send without an error: it reports a blocked action.
local pendingSend
local blockWatch
local function WatchBlocks()
    if blockWatch then return end
    blockWatch = CreateFrame("Frame")
    blockWatch:RegisterEvent("ADDON_ACTION_BLOCKED")
    blockWatch:RegisterEvent("ADDON_ACTION_FORBIDDEN")
    blockWatch:SetScript("OnEvent", function(_, _, addon)
        local p = pendingSend
        if not p or addon ~= ADDON then return end
        pendingSend = nil
        if (GetTime and GetTime() or 0) - p.t < 0.5 then ns.HandOff(p.c, p.text) end
    end)
end

-- auto = true: an automatic message (away reply); never opens the chat box.
function ns.Send(c, text, auto)
    if not c then return end
    text = strtrim(text or "")
    if text == "" then return end
    if c.kind == "test" then
        ns.AddMessage(c, true, text)
        C_Timer.After(1.5, function()
            ns.AddMessage(c, false, TEST_REPLIES[math.random(#TEST_REPLIES)])
        end)
        return
    end
    if ChatLocked() then
        if not auto then ns.HandOff(c, text) end
        return
    end
    WatchBlocks()
    if not auto and c.kind ~= "bn" then ns.lastWhisper = { c = c, t = GetTime and GetTime() or 0 } end
    pendingSend = (not auto) and { c = c, text = text, t = GetTime and GetTime() or 0 } or nil
    local ok
    if c.kind == "bn" then
        ok = pcall(BNSendWhisper, c.bnID, text)
    else
        local send = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
        ok = pcall(send, text, "WHISPER", nil, ns.WhisperTarget(c))
    end
    if not ok then
        pendingSend = nil
        if not auto then ns.HandOff(c, text) end
    end
    -- Real whispers are recorded when the server echoes them back (WHISPER_INFORM).
end


---------------------------------------------------------------------------
-- Test mode: fake whispers so the dock can be tried without a partner
---------------------------------------------------------------------------

local TEST_PEOPLE = {
    { name = "Vexa", class = "MAGE", lines = { "gg, same time tomorrow?" } },
    { name = "Thornwick", class = "ROGUE", lines = { "hey, you around?", "you still need the key for tonight?" } },
    { name = "Brisa", class = "DRUID", lines = { "got the leather + threads", "can you craft the cloak if I send mats?" } },
    { name = "Nolara", class = "PRIEST", lines = { "I can heal if you still need one." } },
    { name = "Garron", class = "WARRIOR", lines = { "Ready to tank when you are." } },
    { name = "Elowen", class = "PALADIN", lines = { "Meet you at the entrance?" } },
    { name = "Flint", class = "HUNTER", lines = { "On my way, just grabbing arrows." } },
    { name = "Zhara", class = "SHAMAN", lines = { "Do you need any potions?" } },
    { name = "Morvyn", class = "WARLOCK", lines = { "I have shards for summons." } },
    { name = "Sable", class = "ROGUE", lines = { "Found the chest you mentioned." } },
    { name = "Caelis", class = "MAGE", lines = { "Want a portal after the run?" } },
    { name = "Rowan", class = "DRUID", lines = { "Thanks for the group!" } },
}

function ns.RunTest(count)
    count=math.max(1,math.min(#TEST_PEOPLE,math.floor(tonumber(count) or 3)))
    local delay = 0
    for i = 1, count do
        local p=TEST_PEOPLE[i]
        for _, line in ipairs(p.lines) do
            delay = delay + (count > 3 and .45 or 1.2)
            C_Timer.After(delay, function()
                local c = ns.GetConvo("t:" .. p.name, true)
                c.kind, c.temp, c.display, c.class = "test", true, p.name, p.class
                ns.AddMessage(c, false, line)
            end)
        end
    end
    Print(L["sending fake whispers from %d test people…"]:format(count))
end

---------------------------------------------------------------------------
-- Shift-clicking an item while one of our inputs has focus links it there
---------------------------------------------------------------------------

local function HookLinkInsert()
    local function onInsert(link)
        local e = ns.focusedEdit
        if e and e:HasFocus() and type(link) == "string" then
            e:Insert(link)
        end
    end
    if ChatFrameUtil and type(ChatFrameUtil.InsertLink) == "function" then
        hooksecurefunc(ChatFrameUtil, "InsertLink", onInsert)
    elseif type(ChatEdit_InsertLink) == "function" then
        hooksecurefunc("ChatEdit_InsertLink", onInsert)
    end
end

---------------------------------------------------------------------------
-- Optional: hide whispers from the default chat frame
---------------------------------------------------------------------------

local function ChatFilter()
    return ns.db and ns.db.hideFromChat
end

local function InstallChatFilters()
    local add = ChatFrame_AddMessageEventFilter
        or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
    if not add then return end
    for _, ev in ipairs({ "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM" }) do
        add(ev, ChatFilter)
    end
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_LOGOUT")

local handlers = {}

function handlers.ADDON_LOADED(name)
    if name ~= ADDON then return end
    -- Renamed from "Whisper Stack" (then "Parley"): the first time Pigeon loads, pick up the
    -- settings saved under the old name (their file was copied across).
    if PigeonDB == nil and type(WhisperStackDB) == "table" then
        PigeonDB = WhisperStackDB
        ns.cameFromWhisperStack = true
    end
    WhisperStackDB = nil
    PigeonDB = PigeonDB or {}
    ApplyDefaults(PigeonDB, DEFAULTS)
    ns.db = PigeonDB
    ns.Migrations.Run(ns.db)

    if PigeonHistory == nil and type(WhisperStackHistory) == "table" then PigeonHistory = WhisperStackHistory end
    WhisperStackHistory = nil
    PigeonHistory = PigeonHistory or {}
    PigeonHistory.convos = PigeonHistory.convos or {}
    PigeonHistory.seq = PigeonHistory.seq or 0
    ns.hist = PigeonHistory
    ns.convos = ns.hist.convos
end

function ns.FillDefaults() ApplyDefaults(ns.db, DEFAULTS) end

function handlers.PLAYER_LOGIN()
    ns.Profiles.LoginLoad() -- this character's own profile, if it has one
    T.Refresh()     -- paint new controls with the selected palette on their first frame
    -- One part failing must not take the rest down with it: say what broke and carry on.
    local function Step(name, fn, ...)
        local ok, err = pcall(fn, ...)
        if not ok then
            ns.startupErrors = ns.startupErrors or {}
            ns.startupErrors[#ns.startupErrors + 1] = name .. ": " .. tostring(err)
            Print("could not start " .. name .. " (" .. tostring(err) .. "). /pigeon chatstatus shows more.")
        end
    end
    Step("chat", ns.Chat.Init, ns.Chat)   -- before the dock, which may attach to it
    Step("dock", ns.Dock.Init, ns.Dock)
    Step("whisper window", ns.Window.Init, ns.Window)
    Step("hub", ns.Hub.Init, ns.Hub)
    Step("ElvUI", ns.ElvUI.Setup)
    Step("EllesmereUI", ns.Ellesmere.Setup)
    Step("Edit Mode", ns.EditMode.Setup)
    Step("look", ns.ApplyLook)
    if ns.Island.StartWatching then ns.Island.StartWatching() end
    ns.Launcher.Init()
    if InCombatLockdown and InCombatLockdown() then ns.Profiles.EnterCombat() end
    SilenceDefaultTell()
    HookLinkInsert()
    InstallChatFilters()
    for _, ev in ipairs({ "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM",
                          "CHAT_MSG_SYSTEM", "WHO_LIST_UPDATE", "GUILD_ROSTER_UPDATE", "FRIENDLIST_UPDATE", "GROUP_ROSTER_UPDATE",
                          "BN_FRIEND_LIST_SIZE_CHANGED", "BN_FRIEND_INFO_CHANGED", "BN_FRIEND_ACCOUNT_ONLINE", "BN_FRIEND_ACCOUNT_OFFLINE",
                          "UPDATE_MOUSEOVER_UNIT", "PLAYER_TARGET_CHANGED", "NAME_PLATE_UNIT_ADDED" }) do
        events:RegisterEvent(ev)
    end
    -- Ask for fresh guild/friends data so saved conversations can be coloured.
    if C_GuildInfo and C_GuildInfo.GuildRoster and IsInGuild and IsInGuild() then C_GuildInfo.GuildRoster() end
    if C_FriendList and C_FriendList.ShowFriends then C_FriendList.ShowFriends() end
    ns.ResolveAll()
    ns.RelinkBNet()
    C_Timer.After(3, ns.RelinkBNet) -- the Battle.net friend list may not be ready yet
    ns.Refresh()
end

function handlers.PLAYER_LOGOUT()
    ns.Chat:SaveHistory()
    -- Drop test conversations (Battle.net ones are kept and re-linked by BattleTag).
    for key, c in pairs(ns.convos) do
        if c.temp then ns.convos[key] = nil end
    end
end

function handlers.CHAT_MSG_WHISPER(text, sender, _, _, _, flags, _, _, _, _, _, guid)
    if not Readable(text) then return end
    local c = WowConvo(sender, guid)
    if not c then return end
    if flags == "GM" then c.gm = true end
    ns.AddMessage(c, false, text)
    ns.Social.OnIncoming(c, text, flags)
    if not c.class then
        -- The client often caches the sender a moment after the whisper lands.
        C_Timer.After(2, function()
            if not c.class and ns.ResolveClass(c) then ns.Refresh() end
        end)
    end
end

function handlers.CHAT_MSG_WHISPER_INFORM(text, target, _, _, _, _, _, _, _, _, _, guid)
    if not Readable(text) then return end
    local c = WowConvo(target, guid)
    if c then ns.AddMessage(c, true, text) end
end

-- "No player named X is currently playing." arrives as a system line, which only the
-- General tab shows. Put it in the conversation you just tried to message.
local notFoundPattern
function handlers.CHAT_MSG_SYSTEM(text)
    local p = ns.lastWhisper
    if not p or not Readable(text) or (GetTime and GetTime() or 0) - p.t > 3 then return end
    if not notFoundPattern then
        local fmt = ERR_CHAT_PLAYER_NOT_FOUND_S or "No player named '%s' is currently playing."
        notFoundPattern = "^" .. fmt:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
    end
    if text:match(notFoundPattern) then
        ns.lastWhisper = nil
        ns.AddMessage(p.c, true, text, { sys = true })
    end
end

-- /who lookup. The game only lets its own code send a /who, so this opens the Who window
-- (or the chat box) with the search typed in and you press Enter. If it came from a conversation, the answer is
-- also written into that conversation as a note.
local pendingWho
function ns.WhoLookup(c, name)
    local target = name or (c and c.kind == "wow" and ns.WhisperTarget(c))
    if not target or target == "" then return end
    local query = 'n-"' .. target .. '"'
    pendingWho = c and { c = c, name = c.display or target, t = GetTime and GetTime() or 0 } or nil
    -- Preferred: the game's Who window with the search typed in; Enter runs it.
    local edit = _G.WhoFrameEditBox
    if edit and _G.FriendsFrame and _G.FriendsFrameTab2 then
        local ok = pcall(function()
            if not FriendsFrame:IsShown() then ShowUIPanel(FriendsFrame) end
            FriendsFrameTab2:Click()
            edit:SetText(query)
            edit:SetFocus()
            edit:HighlightText(0, 0)
        end)
        if ok then
            Print(L["Press Enter in the Who window to search."])
            return
        end
    end
    -- Fallback: the same search typed into the chat box.
    local open = (ChatFrameUtil and ChatFrameUtil.OpenChat) or _G.ChatFrame_OpenChat
    if open then pcall(open, "/who " .. query) end
end

function handlers.WHO_LIST_UPDATE()
    local p = pendingWho
    if not p or (GetTime and GetTime() or 0) - p.t > 60 then return end
    pendingWho = nil
    local info
    if C_FriendList and C_FriendList.GetNumWhoResults and C_FriendList.GetNumWhoResults() > 0 then
        local ok, v1, v2, v3, v4, v5, v6 = pcall(C_FriendList.GetWhoInfo, 1)
        if ok and type(v1) == "table" then
            info = v1
        elseif ok and type(v1) == "string" then -- older clients return the fields one by one
            info = { fullName = v1, fullGuildName = v2, level = v3, raceStr = v4, classStr = v5, area = v6 }
        end
    end
    local text
    if type(info) == "table" and Readable(info.fullName) then
        local parts = { (L["level %s"]):format(tostring(info.level or "?")) }
        if info.raceStr and info.raceStr ~= "" then parts[#parts + 1] = info.raceStr end
        if info.classStr and info.classStr ~= "" then parts[#parts + 1] = info.classStr end
        text = p.name .. ": " .. table.concat(parts, " ")
        if info.fullGuildName and info.fullGuildName ~= "" then text = text .. " <" .. info.fullGuildName .. ">" end
        if info.area and info.area ~= "" then text = text .. ", " .. info.area end
    else
        text = (L["%s is not online."]):format(p.name)
    end
    ns.AddMessage(p.c, true, text, { sys = true })
end

-- New roster/friends/group data may now know players we couldn't place.
local function ScheduleResolve()
    if handlers.resolvePending then return end
    handlers.resolvePending = true
    C_Timer.After(1, function()
        handlers.resolvePending = nil
        ns.ResolveAll()
    end)
end
handlers.GUILD_ROSTER_UPDATE = ScheduleResolve
handlers.FRIENDLIST_UPDATE = function()
    ns.InvalidateFriends()
    ScheduleResolve()
end
for _, ev in ipairs({ "BN_FRIEND_LIST_SIZE_CHANGED", "BN_FRIEND_INFO_CHANGED", "BN_FRIEND_ACCOUNT_ONLINE", "BN_FRIEND_ACCOUNT_OFFLINE" }) do
    handlers[ev] = function()
        ns.InvalidateFriends()
        if ev == "BN_FRIEND_LIST_SIZE_CHANGED" then ns.RelinkBNet() end
    end
end
handlers.GROUP_ROSTER_UPDATE = function()
    ScheduleResolve()
    local n = GetNumGroupMembers and GetNumGroupMembers() or 0
    local prefix = IsInRaid and IsInRaid() and "raid" or "party"
    for i = 1, n do pcall(ns.RememberUnit, prefix .. i) end
end
function handlers.UPDATE_MOUSEOVER_UNIT() pcall(ns.RememberUnit, "mouseover") end
function handlers.PLAYER_TARGET_CHANGED() pcall(ns.RememberUnit, "target") end
function handlers.NAME_PLATE_UNIT_ADDED(unit) pcall(ns.RememberUnit, unit) end

function handlers.CHAT_MSG_BN_WHISPER(text, ...)
    if not Readable(text) then return end
    local bnID = select(12, ...) -- 13th event argument
    local c = BNetConvo(bnID)
    if c then
        ns.AddMessage(c, false, text)
        ns.Social.OnIncoming(c, text)
    end
end

function handlers.CHAT_MSG_BN_WHISPER_INFORM(text, ...)
    if not Readable(text) then return end
    local bnID = select(12, ...)
    local c = BNetConvo(bnID)
    if c then ns.AddMessage(c, true, text) end
end

events:SetScript("OnEvent", function(_, event, ...)
    local h = handlers[event]
    if h then h(...) end
end)

---------------------------------------------------------------------------
-- Key binding + slash commands
---------------------------------------------------------------------------

function WhisperStack_Reply()
    if ns.Dock then ns.Dock:ReplyNewest() end
end

function WhisperStack_Hub()
    if ns.Hub then ns.Hub:Toggle() end
end

---------------------------------------------------------------------------
-- Public API for other addons (used by Island XP's whisper cards)
---------------------------------------------------------------------------

PigeonAPI = PigeonAPI or {}
-- Only PigeonAPI: "ParleyAPI" belongs to an unrelated addon called Parley.

-- Set to true by an addon that shows incoming whispers itself; the dock then
-- skips its own preview bubble (tiles, badges and the sound are unchanged).
PigeonAPI.externalPreview = PigeonAPI.externalPreview or false

local function ApiConvo(sender, guid, bnID)
    if bnID then return BNetConvo(bnID) end
    if type(sender) ~= "string" or sender == "" then return nil end
    return WowConvo(sender, guid)
end

-- { name, r, g, b, unread, viewing } for the conversation with this sender, or nil.
function PigeonAPI.Info(sender, guid, bnID)
    local ok, c = pcall(ApiConvo, sender, guid, bnID)
    if not ok or not c then return nil end
    local r, g, b = ns.ConvoColor(c)
    return { name = c.display, r = r, g = g, b = b, unread = c.unread or 0, viewing = ns.IsViewing(c) }
end

-- Is the player typing in one of Pigeon's text boxes right now?
function PigeonAPI.IsTyping()
    local f = GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus()
    if not f then return false end
    if ns.Chat and f == ns.Chat.eb then return true end
    for _ = 1, 12 do
        if f == ns.Window or f == ns.Hub then return true end
        f = f.GetParent and f:GetParent()
        if not f then break end
    end
    return false
end

-- Open the conversation window for this sender with the reply box focused.
function PigeonAPI.Open(sender, guid, bnID)
    local ok, c = pcall(ApiConvo, sender, guid, bnID)
    if not ok or not c or not ns.Window then return false end
    if ns.Hub and T.IsOpen(ns.Hub) then
        ns.Hub:Close(function() ns.Window:Open(c, true) end)
    else
        ns.Window:Open(c, true)
    end
    return true
end

local function OnOff(v) return v and ("|cff33cc66" .. L["on"] .. "|r") or ("|cffff6666" .. L["off"] .. "|r") end

SLASH_PIGEON1 = "/pigeon"
SLASH_PIGEON2 = "/ws" -- the oldest name's command still works
SlashCmdList.PIGEON = function(msg)
    local cmd = strtrim((msg or ""):lower())
    local word, rest = strtrim(msg or ""):match("^(%S+)%s*(.*)$")
    if word and word:lower() == "away" then
        -- /pigeon away           toggles the away message
        -- /pigeon away <message> turns it on with that message
        local a = ns.db.away
        if rest and rest ~= "" then
            a.message = rest
            a.enabled = true
        else
            a.enabled = not a.enabled
        end
        ns.Social.ResetAway()
        Print(L["away message: %s"]:format(OnOff(a.enabled) .. (a.enabled and ('  "' .. a.message .. '"') or "")))
        return
    end
    if cmd == "export" then
        ns.Profiles.ShowExport()
        return
    elseif cmd == "import" then
        ns.Profiles.ShowImport()
        return
    end
    if cmd == "config" or cmd == "settings" or cmd == "options" then
        ns.Settings:Toggle()
    elseif cmd == "" or cmd == "hub" then
        ns.Hub:Toggle()
    elseif word and word:lower() == "test" then
        local count=rest=="" and 3 or tonumber(rest)
        if not count or count~=math.floor(count) or count<1 or count>#TEST_PEOPLE then
            Print(L["Use /pigeon test [1-12], for example /pigeon test 12."])
            return
        end
        ns.RunTest(count)
    elseif cmd == "hide" then
        ns.db.hideFromChat = not ns.db.hideFromChat
        Print(L["hide whispers from chat frame: %s"]:format(OnOff(ns.db.hideFromChat)))
    elseif cmd == "tint" then
        ns.db.classTint = not ns.db.classTint
        ns.ApplyLook()
        Print(L["class tint: %s"]:format(OnOff(ns.db.classTint)))
    elseif cmd == "chatdebug" then
        ns.debugChat = not ns.debugChat
        Print("chat debug: " .. OnOff(ns.debugChat) .. (ns.debugChat and "  (each line shows how it was filed)" or ""))
    elseif cmd == "ebdebug" then
        -- Chat input caret/link spacing: run it with a link typed in the box.
        local eb = ns.Chat and ns.Chat.eb
        if not eb then Print("no edit box") else
            local font, size, flags = eb:GetFont()
            local l, r, t, b = eb:GetTextInsets()
            local text = eb:GetText() or ""
            Print(("edit box: font=%s size=%s flags=%s"):format(tostring(font), tostring(size), tostring(flags)))
            Print(("insets L%s R%s  width=%.0f  chars=%d  cursor=%s  visible=%s"):format(tostring(l), tostring(r), eb:GetWidth(), #text, tostring(eb:GetCursorPosition()), tostring(eb.GetNumLetters and eb:GetNumLetters())))
            Print(("indentedWrap/multiline: %s / %s  altArrow: %s"):format(tostring(eb.GetIndentedWordWrap and eb:GetIndentedWordWrap()), tostring(eb:IsMultiLine()), tostring(eb:GetAltArrowKeyMode())))
        end
    elseif cmd == "tiles" then
        ns.Dock:ToggleTiles()
    elseif cmd == "emdebug" then
        local em = ns.EditMode
        Print("edit mode: " .. tostring(em.status))
    elseif cmd == "btndebug" then
        if ns.Chat and ns.Chat.DebugSideButtons then ns.Chat:DebugSideButtons() end
    elseif cmd == "chatstatus" then
        -- For "my chat box is missing": says why it is off, hidden or off screen.
        local c = ns.Chat
        local v, build = GetBuildInfo()
        Print(("Pigeon %s on %s (build %s)"):format(tostring(C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version") or GetAddOnMetadata and GetAddOnMetadata(ADDON, "Version")), tostring(v), tostring(build)))
        Print(("chat enabled=%s  built=%s  blockedBy=%s  shown=%s  mover UI=%s"):format(tostring(c.db and c.db.enabled), tostring(c.smf ~= nil), tostring(c.blockedBy), tostring(c:IsShown()), tostring(ns.UsesMovers and ns.UsesMovers())))
        local l, b, w, h = c:GetRect()
        Print(("rect left=%s bottom=%s width=%s height=%s  screen=%.0fx%.0f  scale=%.2f alpha=%.2f"):format(tostring(l and math.floor(l)), tostring(b and math.floor(b)), tostring(w and math.floor(w)), tostring(h and math.floor(h)), UIParent:GetWidth(), UIParent:GetHeight(), c:GetEffectiveScale(), c:GetEffectiveAlpha()))
        if c.db then Print(("saved point=%s,%s,%s,%s  size=%sx%s"):format(tostring(c.db.point and c.db.point[1]), tostring(c.db.point and c.db.point[2]), tostring(c.db.point and c.db.point[3]), tostring(c.db.point and c.db.point[4]), tostring(c.db.width), tostring(c.db.height))) end
        for _, e in ipairs(ns.startupErrors or {}) do Print("startup error - " .. e) end
        Print("if it is off screen or tiny, run /pigeon chatreset")
    elseif cmd == "chatreset" then
        -- Puts the chat box back at its default place and size, turned on and shown.
        local d = DEFAULTS.chat
        local c = ns.Chat
        local cdb = ns.db.chat
        cdb.enabled = true
        cdb.point = { d.point[1], d.point[2], d.point[3], d.point[4] }
        cdb.width, cdb.height = d.width, d.height
        if c.smf then
            c:ApplySettings()
            c:Show()
            Print("chat box reset to its default place and size.")
        else
            Print("chat box reset; type /reload to bring it back.")
        end
    elseif cmd == "chandebug" then
        local eb = ns.Chat and ns.Chat.eb
        if not eb then Print("no edit box") return end
        if not eb.pgDbg then
            eb.pgDbg = true
            hooksecurefunc(eb, "SetAttribute", function(_, k, v)
                if k == "chatType" or k == "stickyType" or k == "channelTarget" then
                    Print(("attr %s=%s | %s"):format(k, tostring(v), (debugstack(3, 2, 0) or ""):gsub("%c+", " <- ")))
                end
            end)
            hooksecurefunc(eb, "Hide", function() Print("eb Hide | " .. (debugstack(3, 2, 0) or ""):gsub("%c+", " <- ")) end)
            Print("channel debug on: pick a channel, click away, click the bar, then paste the output")
        end
        local p = ns.Chat.pick
        Print(("now: chatType=%s sticky=%s pick=%s shown=%s"):format(tostring(eb:GetAttribute("chatType")),
            tostring(eb:GetAttribute("stickyType")), p and tostring(p.kind) or "nil", tostring(eb:IsShown())))
    elseif word and word:lower() == "fadedebug" then
        -- /pigeon fadedebug [seconds]: print the fade state now, or after a wait (so the chat can go idle first)
        local function Run()
            local c = ns.Chat
            if not (c and c.smf) then Print("Pigeon chat box is off") return end
            local db = c.db
            local function A(f) return f and f.GetAlpha and string.format("%.3f", f:GetAlpha()) or "-" end
            Print(("fade: idleFade=%s idleAlpha=%s hideText=%s combat=%s/%s locked=%s"):format(tostring(db.idleFade), tostring(db.idleAlpha),
                tostring(db.idleHideText), tostring(ns.db.combat and ns.db.combat.chat), tostring(ns.db.combat and ns.db.combat.alpha), tostring(db.locked)))
            Print(("now: chrome=%s target=%s idle=%s combatAlpha=%s bgAlphaNow=%s ebShown=%s ebFocus=%s mouseOver=%s"):format(tostring(c.chromeAlpha), tostring(c.fadeTarget),
                tostring(c.fadeIdle), tostring(c.combatAlpha), tostring(c.bgAlphaNow), tostring(c.eb and c.eb:IsShown()),
                tostring(c.eb and c.eb:HasFocus()), tostring(c:IsMouseOver())))
            Print(("alphas: bg=%s sheen=%s border1=%s bar=%s fakeInput=%s eb=%s smf=%s chat=%s skin=%s"):format(A(c.bg), A(c.sheen),
                A(c.border and c.border[1]), A(c.bar), A(c.fakeInput), A(c.eb), A(c.smf), A(c), A(c.wsSkin)))
            local function E(f) return f and f.GetEffectiveAlpha and string.format("%.3f", f:GetEffectiveAlpha()) or "-" end
            local d = ns.Dock
            local tile
            for _, t in pairs(d and d.byKey or {}) do tile = t break end
            Print(("effective: bg=%s fakeInput=%s eb=%s dock=%s dockBtn=%s tile=%s rail=%s | attached=%s fakeShown=%s ebShown=%s"):format(
                E(c.bg), E(c.fakeInput), E(c.eb), E(d), E(d and d.allBtn), E(tile), E(c.tileRail),
                tostring(d and d.attached), tostring(c.fakeInput and c.fakeInput:IsShown()), tostring(c.eb and c.eb:IsShown())))
            local p = c.fakeInput
            Print(("fakeInput parts: bg=%s border1=%s well=%s send=%s"):format(E(p and p.bg), E(p and p.border and p.border[1]),
                E(p and p.textWell), E(p and p.send)))
        end
        local wait = tonumber(rest)
        if wait and wait > 0 then
            Print("fade debug: reading in " .. wait .. "s, keep your hands off the keyboard and mouse")
            C_Timer.After(wait, Run)
        else
            Run()
        end
    elseif cmd == "tabdebug" then
        if ns.Chat and ns.Chat.DebugTabs then ns.Chat:DebugTabs() end
    elseif cmd == "seldebug" then
        local look = ns.db and ns.db.look
        Print("select: bubbleSelect=" .. tostring(look and look.bubbleSelect) .. " autoCopy=" .. tostring(look and look.selectAutoCopy))
        local log = ns.Hub and ns.Hub.log
        local n = 0
        for _, b in ipairs(log and log.bubbles or {}) do
            if b:IsShown() then
                n = n + 1
                local s = b.smf
                Print(("  bubble %d: smf=%s charOK=%s visibleLines=%s"):format(n, tostring(s and true or s), tostring(s and s.charOK), type(s and s.visibleLines)))
                if n >= 2 then break end
            end
        end
        Print("  noSMF=" .. tostring(log and log.noSMF) .. " selection=" .. tostring(log and (log.csel and "char" or log.selLo and "msg" or "none")))
    elseif cmd == "animdebug" then
        ns.debugAnim = not ns.debugAnim
        Print("animation debug: " .. OnOff(ns.debugAnim) .. (ns.debugAnim and "  (open a whisper from its tile)" or ""))
    elseif cmd == "classes" then
        ns.ResolveAll()
        Print("class lookup per conversation:")
        for _, c in pairs(ns.convos) do
            if c.kind == "wow" then
                local guidState = not c.guid and "no id" or (Readable(c.guid) and "id ok" or "id hidden")
                local r, g, b = ns.ConvoColor(c)
                local function hex(v) return math.floor(v * 255 + 0.5) end
                print(("  |cff%02x%02x%02x%s|r  -  %s  (%s, %s)"):format(hex(r), hex(g), hex(b), c.display or "?",
                    c.class or "|cffff6666unknown|r", c.classSource or "saved/test", guidState))
            end
        end
    elseif cmd == "reset" then
        ns.db.point = { DEFAULTS.point[1], DEFAULTS.point[2], DEFAULTS.point[3], DEFAULTS.point[4] }
        ns.Dock:ApplyPosition()
        Print(ns.UsesMovers() and L["the dock is placed with your UI's mover mode."] or L["dock position reset."])
    elseif cmd == "clear" then
        wipe(ns.convos)
        if ns.Window then ns.Window:Hide() end
        ns.Refresh()
        Print(L["whisper history cleared."])
    else
        Print(L["commands:"])
        print(L["  /pigeon  - open or close the whisper hub"])
        print(L["  /pigeon config  - settings (chat box, tabs, whispers, sound)"])
        print(L["  /pigeon test [1-12]  - fake whispers from up to 12 people (default 3)"])
        print(L["  /pigeon hide  - hide whispers from the normal chat frame (%s)"]:format(OnOff(ns.db.hideFromChat)))
        print(L["  /pigeon away [message]  - toggle the away auto-reply (%s)"]:format(OnOff(ns.db.away.enabled)))
        print(L["  /pigeon export | import  - share your setup as a text string"])
        print(L["  /pigeon tint  - use your class colour as the accent (%s)"]:format(OnOff(ns.db.classTint)))
        print(L["  /pigeon reset  - move the dock back to its default spot"])
        print(L["  /pigeon clear  - delete saved whisper history"])
        print(L["  /pigeon classes  - show how each player's class colour was found"])
        print(L["  Shift-drag a tile to move the dock. Right-click a tile to close it."])
    end
end
