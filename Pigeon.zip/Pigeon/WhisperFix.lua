---------------------------------------------------------------------------
-- Whisper fix for WoW: Forever.
-- The game's chat box finds the whisper target with a pattern that only
-- matches ASCII letters (%w), so "/cw Lephoque Mapoussé hi" (or the
-- "/cw Name" the game writes itself when you right-click > Whisper) never
-- turns into a whisper when the name has an accented / non-English letter.
-- We watch the chat box and, for those names only, set the whisper target
-- ourselves. Plain ASCII names are left entirely to the game.
---------------------------------------------------------------------------
local function IsForever()
    local iface = select(4, GetBuildInfo())
    if type(iface) == "number" and iface >= 16000 and iface < 20000 then return true end
    if RegionalUniqueNamesEnabled then
        local ok, on = pcall(RegionalUniqueNamesEnabled)
        return ok and on == true
    end
    return false
end
if not IsForever() then return end

-- Whisper commands: the usual ones plus whatever this client/locale defines.
local CMDS = { ["/cw"] = true, ["/w"] = true, ["/whisper"] = true, ["/tell"] = true, ["/t"] = true }
local CHARACTER_CMDS = { ["/cw"] = true } -- always followed by a character name
for _, key in ipairs({ "WHISPER", "SMART_WHISPER", "CHARACTER_WHISPER", "CHARWHISPER" }) do
    local i = 1
    while type(_G["SLASH_" .. key .. i]) == "string" do
        local cmd = _G["SLASH_" .. key .. i]:lower()
        CMDS[cmd] = true
        if key:find("CHAR", 1, true) then CHARACTER_CMDS[cmd] = true end
        i = i + 1
    end
end

local function NonAscii(s) return s:find("[\128-\255]") ~= nil end

-- Returns target, message for "/cmd First Last message" when the name has a
-- non-ASCII letter and has been finished with a space; nil otherwise.
local function Parse(text)
    local cmd, rest = text:match("^(/%S+)%s+(.*)$")
    if not cmd then return end
    cmd = cmd:lower()
    if not CMDS[cmd] then return end
    local first, afterFirst = rest:match("^(%S+)(.*)$")
    if not first then return end
    -- Chinese / Japanese / Korean names are a single word.
    if first:find("[\227-\244]") then
        local body = afterFirst:match("^%s(.*)$")
        if not body then return end
        return first, body
    end
    local second, tail = afterFirst:match("^%s+(%S+)(.*)$")
    if not second then return end
    local body = tail:match("^%s(.*)$")
    if not body then return end -- still typing the surname
    if not NonAscii(first) and not NonAscii(second) then return end -- the game handles these
    -- For /w and friends the second word could be the start of the message,
    -- so only take it as a surname when it looks like one (capitalised).
    if not CHARACTER_CMDS[cmd] and not NonAscii(first) and second:find("^%l") then return end
    return first .. " " .. second, body
end

local busy = false
local function OnTextChanged(eb)
    if busy then return end
    local text = eb:GetText()
    if type(text) ~= "string" or (issecretvalue and issecretvalue(text)) then return end
    if text:sub(1, 1) ~= "/" or not NonAscii(text) then return end
    local target, body = Parse(text)
    if not target then return end
    busy = true
    pcall(function()
        if eb.SetTellTarget then eb:SetTellTarget(target) else eb:SetAttribute("tellTarget", target) end
        if eb.SetChatType then eb:SetChatType("WHISPER") else eb:SetAttribute("chatType", "WHISPER") end
        eb:SetText(body)
        if eb.UpdateHeader then
            eb:UpdateHeader()
        elseif type(ChatEdit_UpdateHeader) == "function" then
            ChatEdit_UpdateHeader(eb)
        end
    end)
    busy = false
end

local hooked = {}
local function HookAll()
    for i = 1, NUM_CHAT_WINDOWS or 10 do
        local eb = _G["ChatFrame" .. i .. "EditBox"]
        if eb and not hooked[eb] then
            hooked[eb] = true
            eb:HookScript("OnTextChanged", OnTextChanged)
        end
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", HookAll)
if type(FCF_OpenTemporaryWindow) == "function" then
    hooksecurefunc("FCF_OpenTemporaryWindow", HookAll)
end
