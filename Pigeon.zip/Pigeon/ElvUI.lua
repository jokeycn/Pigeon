--[[
    Pigeon - ElvUI integration
    Only does anything when ElvUI is loaded:
      - Chat box: stays off while ElvUI's chat module is on (ElvUI owns the
        chat window); switch ElvUI > Chat off and ours takes over.
      - Movers: the dock and chat box show up in /moveui (ElvUI's mover mode)
        and are positioned there instead of by Shift-drag.
      - Look: optional "ElvUI style" uses ElvUI's font, backdrop, border and
        value colour, and follows profile / media changes.
      - Sound: if ElvUI's chat already plays a whisper sound, ours stays quiet.
]]

local _, ns = ...
local T = ns.Theme

local Elv = {}
ns.ElvUI = Elv

local function Engine()
    local pack = _G.ElvUI
    if type(pack) ~= "table" then return nil end
    local E = pack[1]
    if type(E) ~= "table" then return nil end
    return E
end

function Elv.Loaded()
    return Engine() ~= nil
end

-- ElvUI's chat module replaces the default chat window.
function Elv.ChatActive()
    local E = Engine()
    if not E then return false end
    local chat = E.private and E.private.chat
    return not chat or chat.enable ~= false
end

-- ElvUI chat plays its own alert (ElvUI > Chat > Alerts > Whisper, on by
-- default as "Whisper Alert"). "None" turns it off, letting ours play instead.
function Elv.PlaysWhisperSound()
    local E = Engine()
    if not E or not Elv.ChatActive() then return false end
    local alerts = E.db and E.db.chat and E.db.chat.channelAlerts
    local sound = alerts and alerts.WHISPER
    return sound ~= nil and sound ~= "None" and sound ~= ""
end

-- Movers take over positioning, so our own drag code steps aside.
function Elv.UsesMovers()
    return Elv.moversActive == true
end

---------------------------------------------------------------------------
-- Look: map ElvUI media onto our theme tokens
---------------------------------------------------------------------------

-- ElvUI media colours are plain arrays { r, g, b[, a] }; accept {r=,g=,b=} too.
local function RGB(c, a)
    if type(c) ~= "table" then return nil end
    local r = c.r or c[1]
    local g = c.g or c[2]
    local b = c.b or c[3]
    if not (r and g and b) then return nil end
    return { r, g, b, a or c.a or c[4] or 1 }
end

-- Called from Theme's Refresh after Horizon values are read.
function Elv.ApplyTheme()
    if not (ns.db and ns.db.elvuiStyle) then return end
    local E = Engine()
    if not E or type(E.media) ~= "table" then return end
    local m = E.media
    if type(m.normFont) == "string" and m.normFont ~= "" then T.FONT = m.normFont end
    local bg = RGB(m.backdropfadecolor) or RGB(m.backdropcolor, 0.9)
    if bg then T.BACKDROP = bg end
    local border = RGB(m.bordercolor, 1)
    if border then T.BORDER = border end
    local accent = RGB(m.rgbvaluecolor, 1)
    if accent and not ns.db.classTint then T.ACCENT = accent end
end

---------------------------------------------------------------------------
-- Docking into ElvUI's chat panel
-- ElvUI keeps the chat tabs in GeneralDockManager (22px tall), anchored to
-- the top of its primary chat frame inside LeftChatPanel. The stack button
-- takes the left end of that strip and the tabs are nudged right to make
-- room; whenever ElvUI re-anchors the strip, the nudge is re-applied.
---------------------------------------------------------------------------

function Elv.ChatDockHost()
    if not Elv.ChatActive() then return nil end
    local gdm = _G.GeneralDockManager
    if not gdm then return nil end
    return gdm.primary or _G.ChatFrame1, gdm
end

function Elv.AttachDock(dock)
    local host, gdm = Elv.ChatDockHost()
    if not host then return false end
    local size = math.floor((gdm:GetHeight() or 22) + 0.5)
    if size < 16 then size = 22 end
    dock.size = size
    dock:SetSize(size, size)

    local offset = size + 4
    local shifting = false
    local function Shift(frame, point, rel, relPoint, x, y)
        if shifting or point ~= "BOTTOMLEFT" then return end
        shifting = true
        frame:SetPoint("BOTTOMLEFT", rel, relPoint, (x or 0) + offset, y or 0)
        shifting = false
    end
    hooksecurefunc(gdm, "SetPoint", Shift)
    -- Apply once now in case ElvUI already placed it.
    for i = 1, (gdm:GetNumPoints() or 0) do
        local point, rel, relPoint, x, y = gdm:GetPoint(i)
        if point == "BOTTOMLEFT" then Shift(gdm, point, rel, relPoint, x, y) break end
    end

    -- Follow the panel's visibility (ElvUI's chat toggle buttons hide it).
    local panel = _G.LeftChatPanel
    if panel and panel.HookScript then
        panel:HookScript("OnHide", function() dock:Hide() end)
        panel:HookScript("OnShow", function() dock:Show() end)
    end
    Elv.dockHost = host
    return true
end

---------------------------------------------------------------------------
-- Fitting our chat box into ElvUI's left chat panel (ElvUI chat module off)
-- ElvUI still builds LeftChatPanel + its "Left Chat" mover, but only its chat
-- module sizes the panel. We size it from the same settings (Chat > Panel
-- Width / Height) and fill it, so /moveui, the datatext bar and the panel
-- backdrop all line up like ElvUI's own chat would.
---------------------------------------------------------------------------

function Elv.CanFit()
    local E = Engine()
    return E ~= nil and _G.LeftChatPanel ~= nil and not Elv.ChatActive()
end

function Elv.FitChat(chat)
    local E = Engine()
    local panel = _G.LeftChatPanel
    if not (E and panel and ns.db.chat.fitElvUI and not Elv.ChatActive()) then
        Elv.fitted = false
        return false
    end
    local cdb = E.db and E.db.chat or {}
    local w, h = cdb.panelWidth or 412, cdb.panelHeight or 180
    if type(E.Scale) == "function" then w, h = E:Scale(w), E:Scale(h) end
    panel:SetSize(w, h)
    chat:ClearAllPoints()
    chat:SetAllPoints(panel)
    Elv.fitted = true
    return true
end

-- Does ElvUI draw a backdrop behind the left panel? (Chat > Panel Backdrop)
function Elv.LeftBackdropShown()
    local E = Engine()
    local mode = E and E.db and E.db.chat and E.db.chat.panelBackdrop
    return mode == nil or mode == "SHOWBOTH" or mode == "LEFT"
end

-- The datatext bar under (or over) the left panel, if it's showing.
function Elv.LeftDataPanel()
    local dp = _G.LeftChatDataPanel
    if dp and dp:IsShown() then return dp end
end

function Elv.ToggleMoveMode()
    local E = Engine()
    if E and type(E.ToggleMoveMode) == "function" then E:ToggleMoveMode() return true end
    return false
end

---------------------------------------------------------------------------
-- Setup at login (after the dock and chat box exist)
---------------------------------------------------------------------------

function Elv.Setup()
    local E = Engine()
    if not E then return end

    if type(E.CreateMover) == "function" then
        -- E:CreateMover(parent, name, text, overlay, snapOffset, postdrag, types)
        local ok = pcall(function()
            if not ns.Dock.attached then -- an attached dock rides along with the chat box
                E:CreateMover(ns.Dock, "PigeonDockMover", "Pigeon Dock", nil, nil,
                    function() ns.Dock:Relayout() end, "ALL,GENERAL")
            end
            if ns.Chat.smf and not Elv.fitted then -- fitted: ElvUI's own "Left Chat" mover moves it
                E:CreateMover(ns.Chat, "PigeonChatMover", "Pigeon Chat", nil, nil, nil, "ALL,GENERAL")
            end
        end)
        Elv.moversActive = ok
        if ok and ns.Chat and ns.Chat.overlay then ns.Chat.overlay:Hide() end
    end

    -- Profile swaps and media changes (font, colours) repaint us.
    if type(E.UpdateMedia) == "function" then
        hooksecurefunc(E, "UpdateMedia", function()
            T.Refresh()
            ns.Refresh()
            if ns.Chat.smf then ns.Chat:ApplySettings() end
        end)
    end

    -- ElvUI re-sizes/positions its chat panels here (panel size options,
    -- datatext bar changes, profile swaps): refit to follow.
    local LO = type(E.GetModule) == "function" and E:GetModule("Layout", true)
    if LO and type(LO.RefreshChatMovers) == "function" then
        hooksecurefunc(LO, "RefreshChatMovers", function()
            if Elv.fitted and ns.Chat.smf then
                Elv.FitChat(ns.Chat)
                ns.Chat:ApplySettings()
            end
        end)
    end
end
