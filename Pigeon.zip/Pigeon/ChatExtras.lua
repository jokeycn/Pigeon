--[[
    Pigeon - Chat box extras
      - Spam filter: drops repeated lines and gold-seller style adverts from
        public channels (never guild, party, raid or whispers).
      - Keyword alerts: your name and words you pick are highlighted; a soft
        ping plays and the tab lights up when one shows in a hidden tab.
      - Group finding: in "LFG / LFM / need a healer" lines the role words
        are colour-coded (tank blue, healer green, dps red) and [w] / [inv]
        buttons are added to whisper or invite the poster in one click.
      - Copy window: the current tab as plain, selectable text (also used to
        show and paste setup strings).
      - Idle fade: the chat box's background and tabs fade out when you
        haven't touched it for a while.
]]

local _, ns = ...
local T = ns.Theme
local L = ns.L

local X = {}
ns.ChatX = X

local PUBLIC = {
    say = true, yell = true, emote = true, general = true, trade = true, services = true,
    lfg = true, defense = true, newcomer = true, channel = true,
}
X.PUBLIC = PUBLIC

local ADDON_LINK = "addon:Pigeon:"

local function Plain(text)
    if type(text) ~= "string" then return "" end
    text = text:gsub("|T[^|]-Tags\\Tag(%w+):[^|]*|t", "[%1]") -- channel chips back to [P], [Gen]…
    return (text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|H.-|h(.-)|h", "%1"):gsub("|T.-|t", ""):gsub("|A.-|a", ""))
end
X.Plain = Plain

-- Case-insensitive Lua pattern for a plain word.
local function CI(word)
    local out = word:gsub("[%^%$%(%)%.%[%]%*%+%-%?%%]", "%%%0")
    return (out:gsub("%a", function(ch) return "[" .. ch:lower() .. ch:upper() .. "]" end))
end

-- Apply fn to the parts of text that are not inside a hyperlink or texture.
local function OutsideLinks(text, fn)
    local out, pos = {}, 1
    while true do
        local s, e = text:find("|H.-|h.-|h", pos)
        local ts, te = text:find("|[TA].-|[ta]", pos)
        if ts and (not s or ts < s) then s, e = ts, te end
        if not s then break end
        out[#out + 1] = fn(text:sub(pos, s - 1))
        out[#out + 1] = text:sub(s, e)
        pos = e + 1
    end
    out[#out + 1] = fn(text:sub(pos))
    return table.concat(out)
end

local function Hex(c)
    return ("%02x%02x%02x"):format(math.floor(c[1] * 255 + 0.5), math.floor(c[2] * 255 + 0.5), math.floor(c[3] * 255 + 0.5))
end

---------------------------------------------------------------------------
-- Sender
---------------------------------------------------------------------------

function X.Sender(text, eventArgs)
    if type(eventArgs) == "table" then
        local s = eventArgs[2]
        if type(s) == "string" and ns.Readable(s) and s ~= "" then return s end
    end
    if type(text) == "string" and ns.Readable(text) then
        return text:match("|Hplayer:([^:|]+)")
    end
end

local function IsMe(name)
    if not name then return false end
    local me = UnitName and UnitName("player")
    if not me or not ns.Readable(me) then return false end
    return name == me or name:match("^([^%-]+)") == me
end

---------------------------------------------------------------------------
-- Spam
---------------------------------------------------------------------------

local ADVERT = {
    "www%.", "https?:", "%.com%f[%W]", "%.net%f[%W]", "%.org%f[%W]", "dot%s*com",
    "cheap%s+gold", "gold%s+for%s+sale", "buy%s+gold", "sell%s+gold", "%d+%%%s*off",
    "discount", "power%s*level", "fast%s+delivery", "[%$€£]%s*%d",
}
local recent, recentOrder = {}, {}
local DUPE_WINDOW = 60

function X.IsSpam(e)
    local spam = ns.db.chat.spam
    if not spam or not PUBLIC[e.cat] or e.secret then return false end
    if IsMe(e.sender) then return false end
    local body = Plain(e.text):gsub("^%s*%[?%d+:%d+:?%d*%]?%s*", "") -- ignore the game's timestamp
    local lower = body:lower()
    if spam.gold then
        for _, p in ipairs(ADVERT) do
            if lower:find(p) then return true, "advert" end
        end
    end
    if spam.dupes then
        local now = GetTime and GetTime() or 0
        local key = (e.sender or "") .. "\1" .. lower:gsub("%s+", " ")
        local seen = recent[key]
        if seen and now - seen < DUPE_WINDOW then
            recent[key] = now
            return true, "repeat"
        end
        recent[key] = now
        recentOrder[#recentOrder + 1] = key
        if #recentOrder > 400 then
            for i = 1, 200 do recent[recentOrder[i]] = nil end
            local keep = {}
            for i = 201, #recentOrder do keep[#keep + 1] = recentOrder[i] end
            recentOrder = keep
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Keyword alerts
---------------------------------------------------------------------------

function X.Keywords(includeName)
    local a = ns.db.chat.alerts
    local words = {}
    if not a then return words end
    for w in (a.words or ""):gmatch("[^,]+") do
        w = strtrim(w)
        if #w >= 2 then words[#words + 1] = w end
    end
    if a.myName and includeName~=false then
        local me = UnitName and UnitName("player")
        if me and ns.Readable(me) and me ~= "" then words[#words + 1] = me end
    end
    return words
end

local function Esc(s) return (s:gsub("[%^%$%(%)%.%[%]%*%+%-%?%%]", "%%%0")) end

local function MatchesKeyword(plainLower, words)
    for _, w in ipairs(words) do
        if plainLower:find("%f[%w]" .. Esc(w:lower()) .. "%f[%W]") then return true end
    end
    return false
end

local lastPing = 0
-- Called once per new line; marks e.alert and pings.
-- Where people talk (not loot, xp, system or addon lines; whispers ping already).
local ALERT_CATS = {
    guild = true, officer = true, party = true, raid = true, raidwarning = true, instance = true, community = true,
    guilddiscord=true, partyleader=true, raidleader=true, instanceleader=true,
}
for k in pairs(PUBLIC) do ALERT_CATS[k] = true end

function X.CheckAlert(e)
    local a = ns.db.chat.alerts
    if not a or e.secret or not ALERT_CATS[e.cat] then return false end
    if IsMe(e.sender) then return false end
    local words = X.Keywords()
    if #words == 0 then return false end
    if not MatchesKeyword(Plain(e.text):lower(), words) then return false end
    e.alert = true
    if a.openMatches~=false and MatchesKeyword(Plain(e.text):lower(),X.Keywords(false)) then
        X.OpenWatchedMessage(e)
    end
    if a.sound then
        local now = GetTime and GetTime() or 0
        if now - lastPing > 4 then
            lastPing = now
            pcall(PlaySound, (SOUNDKIT and SOUNDKIT.MAP_PING) or 3175, "Master")
        end
    end
    return true
end

function X.OpenWatchedMessage(e)
    if e.watchCaptured or e.secret or not ALERT_CATS[e.cat] or type(e.sender)~="string" or not ns.Readable(e.sender) or IsMe(e.sender) then return false end
    local guid=ns.Chat.guids[e.sender]
    local shown=e.text:match("|Hplayer:[^|]-|h(.-)|h")
    local who=ns.BestName(e.sender,guid,shown) or e.sender
    local c=ns.StartConvo(ns.StripOwnRealm(who))
    if not c then return false end
    if guid and ns.Readable(guid)then c.guid=guid if ns.ResolveClass then pcall(ns.ResolveClass,c)end end
    e.watchCaptured=true
    local source=e.chan
    if not source then
        for _,category in ipairs(ns.CHAT_CATEGORIES)do if category.key==e.cat then source=category.label break end end
    end
    ns.AddMessage(c,false,L["[%s · keyword match]\n%s"]:format(source or L["Chat"], e.text),{silent=true})
    local function HasDraft(frame)
        local edit=frame and frame.input and frame.input.edit
        if not edit then return false end
        local value=edit:GetText()
        return not ns.Readable(value) or (type(value)=="string" and value~="")
    end
    -- Show the match without changing the recipient of an existing draft.
    if ns.Window.convo~=c and HasDraft(ns.Window) then return true end
    if T.IsOpen(ns.Hub) and HasDraft(ns.Hub) then return true end
    if T.IsOpen(ns.Hub) then ns.Hub:Close(function()ns.Window:Open(c,false)end)
    else ns.Window:Open(c,false)end
    return true
end

---------------------------------------------------------------------------
-- Group finding
---------------------------------------------------------------------------

local ROLES = {
    { { "tanks", "tank" }, { 0.35, 0.62, 1 } },
    { { "healers", "healer", "heals", "heal", "healz" }, { 0.3, 0.9, 0.4 } },
    { { "dps", "dd" }, { 1, 0.4, 0.35 } },
}

local function LooksLikeLFG(lower)
    return lower:find("%f[%w]lf%d*m%f[%W]") or lower:find("%f[%w]lfg%f[%W]") or lower:find("%f[%w]lf%f[%W]")
        or lower:find("looking for")
        or (lower:find("%f[%w]need%f[%W]") and (lower:find("tank") or lower:find("heal") or lower:find("%f[%w]dps%f[%W]")))
end

local function LFGDecorate(e, text)
    local g = ns.db.chat.lfg
    if not g or not g.enabled or not PUBLIC[e.cat] and e.cat ~= "party" and e.cat ~= "instance" then return text end
    local lower = Plain(text):lower()
    if not LooksLikeLFG(lower) then return text end
    if g.roles then
        text = OutsideLinks(text, function(seg)
            for _, role in ipairs(ROLES) do
                local color = "|cff" .. Hex(role[2])
                for _, w in ipairs(role[1]) do
                    seg = seg:gsub("%f[%w]" .. CI(w) .. "%f[%W]", color .. "%0|r")
                end
            end
            return seg
        end)
    end
    local who = e.sender
    if g.buttons and who and not IsMe(who) then
        local acc = "|cff" .. Hex(T.ACCENT)
        text = text .. "  " .. acc .. "|H" .. ADDON_LINK .. "w:" .. who .. "|h[w]|h|r"
            .. " " .. acc .. "|H" .. ADDON_LINK .. "i:" .. who .. "|h[inv]|h|r"
    end
    return text
end

-- Render-time decorations (so turning an option off cleans old lines too).
---------------------------------------------------------------------------
-- Web links: the game can't open a browser, so a click shows the address
-- ready to copy (Ctrl+C).
---------------------------------------------------------------------------

local URL_COLOR = "|cff66b3ff"
local TLDS = { com = true, net = true, org = true, gg = true, io = true, tv = true, me = true, co = true,
    uk = true, de = true, fr = true, eu = true, ru = true, info = true, app = true, dev = true, xyz = true, be = true }

local function WrapURL(url)
    -- Punctuation that ends the sentence isn't part of the address.
    local tail = ""
    while true do
        local last = url:sub(-1)
        if last ~= "" and (last:find("[%.,!%?;:'\"]") or (last == ")" and not url:find("(", 1, true))) then
            tail = last .. tail
            url = url:sub(1, -2)
        else
            break
        end
    end
    if #url < 4 then return url .. tail end
    return URL_COLOR .. "|H" .. ADDON_LINK .. "u:" .. url .. "|h[" .. url .. "]|h|r" .. tail
end

local function LinkSegment(seg)
    if not seg:find("%.", 1) then return seg end
    return (seg:gsub("%S+", function(word)
        if word:find("|", 1, true) then return nil end -- colour codes and the like: leave alone
        local lower = word:lower()
        if lower:find("^https?://[%w]") or lower:find("^www%.[%w%-]+%.%a") then return WrapURL(word) end
        -- bare addresses: name.tld or name.tld/path (discord.gg/abc, wowhead.com/item=1)
        local host = lower:match("^([%w%-%.]+%.%a%a+)/") or lower:match("^([%w%-%.]+%.%a%a+)[%.,!%?]*$")
        local tld = host and host:match("%.(%a+)$")
        if tld and TLDS[tld] and host:find("^[%w]") and not host:find("%.%.") then return WrapURL(word) end
    end))
end

function X.LinkURLs(text)
    if type(text) ~= "string" or not ns.Readable(text) or not text:find(".", 1, true) then return text end
    local ok, out = pcall(OutsideLinks, text, LinkSegment)
    return ok and out or text
end

StaticPopupDialogs.PIGEON_URL = {
    text = L["Press Ctrl+C to copy"],
    button1 = CLOSE or "Close",
    hasEditBox = true,
    editBoxWidth = 320,
    maxLetters = 0,
    OnShow = function(self, url)
        local eb = (self.GetEditBox and self:GetEditBox()) or self.editBox or self.EditBox
        if not eb then return end
        eb.wsURL = url or ""
        eb:SetText(eb.wsURL)
        eb:SetFocus()
        eb:HighlightText()
    end,
    -- Typing can't change it; copying (Ctrl+C) closes the box.
    EditBoxOnTextChanged = function(self)
        if self.wsURL and self:GetText() ~= self.wsURL then
            self:SetText(self.wsURL)
            self:HighlightText()
        end
    end,
    EditBoxOnEnterPressed = function(self) self:GetParent():Hide() end,
    EditBoxOnEscapePressed = function(self) self:GetParent():Hide() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

function X.Decorate(e, text)
    if e.secret or type(text) ~= "string" then return text end
    local words = e.alert and X.Keywords() or nil
    if words and #words > 0 then
        local color = "|cff" .. Hex(ns.Social.STAR)
        text = OutsideLinks(text, function(seg)
            for _, w in ipairs(words) do
                seg = seg:gsub("%f[%w]" .. CI(w) .. "%f[%W]", color .. "%0|r")
            end
            return seg
        end)
    end
    return X.LinkURLs(LFGDecorate(e, text))
end

-- Our own links ([w] / [inv]); returns true when handled.
function X.HandleLink(link)
    if type(link) ~= "string" or link:sub(1, #ADDON_LINK) ~= ADDON_LINK then return false end
    local action, who = link:sub(#ADDON_LINK + 1):match("^(%a):(.+)$")
    if not who then return true end
    if action == "u" then
        StaticPopup_Show("PIGEON_URL", nil, nil, who)
    elseif action == "w" then
        local c = ns.StartConvo(who)
        if c then ns.Window:Open(c, true) end
    elseif action == "i" then
        ns.Invite(who, ns.Chat and ns.Chat.guids and ns.Chat.guids[who])
    end
    return true
end

---------------------------------------------------------------------------
-- Text window (copy chat, export / import)
---------------------------------------------------------------------------

local TW
local function BuildTextWindow()
    TW = CreateFrame("Frame", "PigeonTextWindow", UIParent)
    TW:SetSize(560, 380)
    TW:SetPoint("CENTER", 0, 40)
    TW:SetFrameStrata("DIALOG")
    TW:SetToplevel(true)
    TW:EnableMouse(true)
    TW:SetMovable(true)
    TW:SetClampedToScreen(true)
    TW:Hide()
    T.Panel(TW)
    TW.wsMinAlpha = 0.95
    tinsert(UISpecialFrames, "PigeonTextWindow")
    local bar = T.AccentTexture(TW:CreateTexture(nil, "ARTWORK"))
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("TOPRIGHT")
    bar:SetHeight(3)
    TW.strip = bar
    local head = CreateFrame("Frame", nil, TW)
    head:SetPoint("TOPLEFT", 0, -3)
    head:SetPoint("TOPRIGHT", 0, -3)
    head:SetHeight(34)
    head:EnableMouse(true)
    head:RegisterForDrag("LeftButton")
    head:SetScript("OnDragStart", function() TW:StartMoving() end)
    head:SetScript("OnDragStop", function() TW:StopMovingOrSizing() end)
    TW.title = T.Text(head, 13, T.TEXT)
    TW.title:SetPoint("LEFT", 14, 0)
    local close = T.GlyphButton(head, "x", 24)
    close:SetPoint("RIGHT", -6, 0)
    close:SetScript("OnClick", function() TW:Hide() end)
    TW.closeBtn, TW.titleText, TW.dragHeader = close, TW.title, head
    X.textWindow = TW
    if ns.GameFrames then ns.GameFrames.Apply() end
    TW.hint = T.Text(TW, 10, T.SECTION)
    TW.hint:SetPoint("BOTTOMLEFT", 14, 16)
    TW.hint:SetPoint("RIGHT", -120, 0)
    TW.hint:SetJustifyH("LEFT")

    local box = CreateFrame("Frame", nil, TW)
    box:SetPoint("TOPLEFT", 12, -44)
    box:SetPoint("BOTTOMRIGHT", -12, 48)
    T.Panel(box, T.INPUT_BG, T.INPUT_BORDER)
    -- Preferred: the game's own scrolling edit box (wheel, drag-select and
    -- auto-scroll while selecting all work natively).
    local edit
    do
        local ok, isf = pcall(CreateFrame, "ScrollFrame", nil, box, "InputScrollFrameTemplate")
        if ok and isf and isf.EditBox then
            isf:SetPoint("TOPLEFT", 8, -6)
            isf:SetPoint("BOTTOMRIGHT", -8, 6)
            if isf.CharCount then isf.CharCount:Hide() end
            edit = isf.EditBox
            edit:SetMaxLetters(0)
            edit:SetAutoFocus(false)
            edit:SetFontObject(ChatFontNormal or GameFontHighlight)
            edit:SetTextColor(1, 1, 1, 1)
            edit:HookScript("OnEscapePressed", function() TW:Hide() end)
            edit:HookScript("OnTextChanged", function(self, user)
                -- Only undo real edits; re-setting identical text would
                -- reset the cursor and scroll position (breaking drag-select).
                if user and TW.readOnly and self:GetText() ~= TW.text then
                    self:SetText(TW.text)
                end
            end)
            TW.native = true
            TW.MoveText = function() isf:SetVerticalScroll(0) end
            TW.edit = edit
        end
    end
    if not TW.native then
    -- Fallback: a clipped host with the edit box moved inside it.
    local sf = CreateFrame("Frame", nil, box)
    sf:SetPoint("TOPLEFT", 8, -6)
    sf:SetPoint("BOTTOMRIGHT", -8, 6)
    sf:SetClipsChildren(true)
    edit = CreateFrame("EditBox", nil, sf)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetWidth(510)
    edit:SetHeight(300)
    edit:SetFontObject(ChatFontNormal or GameFontHighlight)
    edit:SetTextColor(1, 1, 1, 1)
    edit:SetFrameLevel(sf:GetFrameLevel() + 5)
    local offset, placed = 0, false
    local function Fit()
        -- GetNumLines is the wrapped line count; ask for it fresh each time.
        local want = math.max(sf:GetHeight() or 0, (edit:GetNumLines() or 1) * 15 + 16)
        if math.abs((edit:GetHeight() or 0) - want) > 0.5 then edit:SetHeight(want) end
    end
    local function Move(v)
        Fit()
        local limit = math.max(0, (edit:GetHeight() or 0) - (sf:GetHeight() or 0))
        local want = math.min(limit, math.max(0, v))
        -- Re-anchoring while the mouse is held would interrupt a drag-select.
        if placed and want == offset then return end
        offset, placed = want, true
        edit:ClearAllPoints()
        edit:SetPoint("TOPLEFT", sf, "TOPLEFT", 0, offset)
    end
    TW.MoveText = Move
    Move(0)
    edit:SetScript("OnEscapePressed", function() TW:Hide() end)
    edit:SetScript("OnTextChanged", function(self, user)
        if user and TW.readOnly and self:GetText() ~= TW.text then
            self:SetText(TW.text)
        end
        Move(offset)
    end)
    edit:SetScript("OnCursorChanged", function(_, _, y, _, h)
        y = -y
        local view = sf:GetHeight() or 0
        if y < offset then Move(y)
        elseif y + h > offset + view then Move(y + h - view) end
    end)
    -- The edit box sits on top of the host and would swallow the wheel.
    local function Wheel(_, delta) Move(offset - delta * 40) end
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", Wheel)
    edit:EnableMouseWheel(true)
    edit:SetScript("OnMouseWheel", Wheel)
    box:EnableMouseWheel(true)
    box:SetScript("OnMouseWheel", Wheel)
    box:EnableMouse(true)
    box:SetScript("OnMouseDown", function() edit:SetFocus() end)
    TW.edit = edit
    end

    TW.action = T.Button(TW, L["Import"], 96, 26, true)
    TW.action:SetPoint("BOTTOMRIGHT", -12, 12)
    TW.action:SetScript("OnClick", function()
        if TW.onAccept then TW.onAccept(TW.edit:GetText()) end
    end)
end

-- opts: { hint = "...", editable = bool, action = "Import", onAccept = fn(text) }
function X.ShowText(title, text, opts)
    if not TW then BuildTextWindow() end
    opts = opts or {}
    TW.title:SetText(title)
    TW.hint:SetText(opts.hint or L["Ctrl+A then Ctrl+C to copy."])
    TW.readOnly = not opts.editable
    TW.text = text or ""
    TW.onAccept = opts.onAccept
    TW.action:SetShown(opts.onAccept ~= nil)
    if opts.action then TW.action.label:SetText(opts.action) end
    TW:Show()
    TW:Raise()
    -- Fill the box once the window is laid out; a multi-line edit box that
    -- gets its text while hidden (or with no height) can draw nothing.
    local edit = TW.edit
    local function Fill()
        if not TW:IsShown() then return end
        if TW.native then
            -- The template sizes its edit box on layout; do it by hand too, in
            -- case the window was opened before it had a size.
            local isf = edit:GetParent()
            local iw = isf and isf:GetWidth() or 0
            if iw > 60 then edit:SetWidth(iw - 18) end
            edit:Show()
            edit:SetAlpha(1)
        else
            local sf = edit:GetParent()
            local w = (sf:GetWidth() or 0) > 50 and sf:GetWidth() or 510
            edit:SetWidth(w)
            edit:SetHeight(math.max(sf:GetHeight() or 0, 40))
        end
        edit:SetText(TW.text)
        edit:SetCursorPosition(0)
        TW.MoveText(0)
        edit:SetFocus()
        if not opts.editable and not opts.noHighlight then edit:HighlightText() end
    end
    Fill()
    C_Timer.After(0, Fill)
    C_Timer.After(0.15, function()
        -- Last pass: only fill again if the box still came up empty.
        if TW:IsShown() and edit:GetText() ~= TW.text then Fill() end
        if ns.debugChat then
            local p = edit:GetParent()
            local l, b, w, h = edit:GetRect()
            print(("|cffffd100copy window|r native=%s want=%d have=%d editW=%s editH=%s parent=%sx%s lines=%s shown=%s alpha=%s rect=%s,%s font=%s"):format(
                tostring(TW.native), #TW.text, #(edit:GetText() or ""), tostring(edit:GetWidth()), tostring(edit:GetHeight()),
                tostring(p and p:GetWidth()), tostring(p and p:GetHeight()), tostring(edit:GetNumLines()),
                tostring(edit:IsVisible()), tostring(edit:GetEffectiveAlpha()), tostring(l), tostring(b), tostring(edit:GetFont())))
        end
    end)
    return TW
end

function X.HideText() if TW then TW:Hide() end end

function X.CopyTab(chat)
    local tab = chat.db.tabs[chat.active]
    if not tab then return end
    local lines = {}
    for _, e in ipairs(chat.log) do
        if not e.secret and ns.TabMatches(tab, e) then
            local stamp = date("%H:%M", e.t)
            lines[#lines + 1] = stamp .. "  " .. Plain(e.text)
        end
    end
    -- Fall back to what the chat window itself is holding.
    local smf = chat.smf
    if #lines == 0 and smf and smf.GetNumMessages and smf.GetMessageInfo then
        for i = 1, smf:GetNumMessages() do
            local ok, text = pcall(smf.GetMessageInfo, smf, i)
            if ok and type(text) == "string" and issecretvalue ~= nil and not issecretvalue(text) or (ok and type(text) == "string" and issecretvalue == nil) then
                lines[#lines + 1] = Plain(text)
            end
        end
    end
    if #lines == 0 then
        lines[1] = L["(Nothing to copy: this tab has no readable lines yet. Lines received while chat text is restricted can't be copied.)"]
    end
    X.ShowText(L["Copy chat  ·  %s"]:format(tab.name:upper()), table.concat(lines, "\n"),
        { hint = L["%d lines. Drag to select what you need and press Ctrl+C (Ctrl+A selects all)."]:format(#lines), noHighlight = true })
end

---------------------------------------------------------------------------
-- Idle fade
---------------------------------------------------------------------------

-- The chat's background does not respond to SetAlpha, so fade it by repainting its colour at
-- the faded opacity (and hide it outright once it is gone).
function X.PaintBg(chat, a)
    local bg = chat.bg
    if not bg then return end
    bg:SetAlpha(1)
    local ownOff = chat.wsSkinned or (ns.ElvUI and ns.ElvUI.fitted and ns.ElvUI.LeftBackdropShown and ns.ElvUI.LeftBackdropShown())
    if not ownOff and not (chat.db and chat.db.classic) and T and T.PaintSurface then
        local vanilla = ns.db and ns.db.look and ns.db.look.preset == "forever"
        local c = vanilla and { 0.02, 0.018, 0.016 } or T.BACKDROP
        local tab = chat.db and chat.db.tabs and chat.db.tabs[chat.active] or {}
        local base = tab.bgAlpha or (chat.db and chat.db.bgAlpha) or 1
        T.PaintSurface(chat, c[1], c[2], c[3], base * a)
    else
        bg:SetAlpha(a)
    end
    if a <= 0.01 then bg:Hide() elseif not bg:IsShown() then bg:Show() end
end

function X.ChromeAlpha(chat, a)
    a = math.max(0, math.min(1, a)) + 0 -- (+ 0 turns a stray -0 from the slider into 0)
    chat.chromeAlpha = a
    -- The game's own input box stays shown while you are not typing; fade it too.
    local eb = chat.eb
    if eb and eb.SetAlpha then
        if a < 0.999 then
            if not chat.ebBase then chat.ebBase = eb:GetAlpha() or 1 end
            eb:SetAlpha(chat.ebBase * a)
        elseif chat.ebBase then
            eb:SetAlpha(eb:HasFocus() and 1 or chat.ebBase)
            chat.ebBase = nil
        end
    end
    X.PaintBg(chat, a)
    if chat.sheen then chat.sheen:SetAlpha(a) chat.shine:SetAlpha(a) end
    for _, edge in ipairs(chat.border or {}) do edge:SetAlpha(a) end
    local tabs = chat.tabsAlpha or 1 -- the tab bar can rest faded until the mouse is over the chat
    if chat.bar then chat.bar:SetAlpha(math.max(a * tabs, 0.001)) end
    if chat.divider then chat.divider:SetAlpha(a) end
    -- Loose parts that are not inside the bar or the input: the emote button, the
    -- resize grip, the line beside the dock tiles and the jump-to-latest button.
    for _, part in ipairs({ chat.emoteBtn, chat.grip, chat.railDivider, chat.jump }) do
        if part and part.SetAlpha then part:SetAlpha(a) end
    end
    if chat.fakeInput then chat.fakeInput:SetAlpha(math.max(a, 0.001)) end -- resting input fades too
    -- Optionally the messages themselves fade with the rest while idle.
    if chat.smf then
        if (chat.db and chat.db.idleHideText) or chat.combatAlpha then -- fading in combat covers the text too
            chat.smf:SetAlpha(a)
            chat.textFaded = true
        elseif chat.textFaded then
            chat.smf:SetAlpha(1)
            chat.textFaded = nil
        end
    end
    -- The stack button in the tab bar fades with the chat's own chrome.
    -- Its conversation tiles (and the rail behind them) fade along with it.
    if ns.Dock and ns.Dock.attached == "chat" then
        ns.Dock:SetAlpha(math.max(a * tabs, 0.001))
        if ns.Dock.allBtn then ns.Dock.allBtn:SetAlpha(ns.Dock.allBtn.wsFadeA or 1) end
    end
end

-- Tab bar rest state: with "Show on hover" the tabs, the chat controls and the stack
-- button in the tab bar fade away until the mouse is over the chat (or you are typing).
local function ApplyTabsAlpha(chat)
    local a, k = chat.chromeAlpha or 1, chat.tabsAlpha or 1
    if chat.bar then chat.bar:SetAlpha(math.max(a * k, 0.001)) end
    if ns.Dock and ns.Dock.attached == "chat" then
        ns.Dock:SetAlpha(math.max(a * k, 0.001))
        if ns.Dock.allBtn then ns.Dock.allBtn:SetAlpha(ns.Dock.allBtn.wsFadeA or 1) end
    end
end

-- Move a frame's own opacity toward a target: slowly away, quickly back.
local function FadeStep(frame, target, elapsed)
    local cur = frame.wsFadeA or 1
    if math.abs(cur - target) <= 0.002 then
        if cur ~= target then frame.wsFadeA = target frame:SetAlpha(target) end
        return
    end
    local step = elapsed / (target < cur and 0.4 or 0.12)
    cur = cur < target and math.min(target, cur + step) or math.max(target, cur - step)
    frame.wsFadeA = cur
    frame:SetAlpha(cur)
end

local function TabsTick(chat, elapsed)
    local db = chat.db
    if not db then return end
    -- With "Include the options and stack buttons", "Inactive tab opacity" also rests the
    -- options button and the stack button in the tab bar; each comes back while the mouse is
    -- over it (the stack button stays solid while it has unread whispers).
    local ia = math.max(0.1, math.min(1, tonumber(db.tabInactiveAlpha) or 1))
    if not db.tabFadeExtras then ia = 1 end -- only when "Include the options and stack buttons" is on
    local ind = chat.toolbarIndicator
    if ind and ind.IsMouseOver then
        local hot = ia >= 1 or ind:IsMouseOver() or chat.toolbarTarget == 1
        FadeStep(ind, hot and 1 or ia, elapsed)
    end
    local d = ns.Dock
    local btn = d and d.attached == "chat" and d.allBtn
    if btn and btn.IsMouseOver then
        local unread = btn.badge and btn.badge.IsShown and btn.badge:IsShown()
        local hot = ia >= 1 or unread or btn:IsMouseOver()
        FadeStep(btn, hot and 1 or ia, elapsed)
    end
    local target = 1
    if db.tabsMode == "hover" then
        local awake = (chat.IsMouseOver and chat:IsMouseOver()) or (chat.eb and chat.eb:HasFocus())
            or ns.Chat.dragging or not db.locked or (ns.Settings and ns.Settings:IsShown())
        if not awake and ns.Dock and ns.Dock.attached == "chat" and ns.Dock.allBtn and ns.Dock.allBtn:IsMouseOver() then awake = true end
        if not awake then target = math.max(0, math.min(0.9, tonumber(db.tabsHiddenAlpha) or 0)) end
    end
    local cur = chat.tabsAlpha or 1
    if math.abs(cur - target) <= 0.002 then
        if cur ~= target then chat.tabsAlpha = target ApplyTabsAlpha(chat) end
        return
    end
    local step = elapsed / (target < cur and 0.4 or 0.12) -- fades away slowly, back quickly
    cur = cur < target and math.min(target, cur + step) or math.max(target, cur - step)
    chat.tabsAlpha = cur
    ApplyTabsAlpha(chat)
end

-- The mouse over the dock (its button or a tile) keeps the chat awake too.
local function DockHovered()
    local d = ns.Dock
    if not (d and d.attached == "chat") then return false end
    if d.allBtn and d.allBtn:IsMouseOver() then return true end
    for _, tile in pairs(d.byKey or {}) do
        if tile.IsShown and tile:IsShown() and tile:IsMouseOver() then return true end
    end
    return false
end

-- With "Fade old messages" on, the message frame has already faded old lines out on its
-- own; when the chat wakes from its idle fade, bring those lines back too.
function X.WakeText(chat)
    local smf = chat.smf
    if smf and chat.db and chat.db.fade and smf.ResetAllFadeTimes then pcall(smf.ResetAllFadeTimes, smf) end
end

local acc = 0
local FADE_OUT, FADE_IN = 0.7, 0.15 -- seconds for a full fade out / back in
function X.IdleTick(chat, elapsed)
    TabsTick(chat, elapsed)
    -- Decide the target a few times a second...
    acc = acc + elapsed
    if acc >= 0.1 then
        acc = 0
        local db = chat.db
        local now = GetTime and GetTime() or 0
        local busy = (chat.IsMouseOver and chat:IsMouseOver()) or (chat.eb and chat.eb:HasFocus())
            or (ns.Chat.dragging) or not db.locked or DockHovered()
        if busy then chat.lastActive = now end
        local idle = (db.idleFade or 0) > 0 and now - (chat.lastActive or now) > db.idleFade
        local target = idle and (db.idleAlpha or 0.2) or 1
        if chat.combatAlpha then
            -- Faded for combat, but hovering the chat or a new message on this tab brings it
            -- back for a few seconds first.
            local wake = (ns.db.combat and ns.db.combat.wake) or 4
            if now - (chat.lastActive or -1000) > wake then target = math.min(target, chat.combatAlpha) end
        end
        if target >= 0.999 and (chat.fadeTarget or 1) < 0.999 then X.WakeText(chat) end
        chat.fadeTarget, chat.fadeIdle = target, target < 0.999 -- fades out slowly, back in quickly
    end
    -- ...but move toward it every frame, so the fade is smooth.
    local target = chat.fadeTarget
    if not target then return end
    local cur = chat.chromeAlpha or 1
    -- Something else repainting the background can put its opacity back; keep it faded.
    if cur < 0.999 then X.PaintBg(chat, cur) end
    if math.abs(cur - target) > 0.002 then
        local step = elapsed / (chat.fadeIdle and FADE_OUT or FADE_IN)
        cur = cur < target and math.min(target, cur + step) or math.max(target, cur - step)
        X.ChromeAlpha(chat, cur)
    elseif chat.textFaded and not (chat.db.idleHideText or chat.combatAlpha) then
        X.ChromeAlpha(chat, cur) -- the option was just turned off: bring the text back
    end
end

function X.Touch(chat)
    chat.lastActive = GetTime and GetTime() or 0
    if (chat.fadeTarget or 1) < 0.999 then X.WakeText(chat) end
    chat.fadeTarget, chat.fadeIdle = 1, false -- wake at once, without waiting for the next check
end
