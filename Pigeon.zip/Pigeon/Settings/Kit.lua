--[[
    Pigeon - Settings kit: the shared widgets, layout helpers and window frame
    that every settings page builds on. Split from Settings.lua.
]]

local _, ns = ...
local K = {}
ns.SettingsKit = K

local T = ns.Theme
local LT = ns.L
local function SettingsText(parent,size,color,flags,weight)
    local text=T.Text(parent,size,color,"")
    text.wsSettingsWeight=weight or (size>=18 and "extra" or size<=10.5 and "bold" or "medium")
    T.StyleText(text,size,"")
    return text
end
local function SettingsButton(...)
    local b=T.Button(...)
    b.label.wsSettingsWeight="bold" T.StyleText(b.label,12.5,"")
    return b
end
local function SettingsEditBox(...)
    local b=T.EditBox(...)
    b.wsQuietFocus=true
    b.edit.wsSettingsWeight="medium" b.edit.wsSettingsSize=12 T.ApplyFont(b.edit,12,"") b.edit:SetShadowColor(0,0,0,0)
    b.placeholder.wsSettingsWeight="medium" T.StyleText(b.placeholder,12,"")
    return b
end

-- Font-independent dropdown arrow, shared by fixed and dynamic choices.
local function SettingsChevron(parent)
    local f=CreateFrame("Frame",nil,parent)
    f:SetSize(10,10) f:SetPoint("RIGHT",-11,0) f:EnableMouse(false)
    f.lines={}
    for i=1,2 do
        local line=f:CreateTexture(nil,"ARTWORK")
        line:SetColorTexture(T.SECTION[1],T.SECTION[2],T.SECTION[3],1)
        line:SetSize(6,1.5) line:SetPoint("CENTER",i==1 and -2 or 2,0)
        line:SetRotation(i==1 and -math.pi/4 or math.pi/4)
        f.lines[i]=line
    end
    return f
end




local S = CreateFrame("Frame", "PigeonSettings", UIParent)

ns.Settings = S

S:SetSize(780, 580)

S:SetFrameStrata("DIALOG")

S:SetToplevel(true) -- stays above the hub / whisper window it opens over

S:SetMovable(true)

S:SetClampedToScreen(true)

S:EnableMouse(true)

S:Hide()

S.pages = {}



-- CONTENT_W is the page width (window width minus the nav column and paddings).
-- It starts at the 780px window's 528 and follows the window via UpdateContentW.
local NAV_W = 200
K.CONTENT_W = 528
local MIN_W, MIN_H = 780, 580

local function UpdateContentW()
    local w = S:GetWidth() or MIN_W
    K.CONTENT_W = math.max(300, math.floor(w + 0.5) - NAV_W - 52)
end



local PAGE_KEYS = { "look", "chat", "tabs", "whispers", "replies", "alerts", "behavior", "profiles" }



---------------------------------------------------------------------------

-- Widgets

---------------------------------------------------------------------------



-- Greys out a control that depends on another one and blocks its input.
-- The row keeps its mouse so the tooltip still shows; inner controls and
-- clicks are blocked instead. reason (optional) explains the dependency.
local function SetEnabled(w, enabled, reason)
    enabled = enabled and true or false
    w:SetAlpha(enabled and 1 or 0.4)
    w.settingsDisabled = not enabled
    if reason then w.settingsReason = reason end
    if w.GetScript and w.SetScript and not w.settingsClickGuard then
        local orig = w:GetScript("OnClick")
        if orig then
            w.settingsClickGuard = true
            w:SetScript("OnClick", function(self, ...)
                if self.settingsDisabled then return end
                return orig(self, ...)
            end)
        end
    end
    if w.settingsSlider then w.settingsSlider:EnableMouse(enabled) end
    if w.box and w.box.edit and w.box.edit.EnableMouse then w.box.edit:EnableMouse(enabled) end
    if w.EnableMouse and not w:IsMouseEnabled() then w:EnableMouse(true) end
end

-- Hover tooltip for an option: the label as title, the tip as body text.
local function AttachTip(w, label, tip, extra)
    if not tip then return end
    local function enter(self)
        GameTooltip:SetOwner(w, "ANCHOR_RIGHT")
        GameTooltip:AddLine(label)
        GameTooltip:AddLine(tip, 0.8, 0.8, 0.8, true)
        if w.settingsDisabled then
            GameTooltip:AddLine(w.settingsReason or LT["Unavailable right now: this depends on another option."], 0.6, 0.6, 0.6, true)
        end
        GameTooltip:Show()
    end
    local function leave() GameTooltip:Hide() end
    if w.EnableMouse and not w:IsMouseEnabled() then w:EnableMouse(true) end
    w:HookScript("OnEnter", enter)
    w:HookScript("OnLeave", leave)
    if extra then
        extra:HookScript("OnEnter", enter)
        extra:HookScript("OnLeave", leave)
    end
end

local function Toggle(parent, label, get, set, width, tip)
    local b = CreateFrame("Button", nil, parent)
    AttachTip(b, label, tip)
    b:SetSize(width or 280, 36)
    b.text = SettingsText(b, 13, T.TEXT)
    b.text:SetPoint("LEFT")
    b.text:SetPoint("RIGHT", -38, 0)
    b.text:SetJustifyH("LEFT")
    b.text:SetWordWrap(false)
    b.text:SetText(label)
    b.track = T.Pill(b,20,{1,1,1,1},"ARTWORK")
    b.track:SetSize(36, 20)
    b.track:SetPoint("RIGHT")
    b.thumb = b:CreateTexture(nil, "OVERLAY")
    b.thumb:SetParent(b.track)
    T.Circle(b.thumb)
    b.thumb:SetSize(16, 16)
    T.Color(b.thumb, 1, 1, 1, 1)
    function b:Refresh()
        local on = get()
        self.thumb:ClearAllPoints()
        if on then
            T.Color(self.track, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1)
            self.thumb:SetPoint("RIGHT", self.track, "RIGHT", -2, 0)
        else
            T.Color(self.track, 0.24, 0.25, 0.29, 1)
            self.thumb:SetPoint("LEFT", self.track, "LEFT", 2, 0)
        end
    end
    b:SetScript("OnClick", function(self)
        set(not get())
        self:Refresh()
    end)
    b:Refresh()
    return b
end
local function Slider(parent, label, min, max, step, get, set, fmt, width, tip)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(width or 280, 36)
    f.text = SettingsText(f, 13, T.TEXT)
    f.text:SetJustifyH("LEFT") f.text:SetWordWrap(false) f.text:SetText(label)
    f.value = SettingsText(f, 12, T.SECTION, "", "bold")
    local s = CreateFrame("Slider", nil, f)
    f.settingsSlider = s
    s:SetOrientation("HORIZONTAL") s:EnableMouse(true)
    s:SetMinMaxValues(min, max) s:SetValueStep(step)
    if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    s:SetSize(120, 22)
    -- Keep the native thumb on its Slider. Decorative child frames used to
    -- sit above it; reparenting the thumb broke the client's drag ownership.
    local art = CreateFrame("Frame", nil, f)
    art:SetAllPoints(s) art:EnableMouse(false)
    local track = T.Pill(art,4,{1,1,1,0.13},"BACKGROUND")
    track:SetHeight(4) track:SetPoint("LEFT") track:SetPoint("RIGHT")
    local fill = T.AccentTexture(T.Pill(art,4,T.ACCENT,"ARTWORK"))
    fill:SetHeight(4) fill:SetPoint("LEFT", track, "LEFT")
    s:SetFrameLevel(fill:GetFrameLevel()+2)
    local thumb = s:CreateTexture(nil, "OVERLAY")
    thumb:SetSize(14,14) T.Circle(thumb) T.Color(thumb,1,1,1,1)
    s:SetThumbTexture(thumb)
    f.track,f.thumb,f.fill=track,thumb,fill
    local function normalize(v)
        v=tonumber(v) or min
        return math.max(min,math.min(max,min+math.floor((v-min)/step+0.5)*step))
    end
    local function show(v)
        f.value:SetText(fmt and fmt(v) or tostring(v))
        local fraction=(v-min)/(max-min)
        fill:SetWidth(math.max(4,7+fraction*math.max(0,s:GetWidth()-14)))
    end
    local function layout()
        f.text:ClearAllPoints() f.value:ClearAllPoints() s:ClearAllPoints()
        if f:GetWidth()<360 then
            f.text:SetPoint("TOPLEFT",0,-1) f.text:SetPoint("RIGHT",-90,0)
            f.value:SetPoint("TOPRIGHT",0,-1)
            s:SetPoint("BOTTOMLEFT",0,-2) s:SetPoint("BOTTOMRIGHT",0,-2)
            s:SetHeight(18)
        else
            -- The track grows with spare row width (476 is the 780px window's row), capped at 320.
            local tw=math.max(120,math.min(320,120+((f:GetWidth() or 476)-476)))
            s:SetPoint("RIGHT") s:SetSize(tw,22)
            f.value:SetPoint("RIGHT",s,"LEFT",-10,0)
            f.text:SetPoint("LEFT") f.text:SetPoint("RIGHT",-(tw+90),0)
        end
        show(normalize(get()))
    end
    f.settingsRelayout=layout
    s:SetScript("OnValueChanged",function(_,v)
        v=normalize(v) show(v)
        -- Some supported clients omit userInput, others report false while
        -- dragging. Only our explicit refresh guard distinguishes a refresh.
        if not f.loading and math.abs(v-(tonumber(get()) or min))>step/1000 then
            set(v)
        end
    end)
    function f:Refresh()
        self.loading=true
        local v=normalize(get()) s:SetValue(v) show(v)
        self.loading=false
    end
    f:SetScript("OnSizeChanged",layout)
    layout() f:Refresh()
    AttachTip(f, label, tip, s)
    return f
end
-- Choice pills show every option in a local dropdown.
local function Choice(parent, label, options, get, set, width, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 280, 36)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b.text = SettingsText(b, 13, T.TEXT, "")
    b.text:SetPoint("LEFT")
    b.text:SetText(label)
    local box = CreateFrame("Frame", nil, b)
    box:SetSize(math.min(180, (width or 280) * 0.6), 30)
    box:SetPoint("RIGHT")
    b.text:SetPoint("RIGHT", box, "LEFT", -12, 0) b.text:SetJustifyH("LEFT") b.text:SetWordWrap(false)
    box.bg=T.Pill(box,30,{1,1,1,0.10},"BACKGROUND") box.bg:SetAllPoints()
    b.choiceBox = box
    b.val = SettingsText(box, 12.5, T.TEXT, "", "bold")
    b.val:SetPoint("LEFT", 22, 0)
    b.val:SetPoint("RIGHT", -22, 0)
    b.val:SetJustifyH("CENTER")
    b.val:SetWordWrap(false)
    b.val:SetParent(box.bg)
    b.choiceArrow=SettingsChevron(box.bg)
    b.settingsOptions = options
    local function index()
        local cur = get()
        for i, o in ipairs(options) do if o[1] == cur then return i end end
        return 1
    end
    function b:Refresh() self.val:SetText(options[index()][2]) end
    b:SetScript("OnClick", function(self, button)
        K.OpenMenu(self, options, get(), function(v) set(v) self:Refresh() end)
    end)
    b:SetScript("OnEnter",function() T.Color(box.bg,1,1,1,0.17) end)
    b:SetScript("OnLeave",function() T.Color(box.bg,1,1,1,0.10) end)
    AttachTip(b, label, tip) -- after the SetScript hover handlers above, so they can't replace the tip hooks
    b:Refresh()
    return b
end
local function Heading(parent, text)

    local fs = SettingsText(parent, 10, T.SECTION)

    fs:SetText(text:upper())

    return fs

end



-- Vertical stacking helper. Each heading opens a "card": a soft rounded

-- panel behind that section's widgets, which grows as widgets are added.

local CARD_PAD, CARD_GAP = 12, 12

local function LegacyStack(page, x, y)

    local st = { x = x + CARD_PAD, left = x, y = y, widgets = {}, labels = {} }

    local function Grow(self)

        local card = self.card

        if not card then return end

        card:SetHeight(self.y - card.top + CARD_PAD - 8)

        if (self.widest or 0) + CARD_PAD * 2 > card:GetWidth() then card:SetWidth(self.widest + CARD_PAD * 2) end

    end

    function st:Add(w, gap)

        w:ClearAllPoints()

        w:SetPoint("TOPLEFT", page, "TOPLEFT", self.x, -self.y)

        self.y = self.y + (w.GetHeight and w:GetHeight() or 14) + (gap or 8)

        self.widest = math.max(self.widest or 0, w.GetWidth and w:GetWidth() or 0)

        if w.Refresh then self.widgets[#self.widgets + 1] = w end

        if w.text and w.text.GetText then self.labels[#self.labels + 1] = w.text:GetText() end

        Grow(self)

        return w

    end

    function st:Head(text)

        if self.card then self.y = self.y + CARD_GAP end

        local card = CreateFrame("Frame", nil, page)

        card:SetFrameLevel(math.max(0, page:GetFrameLevel()))

        card:SetPoint("TOPLEFT", page, "TOPLEFT", self.left, -self.y)

        card:SetWidth(40)

        card.top = self.y

        card.bg = T.ShapeFill(card, { 1, 1, 1, 0.03 }, 8)

        card.border = T.Border(card, { T.INPUT_BORDER[1], T.INPUT_BORDER[2], T.INPUT_BORDER[3], 0.5 }, 1, 8)

        T.RegisterCard(card)

        self.card = card

        self.widest = 0

        self.y = self.y + CARD_PAD

        local h = Heading(page, text)

        h:SetPoint("TOPLEFT", page, "TOPLEFT", self.x, -self.y)

        self.labels[#self.labels + 1] = text

        self.y = self.y + 20

        Grow(self)

        return h

    end

    return st

end



-- Section bars match the Tabs page groups: 30px bar, 6px gap, accent border while open.
local SECTION_HEAD, SECTION_GAP = 30, 6

local function PaintSection(section)
    local header, card = section.header, section.card
    local open = section.open and true or false
    T.Color(header.bg, T.INPUT_BG[1], T.INPUT_BG[2], T.INPUT_BG[3], 1)
    T.SetBorderColor(header.border, open and T.ACCENT or T.INPUT_BORDER, open and 0.55 or nil)
    T.Color(card.bg, 0.075, 0.078, 0.095, 1)
    T.SetBorderColor(card.border, T.INPUT_BORDER)
    header.text:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3])
    header.marker:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
    header.count:SetTextColor(T.SECTION[1], T.SECTION[2], T.SECTION[3])
    header.marker:SetText(open and "-" or "+")
    header.count:SetText(tostring(#section.rows))
end

-- Sizes one stretchable row to width rw (476 in the 780px window). Labels stay
-- left; the control hugs the right edge and grows with spare width up to a cap.
local function LayoutRow(w, rw)
    w:SetWidth(rw)
    if w.choiceBox then w.choiceBox:SetWidth(math.max(180, math.min(240, 180 + (rw - 476)))) end
    if w.settingsRelayout then w.settingsRelayout() end
    if w.settingsRowLayout then w.settingsRowLayout(rw) end
end

-- Re-fits a built page to the current CONTENT_W: scroll child, section bars,
-- cards and every stretchable row. Cheap no-op when the width is unchanged.
local function FitPage(page)
    if page.fitW == K.CONTENT_W then return end
    page.fitW = K.CONTENT_W
    local cw = K.CONTENT_W
    if page.content then page.content:SetWidth(cw) end
    for _, section in ipairs(page.sections or {}) do
        section.header:SetWidth(cw - 20)
        section.card:SetWidth(cw - 20)
        for _, row in ipairs(section.rows) do
            if row.settingsStretch then LayoutRow(row, cw - 52 - (row.settingsRowInset or 0)) end
        end
    end
    if page.fitExtra then page.fitExtra() end
end

-- Keep every row inside its section, so folding moves labels and controls together.

local function Stack(page, x, y)

    local outer = page.settingsOuter

    if not outer or outer.settingsKey == "profiles" then return LegacyStack(page, x, y) end

    outer.sections = outer.sections or {}

    outer.entries = outer.entries or {}

    local st = { x = 12, y = 0, widgets = {}, labels = {} }

    function st:Head(text)

        -- open stays nil until Reflow decides: only the first section of the active tab starts open.
        local section = { name = text, rows = {}, height = 0 }

        local header = CreateFrame("Button", nil, page)

        header:SetSize(K.CONTENT_W - 20, SECTION_HEAD)

        header.bg = T.ShapeFill(header, T.INPUT_BG, 8)

        header.border = T.Border(header, T.INPUT_BORDER, 1, 8)

        header.text = SettingsText(header, 13, T.TEXT)

        header.text:SetPoint("LEFT", 30, 0)

        header.text:SetText(text)

        header.count = SettingsText(header, 11, T.SECTION)

        header.count:SetPoint("RIGHT", -12, 0)

        header.marker = SettingsText(header, 14, T.SECTION)

        header.marker:SetPoint("LEFT", 11, 0)

        local card = CreateFrame("Frame", nil, page)

        card:SetWidth(K.CONTENT_W - 20)

        card.top = 0

        card.bg = T.ShapeFill(card, { 0.075, 0.078, 0.095, 1 }, 8)

        card.border = T.Border(card, T.INPUT_BORDER, 1, 8)

        section.header, section.card = header, card

        header:SetScript("OnClick", function()

            K.CloseMenu()

            section.open = not section.open

            K.Reflow(outer)

        end)

        outer.sections[#outer.sections + 1] = section

        self.section, self.card = section, card

        self.labels[#self.labels + 1] = text

        return header.text

    end

    function st:Add(w, gap)

        if not self.section then self:Head(LT["Settings"]) end

        local section = self.section

        local wh = w:GetHeight() or 18
        local h = math.max(36, wh + (wh > 36 and (gap or 8) or 0))

        local width = w:GetWidth() or 0

        if w.text and w.val then

            -- The label runs up to the choice box (anchored in Choice / Dropdown);
            -- LayoutRow sizes the box.
            w.text:SetJustifyH("LEFT")

            w.text:SetWordWrap(false)

        end

        local isString = w.GetObjectType and w:GetObjectType() == "FontString"

        if w.settingsStretch or w.settingsSlider or w.box or ((w.text or isString) and width >= 200) then

            w.settingsStretch = true

            LayoutRow(w, K.CONTENT_W - 52 - (w.settingsRowInset or 0))

        end

        w:SetParent(section.card)

        w.settingsOffset = section.height

        w:ClearAllPoints()

        w:SetPoint("TOPLEFT", section.card, "TOPLEFT", 16, -section.height - (h - w:GetHeight()) / 2)

        if #section.rows > 0 then

            local rule = section.card:CreateTexture(nil, "ARTWORK")

            rule:SetColorTexture(1, 1, 1, 0.045)

            rule:SetHeight(1)

            rule:SetPoint("TOPLEFT", 16, -section.height)

            rule:SetPoint("TOPRIGHT", -16, -section.height)

        end

        section.rows[#section.rows + 1] = w

        section.height = section.height + h

        section.card:SetHeight(section.height)

        self.y = self.y + h

        if w.Refresh then self.widgets[#self.widgets + 1] = w end

        if w.text and w.text.GetText then

            local label = w.text:GetText()

            self.labels[#self.labels + 1] = label

            outer.entries[#outer.entries + 1] = { label = label, widget = w, section = section }

        end

        return w

    end

    return st

end



-- Colour swatch. get() returns {r,g,b[,a]} or nil (= follow the theme);

-- fallback() gives the colour currently in use for the swatch preview.

-- Click opens the game's colour picker; right-click goes back to auto.

local function OpenPicker(color, hasAlpha, onChange)

    local r, g, b, a = color[1], color[2], color[3], color[4] or 1

    local function Read()

        local nr, ng, nb = ColorPickerFrame:GetColorRGB()

        local na = a

        if hasAlpha then

            if ColorPickerFrame.GetColorAlpha then na = ColorPickerFrame:GetColorAlpha()

            elseif OpacitySliderFrame then na = 1 - OpacitySliderFrame:GetValue() end

        end

        return { nr, ng, nb, na }

    end

    local info = {

        r = r, g = g, b = b, opacity = a, hasOpacity = hasAlpha,

        swatchFunc = function() onChange(Read()) end,

        opacityFunc = function() onChange(Read()) end,

        cancelFunc = function() onChange({ r, g, b, a }) end,

    }

    if ColorPickerFrame and ColorPickerFrame.SetupColorPickerAndShow then

        ColorPickerFrame:SetupColorPickerAndShow(info)

    elseif OpenColorPicker then

        info.func = info.swatchFunc

        OpenColorPicker(info)

    end

end



local function Swatch(parent, label, get, set, fallback, hasAlpha, width)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 280, 30)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b.bg = T.ShapeFill(b, { 1, 1, 1, 0.03 }, 6)
    b.border = T.Border(b, T.INPUT_BORDER, 1, 6)
    b.bg:SetAlpha(0) for _, edge in ipairs(b.border) do edge:Hide() end
    local box = CreateFrame("Frame", nil, b)
    box:SetSize(22, 22)
    box:SetPoint("RIGHT")
    local ring = box:CreateTexture(nil, "BACKGROUND") ring:SetAllPoints() T.Circle(ring) T.Color(ring, 1,1,1,0.25)
    local fill = box:CreateTexture(nil, "ARTWORK") fill:SetSize(18,18) fill:SetPoint("CENTER") T.Circle(fill)
    box.border = {} -- the circular ring supplies the border
    b.text = SettingsText(b, 13, T.TEXT)
    b.text:SetPoint("LEFT", 6, 0)
    b.text:SetText(label)
    b.state = SettingsText(b, 9, T.DIM)
    b.state:SetPoint("RIGHT", -30, 0)
    function b:Refresh()
        local c = get() or fallback()
        local cls = self.classOn and self.classOn() and RAID_CLASS_COLORS and RAID_CLASS_COLORS[select(2, UnitClass("player"))]
        if cls then c = { cls.r, cls.g, cls.b, c[4] } end
        T.Color(fill, c[1], c[2], c[3], hasAlpha and (c[4] or 1) or 1)
        self.state:SetText(cls and LT["CLASS"] or (get() and LT["CUSTOM"] or LT["AUTO"]))
    end
    b:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            set(nil)
            self:Refresh()
            return
        end
        OpenPicker(get() or fallback(), hasAlpha, function(c)
            set(c)
            self:Refresh()
        end)
    end)
    b:SetScript("OnEnter", function(self)
        T.SetBorderColor(self.border, T.ACCENT, 0.7)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(label)
        GameTooltip:AddLine(LT["Click to pick a colour. Right-click to follow your theme again."], 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function(self)
        T.SetBorderColor(self.border, T.INPUT_BORDER)
        GameTooltip:Hide()
    end)
    b:Refresh()
    return b
end
-- Dynamic choices share the settings dropdown, including long font lists.
-- items() returns { { value, label }, ... }.
local function Dropdown(parent, label, items, get, set, width, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 280, 36)
    b.text = SettingsText(b, 13, T.TEXT, "")
    b.text:SetPoint("LEFT")
    b.text:SetText(label)
    local box = CreateFrame("Frame", nil, b)
    box:SetSize(180, 30)
    box:SetPoint("RIGHT")
    b.text:SetPoint("RIGHT", box, "LEFT", -12, 0) b.text:SetJustifyH("LEFT") b.text:SetWordWrap(false)
    box.bg=T.Pill(box,30,{1,1,1,0.10},"BACKGROUND") box.bg:SetAllPoints()
    b.choiceBox = box
    b.val = SettingsText(box, 12.5, T.TEXT, "", "bold")
    b.val:SetPoint("LEFT", 22, 0)
    b.val:SetPoint("RIGHT", -22, 0)
    b.val:SetJustifyH("CENTER")
    b.val:SetWordWrap(false)
    b.val:SetParent(box.bg)
    b.val:SetPoint("RIGHT", -22, 0)
    b.val:SetJustifyH("CENTER")
    b.val:SetWordWrap(false)
    b.choiceArrow=SettingsChevron(box.bg)
    b.settingsOptions = items
    function b:Refresh()
        local cur = get()
        for _, it in ipairs(items()) do
            if it[1] == cur then self.val:SetText(it[2]) return end
        end
        self.val:SetText(tostring(cur or "?"))
    end
    b:SetScript("OnClick", function(self)
        K.OpenMenu(self, items(), get(), function(v) set(v) self:Refresh() end)
    end)
    b:SetScript("OnEnter",function() T.Color(box.bg,1,1,1,0.17) end)
    b:SetScript("OnLeave",function() T.Color(box.bg,1,1,1,0.10) end)
    AttachTip(b, label, tip) -- after the SetScript hover handlers above, so they can't replace the tip hooks
    b:Refresh()
    return b
end
-- Single-line text setting. Saved on Enter or when the box loses focus.
local function TextInput(parent, label, get, set, width, placeholder, tip)

    local f = CreateFrame("Frame", nil, parent)

    AttachTip(f, label or placeholder or "", tip, nil)

    f:SetSize(width or 280, label and 50 or 30)

    local box = SettingsEditBox(f, placeholder or "")

    if label then

        f.text = SettingsText(f, 13, T.TEXT)

        f.text:SetPoint("TOPLEFT")

        f.text:SetText(label)

        box:SetPoint("TOPLEFT", 0, -18)

    else

        box:SetPoint("TOPLEFT")

    end

    box:SetPoint("RIGHT")

    box.edit:SetTextColor(1, 1, 1)

    box.edit:SetMaxLetters(200)

    local function Save(e)

        if f.loading then return end

        set(strtrim(e:GetText() or ""))

    end

    box.edit:SetScript("OnEnterPressed", function(e) Save(e) e:ClearFocus() end)

    box.edit:HookScript("OnEditFocusLost", Save)

    box.edit:SetScript("OnEscapePressed", function(e) f:Refresh() e:ClearFocus() end)

    f.box = box

    function f:Refresh()

        self.loading = true

        box.edit:SetText(get() or "")

        self.loading = false

    end

    f:Refresh()

    return f

end



local function Note(parent, text, width)

    local n = SettingsText(parent, 11.5, T.SECTION)

    n:SetWidth(width)

    n:SetJustifyH("LEFT")

    n:SetText(text)

    return n

end



-- A page that scrolls: returns the content frame to build on and a

-- function to call once its height is known.

local function Scroller(page)

    local sf = CreateFrame("ScrollFrame", nil, page)

    sf:SetPoint("TOPLEFT")

    sf:SetPoint("BOTTOMRIGHT", -12, 0)

    local child = CreateFrame("Frame", nil, sf)

    child:SetSize(K.CONTENT_W, 10)

    child.settingsOuter = page

    page.content, page.scroll = child, sf

    sf:SetScrollChild(child)

    local track = page:CreateTexture(nil, "ARTWORK")

    track:SetWidth(3)

    -- Anchored to the scroll frame (not the page) so the bar follows the preview inset.
    track:SetPoint("TOPRIGHT", sf, "TOPRIGHT", 12, 0)

    track:SetPoint("BOTTOMRIGHT", sf, "BOTTOMRIGHT", 12, 0)

    track:SetColorTexture(1, 1, 1, 0.05)

    local thumb = T.AccentTexture(page:CreateTexture(nil, "OVERLAY"))

    thumb:SetWidth(3)

    -- Visible height of the scroll area: the page minus the preview inset when known.
    local function ViewH()
        local ph = page:GetHeight() or 0
        if page.scrollInset and ph > 0 then return math.max(0, ph - page.scrollInset) end
        return sf:GetHeight() or 0
    end

    local function Update()

        local view = ViewH()

        local total = child:GetHeight() or 0

        local max = math.max(0, total - view)

        local cur = math.max(0, math.min(sf:GetVerticalScroll() or 0, max))

        sf:SetVerticalScroll(cur)

        if max <= 0 or view <= 0 then thumb:Hide() track:Hide() return end

        thumb:Show() track:Show()

        local h = math.max(24, view * view / total)

        thumb:SetHeight(h)

        thumb:ClearAllPoints()

        thumb:SetPoint("TOPRIGHT", sf, "TOPRIGHT", 12, -(view - h) * (cur / max))

    end

    -- Any change to the content height updates the bar, not only the end of Reflow.
    child:SetScript("OnSizeChanged", function() Update() end)

    -- The bar itself: click anywhere on it to jump there, or drag it.

    local grab = CreateFrame("Frame", nil, page)

    grab:SetPoint("TOPRIGHT", sf, "TOPRIGHT", 14, 0)

    grab:SetPoint("BOTTOMRIGHT", sf, "BOTTOMRIGHT", 14, 0)

    grab:SetWidth(14)

    grab:SetFrameLevel(sf:GetFrameLevel() + 5)

    grab:EnableMouse(true)

    local function Follow()

        local view = ViewH()

        local total = child:GetHeight() or 0

        local max = math.max(0, total - view)

        if max <= 0 or view <= 0 then return end

        local h = math.max(24, view * view / total)

        local _, cy = GetCursorPosition()

        cy = cy / grab:GetEffectiveScale()

        -- Keep the spot that was grabbed under the mouse.

        local pos = ((grab:GetTop() or 0) - cy) - (grab.offset or h / 2)

        local frac = (view - h) > 0 and math.max(0, math.min(1, pos / (view - h))) or 0

        sf:SetVerticalScroll(frac * max)

        Update()

    end

    grab:SetScript("OnMouseDown", function(self, button)

        if button ~= "LeftButton" or not thumb:IsShown() then return end

        local _, cy = GetCursorPosition()

        cy = cy / self:GetEffectiveScale()

        local top, bottom = thumb:GetTop(), thumb:GetBottom()

        -- On the bar: hold it where it was grabbed. Elsewhere: centre it on the click.

        self.offset = (top and bottom and cy <= top and cy >= bottom) and (top - cy) or nil

        self:SetScript("OnUpdate", Follow)

        Follow()

    end)

    grab:SetScript("OnMouseUp", function(self) self:SetScript("OnUpdate", nil) end)

    grab:SetScript("OnHide", function(self) self:SetScript("OnUpdate", nil) end)

    grab:SetScript("OnEnter", function() thumb:SetWidth(6) track:SetWidth(6) end)

    grab:SetScript("OnLeave", function() thumb:SetWidth(3) track:SetWidth(3) end)



    sf:EnableMouseWheel(true)

    sf:SetScript("OnMouseWheel", function(_, delta)

        K.CloseMenu()

        local max = math.max(0, (child:GetHeight() or 0) - ViewH())

        local v = (sf:GetVerticalScroll() or 0) - delta * 48

        sf:SetVerticalScroll(math.max(0, math.min(v, max)))

        Update()

    end)

    sf:SetScript("OnSizeChanged", Update)

    page.updateScroll = Update

    return child, function(height)

        child:SetHeight(height)

        Update()

    end

end



---------------------------------------------------------------------------

-- Pages

---------------------------------------------------------------------------



local function ChatDB() return ns.db.chat end

local function ApplyChat() if ns.Chat.smf then ns.Chat:ApplySettings() end end

-- Chat box border toggle/thickness: re-applied after every restyle (tab switch, opacity, look).
hooksecurefunc(ns.Chat, "ApplyTabStyle", function(self) T.ApplyChatBorder(self) end)

local builders = {}
K.builders = builders
K.ApplyChat = ApplyChat
K.ChatDB = ChatDB
K.Choice = Choice
K.Dropdown = Dropdown
K.FitPage = FitPage
K.Heading = Heading
K.LayoutRow = LayoutRow
K.MIN_H = MIN_H
K.MIN_W = MIN_W
K.NAV_W = NAV_W
K.Note = Note
K.PAGE_KEYS = PAGE_KEYS
K.PaintSection = PaintSection
K.S = S
K.SECTION_GAP = SECTION_GAP
K.SECTION_HEAD = SECTION_HEAD
K.Scroller = Scroller
K.SetEnabled = SetEnabled
K.SettingsButton = SettingsButton
K.SettingsEditBox = SettingsEditBox
K.SettingsText = SettingsText
K.Slider = Slider
K.Stack = Stack
K.Swatch = Swatch
K.TextInput = TextInput
K.Toggle = Toggle
K.UpdateContentW = UpdateContentW
