--[[
    Pigeon - Settings: the Tabs page. Split from Settings.lua.
]]

local _, ns = ...
local T = ns.Theme
local LT = ns.L
local K = ns.SettingsKit
local builders = K.builders
local ChatDB, Heading, S, SetEnabled, SettingsButton, SettingsEditBox, SettingsText, Slider, Toggle = K.ChatDB, K.Heading, K.S, K.SetEnabled, K.SettingsButton, K.SettingsEditBox, K.SettingsText, K.Slider, K.Toggle

local CATEGORY_GROUPS = ns.CHAT_CATEGORY_GROUPS

function builders.tabs(page)

    local db = ChatDB()
    for _,tab in ipairs(db.tabs)do ns.UpgradeChatFilters(tab)end

    page.selected = page.selected or 1

    page.listButtons = {}

    local LIST_W = 140

    local DETAIL_X = LIST_W + 18



    -- Left: the tab list

    -- A scrollable card list keeps user-created tabs above the footer actions.
    local viewport=CreateFrame("ScrollFrame",nil,page)
    viewport:SetPoint("TOPLEFT",0,0) viewport:SetPoint("BOTTOMLEFT",0,90)
    viewport:SetWidth(LIST_W) viewport:EnableMouseWheel(true)
    local list=CreateFrame("Frame",nil,viewport)
    list:SetSize(LIST_W,1) viewport:SetScrollChild(list)
    page.list,page.listViewport=list,viewport
    viewport:SetScript("OnMouseWheel",function(self,delta)
        local maximum=math.max(0,list:GetHeight()-self:GetHeight())
        self:SetVerticalScroll(math.max(0,math.min(maximum,self:GetVerticalScroll()-delta*44)))
    end)

    local add = SettingsButton(page, LT["+ New tab"], LIST_W, 34)

    add:SetPoint("BOTTOMLEFT", 0, 42)

    add:SetScript("OnClick", function() StaticPopup_Show("PIGEON_NEW_TAB") end)



    local join=SettingsButton(page,LT["Join channel"],LIST_W,34)
    join:SetPoint("BOTTOMLEFT",0,0)
    page.joinButton=join
    join:SetScript("OnClick",function()
        local dialog=page.joinDialog
        if not dialog then
            dialog=CreateFrame("Frame",nil,S)
            dialog:SetSize(344,152) dialog:SetPoint("CENTER") dialog:SetFrameStrata("DIALOG")
            dialog:SetFrameLevel(S:GetFrameLevel()+30) dialog:EnableMouse(true)
            T.Panel(dialog) T.Reshape(dialog,16)
            local title=SettingsText(dialog,15,T.TEXT,"","bold")
            title:SetPoint("TOPLEFT",16,-14) title:SetText(LT["Join a global channel"])
            local input=SettingsEditBox(dialog,LT["Channel name, e.g. World"])
            input:SetPoint("TOPLEFT",16,-45) input:SetSize(312,30)
            dialog.input=input
            local hint=SettingsText(dialog,11,T.SECTION)
            hint:SetPoint("TOPLEFT",16,-82) hint:SetText(LT["Joins the channel and creates a filtered tab."])
            local cancel=SettingsButton(dialog,LT["Cancel"],80,26) cancel:SetPoint("BOTTOMRIGHT",-108,12)
            cancel:SetScript("OnClick",function()dialog:Hide()end)
            local accept=SettingsButton(dialog,LT["Join"],80,26) accept:SetPoint("BOTTOMRIGHT",-16,12)
            local function submit()
                local index=ns.Chat:JoinTabChannel(input.edit:GetText())
                if index then page.selected=index page:Render() dialog:Hide() end
            end
            accept:SetScript("OnClick",submit)
            input.edit:SetScript("OnEnterPressed",submit)
            input.edit:SetScript("OnEscapePressed",function()dialog:Hide()end)
            dialog:SetScript("OnHide",function()input.edit:ClearFocus()end)
            dialog:Hide() page.joinDialog=dialog
            page:HookScript("OnHide",function()dialog:Hide()end)
        end
        dialog.input.edit:SetText("") dialog:Show() dialog:Raise() dialog.input.edit:SetFocus()
    end)

    local vdiv = page:CreateTexture(nil, "ARTWORK")

    vdiv:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])

    vdiv:SetWidth(1)

    vdiv:SetPoint("TOPLEFT", LIST_W + 8, 0)

    vdiv:SetPoint("BOTTOMLEFT", LIST_W + 8, 0)



    -- Right: the selected tab

    local detail = CreateFrame("Frame", nil, page)

    detail:SetPoint("TOPLEFT", DETAIL_X, 0)

    detail:SetPoint("BOTTOMRIGHT")

    page.detail = detail

    local DW = K.CONTENT_W - DETAIL_X



    local nameHead = Heading(detail, LT["Name"])

    nameHead:Hide()

    local name = SettingsEditBox(detail, LT["Tab name"])

    name:SetPoint("TOPLEFT", 0, 0)

    name:SetSize(DW - 104, 34)

    name.edit:SetTextColor(1, 1, 1)

    name.edit:SetScript("OnEnterPressed", function(e)

        local tab = db.tabs[page.selected]

        local text = strtrim(e:GetText())

        if tab and text ~= "" then tab.name = text if ns.Chat.smf then ns.Chat:RenderTabs() end end

        e:ClearFocus()

        page:Render()

    end)

    page.name = name



    local smart = SettingsButton(detail, LT["Auto-filter"], 96, 34)

    smart:SetPoint("LEFT", name, "RIGHT", 8, 0)

    smart:SetScript("OnEnter", function(b)

        GameTooltip:SetOwner(b, "ANCHOR_TOP")

        GameTooltip:AddLine(LT["Auto-filter from name"])

        GameTooltip:AddLine(LT["Sets the filters from the tab's name: Guild, Trade, Raid, Loot…"], T.SECTION[1], T.SECTION[2], T.SECTION[3], true)

        GameTooltip:Show()

    end)

    smart:SetScript("OnLeave", function() GameTooltip:Hide() end)

    smart:SetScript("OnClick", function()

        local tab = db.tabs[page.selected]

        if not tab then return end

        local cats, channels, summary = ns.SmartFilter(tab.name)

        tab.all = (cats == nil and channels == nil) or nil

        tab.cats, tab.channels = cats, channels

        ns.Print(LT["|cffe6ebf5%s|r now shows %s."]:format(tab.name, summary))

        page:Render()

        if ns.Chat.smf then ns.Chat:Rerender() end

    end)



    page.summary = SettingsText(detail, 11, T.SECTION)

    page.summary:SetPoint("TOPLEFT", 0, -42)

    page.summary:SetWidth(DW)

    page.summary:SetJustifyH("LEFT")

    page.summary:SetMaxLines(1)



    -- Tab actions, in one row under the name.

    local function move(dir)

        local i, j = page.selected, page.selected + dir

        if not db.tabs[j] then return end

        db.tabs[i], db.tabs[j] = db.tabs[j], db.tabs[i]

        page.selected = j

        if ns.Chat.smf then

            ns.Chat.unread = {}

            ns.Chat.active = j

            ns.Chat:RenderTabs()

        end

        page:Render()

    end

    local left = SettingsButton(detail, LT["< Move"], 72, 24)

    left:SetPoint("BOTTOMLEFT", 0, 0)

    left:SetScript("OnClick", function() move(-1) end)

    local right = SettingsButton(detail, LT["Move >"], 72, 24)

    right:SetPoint("LEFT", left, "RIGHT", 6, 0)

    right:SetScript("OnClick", function() move(1) end)

    local del = SettingsButton(detail, LT["Delete tab"], 86, 24)

    del:SetPoint("BOTTOMRIGHT", 0, 0)

    del.label:SetTextColor(1, 0.55, 0.5)

    -- Only on a tab called General: back to the recommended, less noisy set.
    local recommended = SettingsButton(detail, LT["Default"], 86, 24)
    recommended:SetPoint("RIGHT", del, "LEFT", -6, 0)
    StaticPopupDialogs.PIGEON_RESET_GENERAL = {
        text = LT["Reset this tab to its default chat channels?"],
        button1 = YES, button2 = NO,
        OnAccept = function()
            local tab = db.tabs[page.selected]
            if not tab then return end
            -- Shipped tabs go back to their shipped set; any other tab to what its name
            -- would pick if it were created now.
            local fresh = ns.DefaultTabByName(tab.name)
            if fresh then
                tab.all, tab.combat, tab.channels = nil, nil, nil
                tab.cats, tab.categoryVersion = fresh.cats, fresh.categoryVersion
            else
                local cats, channels = ns.SmartFilter(tab.name)
                tab.combat = nil
                tab.all = (cats == nil and channels == nil) or nil
                tab.cats, tab.channels = cats, channels
                if ns.IsCombatTab({ name = tab.name }) then tab.combat, tab.all = true, nil end
            end
            page:Render()
            if ns.Chat.smf then ns.Chat:Rerender() end
        end,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
    }
    recommended:SetScript("OnClick", function() StaticPopup_Show("PIGEON_RESET_GENERAL") end)
    page.recommended = recommended

    del:SetScript("OnClick", function()

        if #db.tabs <= 1 then return end

        if ns.Chat.smf then ns.Chat:RemoveTab(page.selected) else table.remove(db.tabs, page.selected) end

        page.selected = math.max(1, page.selected - 1)

        page:Render()

    end)

    page.del, page.moveL, page.moveR = del, left, right



    page.allToggle = Toggle(detail, LT["Show everything"], function()

        local tab = db.tabs[page.selected]

        return tab and tab.all

    end, function(v)

        local tab = db.tabs[page.selected]

        if not tab then return end

        tab.all = v or nil

        if not v then tab.cats = tab.cats or {} end

        page:Render()

        if ns.Chat.smf then ns.Chat:Rerender() end

    end, DW, LT["Shows every message type and channel on this tab, ignoring the group boxes."])

    page.allToggle:SetPoint("TOPLEFT", 0, -65)
    page.allToggle:SetHeight(28)



    local div = detail:CreateTexture(nil, "ARTWORK")

    div:SetColorTexture(T.DIVIDER[1], T.DIVIDER[2], T.DIVIDER[3], T.DIVIDER[4])

    div:SetHeight(1)

    div:SetPoint("TOPLEFT", 0, -101)

    div:SetPoint("TOPRIGHT", 0, -101)



    -- Grouped category toggles in a scrolling list.

    local scroll = CreateFrame("ScrollFrame", nil, detail)

    scroll:SetPoint("TOPLEFT", 0, -110)

    scroll:SetPoint("BOTTOMRIGHT", -10, 38)

    local child = CreateFrame("Frame", nil, scroll)

    child:SetWidth(DW - 10)

    scroll:SetScrollChild(child)

    page.scroll, page.scrollChild = scroll, child



    local byKey={}
    for _,c in ipairs(ns.CHAT_CATEGORIES)do byKey[c.key]=c end
    page.catToggles={} page.filterGroups={}
    local function Group(title)
        local group={title=title,toggles={},keys={}}
        local head=CreateFrame("Button",nil,child) head:SetSize(DW-10,30)
        head.bg=T.ShapeFill(head,T.INPUT_BG,8)
        head.border=T.Border(head,T.INPUT_BORDER,1,8)
        head.label=SettingsText(head,13,T.TEXT) head.label:SetPoint("LEFT",30,0) head.label:SetText(title)
        head.count=SettingsText(head,11,T.SECTION) head.count:SetPoint("RIGHT",-12,0)
        head.marker=SettingsText(head,14,T.SECTION)
        head.marker:SetPoint("LEFT",11,0)
        local body=CreateFrame("Frame",nil,child) body:SetWidth(DW-10)
        body.bg=T.ShapeFill(body,{0.075,0.078,0.095,1},8)
        body.border=T.Border(body,T.INPUT_BORDER,1,8)
        group.header,group.body=head,body
        head:SetScript("OnClick",function()
            if page.openGroup==title then page.openGroup=nil else page.openGroup=title end
            page:Render()
        end)
        page.filterGroups[#page.filterGroups+1]=group
        return group
    end
    for _,definition in ipairs(CATEGORY_GROUPS)do
        local group=Group(definition[1])
        for _,key in ipairs(definition[2])do
            local c=byKey[key]
            local tg=Toggle(group.body,c.label,function()
                local tab=db.tabs[page.selected]
                return tab and (tab.all or (tab.cats and tab.cats[c.key])) and true or false
            end,function(v)
                local tab=db.tabs[page.selected] if not tab then return end
                if tab.all then
                    tab.all=nil tab.cats={}
                    for _,cc in ipairs(ns.CHAT_CATEGORIES)do tab.cats[cc.key]=true end
                end
                tab.cats=tab.cats or {} tab.cats[c.key]=v or nil
                page:Render() if ns.Chat.smf then
                    ns.Chat:Rerender()
                    if c.key=="crafting" and ns.Chat.combatShown and type(Blizzard_CombatLog_Refilter)=="function"then
                        pcall(Blizzard_CombatLog_Refilter)
                    end
                end
            end,DW-34)
            tg:SetPoint("TOPLEFT",12,-6-(#group.toggles)*36)
            group.toggles[#group.toggles+1]=tg group.keys[#group.keys+1]=key
            page.catToggles[#page.catToggles+1]=tg
        end
    end
    local joined=Group(LT["Joined channels"])
    page.joinedGroup=joined
    function page:RefreshJoined()
        -- General, Trade, LocalDefense and the like already have their own switch above;
        -- this list is for the other channels you have joined.
        local channels={}
        for _,entry in ipairs(ns.Chat:JoinedChannels())do
            if ns.ChannelCategory(entry.key)=="channel" then channels[#channels+1]=entry end
        end
        joined.keys={}
        for i,entry in ipairs(channels)do
            local tg=joined.toggles[i]
            if not tg then
                tg=Toggle(joined.body,"",function()
                    local tab=db.tabs[page.selected]
                    local key=joined.keys[i]
                    if not tab or not key then return false end
                    if tab.all or (tab.channels and tab.channels[key]) then return true end
                    return tab.cats and tab.cats[ns.ChannelCategory(key)] and true or false
                end,function(v)
                    local tab=db.tabs[page.selected] local key=joined.keys[i]
                    if not tab or not key then return end
                    if tab.all then
                        tab.all=nil tab.cats={}
                        for _,cc in ipairs(ns.CHAT_CATEGORIES)do tab.cats[cc.key]=true end
                    end
                    tab.channels=tab.channels or {}
                    local cat=ns.ChannelCategory(key)
                    if v then
                        tab.channels[key]=true
                    else
                        tab.channels[key]=nil
                        -- A shared category (General, Trade, other channels) was what showed it.
                        if tab.cats and tab.cats[cat] then
                            tab.cats[cat]=nil
                            if cat=="channel" then
                                for _,other in ipairs(ns.Chat:JoinedChannels())do
                                    if other.key~=key and ns.ChannelCategory(other.key)=="channel" then tab.channels[other.key]=true end
                                end
                            end
                        end
                    end
                    page:Render() if ns.Chat.smf then ns.Chat:Rerender()end
                end,DW-34)
                joined.toggles[i]=tg
            end
            joined.keys[i]=entry.key tg.text:SetText(entry.name)
            tg:SetPoint("TOPLEFT",12,-6-(i-1)*36) tg:Show() tg:Refresh()
        end
        for i=#channels+1,#joined.toggles do joined.toggles[i]:Hide()end
        joined.visibleCount=#channels
    end
    local keywords=Group(LT["Hide keywords"])
    page.keywordGroup=keywords
    local keywordLabel=SettingsText(keywords.body,12,T.TEXT,"")
    keywordLabel:SetPoint("TOPLEFT",12,-8)keywordLabel:SetText(LT["Hide words or phrases"])
    local keywordInput=SettingsEditBox(keywords.body,LT["summon, summons, summoning"])
    keywordInput:SetPoint("TOPLEFT",12,-28)keywordInput:SetSize(DW-110,32)
    keywordInput.edit:SetMaxLetters(1024)
    page.keywordInput=keywordInput
    local function SaveKeywords()
        local tab=page.keywordOwner
        if not tab then return end
        local value=strtrim(keywordInput.edit:GetText() or "")
        value=value~="" and value or nil
        if tab.hideKeywords==value then return end
        tab.hideKeywords=value
        if ns.Chat.smf then ns.Chat:Rerender() end
        if page.LayoutGroups then page:LayoutGroups()end
    end
    keywordInput.edit:SetScript("OnEnterPressed",function(e)SaveKeywords()e:ClearFocus()end)
    keywordInput.edit:SetScript("OnEditFocusLost",SaveKeywords)
    local applyKeywords=SettingsButton(keywords.body,LT["Apply"],70,32)
    applyKeywords:SetPoint("LEFT",keywordInput,"RIGHT",6,0)
    applyKeywords:SetScript("OnClick",function()SaveKeywords()keywordInput.edit:ClearFocus()end)
    page.keywordApply=applyKeywords
    local keywordHint=SettingsText(keywords.body,11,T.SECTION,"")
    keywordHint:SetPoint("TOPLEFT",12,-68)keywordHint:SetWidth(DW-34)keywordHint:SetJustifyH("LEFT")
    keywordHint:SetText(LT["Comma-separated; hide any match, ignoring case. Leave blank to disable. Applies only to this tab."])

    local appearance=Group(LT["Tab appearance"])
    page.appearanceGroup=appearance
    local y=0

    -- This tab's own look (unset = the chat box's settings).

    local lookHead = appearance.header

    lookHead:SetPoint("TOPLEFT", 0, -(y + 4))

    y = y + 24

    local function Restyle() if ns.Chat.smf and ns.Chat.active == page.selected then ns.Chat:ApplyTabStyle() end end

    page.tabSize = Slider(appearance.body, LT["Text size"], 9, 20, 1, function()

        local tab = db.tabs[page.selected]

        return (tab and tab.fontSize) or db.fontSize

    end, function(v)

        local tab = db.tabs[page.selected]

        if tab then tab.fontSize = v Restyle() end

    end, function(v)

        local tab = db.tabs[page.selected]

        return (tab and tab.fontSize) and tostring(v) or LT["%d  (chat)"]:format(v)

    end, DW - 10, LT["Font size for this tab. Unset follows the chat box."])

    page.tabSize:SetPoint("TOPLEFT", 0, -y)

    y = y + 44

    page.tabAlpha = Slider(appearance.body, LT["Background"], 0, 1, 0.05, function()

        local tab = db.tabs[page.selected]

        return (tab and tab.bgAlpha) or db.bgAlpha

    end, function(v)

        local tab = db.tabs[page.selected]

        if tab then tab.bgAlpha = v Restyle() end

    end, function(v)

        local tab = db.tabs[page.selected]

        local pct = math.floor(v * 100 + 0.5) .. "%"

        return (tab and tab.bgAlpha) and pct or LT["%s  (chat)"]:format(pct)

    end, DW - 10, LT["Background opacity for this tab. Unset follows the chat box."])

    page.tabAlpha:SetPoint("TOPLEFT", 0, -y)

    y = y + 44

    local resetLook = SettingsButton(appearance.body, LT["Use the chat's settings"], 170, 24)

    resetLook:SetPoint("TOPLEFT", 0, -y)

    resetLook:SetScript("OnClick", function()

        local tab = db.tabs[page.selected]

        if not tab then return end

        tab.fontSize, tab.bgAlpha = nil, nil

        Restyle()

        page:Render()

    end)

    y = y + 34

    page.tabSize:SetWidth(DW-34) page.tabAlpha:SetWidth(DW-34)
    page.tabSize:ClearAllPoints() page.tabSize:SetPoint("TOPLEFT",12,-6)
    page.tabAlpha:ClearAllPoints() page.tabAlpha:SetPoint("TOPLEFT",12,-46)
    resetLook:ClearAllPoints() resetLook:SetPoint("TOPLEFT",12,-92)
    function page:LayoutGroups()
        local tab=db.tabs[self.selected]
        local top=0
        for _,group in ipairs(self.filterGroups)do
            local open=self.openGroup==group.title
            group.header:ClearAllPoints() group.header:SetPoint("TOPLEFT",0,-top)
            group.body:ClearAllPoints() group.body:SetPoint("TOPLEFT",0,-top-30)
            group.body:SetShown(open)
            local count=0
            for _,key in ipairs(group.keys)do
                if tab.all or (group==joined and ((tab.channels and tab.channels[key]) or (tab.cats and tab.cats[ns.ChannelCategory(key)]))) or
                    (group~=joined and tab.cats and tab.cats[key])then count=count+1 end
            end
            group.header.count:SetText(group==appearance and "" or (group==keywords and (tab.hideKeywords and LT["On"] or LT["Off"]) or (count.." / "..#group.keys)))
            group.header.marker:SetText(open and "-" or "+")
            local bg=T.INPUT_BG
            T.Color(group.header.bg,bg[1],bg[2],bg[3],1)
            T.SetBorderColor(group.header.border,open and T.ACCENT or T.INPUT_BORDER,open and .55 or nil)
            group.header.label:SetTextColor(T.TEXT[1],T.TEXT[2],T.TEXT[3])
            local height=group==appearance and 128 or (group==keywords and 112 or ((group.visibleCount or #group.toggles)*36+12))
            group.body:SetHeight(height)
            top=top+30+(open and height or 0)+6
        end
        child:SetHeight(top)
        local max=math.max(0,top-(scroll:GetHeight() or 0))
        scroll:SetVerticalScroll(math.min(scroll:GetVerticalScroll(),max))
    end





    -- Thin scroll indicator on the right edge.

    local track = detail:CreateTexture(nil, "ARTWORK")

    track:SetColorTexture(0.14, 0.14, 0.18, 0.9)

    track:SetWidth(3)

    track:SetPoint("TOPRIGHT", scroll, "TOPRIGHT", 10, 0)

    track:SetPoint("BOTTOMRIGHT", scroll, "BOTTOMRIGHT", 10, 0)

    local thumb = T.AccentTexture(detail:CreateTexture(nil, "OVERLAY"))

    thumb:SetWidth(3)

    local function UpdateThumb()

        local viewH = scroll:GetHeight() or 0

        local total = child:GetHeight() or 0

        local max = math.max(0, total - viewH)

        track:SetShown(max > 0)

        thumb:SetShown(max > 0)

        if max <= 0 or viewH <= 0 then return end

        local th = math.max(20, viewH * viewH / total)

        local pos = (scroll:GetVerticalScroll() / max) * (viewH - th)

        thumb:SetHeight(th)

        thumb:ClearAllPoints()

        thumb:SetPoint("TOPRIGHT", scroll, "TOPRIGHT", 10, -pos)

    end

    scroll:EnableMouseWheel(true)

    scroll:SetScript("OnMouseWheel", function(sf, delta)

        local max = math.max(0, (child:GetHeight() or 0) - (sf:GetHeight() or 0))

        sf:SetVerticalScroll(math.max(0, math.min(max, sf:GetVerticalScroll() - delta * 48)))

        UpdateThumb()

    end)

    scroll:SetScript("OnSizeChanged", UpdateThumb)

    page.UpdateThumb = UpdateThumb



    function page:Render()

        if not db.tabs[self.selected] then self.selected = 1 end

        local tab = db.tabs[self.selected]

        if self.keywordOwner~=tab then
            self.keywordInput.edit:ClearFocus()
            self.keywordOwner=tab
            self.keywordInput.edit:SetText(tab.hideKeywords or "")
        elseif not self.keywordInput.edit:HasFocus()then
            self.keywordInput.edit:SetText(tab.hideKeywords or "")
        end

        for i, t in ipairs(db.tabs) do

            local b = self.listButtons[i]

            if not b then

                b = CreateFrame("Button", nil, self.list)

                b:SetSize(LIST_W, 40)

                b.bg = T.ShapeFill(b,T.INPUT_BG,9)
                b.border=T.Border(b,T.INPUT_BORDER,1,9)
                b.icon=CreateFrame("Frame",nil,b) b.icon:SetSize(18,18) b.icon:SetPoint("LEFT",10,0)
                b.icon:EnableMouse(false)

                b.bg:SetAllPoints()

                b.bar = T.AccentTexture(b:CreateTexture(nil, "ARTWORK"))

                b.bar:SetPoint("TOPLEFT")

                b.bar:SetPoint("BOTTOMLEFT")

                b.bar:SetWidth(2)

                b.text = SettingsText(b, 12)

                b.text:SetPoint("LEFT", 36, 0)

                b.text:SetPoint("RIGHT", -8, 0)

                b.text:SetJustifyH("LEFT")

                b.text:SetWordWrap(false)

                local hl = b:CreateTexture(nil, "HIGHLIGHT")

                hl:SetAllPoints()

                T.Shape(hl,10) T.Color(hl,1,1,1,0.05)

                b:SetScript("OnClick", function(btn) self.selected = btn.index self:Render() end)

                self.listButtons[i] = b

            end

            b.index = i

            b:ClearAllPoints()

            b:SetPoint("TOPLEFT", 0, -(i - 1) * 44)

            local sel = i == self.selected

            local bg=sel and T.ACCENT or T.INPUT_BG
            T.Color(b.bg,bg[1],bg[2],bg[3],1)
            T.SetBorderColor(b.border,sel and T.ACCENT or T.INPUT_BORDER)
            local cats=t.cats or {}
            local icon=t.all and T.Icons.Reply or ns.IsCombatTab(t) and T.Icons.Shield
                or (cats.guild or cats.party or cats.raid) and T.Icons.Person
                or (cats.loot or cats.crafting) and T.Icons.Tabs
                or (cats.trade or cats.channel) and T.Icons.Bell or T.Icons.Reply
            b.iconVariants=b.iconVariants or {}
            if not b.iconVariants[icon] then
                local glyph=CreateFrame("Frame",nil,b.icon)
                glyph:SetAllPoints() glyph:EnableMouse(false)
                T.DrawIcon(glyph,icon) b.iconVariants[icon]=glyph
            end
            for key,glyph in pairs(b.iconVariants)do glyph:SetShown(key==icon)end
            local light=T.ACCENT[1]*.299+T.ACCENT[2]*.587+T.ACCENT[3]*.114>.55
            local color=sel and (light and T.DARK_TEXT or T.TEXT) or T.LABEL
            b.iconVariants[icon]:SetIconColor(color)

            b.bar:Hide()

            b.text:SetText(t.name)

            b.text:SetTextColor(color[1],color[2],color[3])

            b:Show()

        end

        for i = #db.tabs + 1, #self.listButtons do self.listButtons[i]:Hide() end

        self:RefreshJoined()
        list:SetHeight(#db.tabs*44)
        local maxScroll=math.max(0,list:GetHeight()-viewport:GetHeight())
        local offset=viewport:GetVerticalScroll()
        if self.lastSelectedTab~=tab then
            local top=(self.selected-1)*44
            offset=math.min(offset,top)
            if top+40>offset+viewport:GetHeight() then offset=top+40-viewport:GetHeight() end
            local best,bestCount=nil,0
            if not tab.all then
                for _,group in ipairs(self.filterGroups)do
                    local count=0
                    for _,key in ipairs(group.keys)do
                        if (tab.cats and tab.cats[key]) or (tab.channels and tab.channels[key])then count=count+1 end
                    end
                    if count>bestCount then best,bestCount=group.title,count end
                end
            end
            self.openGroup=best self.lastSelectedTab=tab
            scroll:SetVerticalScroll(0)
        end
        viewport:SetVerticalScroll(math.max(0,math.min(maxScroll,offset)))
        if not self.name.edit:HasFocus() then self.name.edit:SetText(tab.name) end

        local enabled,channels=0,0
        for _,on in pairs(tab.cats or {})do if on then enabled=enabled+1 end end
        for _,on in pairs(tab.channels or {})do if on then channels=channels+1 end end
        local summary=tab.all and LT["All messages"] or LT["%d message types · %d channels"]:format(enabled,channels)
        if not tab.all and enabled>1 and channels==0 then
            for _,definition in ipairs(CATEGORY_GROUPS)do
                local count=0
                for _,key in ipairs(definition[2])do if tab.cats and tab.cats[key]then count=count+1 end end
                if count==enabled then summary=LT["%s · %d message types"]:format(definition[1],enabled)break end
            end
        end
        if enabled==1 and channels==0 then
            for _,c in ipairs(ns.CHAT_CATEGORIES)do if tab.cats[c.key]then summary=LT["%s · 1 message type"]:format(c.label)break end end
        end
        if ns.IsCombatTab(tab)then summary=LT["The game's combat log"]end
        self.summary:SetText(summary)
        self:LayoutGroups()

        self.allToggle:Refresh()

        for _, tg in ipairs(self.catToggles) do tg:Refresh() end

        self.tabSize:Refresh()

        self.tabAlpha:Refresh()

        self.del:SetEnabled(#db.tabs > 1)
        do
            local tab = db.tabs[self.selected]
            self.recommended:SetShown(tab and true or false)
        end

        self.del:SetAlpha(#db.tabs > 1 and 1 or 0.4)

        self.moveL:SetAlpha(self.selected > 1 and 1 or 0.4)

        self.moveR:SetAlpha(self.selected < #db.tabs and 1 or 0.4)

        self.UpdateThumb()

    end

    -- Window resize: every width in the detail pane derives from DW.
    page.fitExtra = function()
        DW = K.CONTENT_W - DETAIL_X
        name:SetWidth(DW - 104)
        page.summary:SetWidth(DW)
        page.allToggle:SetWidth(DW)
        child:SetWidth(DW - 10)
        for _, group in ipairs(page.filterGroups) do
            group.header:SetWidth(DW - 10)
            group.body:SetWidth(DW - 10)
            for _, tg in ipairs(group.toggles) do tg:SetWidth(DW - 34) end
        end
        keywordInput:SetWidth(DW - 110)
        keywordHint:SetWidth(DW - 34)
        page.tabSize:SetWidth(DW - 34)
        page.tabAlpha:SetWidth(DW - 34)
    end

    page.widgets = {}

end
