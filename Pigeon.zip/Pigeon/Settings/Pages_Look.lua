--[[
    Pigeon - Settings: the Look page. Split from Settings.lua.
]]

local _, ns = ...
local T = ns.Theme
local LT = ns.L
local K = ns.SettingsKit
local builders = K.builders
local Choice, Dropdown, Heading, Note, S, Scroller, SetEnabled, SettingsButton, SettingsText, Slider, Stack, Swatch, Toggle = K.Choice, K.Dropdown, K.Heading, K.Note, K.S, K.Scroller, K.SetEnabled, K.SettingsButton, K.SettingsText, K.Slider, K.Stack, K.Swatch, K.Toggle

function builders.look(page)

    local L = ns.db.look

    local W = 440

    local content, done = Scroller(page)

    local st = Stack(content, 0, 0)

    local preview

    -- Controls greyed out while the setting they depend on is off.
    local deps = {}

    local function RefreshDeps()
        for _, d in ipairs(deps) do SetEnabled(d.widget, d.cond(), d.reason) end
    end

    -- Registers a dependent widget; it also re-evaluates on its own Refresh.
    local function DependsOn(widget, cond, reason)
        deps[#deps + 1] = { widget = widget, cond = cond, reason = reason }
        local refresh = widget.Refresh
        widget.Refresh = function(self, ...)
            if refresh then refresh(self, ...) end
            SetEnabled(self, cond(), reason)
        end
        SetEnabled(widget, cond(), reason)
        return widget
    end

    local function Apply()

        ns.ApplyLook()

        if S.RefreshChrome then S:RefreshChrome() end

        if preview then preview:Update() end

        RefreshDeps()

    end

    local function Pct(v) return math.floor(v * 100 + 0.5) .. "%" end

    local function Times(v) return ("%.2fx"):format(v) end



    -- Theme presets: one click sets a whole look.

    local PRESETS = {

        { "island", "Island", { 0, 0, 0 }, { panelStyle = "flat", whisperStyle = "signal", tileStyle = "symbol", msgOutline = false } },

        { "softsignal", LT["Soft Signal"], { 0.043, 0.047, 0.063 }, { panelStyle = "flat", whisperStyle = "signal", tileStyle = "symbol", msgOutline = false } },

        { "horizon", LT["Legacy"], { 0.08, 0.08, 0.12 }, { panelStyle = "flat" } }, -- key kept for saved settings

        { "classic", LT["Classic"], { 0.2, 0.14, 0.07 }, { panelStyle = "flat", panelAlpha = 0.93, backdrop = { 0.1, 0.07, 0.04, 1 },

            border = { 0.62, 0.5, 0.25, 0.85 }, accent = { 1, 0.82, 0.25, 1 } } },

        -- Island's Forever finish: dark bronze panels, bronze edges, small plaque corners.
        { "forever", LT["Forever"], { 44 / 255, 40 / 255, 37 / 255 }, { panelStyle = "flat", whisperStyle = "signal", tileStyle = "symbol", msgOutline = false, cornerRadius = 4, chatAlpha = 0.45 } },

    }

    st:Head(LT["Theme"])

    local presetRow = CreateFrame("Frame", nil, content)

    presetRow:SetSize(W, 82)

    presetRow.buttons = {}

    for i, pr in ipairs(PRESETS) do

        local b = CreateFrame("Button", nil, presetRow)

        b:SetSize(80, 82)

        b:SetPoint("TOPLEFT", (i - 1) * 88, 0)

        local thumb = CreateFrame("Frame", nil, b)

        thumb:SetSize(80, 60)

        thumb:SetPoint("TOP")

        thumb.bg = T.ShapeFill(thumb, { pr[3][1], pr[3][2], pr[3][3], 1 }, 6)

        thumb.border = T.Border(thumb, T.INPUT_BORDER, 1, 6)

        b.thumb = thumb
        local accent = pr[1] == "softsignal" and {0.616,0.733,1,1}
            or pr[1] == "classic" and {1,0.82,0.25,1}
            or pr[1] == "forever" and {208/255,173/255,125/255,1}
            or pr[1] == "horizon" and {0.48,0.58,0.82,1} or T.ACCENT
        for n=1,3 do
            local sample=CreateFrame("Frame",nil,thumb)
            sample:SetSize(20,16) sample:SetPoint("LEFT",8+(n-1)*22,0)
            sample.bg=T.ShapeFill(sample,n==1 and accent or {0.20,0.21,0.24,1},4)
            if n==1 then b.accentSample=sample.bg end
        end

        b.text = SettingsText(b, 12, T.SECTION)

        b.text:SetPoint("BOTTOM", 0, 0)

        b.text:SetText(pr[2])

        b:SetScript("OnClick", function()

            for _, k in ipairs({ "panelStyle", "glass", "panelAlpha", "backdrop", "border", "accent", "gameFrames" }) do L[k] = nil end

            if L.preset == "forever" and pr[1] ~= "forever" then L.cornerRadius, L.chatAlpha = nil, nil end -- Forever's plaque corners and see-through chat go with it

            for k, v in pairs(pr[4]) do L[k] = type(v) == "table" and { v[1], v[2], v[3], v[4] } or v end

            L.preset = pr[1]

            ns.db.classTint = false -- selecting a theme starts with that theme's colours

            ns.db.islandStyle = pr[1] == "island" or pr[1] == "horizon"

            Apply()

            for _, w in ipairs(page.widgets) do w:Refresh() end

        end)

        presetRow.buttons[i] = b

        b.key = pr[1]

    end

    function presetRow:Refresh()

        for _, b in ipairs(self.buttons) do

            local on = (L.preset or "horizon") == b.key
            if b.key=="island" then T.Color(b.accentSample,ns.Island.Color()) end

            T.SetBorderColor(b.thumb.border, on and T.ACCENT or T.INPUT_BORDER, on and 1 or nil)

            local c = on and T.TEXT or T.SECTION

            b.text:SetTextColor(c[1], c[2], c[3])

        end

    end

    st:Add(presetRow, 6)

    -- Only offered when the Island addon is installed and loaded.

    if ns.Island and ns.Island.Loaded() then

        st:Add(Toggle(content, LT["Match Island's look"], function() return ns.Island.Active() end,

            function(v) ns.db.islandStyle = v and true or false ns.db.classTint = false L.preset = v and "island" or "softsignal" L.accent = nil L.backdrop = nil L.border = nil L.classColors = nil L.panelAlpha = nil Apply() presetRow:Refresh() end, W,
                LT["Applies the Island preset and turns off the class colour tint."]))

    end

    local reset = SettingsButton(content, LT["Reset look to defaults"], 180, 26)

    reset:SetScript("OnClick", function()

        for k in pairs(L) do L[k] = nil end

        L.tileAlpha, L.wash, L.railWidth, L.msgSize, L.msgOutline = 1, 1, 2, 14, false
        L.idleTileAlpha = 1

        L.preset, L.whisperStyle, L.tileStyle = "island", "signal", "symbol"

        ns.db.islandStyle = true

        ns.db.classTint = false

        L.windowScale, L.hubScale, L.dockScale, L.uiTextScale = 1, 1, 1, 1
        ns.db.windowSize = nil

        L.panelStyle, L.glass = "flat", 0.5

        Apply()

        for _, w in ipairs(page.widgets) do w:Refresh() end

    end)

    st:Add(reset, 14)



    -- Live preview: a tiny whisper log that follows every change on this page.

    st:Head(LT["Preview"])

    st:Add(Choice(content, LT["Whisper style"], {

        { "signal", LT["Soft Signal"] }, { "rails", LT["Accent rails"] }, { "bubbles", LT["Bubbles"] }, { "threads", LT["Threads"] },

        { "classic", LT["Classic"] }, { "minimal", LT["Minimal"] },

    }, function() return ns.WhisperStyle() end, function(v) L.whisperStyle = v Apply() end, W,
        LT["How whisper messages are laid out. Accent rails enables Message rail width."]))

    local fake = {

        kind = "wow", display = "Taingo Down", class = "HUNTER", messages = {

            { t = time() - 60, text = "is your pet from the new dungeon?" },

            { t = time() - 30, out = true, text = "nah it's from ashenvale" },

            { t = time() - 20, out = true, text = "want the route?" },

        },

    }

    preview = CreateFrame("Frame", nil, content)

    preview:SetSize(W, 200)

    T.Panel(preview)

    local plog = ns.NewBubbleLog(preview, { widthFrac = 0.8, fontSize = 13 })

    plog:SetPoint("TOPLEFT", 10, -6)

    plog:SetPoint("BOTTOMRIGHT", -10, 4)

    plog.fallbackW, plog.fallbackH = W - 20, 190

    function preview:Update()

        plog:Reset(fake)

        plog:Render(fake)

    end

    preview:SetParent(page)

    local mat = CreateFrame("Frame", nil, page)

    mat:SetPoint("TOPLEFT", 0, 0)

    mat:SetSize(K.CONTENT_W - 20, 224)

    mat.bg = T.ShapeFill(mat, { 0.14, 0.14, 0.16, 1 }, 16)

    preview:SetParent(mat)

    preview:ClearAllPoints()

    preview:SetPoint("TOPLEFT", mat, "TOPLEFT", 12, -12)

    preview:SetWidth(K.CONTENT_W - 52)

    page.previewDock = mat

    preview:Update()

    -- Window resize: the preview mat and its log follow the page width.
    page.fitExtra = function()
        mat:SetWidth(K.CONTENT_W - 20)
        preview:SetWidth(K.CONTENT_W - 52)
        preview:Update()
    end



    -- Small "Class" pill inside a colour chip: tint that colour with your class colour.
    local function AddClassPill(chip, label, isOn, setOn)
        local btn = CreateFrame("Button", nil, chip)
        btn:SetSize(38, 18)
        btn:SetPoint("RIGHT", chip, "RIGHT", -82, 0)
        btn.bg = T.Pill(btn, 20, { 1, 1, 1, 1 }, "ARTWORK")
        btn.bg:SetAllPoints()
        btn.label = SettingsText(btn.bg, 9, T.TEXT)   -- on the pill frame itself, or it is drawn underneath it
        btn.label:SetPoint("CENTER")
        btn.label:SetText(LT["Class"])
        local function Paint()
            if isOn() then
                T.Color(btn.bg, T.ACCENT[1], T.ACCENT[2], T.ACCENT[3], 1)
                btn.label:SetTextColor(0.04, 0.04, 0.07, 1)   -- dark text: white is unreadable on the light accent
            else
                T.Color(btn.bg, 1, 1, 1, 0.10)
                btn.label:SetTextColor(T.TEXT[1], T.TEXT[2], T.TEXT[3], T.TEXT[4] or 1)
            end
        end
        btn:SetScript("OnClick", function() setOn(not isOn()) Paint() chip:Refresh() end)
        btn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(LT["%s: use class colour"]:format(label))
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        chip.classOn = isOn
        local base = chip.Refresh
        function chip:Refresh() base(self) Paint() end
        chip:Refresh()
        Paint()
    end

    local function ColorChip(label, key, token, hasAlpha, withClass)
        local chip = Swatch(content, label, function() return L[key] end, function(c)
            L[key] = c
            if L.classColors then L.classColors[key] = nil end
            if L.preset ~= "softsignal" and L.preset ~= "island" and L.preset ~= "forever" then L.preset = nil end
            Apply()
            presetRow:Refresh()
        end, function() return T[token] end, hasAlpha, (W - 12) / 2)
        if withClass then
            AddClassPill(chip, label, function() return L.classColors and L.classColors[key] and true or false end,
                function(v)
                    L.classColors = L.classColors or {}
                    L.classColors[key] = v or nil
                    if L.preset ~= "softsignal" and L.preset ~= "island" and L.preset ~= "forever" then L.preset = nil end
                    Apply()
                    presetRow:Refresh()
                end)
        end
        return chip
    end

    local function ChipRow(a, b)

        local row = CreateFrame("Frame", nil, content)

        row:SetSize(W, 36)

        a:SetParent(row) a:ClearAllPoints() a:SetPoint("LEFT", row, "LEFT", 0, 0)

        if b then b:SetParent(row) b:ClearAllPoints() b:SetPoint("RIGHT", row, "RIGHT", 0, 0) end

        -- Two chips share the row; each is half the width minus a 12px gap.
        row.settingsStretch = true
        row.settingsRowLayout = function(rw)
            a:SetWidth((rw - 12) / 2)
            if b then b:SetWidth((rw - 12) / 2) end
        end

        st:Add(row, 6)

        if page.entries then

            page.entries[#page.entries + 1] = { label = a.text:GetText(), widget = a, section = st.section }

            if b then page.entries[#page.entries + 1] = { label = b.text:GetText(), widget = b, section = st.section } end

        end

        st.widgets[#st.widgets + 1] = a

        st.labels[#st.labels + 1] = a.text:GetText()

        if b then

            st.widgets[#st.widgets + 1] = b

            st.labels[#st.labels + 1] = b.text:GetText()

        end

    end



    st:Head(LT["Colours"])
    st:Add(Choice(content, LT["Accent source"], { { "theme", LT["Theme colors"] }, { "class", LT["My class color"] } },
        function() return ns.db.classTint and "class" or "theme" end,
        function(v) ns.db.classTint = v == "class" L.accent = nil Apply() end, W,
        LT["Use the theme colour or your class colour. Picking class colour clears the custom accent."]))
    ChipRow(ColorChip(LT["Accent"], "accent", "ACCENT"))
    local note = SettingsText(content, 10, T.SECTION)

    note:SetWidth(W)

    note:SetJustifyH("LEFT")

    note:SetText(LT["Theme colors follow the selected theme. Choose My class color to use your class as the accent. A custom Accent swatch overrides either choice."])

    st:Add(note, 10)

    st:Head(LT["Chat window"])
    ChipRow(ColorChip(LT["Background"], "backdrop", "BACKDROP", false, true), ColorChip(LT["Border"], "border", "BORDER", true, true))
    st:Add(Toggle(content, LT["Show chat border"], function() return not L.chatBorderOff end,
        function(v) L.chatBorderOff = (not v) or nil Apply() end, W,
        LT["Draws an outline around the chat box. Turn it off for a borderless look."]))
    st:Add(DependsOn(Slider(content, LT["Chat border thickness"], 1, 6, 1,
        function() return L.chatBorderSize or 1 end,
        function(v) L.chatBorderSize = (v ~= 1) and v or nil Apply() end, nil, W,
        LT["How thick the chat box border is, in pixels. Needs Show chat border."]),
        function() return not L.chatBorderOff end, LT["Turn on Show chat border."]))
    st:Add(Slider(content, LT["Chat background opacity"], 0, 1, 0.05,
        function() return ns.ChatOpacity() end,
        function(v) ns.SetChatOpacity(v) if preview then preview:Update()end end, Pct, W))
    st:Add(Slider(content, LT["Whisper background opacity"], 0, 1, 0.05,
        function() return ns.WhisperOpacity() end,
        function(v) ns.SetWhisperOpacity(v) if preview then preview:Update()end end, Pct, W))

    st:Head(LT["Transparency"])

    st:Add(Slider(content, LT["Dock tiles"], 0.3, 1, 0.05, function() return L.tileAlpha end,

        function(v) L.tileAlpha = v Apply() end, Pct, W,
        LT["How see-through the whisper dock tiles are. Lower values let the game world show through."]))

    st:Add(Slider(content, LT["Read dock tiles"], 0.1, 1, 0.05, function() return L.idleTileAlpha or 1 end,

        function(v) L.idleTileAlpha = v Apply() end, Pct, W,
        LT["How faded a dock tile becomes once you have read it. It returns to full opacity when a new whisper arrives or the mouse is over it. 100% turns this off."]))

    st:Head(LT["Text colours"])
    ChipRow(ColorChip(LT["Their text"], "theirText", "WHISPER", false, true), ColorChip(LT["Your text"], "yourText", "YOURS", false, true))
    ChipRow(ColorChip(LT["Battle.net"], "bnetText", "BNET", false, true))

    -- This settings window only; empty table = the theme's own look.
    st:Head(LT["Settings window"])
    local function SP() L.settingsPanel = L.settingsPanel or {} return L.settingsPanel end
    local function SPApply() Apply() end
    local function SPChip(label, key, token, hasAlpha, withClass)
        local chip = Swatch(content, label, function() return L.settingsPanel and L.settingsPanel[key] end, function(c)
            SP()[key] = c
            SPApply()
        end, function() return T[token] end, hasAlpha, (W - 12) / 2)
        if withClass then
            AddClassPill(chip, label, function() return L.settingsPanel and L.settingsPanel.borderClass and true or false end,
                function(v) SP().borderClass = v or nil SPApply() end)
        end
        return chip
    end
    ChipRow(SPChip(LT["Background"], "bg", "BACKDROP"), SPChip(LT["Border"], "border", "BORDER", true, true))
    st:Add(Slider(content, LT["Window background opacity"], 0, 1, 0.05,
        function() return (L.settingsPanel and L.settingsPanel.bgAlpha) or T.BACKDROP[4] or 1 end,
        function(v) SP().bgAlpha = v SPApply() end, Pct, W))
    st:Add(Toggle(content, LT["Show window border"], function() return not (L.settingsPanel and L.settingsPanel.borderOff) end,
        function(v) SP().borderOff = (not v) or nil SPApply() end, W))
    st:Add(DependsOn(Slider(content, LT["Window border thickness"], 1, 6, 1,
        function() return (L.settingsPanel and L.settingsPanel.borderSize) or 1 end,
        function(v) SP().borderSize = v SPApply() end, nil, W),
        function() return not (L.settingsPanel and L.settingsPanel.borderOff) end, LT["Turn on Show window border."]))
    local resetWin = SettingsButton(content, LT["Reset window colours"], 170, 26)
    resetWin:SetScript("OnClick", function()
        L.settingsPanel = nil
        SPApply()
        for _, w in ipairs(page.widgets) do w:Refresh() end
    end)
    st:Add(resetWin, 10)


    st:Head(LT["Panels"])

    st:Add(Toggle(content, LT["Use the game's own window frames"], function() return L.gameFrames == true end,

        function(v) L.gameFrames = v or nil if L.preset ~= "softsignal" and L.preset ~= "island" and L.preset ~= "forever" then L.preset = nil end Apply() presetRow:Refresh() end, W,
        LT["Uses the game's own frame art for Pigeon windows."]))

    st:Head(LT["Tiles"])

    -- Class icons on the tiles: the game's, or packs other addons share.

    st:Add(Choice(content, LT["Class tile design"], { { "symbol", LT["Class symbols"] }, { "artwork", LT["Class artwork"] } },

        function() return L.tileStyle or "symbol" end, function(v) L.tileStyle = v Apply() end, W,
        LT["Class symbols draws a simple class mark on each tile. Class artwork uses full class icons, chosen below."]))

    st:Add(DependsOn(Choice(content, LT["Tile class icons"], ns.ClassIconSources(),

        function() local v = L.classIcons or "parley" if v == "game" then v = "crest" end return v end,
        function(v) L.classIcons = v Apply() end, W,
        LT["Which icon pack supplies the class artwork. Only used when Class tile design is Class artwork."]),
        function() return L.tileStyle == "artwork" end, LT["Set Class tile design to Class artwork."]))

    st:Add(DependsOn(Toggle(content, LT["Dark class artwork"], function() return L.tileDark and true or false end,
        function(v) L.tileDark = v or nil Apply() end, W,
        LT["Draws Pigeon's class icons in the class colour on a dark tile, like Class symbols, instead of a bright coloured square. Only for the Pigeon icons pack."]),
        function() return L.tileStyle == "artwork" and (L.classIcons or "parley") == "parley" end,
        LT["Set Class tile design to Class artwork and Tile class icons to Pigeon icons."]))

    st:Head(LT["Panel shape"])

    st:Add(Choice(content, LT["Panel style"], { { "flat", LT["Flat"] }, { "glass", LT["Glass"] } },

        function() return L.panelStyle or "flat" end, function(v) L.panelStyle = v if L.preset ~= "softsignal" and L.preset ~= "island" and L.preset ~= "forever" then L.preset = nil end Apply() presetRow:Refresh() end, W))

    -- Live: T.ApplyCorners (run by every theme refresh) re-shapes all panels, buttons and tiles.
    local cornerPending
    st:Add(DependsOn(Slider(content, LT["Corner radius"], 0, 8, 1, function() return T.CornerRadius() end,
        function(v)
            L.cornerRadius = v
            if cornerPending then return end
            cornerPending = true -- coalesce a fast drag into one refresh per tick
            C_Timer.After(0.03, function() cornerPending = nil Apply() end)
        end, function(v) return v == 0 and LT["Square"] or tostring(v) end, W,
        LT["How round panel, button and tile corners are. 0 is square."]),
        function() return T.canRound ~= false end, LT["Your game client can't draw rounded corners."]))

    st:Add(DependsOn(Slider(content, LT["Glass shine"], 0, 1, 0.05, function() return L.glass or 0.5 end,

        function(v) L.glass = v Apply() end, Pct, W,
        LT["Strength of the glossy highlight. Only applies to the Glass panel style."]),
        function() return (L.panelStyle or "flat") == "glass" end, LT["Only used by the Glass panel style."]))



    st:Head(LT["Message details"])

    -- The wash is only drawn by three of the whisper styles; the others have no tint to change.
    local function WashStyle() local s = ns.WhisperStyle() return s == "rails" or s == "bubbles" or s == "threads" end
    local washReason = LT["Used by the Accent rails, Bubbles and Threads whisper styles."]

    st:Add(DependsOn(Slider(content, LT["Message colour wash"], 0, 2.5, 0.25, function() return L.wash end,

        function(v) L.wash = v Apply() end, Times, W,
        LT["How strong the tint behind messages is. 0 turns it off. Accent rails tint with the sender's colour; Bubbles and Threads tint incoming messages, and the Wash colour below changes it."]),
        WashStyle, washReason))

    st:Add(DependsOn(Swatch(content, LT["Wash colour"], function() return L.washColor end,
        function(c) L.washColor = c Apply() end, function() return T.TEXT end, false, W),
        WashStyle, washReason))

    st:Add(DependsOn(Slider(content, LT["Message rail width"], 1, 4, 1, function() return L.railWidth end,

        function(v) L.railWidth = v Apply() end, function(v) return LT["%dpx"]:format(v) end, W,
        LT["Width of the coloured bar beside each message. Only used by the Accent rails whisper style."]),
        function() return ns.WhisperStyle() == "rails" end, LT["Only used by the Rails whisper style."]))



    st:Head(LT["Text"])

    local function FontItems()

        local list = { { false, LT["Theme font"] } }

        local lsm = T.SharedMedia()

        if lsm then

            local names = lsm:List("font")

            for _, n in ipairs(names) do list[#list + 1] = { n, n } end

        end

        return list

    end

    local fontRow = st:Add(Dropdown(content, LT["Font"], FontItems, function() return L.font or false end,

        function(v) L.font = v or nil Apply() end, W,
        LT["The theme font, or a LibSharedMedia font if one is installed."]))

    if not T.SharedMedia() then

        fontRow:SetAlpha(0.5)

        local fn = SettingsText(content, 10, T.SECTION)

        fn:SetWidth(W)

        fn:SetJustifyH("LEFT")

        fn:SetText(LT["More fonts appear here when an addon with LibSharedMedia (ElvUI, EllesmereUI, ...) is loaded."])

        st:Add(fn, 10)

    end

    st:Add(Slider(content, LT["Whisper text size"], 10, 20, 1, function() return L.msgSize end,

        function(v) L.msgSize = v Apply() end, nil, W))

    st:Add(Choice(content, LT["Whisper text outline"], { { "off", LT["Off"] }, { "thin", LT["Thin"] }, { "thick", LT["Thick"] } },

        function() return (L.msgOutline == false and "off") or (L.msgOutlineThick and "thick" or "thin") end,

        function(v)
            L.msgOutline = v ~= "off"
            L.msgOutlineThick = v == "thick" or nil
            Apply()
        end, W,
        LT["An outline around whisper text. Thick is easier to read over busy backgrounds."]))

    st:Head(LT["Size"])

    st:Add(Slider(content, LT["Interface text"], 0.8, 1.5, 0.1, function() return L.uiTextScale or 1 end,
        function(v) L.uiTextScale = v Apply() end, Pct, W,
        LT["Makes the text in Pigeon's windows and settings larger or smaller. Chat message text has its own size under Look > Messages. Reopen a window if something looks cramped."]))

    st:Add(Slider(content, LT["Chat width"], 300, 1000, 10, function() return ns.db.chat.width end,
        function(v)
            ns.db.chat.width = v
            if ns.Chat.smf then ns.Chat:SetSize(v, ns.db.chat.height) end
        end, function(v) return tostring(math.floor(v)) end, W,
        LT["The chat box's width. You can also drag its corner."]))

    st:Add(Slider(content, LT["Chat height"], 140, 700, 10, function() return ns.db.chat.height end,
        function(v)
            ns.db.chat.height = v
            if ns.Chat.smf then ns.Chat:SetSize(ns.db.chat.width, v) end
        end, function(v) return tostring(math.floor(v)) end, W,
        LT["The chat box's height. You can also drag its corner."]))

    st:Add(Slider(content, LT["Distance from chat"], 0, 80, 2, function() return L.windowGap or 0 end,
        function(v) L.windowGap = v Apply() if ns.Window.Reanchor then ns.Window:Reanchor() end end, nil, W,
        LT["Space between the chat box and a whisper window that opens above it."]))

    local function ResizeWindow(w, h)
        ns.db.windowSize = { w, h }
        local win = ns.Window
        if win and win.log and win:IsShown() and (win.growV or 1) >= 1 then
            win:PlaceFinal()
            win:SyncContent()
            win.log:Render(win.convo)
        end
    end

    st:Add(Slider(content, LT["Whisper window width"], 340, 1000, 10, function() return (select(1, ns.Window:FullSize())) end,
        function(v) local _, h = ns.Window:FullSize() ResizeWindow(v, h) end,
        function(v) return tostring(math.floor(v)) end, W,
        LT["The width of the whisper window. You can also drag its edges."]))

    st:Add(Slider(content, LT["Whisper window height"], 250, 900, 10, function() return (select(2, ns.Window:FullSize())) end,
        function(v) local w = ns.Window:FullSize() ResizeWindow(w, v) end,
        function(v) return tostring(math.floor(v)) end, W,
        LT["The height of the whisper window. You can also drag its edges."]))

    st:Add(Slider(content, LT["Whisper hub"], 0.7, 1.5, 0.05, function() return L.hubScale end,

        function(v) L.hubScale = v Apply() end, Pct, W,
        LT["Scales the whisper hub list."]))

    st:Add(DependsOn(Slider(content, LT["Dock"], 0.7, 1.5, 0.05, function() return L.dockScale end,
        function(v) L.dockScale = v Apply() end, Pct, W,
        LT["Scales the dock tiles. Ignored while the stack button sits in the chat's tab bar."]),
        function() return not ns.Dock.attached end, LT["The stack button is in the chat's tab bar right now."]))




    done(st.y + 8)



    page.widgets = {}

    for _, w in ipairs(st.widgets) do page.widgets[#page.widgets + 1] = w end

    page.labels = st.labels

end
