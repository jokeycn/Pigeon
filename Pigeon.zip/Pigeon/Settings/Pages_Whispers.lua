--[[
    Pigeon - Settings: the Whispers page. Split from Settings.lua.
]]

local _, ns = ...
local T = ns.Theme
local LT = ns.L
local K = ns.SettingsKit
local builders = K.builders
local Choice, LayoutRow, S, Scroller, SetEnabled, SettingsButton, SettingsText, Slider, Stack, Toggle = K.Choice, K.LayoutRow, K.S, K.Scroller, K.SetEnabled, K.SettingsButton, K.SettingsText, K.Slider, K.Stack, K.Toggle

local SOUNDS = {

    { "chime", LT["Chime"] }, { "pop", LT["Soft pop"] }, { "tell", LT["Classic tell"] }, { "off", LT["Off"] },

}



function builders.whispers(page)

    local db = ns.db

    local W = 440 -- one comfortable column

    local outer = page

    local content, done = Scroller(outer)

    page = content

    local st = Stack(page, 0, 0)



    st:Head(LT["Notifications"])

    local sound = st:Add(Choice(page, LT["Whisper sound"], SOUNDS, function() return db.sound end,

        function(v) db.sound = v ns.PlayWhisperSound(true) end, W - 32))

    -- Small play icon right of the choice box.

    local play = CreateFrame("Button", nil, page)

    play:SetSize(24, 22)

    play:SetParent(sound)

    sound.settingsRowInset = 24 -- room for the play button; FitPage keeps it on resize

    LayoutRow(sound, K.CONTENT_W - 76)

    play:SetPoint("LEFT", sound, "RIGHT", 8, 0)

    T.Panel(play, T.INPUT_BG, T.INPUT_BORDER)

    play.icon = play:CreateTexture(nil, "ARTWORK")

    play.icon:SetSize(10, 12)

    play.icon:SetPoint("CENTER", 1, 0)

    play.icon:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")

    if not play.icon:GetTexture() then

        play.icon:Hide()

        local t = SettingsText(play, 11, T.ACCENT)

        t:SetPoint("CENTER")

        t:SetText(">")

    end

    play.icon:SetVertexColor(T.ACCENT[1], T.ACCENT[2], T.ACCENT[3])

    local hl = play:CreateTexture(nil, "HIGHLIGHT")

    hl:SetAllPoints()

    hl:SetColorTexture(1, 1, 1, 0.08)

    play:SetScript("OnClick", function() ns.PlayWhisperSound(true) end)

    play:SetScript("OnEnter", function(b)

        GameTooltip:SetOwner(b, "ANCHOR_TOP")

        GameTooltip:AddLine(LT["Preview sound"])

        GameTooltip:Show()

    end)

    play:SetScript("OnLeave", function() GameTooltip:Hide() end)



    if ns.ElvUI.PlaysWhisperSound() then

        local note = SettingsText(page, 11, { 1, 0.75, 0.35, 1 })

        note:SetWidth(W)

        note:SetJustifyH("LEFT")

        note:SetText(LT["ElvUI's chat already plays a whisper alert, so this one stays quiet. Set ElvUI > Chat > Alerts > Whisper to None to use it instead."])

        st:Add(note)

    end

    st:Add(Toggle(page, LT["Also play for Battle.net whispers"], function() return db.soundBNet end,

        function(v) db.soundBNet = v end, W))

    st:Add(Toggle(page, LT["Quiet in combat"], function() return db.soundCombat == false end,

        function(v) db.soundCombat = not v end, W))

    st:Add(Slider(page, LT["Preview toast shows for"], 2, 15, 1, function() return db.previewSeconds end,

        function(v) db.previewSeconds = v end, function(v) return LT["%ds"]:format(v) end, W,
        LT["How long the new whisper preview stays up."]))

    local test = SettingsButton(page, LT["Send test whispers"], 150, 26)

    test:SetScript("OnClick", function() ns.RunTest() end)

    st:Add(test)



    st:Head(LT["Dock"])

    st:Add(Slider(page, LT["Tiles shown"], 3, 10, 1, function() return db.maxTiles end,

        function(v) db.maxTiles = v ns.Refresh() end, nil, W,
        LT["The most dock tiles shown at once."]))

    st:Add(Toggle(page, LT["Stack button in the tab bar"], function() return ns.db.chat.attachDock end,

        function(v) ns.db.chat.attachDock = v S:NeedReload() end, W,
        LT["Puts the whisper stack button in the chat's tab bar. Needs a reload."]))

    local horizontal = st:Add(Toggle(page, LT["Horizontal dock"], function() return ns.db.dockHorizontal and true or false end,
        function(v) ns.db.dockHorizontal = v or nil ns.Dock:Update() end, W,
        LT["Lines the whisper tiles up sideways instead of up and down. Only for a dock that is not in the tab bar. Tiles open toward whichever side of the screen has room."]))
    -- The stack button in the tab bar always opens its tiles upward, so this has no effect there.
    SetEnabled(horizontal, not ns.db.chat.attachDock, LT["Turn off Stack button in the tab bar to place the dock yourself."])

    st:Add(Toggle(page, LT["Use envelope instead of bird"], function() return db.chat.envelopeIcon and true or false end,
        function(v) db.chat.envelopeIcon=v or nil ns.Dock:PaintStackIcon() end, W,
        LT["Shows an envelope instead of the bird on the stack button."]))



    outer.widgets = {}

    for _, w in ipairs(st.widgets) do outer.widgets[#outer.widgets + 1] = w end

    outer.labels = st.labels

    done(st.y + 8)

end
